# IMO

The **International Maritime Organization** sets the rules. See [[SOLAS]] and [[MARPOL]].
