---
tags: [convention, safety]
---
# SOLAS

- Chapter II-1 construction
- Chapter III life-saving
    - Lifeboat drills monthly
- Chapter V navigation
