The ISM Code requires a *Safety Management System*.
