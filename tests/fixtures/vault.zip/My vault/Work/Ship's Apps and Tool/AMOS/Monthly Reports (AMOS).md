1. Monthly Reports [[AMOS]] *(left AMOS Toolbar)*
2. **Monthly Reports (Work Order)**
3. **Ok**
4. Select **GOF-06.4 Water Testing Record**
5. Work Flow
6. Started
7. Ok
8. Close
9. Actions
10. Attach File
