AMOS is the planned maintenance system.

- [ ] Weekly update
- [x] Monthly report
