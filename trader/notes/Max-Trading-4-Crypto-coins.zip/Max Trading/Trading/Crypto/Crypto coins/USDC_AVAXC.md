---
tags: [trading, crypto, usdc_avaxc]
---
**USDC_AVAXC**
- Data: 2021-11-25 → 2026-05-23 (1,641 days)
- Last $0.9997 (2026-05-23) · all-time high $1.01 (2023-05-08) · now -0.9% from high · lowest $0.9706 (2023-03-11)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.9998 start · H 1.00 L 0.9997 · cap $48.6M (#106)
- 2022: $0.9999 +0.0% · H 1.00 L 0.9987 · cap $645.1M (#45)
- 2023: $0.9999 +0.0% · H 1.01 L 0.9706 · cap $242.4M (#77)
- 2024: $0.9998 -0.0% · H 1.00 L 0.9996 · cap $409.1M (#63)
- 2025: $0.9996 -0.0% · H 1.00 L 0.9990 · cap $605.9M (#45)
- 2026: $0.9997 +0.0% · H 1.00 L 0.9995 · cap $432.6M (#47)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
