---
tags: [trading, crypto, dash]
---
**DASH**
- Data: 2014-02-08 → 2026-11-08 (4,657 days)
- Last $47.13 (2026-11-08) · all-time high $1,447 (2017-12-20) · now -96.7% from high · lowest $0.1194 (2014-02-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $2.00 start · H 14.75 L 0.1194 · cap $10.0M (#6)
- 2015: $3.32 +66.4% · H 5.27 L 1.08 · cap $20.3M (#6)
- 2016: $11.41 +243.6% · H 14.38 L 3.03 · cap $79.8M (#8)
- 2017: $1,020 +8838.0% · H 1,447 L 11.29 · cap $7.9B (#9)
- 2018: $77.45 -92.4% · H 1,158 L 58.15 · cap $661.2M (#15)
- 2019: $41.16 -46.9% · H 178.4 L 39.63 · cap $378.9M (#27) · Binance $838.2K/d
- 2020: $99.45 +141.6% · H 133.6 L 40.04 · cap $987.5M (#35) · Binance $10.1M/d
- 2021: $133.6 +34.3% · H 443.1 L 87.02 · cap $1.4B (#52) · Binance $43.3M/d
- 2022: $42.01 -68.6% · H 153.1 L 32.16 · cap $465.5M (#54) · Binance $9.1M/d
- 2023: $31.71 -24.5% · H 74.33 L 24.73 · cap $367.2M (#66) · Binance $4.2M/d
- 2024: $37.91 +19.6% · H 64.81 L 21.47 · cap $456.5M (#61) · Binance $4.3M/d
- 2025: $41.66 +9.9% · H 121.1 L 18.30 · cap $521.4M (#47) · Binance $13.5M/d
- 2026: $47.13 +13.1% · H 85.69 L 29.68 · cap $584.6M (#44) · Binance $14.6M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance DASHUSDT daily (2019-03-28 → 2026-11-08)
