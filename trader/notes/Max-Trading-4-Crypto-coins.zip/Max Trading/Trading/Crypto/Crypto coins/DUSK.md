---
tags: [trading, crypto, dusk]
---
**DUSK**
- Data: 2019-07-22 → 2026-11-08 (2,667 days)
- Last $0.0704 (2026-11-08) · all-time high $1.03 (2022-01-16) · now -93.2% from high · lowest $0.0141 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0434 start · H 0.2962 L 0.0335 · Binance $979.8K/d
- 2020: $0.0451 +3.9% · H 0.1162 L 0.0141 · Binance $494.3K/d
- 2021: $0.9356 +1974.5% · H 0.9819 L 0.0438 · Binance $7.4M/d
- 2022: $0.0832 -91.1% · H 1.03 L 0.0757 · Binance $9.3M/d
- 2023: $0.1868 +124.5% · H 0.2836 L 0.0819 · Binance $4.0M/d
- 2024: $0.2371 +26.9% · H 0.6390 L 0.1555 · Binance $5.0M/d
- 2025: $0.0470 -80.2% · H 0.2596 L 0.0379 · Binance $1.2M/d
- 2026: $0.0704 +49.8% · H 0.2247 L 0.0488 · Binance $2.5M/d

**Sources**
- Binance DUSKUSDT daily (2019-07-22 → 2026-11-08)
