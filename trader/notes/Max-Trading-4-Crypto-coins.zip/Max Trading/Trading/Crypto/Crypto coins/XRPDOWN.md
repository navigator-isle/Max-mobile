---
tags: [trading, crypto, xrpdown]
---
**XRPDOWN**
- Data: 2020-09-11 → 2023-05-12 (974 days)
- Last $8.17e-05 (2023-05-12) · all-time high $12.21 (2020-09-23) · now -100.0% from high · lowest $4.91e-05 (2023-03-29)
- Binance: stopped trading on Binance (delisted) after 2023-05-12

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.6960 start · H 12.21 L 0.1950 · Binance $14.0M/d
- 2021: $0.000945 -99.9% · H 0.6600 L 5.2e-05 · Binance $9.4M/d
- 2022: $0.000302 -68.1% · H 0.00191 L 0.000211 · Binance $2.6M/d
- 2023: $8.17e-05 -72.9% · H 0.000316 L 4.91e-05 · Binance $764.5K/d

**Sources**
- Binance XRPDOWNUSDT daily (2020-09-11 → 2023-05-12)
