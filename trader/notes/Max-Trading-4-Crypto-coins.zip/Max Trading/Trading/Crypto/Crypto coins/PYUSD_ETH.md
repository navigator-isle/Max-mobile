---
tags: [trading, crypto, pyusd_eth]
---
**PYUSD_ETH**
- Data: 2023-08-22 → 2026-05-23 (1,006 days)
- Last $0.9996 (2026-05-23) · all-time high $1.00 (2024-03-29) · now -0.5% from high · lowest $0.9919 (2024-04-03)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.9998 start · H 1.00 L 0.9978 · cap $264.5M (#74)
- 2024: $0.9998 +0.0% · H 1.00 L 0.9919 · cap $327.3M (#68)
- 2025: $1.00 +0.0% · H 1.00 L 0.9982 · cap $2.7B (#29)
- 2026: $0.9996 -0.0% · H 1.00 L 0.9996 · cap $2.6B (#29)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
