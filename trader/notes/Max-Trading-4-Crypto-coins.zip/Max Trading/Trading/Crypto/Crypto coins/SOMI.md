---
tags: [trading, crypto, somi]
---
**SOMI**
- Data: 2025-09-02 → 2026-11-08 (433 days)
- Last $0.1638 (2026-11-08) · all-time high $1.65 (2025-09-07) · now -90.1% from high · lowest $0.0835 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.2521 start · H 1.65 L 0.2146 · Binance $44.8M/d
- 2026: $0.1638 -35.0% · H 0.3385 L 0.0835 · Binance $1.8M/d

**Sources**
- Binance SOMIUSDT daily (2025-09-02 → 2026-11-08)
