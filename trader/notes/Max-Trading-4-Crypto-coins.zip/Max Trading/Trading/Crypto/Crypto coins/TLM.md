---
tags: [trading, crypto, tlm]
---
**TLM**
- Data: 2021-04-13 → 2026-11-08 (2,036 days)
- Last $0.00107 (2026-11-08) · all-time high $0.7549 (2021-05-02) · now -99.9% from high · lowest $0.000841 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.2126 start · H 0.7549 L 0.0714 · Binance $102.8M/d
- 2022: $0.0121 -94.3% · H 0.2256 L 0.0120 · Binance $11.1M/d
- 2023: $0.0192 +58.9% · H 0.0269 L 0.00935 · Binance $2.4M/d
- 2024: $0.0134 -30.5% · H 0.0319 L 0.00831 · Binance $5.0M/d
- 2025: $0.00257 -80.8% · H 0.0151 L 0.00194 · Binance $1.5M/d
- 2026: $0.00107 -58.2% · H 0.00331 L 0.000841 · Binance $1.7M/d

**Sources**
- Binance TLMUSDT daily (2021-04-13 → 2026-11-08)
