---
tags: [trading, crypto, strk]
---
**STRK**
- Data: 2024-02-20 → 2026-11-08 (993 days)
- Last $0.0396 (2026-11-08) · all-time high $2.63 (2024-03-13) · now -98.5% from high · lowest $0.0225 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.4687 start · H 2.63 L 0.3344 · Binance $39.5M/d
- 2025: $0.0792 -83.1% · H 0.5253 L 0.0779 · Binance $12.8M/d
- 2026: $0.0396 -50.1% · H 0.1232 L 0.0225 · Binance $5.5M/d

**Sources**
- Binance STRKUSDT daily (2024-02-20 → 2026-11-08)
