---
tags: [trading, crypto, wal]
---
**WAL**
- Data: 2025-10-10 → 2026-11-08 (395 days)
- Last $0.0281 (2026-11-08) · all-time high $0.2598 (2025-10-26) · now -89.2% from high · lowest $0.0205 (2026-08-17)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1189 start · H 0.2598 L 0.1164 · Binance $83.5M/d
- 2026: $0.0281 -76.3% · H 0.1585 L 0.0205 · Binance $1.2M/d

**Sources**
- Binance WALUSDT daily (2025-10-10 → 2026-11-08)
