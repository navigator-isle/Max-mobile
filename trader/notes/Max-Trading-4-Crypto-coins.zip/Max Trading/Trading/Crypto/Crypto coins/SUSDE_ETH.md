---
tags: [trading, crypto, susde_eth]
---
**SUSDE_ETH**
- Data: 2024-06-17 → 2026-05-23 (706 days)
- Last $1.23 (2026-05-23) · all-time high $1.23 (2026-05-17) · now -0.0% from high · lowest $1.06 (2024-06-22)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.14 start · H 1.14 L 1.06 · cap $4.3B (#28)
- 2025: $1.21 +6.6% · H 1.21 L 1.14 · cap $3.5B (#26)
- 2026: $1.23 +1.7% · H 1.23 L 1.21 · cap $1.8B (#34)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
