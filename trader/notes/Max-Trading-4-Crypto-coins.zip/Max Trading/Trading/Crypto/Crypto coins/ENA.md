---
tags: [trading, crypto, ena]
---
**ENA**
- Data: 2024-04-02 → 2026-11-08 (951 days)
- Last $0.1539 (2026-11-08) · all-time high $1.46 (2024-04-10) · now -89.5% from high · lowest $0.0714 (2026-07-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.9093 start · H 1.46 L 0.2050 · Binance $109.7M/d
- 2025: $0.1999 -78.0% · H 1.26 L 0.1976 · Binance $95.9M/d
- 2026: $0.1539 -23.0% · H 0.2725 L 0.0714 · Binance $26.0M/d

**Sources**
- Binance ENAUSDT daily (2024-04-02 → 2026-11-08)
