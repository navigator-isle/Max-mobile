---
tags: [trading, crypto, neo]
---
**NEO**
- Data: 2017-07-15 → 2026-11-08 (3,404 days)
- Last $1.84 (2026-11-08) · all-time high $189.4 (2018-01-15) · now -99.0% from high · lowest $1.66 (2026-08-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $74.85 start · H 77.04 L 5.03 · cap $7.6B (#11) · Binance $6.5M/d
- 2018: $7.41 -90.1% · H 189.4 L 5.59 · cap $737.1M (#13) · Binance $21.2M/d
- 2019: $8.68 +17.1% · H 19.61 L 6.86 · cap $864.9M (#19) · Binance $6.1M/d
- 2020: $14.26 +64.3% · H 25.31 L 5.39 · cap $1.4B (#29) · Binance $10.6M/d
- 2021: $25.69 +80.2% · H 122.8 L 14.43 · cap $2.6B (#42) · Binance $63.1M/d
- 2022: $6.14 -76.1% · H 28.36 L 6.06 · cap $612.3M (#47) · Binance $7.6M/d
- 2023: $13.95 +127.2% · H 14.67 L 6.40 · cap $1.4B (#40) · Binance $8.0M/d
- 2024: $13.55 -2.9% · H 26.09 L 8.53 · cap $1.4B (#43) · Binance $10.0M/d
- 2025: $3.51 -74.1% · H 16.94 L 3.48 · cap $488.2M (#49) · Binance $6.3M/d
- 2026: $1.84 -47.6% · H 4.05 L 1.66 · Binance $880.0K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance NEOUSDT daily (2017-11-20 → 2026-11-08)
