---
tags: [trading, crypto, rare]
---
**RARE**
- Data: 2021-10-11 → 2026-11-08 (1,855 days)
- Last $0.0113 (2026-11-08) · all-time high $2.56 (2021-10-11) · now -99.6% from high · lowest $0.0113 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.9480 start · H 2.56 L 0.9270 · Binance $15.4M/d
- 2022: $0.1008 -89.4% · H 1.02 L 0.0897 · Binance $3.9M/d
- 2023: $0.1174 +16.5% · H 0.1757 L 0.0527 · Binance $2.2M/d
- 2024: $0.1117 -4.9% · H 0.2685 L 0.0632 · Binance $8.9M/d
- 2025: $0.0213 -80.9% · H 0.1221 L 0.0194 · Binance $5.8M/d
- 2026: $0.0113 -46.8% · H 0.0293 L 0.0113 · Binance $998.3K/d

**Sources**
- Binance RAREUSDT daily (2021-10-11 → 2026-11-08)
