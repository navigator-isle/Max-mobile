---
tags: [trading, crypto, dent]
---
**DENT**
- Data: 2019-08-27 → 2026-04-28 (2,437 days)
- Last $3.8e-05 (2026-04-28) · all-time high $0.0193 (2021-04-05) · now -99.8% from high · lowest $3.8e-05 (2026-04-28)
- Binance: stopped trading on Binance (delisted) after 2026-04-28

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.000159 start · H 0.00051 L 0.00015 · Binance $85.9K/d
- 2020: $0.000189 +19.1% · H 0.000346 L 7.89e-05 · Binance $164.8K/d
- 2021: $0.00387 +1946.6% · H 0.0193 L 0.000193 · Binance $63.6M/d
- 2022: $0.000684 -82.3% · H 0.00411 L 0.000591 · Binance $6.7M/d
- 2023: $0.00133 +93.7% · H 0.00147 L 0.000573 · Binance $2.1M/d
- 2024: $0.00133 +0.5% · H 0.00244 L 0.000693 · Binance $3.0M/d
- 2025: $0.000201 -84.9% · H 0.00158 L 0.0002 · Binance $1.0M/d
- 2026: $3.8e-05 -81.1% · H 0.000353 L 3.8e-05 · Binance $1.6M/d

**Sources**
- Binance DENTUSDT daily (2019-08-27 → 2026-04-28)
