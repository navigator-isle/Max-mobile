---
tags: [trading, crypto, wrx]
---
**WRX**
- Data: 2020-02-05 → 2024-12-25 (1,786 days)
- Last $0.0173 (2024-12-25) · all-time high $4.04 (2021-04-07) · now -99.6% from high · lowest $0.0173 (2024-12-25)
- Binance: stopped trading on Binance (delisted) after 2024-12-25

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.0652 start · H 0.2034 L 0.0602 · Binance $3.6M/d
- 2021: $1.18 +1715.1% · H 4.04 L 0.0651 · Binance $30.4M/d
- 2022: $0.1331 -88.8% · H 1.22 L 0.1331 · Binance $2.7M/d
- 2023: $0.2205 +65.7% · H 0.2588 L 0.0793 · Binance $1.5M/d
- 2024: $0.0173 -92.2% · H 0.3699 L 0.0173 · Binance $2.0M/d

**Sources**
- Binance WRXUSDT daily (2020-02-05 → 2024-12-25)
