---
tags: [trading, crypto, lusd_eth]
---
**LUSD_ETH**
- Data: 2021-04-27 → 2026-05-23 (1,853 days)
- Last $1.00 (2026-05-23) · all-time high $9.01 (2022-10-19) · now -88.9% from high · lowest $0.6009 (2021-05-25)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.9498 start · H 1.98 L 0.6009 · cap $823.9M (#67)
- 2022: $1.02 +7.6% · H 9.01 L 0.7653 · cap $183.2M (#70)
- 2023: $0.9970 -2.4% · H 3.11 L 0.9810 · cap $176.5M (#83)
- 2024: $0.9985 +0.2% · H 1.03 L 0.9922 · cap $61.3M (#95)
- 2025: $1.00 +0.3% · H 1.01 L 0.9968 · cap $35.1M (#89)
- 2026: $1.00 +0.2% · H 1.03 L 1.0000 · cap $28.6M (#84)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
