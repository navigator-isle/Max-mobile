---
tags: [trading, crypto, zil_eth]
---
**ZIL_ETH**
- Data: 2018-01-27 → 2026-05-23 (3,039 days)
- Last $0.00399 (2026-05-23) · all-time high $0.2365 (2021-05-06) · now -98.3% from high · lowest $0.0033 (2020-03-12)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.0192 start · H 0.1969 L 0.0125 · cap $241.7M (#27)
- 2019: $0.00446 -76.7% · H 0.0254 L 0.0044 · cap $3.0M (#83)
- 2020: $0.0824 +1748.0% · H 0.0901 L 0.0033 · cap $17.6M (#102)
- 2021: $0.0749 -9.2% · H 0.2365 L 0.0534 · cap $13.5M (#114)
- 2022: $0.0158 -78.9% · H 0.1837 L 0.0158 · cap $2.3M (#112)
- 2023: $0.0247 +56.2% · H 0.0354 L 0.0150 · cap $3.4M (#109)
- 2024: $0.0201 -18.7% · H 0.0405 L 0.0124 · cap $2.7M (#114)
- 2025: $0.00468 -76.7% · H 0.0243 L 0.00436 · cap $632.8K (#108)
- 2026: $0.00399 -14.8% · H 0.00588 L 0.00366 · cap $539.1K (#107)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
