---
tags: [trading, crypto, ppt]
---
**PPT**
- Data: 2017-09-20 → 2022-09-12 (1,819 days)
- Last $0.0510 (2022-09-12) · all-time high $74.79 (2018-01-28) · now -99.9% from high · lowest $0.0510 (2022-08-29)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $40.73 start · H 48.40 L 2.32 · cap $2.2B (#20)
- 2018: $1.45 -96.4% · H 74.79 L 1.08 · cap $77.2M (#49)
- 2019: $0.3365 -76.8% · H 1.75 L 0.3147 · cap $17.9M (#71)
- 2020: $0.4202 +24.9% · H 0.7298 L 0.1792 · cap $22.4M (#97)
- 2021: $0.5355 +27.4% · H 7.11 L 0.5117 · cap $28.5M (#110)
- 2022: $0.0510 -90.5% · H 0.5833 L 0.0510 · cap $2.7M (#114)

**Sources**
- Coin Metrics community data (daily, to 2022-09-12)
