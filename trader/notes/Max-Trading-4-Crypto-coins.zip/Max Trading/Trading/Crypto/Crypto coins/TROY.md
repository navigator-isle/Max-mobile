---
tags: [trading, crypto, troy]
---
**TROY**
- Data: 2019-12-05 → 2025-04-16 (1,960 days)
- Last $6.9e-05 (2025-04-16) · all-time high $0.0308 (2021-04-17) · now -99.8% from high · lowest $6.9e-05 (2025-04-16)
- Binance: stopped trading on Binance (delisted) after 2025-04-16

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00669 start · H 0.00956 L 0.00664 · Binance $5.3M/d
- 2020: $0.00233 -65.1% · H 0.00886 L 0.00146 · Binance $457.3K/d
- 2021: $0.0106 +354.0% · H 0.0308 L 0.00248 · Binance $9.3M/d
- 2022: $0.00262 -75.3% · H 0.0126 L 0.00219 · Binance $4.6M/d
- 2023: $0.00253 -3.3% · H 0.00533 L 0.00187 · Binance $2.0M/d
- 2024: $0.0061 +140.6% · H 0.0064 L 0.00119 · Binance $10.6M/d
- 2025: $6.9e-05 -98.9% · H 0.00709 L 6.9e-05 · Binance $10.7M/d

**Sources**
- Binance TROYUSDT daily (2019-12-05 → 2025-04-16)
