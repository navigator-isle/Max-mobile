---
tags: [trading, crypto, sign]
---
**SIGN**
- Data: 2025-04-28 → 2026-11-08 (560 days)
- Last $0.00905 (2026-11-08) · all-time high $0.1158 (2025-09-23) · now -92.2% from high · lowest $0.0064 (2026-08-14)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0372 start · H 0.1158 L 0.0312 · Binance $5.8M/d
- 2026: $0.00905 -75.7% · H 0.0566 L 0.0064 · Binance $1.9M/d

**Sources**
- Binance SIGNUSDT daily (2025-04-28 → 2026-11-08)
