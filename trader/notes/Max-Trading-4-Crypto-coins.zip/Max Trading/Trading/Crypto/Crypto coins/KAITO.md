---
tags: [trading, crypto, kaito]
---
**KAITO**
- Data: 2025-02-20 → 2026-11-08 (627 days)
- Last $0.2116 (2026-11-08) · all-time high $2.45 (2025-02-26) · now -91.4% from high · lowest $0.2089 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.5069 start · H 2.45 L 0.4836 · Binance $21.5M/d
- 2026: $0.2116 -58.3% · H 1.29 L 0.2089 · Binance $2.9M/d

**Sources**
- Binance KAITOUSDT daily (2025-02-20 → 2026-11-08)
