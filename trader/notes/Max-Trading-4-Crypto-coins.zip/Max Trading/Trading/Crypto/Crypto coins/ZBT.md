---
tags: [trading, crypto, zbt]
---
**ZBT**
- Data: 2025-10-17 → 2026-11-08 (388 days)
- Last $0.0604 (2026-11-08) · all-time high $0.4197 (2025-10-17) · now -85.6% from high · lowest $0.0604 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1459 start · H 0.4197 L 0.0712 · Binance $31.6M/d
- 2026: $0.0604 -58.6% · H 0.2179 L 0.0604 · Binance $3.1M/d

**Sources**
- Binance ZBTUSDT daily (2025-10-17 → 2026-11-08)
