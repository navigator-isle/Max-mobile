---
tags: [trading, crypto, spk]
---
**SPK**
- Data: 2025-06-17 → 2026-11-08 (510 days)
- Last $0.0160 (2026-11-08) · all-time high $0.1767 (2025-07-23) · now -91.0% from high · lowest $0.0132 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0210 start · H 0.1767 L 0.0195 · Binance $16.2M/d
- 2026: $0.0160 -23.9% · H 0.0519 L 0.0132 · Binance $4.3M/d

**Sources**
- Binance SPKUSDT daily (2025-06-17 → 2026-11-08)
