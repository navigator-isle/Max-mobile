---
tags: [trading, crypto, zama]
---
**ZAMA**
- Data: 2026-02-02 → 2026-11-08 (280 days)
- Last $0.0669 (2026-11-08) · all-time high $0.1017 (2026-09-22) · now -34.2% from high · lowest $0.0181 (2026-02-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0669 start · H 0.1017 L 0.0181 · Binance $11.8M/d

**Sources**
- Binance ZAMAUSDT daily (2026-02-02 → 2026-11-08)
