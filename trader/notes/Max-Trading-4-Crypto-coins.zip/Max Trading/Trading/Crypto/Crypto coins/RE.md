---
tags: [trading, crypto, re]
---
**RE**
- Data: 2026-06-18 → 2026-11-08 (144 days)
- Last $0.2899 (2026-11-08) · all-time high $1.00 (2026-06-20) · now -71.1% from high · lowest $0.2899 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.2899 start · H 1.00 L 0.2899 · Binance $28.9M/d

**Sources**
- Binance REUSDT daily (2026-06-18 → 2026-11-08)
