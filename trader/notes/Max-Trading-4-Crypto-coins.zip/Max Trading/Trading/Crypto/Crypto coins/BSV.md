---
tags: [trading, crypto, bsv]
---
**BSV**
- Data: 2018-11-15 → 2026-05-23 (2,747 days)
- Last $14.72 (2026-05-23) · all-time high $439.7 (2021-04-16) · now -96.7% from high · lowest $12.45 (2026-02-05)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $83.71 start · H 116.1 L 41.54 · cap $1.5B (#9)
- 2019: $96.97 +15.9% · H 238.6 L 50.72 · cap $1.8B (#11)
- 2020: $164.1 +69.2% · H 422.7 L 92.94 · cap $3.1B (#20)
- 2021: $121.4 -26.0% · H 439.7 L 114.0 · cap $2.3B (#45)
- 2022: $41.18 -66.1% · H 124.1 L 35.36 · cap $793.5M (#40)
- 2023: $94.89 +130.4% · H 95.12 L 24.06 · cap $703.2M (#48)
- 2024: $50.30 -47.0% · H 115.7 L 34.79
- 2025: $17.31 -65.6% · H 63.95 L 17.28
- 2026: $14.72 -15.0% · H 21.17 L 12.45

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
