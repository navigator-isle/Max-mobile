---
tags: [trading, crypto, sun]
---
**SUN**
- Data: 2020-09-21 → 2026-11-08 (2,237 days)
- Last $0.0155 (2026-11-08) · all-time high $50.19 (2021-04-04) · now -100.0% from high · lowest $0.00487 (2022-11-22)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $6.50 start · H 19.33 L 6.06 · Binance $678.3K/d
- 2021: $0.0218 -99.7% · H 50.19 L 0.0173 · Binance $25.7M/d
- 2022: $0.00512 -76.5% · H 0.0225 L 0.00487 · Binance $9.0M/d
- 2023: $0.00825 +61.1% · H 0.0084 L 0.00501 · Binance $638.6K/d
- 2024: $0.0243 +194.2% · H 0.0398 L 0.00694 · Binance $7.8M/d
- 2025: $0.0188 -22.4% · H 0.0327 L 0.0154 · Binance $3.4M/d
- 2026: $0.0155 -17.6% · H 0.0212 L 0.0151 · Binance $941.0K/d

**Sources**
- Binance SUNUSDT daily (2020-09-21 → 2026-11-08)
