---
tags: [trading, crypto, id]
---
**ID**
- Data: 2023-03-22 → 2026-11-08 (1,328 days)
- Last $0.0275 (2026-11-08) · all-time high $1.73 (2024-03-17) · now -98.4% from high · lowest $0.0239 (2026-06-09)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.3002 start · H 0.9352 L 0.1715 · Binance $26.3M/d
- 2024: $0.4362 +45.3% · H 1.73 L 0.2642 · Binance $11.4M/d
- 2025: $0.0706 -83.8% · H 0.4883 L 0.0585 · Binance $2.4M/d
- 2026: $0.0275 -61.0% · H 0.0846 L 0.0239 · Binance $1.3M/d

**Sources**
- Binance IDUSDT daily (2023-03-22 → 2026-11-08)
