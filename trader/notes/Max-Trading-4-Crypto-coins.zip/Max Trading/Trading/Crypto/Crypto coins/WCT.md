---
tags: [trading, crypto, wct]
---
**WCT**
- Data: 2025-04-15 → 2026-11-08 (573 days)
- Last $0.0306 (2026-11-08) · all-time high $1.14 (2025-05-29) · now -97.3% from high · lowest $0.0306 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0805 start · H 1.14 L 0.0678 · Binance $12.6M/d
- 2026: $0.0306 -62.0% · H 0.0872 L 0.0306 · Binance $1.1M/d

**Sources**
- Binance WCTUSDT daily (2025-04-15 → 2026-11-08)
