---
tags: [trading, crypto, trx]
---
**TRX**
- Data: 2018-06-11 → 2026-11-08 (3,073 days)
- Last $0.3205 (2026-11-08) · all-time high $0.4334 (2024-12-03) · now -26.0% from high · lowest $0.00841 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.0187 start · H 0.0498 L 0.0119 · Binance $16.3M/d
- 2019: $0.0133 -28.8% · H 0.0385 L 0.0124 · Binance $17.3M/d
- 2020: $0.0268 +101.3% · H 0.0400 L 0.00841 · Binance $29.1M/d
- 2021: $0.0754 +181.6% · H 0.1642 L 0.0268 · Binance $199.3M/d
- 2022: $0.0545 -27.7% · H 0.0879 L 0.0501 · Binance $77.9M/d
- 2023: $0.1076 +97.5% · H 0.1090 L 0.0520 · Binance $25.2M/d
- 2024: $0.2548 +136.7% · H 0.4334 L 0.1028 · Binance $76.0M/d
- 2025: $0.2845 +11.7% · H 0.3667 L 0.2119 · Binance $124.1M/d
- 2026: $0.3205 +12.7% · H 0.3756 L 0.2696 · Binance $37.7M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance TRXUSDT daily (2018-06-11 → 2026-11-08)
