---
tags: [trading, crypto, ustc]
---
**USTC**
- Data: 2023-03-10 → 2026-11-08 (1,340 days)
- Last $0.00416 (2026-11-08) · all-time high $0.0614 (2023-12-03) · now -93.2% from high · lowest $0.00416 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.0330 start · H 0.0614 L 0.0107 · Binance $16.4M/d
- 2024: $0.0195 -41.1% · H 0.0395 L 0.0134 · Binance $10.3M/d
- 2025: $0.00641 -67.1% · H 0.0216 L 0.00569 · Binance $3.2M/d
- 2026: $0.00416 -35.1% · H 0.00804 L 0.00416 · Binance $778.9K/d

**Sources**
- Binance USTCUSDT daily (2023-03-10 → 2026-11-08)
