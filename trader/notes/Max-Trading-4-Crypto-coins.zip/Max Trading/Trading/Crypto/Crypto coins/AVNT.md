---
tags: [trading, crypto, avnt]
---
**AVNT**
- Data: 2025-09-15 → 2026-11-08 (420 days)
- Last $0.0834 (2026-11-08) · all-time high $2.36 (2025-09-21) · now -96.5% from high · lowest $0.0795 (2026-08-03)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.3472 start · H 2.36 L 0.2294 · Binance $76.1M/d
- 2026: $0.0834 -76.0% · H 0.3623 L 0.0795 · Binance $2.7M/d

**Sources**
- Binance AVNTUSDT daily (2025-09-15 → 2026-11-08)
