---
tags: [trading, crypto, at]
---
**AT**
- Data: 2025-11-27 → 2026-11-08 (347 days)
- Last $0.0936 (2026-11-08) · all-time high $0.2200 (2025-11-27) · now -57.5% from high · lowest $0.0848 (2025-12-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1768 start · H 0.2200 L 0.0848 · Binance $42.7M/d
- 2026: $0.0936 -47.1% · H 0.1947 L 0.0936 · Binance $1.1M/d

**Sources**
- Binance ATUSDT daily (2025-11-27 → 2026-11-08)
