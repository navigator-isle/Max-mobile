---
tags: [trading, crypto, jasmy]
---
**JASMY**
- Data: 2021-11-22 → 2026-11-08 (1,813 days)
- Last $0.0036 (2026-11-08) · all-time high $0.2366 (2021-11-22) · now -98.5% from high · lowest $0.0028 (2022-12-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.0852 start · H 0.2366 L 0.0652 · Binance $33.3M/d
- 2022: $0.00294 -96.5% · H 0.0862 L 0.0028 · Binance $40.1M/d
- 2023: $0.00655 +122.4% · H 0.00797 L 0.003 · Binance $9.2M/d
- 2024: $0.0317 +384.6% · H 0.0581 L 0.0048 · Binance $30.8M/d
- 2025: $0.00562 -82.3% · H 0.0398 L 0.00562 · Binance $7.8M/d
- 2026: $0.0036 -35.9% · H 0.00962 L 0.0035 · Binance $1.4M/d

**Sources**
- Binance JASMYUSDT daily (2021-11-22 → 2026-11-08)
