---
tags: [trading, crypto, ust]
---
**UST**
- Data: 2021-12-24 → 2022-05-13 (141 days)
- Last $0.2458 (2022-05-13) · all-time high $1.01 (2022-03-02) · now -75.6% from high · lowest $0.2458 (2022-05-13)
- Binance: stopped trading on Binance (delisted) after 2022-05-13

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $1.00 start · H 1.00 L 1.00 · Binance $11.1M/d
- 2022: $0.2458 -75.4% · H 1.01 L 0.2458 · Binance $170.7M/d

**Sources**
- Binance USTUSDT daily (2021-12-24 → 2022-05-13)
