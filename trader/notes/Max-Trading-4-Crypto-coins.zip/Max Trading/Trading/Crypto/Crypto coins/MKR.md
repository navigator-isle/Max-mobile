---
tags: [trading, crypto, mkr]
---
**MKR**
- Data: 2017-12-26 → 2025-09-15 (2,821 days)
- Last $1,814 (2025-09-15) · all-time high $5,982 (2021-05-03) · now -69.7% from high · lowest $201.1 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2025-09-15

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $1,187 start · H 1,562 L 1,187 · cap $1.2B (#29)
- 2018: $455.6 -61.6% · H 2,205 L 318.0 · cap $455.6M (#18)
- 2019: $430.5 -5.5% · H 792.3 L 364.9 · cap $430.5M (#26)
- 2020: $585.7 +36.0% · H 789.7 L 201.1 · cap $586.1M (#46) · Binance $2.3M/d
- 2021: $2,334 +298.5% · H 5,982 L 581.1 · cap $2.3B (#44) · Binance $16.7M/d
- 2022: $511.0 -78.1% · H 2,471 L 511.0 · cap $497.5M (#51) · Binance $4.2M/d
- 2023: $1,701 +232.9% · H 1,701 L 505.0 · cap $1.7B (#38) · Binance $10.2M/d
- 2024: $1,492 -12.3% · H 3,954 L 1,063 · cap $1.4B (#42) · Binance $20.3M/d
- 2025: $1,814 +21.6% · H 2,319 L 901.0 · cap $181.2M (#60) · Binance $12.5M/d

**Sources**
- Coin Metrics community data (daily, to 2026-03-25)
- Binance MKRUSDT daily (2020-07-23 → 2025-09-15)
