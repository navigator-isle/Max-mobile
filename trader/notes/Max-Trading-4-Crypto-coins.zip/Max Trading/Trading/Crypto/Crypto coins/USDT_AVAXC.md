---
tags: [trading, crypto, usdt_avaxc]
---
**USDT_AVAXC**
- Data: 2021-09-21 → 2026-05-23 (1,706 days)
- Last $0.9987 (2026-05-23) · all-time high $1.01 (2023-03-11) · now -0.9% from high · lowest $0.9954 (2022-05-11)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $1.00 start · H 1.00 L 0.9998 · cap $1.0M (#117)
- 2022: $0.9995 -0.1% · H 1.00 L 0.9954 · cap $650.7M (#43)
- 2023: $0.9998 +0.0% · H 1.01 L 0.9984 · cap $847.0M (#50)
- 2024: $0.9980 -0.2% · H 1.00 L 0.9980 · cap $1.8B (#40)
- 2025: $0.9983 +0.0% · H 1.00 L 0.9978 · cap $1.8B (#35)
- 2026: $0.9987 +0.0% · H 1.00 L 0.9977 · cap $1.8B (#33)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
