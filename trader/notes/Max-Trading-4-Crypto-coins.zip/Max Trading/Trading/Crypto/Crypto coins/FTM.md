---
tags: [trading, crypto, ftm]
---
**FTM**
- Data: 2019-06-11 → 2025-01-13 (2,044 days)
- Last $0.6994 (2025-01-13) · all-time high $3.31 (2022-01-16) · now -78.9% from high · lowest $0.0023 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2025-01-13

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0109 start · H 0.0324 L 0.00964 · Binance $1.0M/d
- 2020: $0.0169 +55.6% · H 0.0552 L 0.0023 · Binance $2.0M/d
- 2021: $2.25 +13207.1% · H 3.16 L 0.0164 · Binance $161.5M/d
- 2022: $0.1998 -91.1% · H 3.31 L 0.1691 · Binance $109.9M/d
- 2023: $0.4740 +137.2% · H 0.6325 L 0.1756 · Binance $37.0M/d
- 2024: $0.6809 +43.6% · H 1.43 L 0.2917 · Binance $64.3M/d
- 2025: $0.6994 +2.7% · H 0.8554 L 0.6451 · Binance $51.0M/d

**Sources**
- Binance FTMUSDT daily (2019-06-11 → 2025-01-13)
