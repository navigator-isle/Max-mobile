---
tags: [trading, crypto, bera]
---
**BERA**
- Data: 2025-02-06 → 2026-11-08 (641 days)
- Last $0.1111 (2026-11-08) · all-time high $8.81 (2025-02-20) · now -98.7% from high · lowest $0.1111 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.6080 start · H 8.81 L 0.5490 · Binance $20.2M/d
- 2026: $0.1111 -81.7% · H 0.9520 L 0.1111 · Binance $3.4M/d

**Sources**
- Binance BERAUSDT daily (2025-02-06 → 2026-11-08)
