---
tags: [trading, crypto, waves]
---
**WAVES**
- Data: 2019-01-18 → 2024-06-17 (1,978 days)
- Last $1.08 (2024-06-17) · all-time high $54.45 (2022-03-31) · now -98.0% from high · lowest $0.5280 (2019-12-10)
- Binance: stopped trading on Binance (delisted) after 2024-06-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $1.01 start · H 3.28 L 0.5280 · Binance $966.8K/d
- 2020: $6.19 +513.9% · H 8.95 L 0.7386 · Binance $6.4M/d
- 2021: $14.53 +134.6% · H 35.93 L 5.39 · Binance $30.6M/d
- 2022: $1.31 -91.0% · H 54.45 L 1.31 · Binance $45.7M/d
- 2023: $2.68 +104.3% · H 3.09 L 1.31 · Binance $11.1M/d
- 2024: $1.08 -59.8% · H 4.54 L 1.03 · Binance $12.3M/d

**Sources**
- Binance WAVESUSDT daily (2019-01-18 → 2024-06-17)
