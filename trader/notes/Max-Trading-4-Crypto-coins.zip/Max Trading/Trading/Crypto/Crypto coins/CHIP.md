---
tags: [trading, crypto, chip]
---
**CHIP**
- Data: 2026-04-21 → 2026-11-08 (202 days)
- Last $0.0336 (2026-11-08) · all-time high $0.1128 (2026-04-22) · now -70.2% from high · lowest $0.0217 (2026-08-09)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0336 start · H 0.1128 L 0.0217 · Binance $27.0M/d

**Sources**
- Binance CHIPUSDT daily (2026-04-21 → 2026-11-08)
