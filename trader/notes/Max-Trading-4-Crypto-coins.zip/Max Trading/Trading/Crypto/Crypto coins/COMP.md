---
tags: [trading, crypto, comp]
---
**COMP**
- Data: 2020-06-18 → 2026-11-08 (2,335 days)
- Last $19.86 (2026-11-08) · all-time high $854.3 (2021-05-11) · now -97.7% from high · lowest $15.19 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $149.0 start · H 331.3 L 87.47 · cap $1.5B (#28) · Binance $7.0M/d
- 2021: $199.7 +34.0% · H 854.3 L 136.7 · cap $2.0B (#47) · Binance $26.8M/d
- 2022: $31.20 -84.4% · H 222.7 L 28.80 · cap $311.5M (#57) · Binance $7.3M/d
- 2023: $57.41 +84.0% · H 77.53 L 26.20 · cap $573.2M (#53) · Binance $8.2M/d
- 2024: $73.36 +27.8% · H 120.3 L 37.30 · cap $731.5M (#51) · Binance $7.1M/d
- 2025: $24.82 -66.2% · H 89.60 L 23.95 · cap $248.0M (#56) · Binance $5.1M/d
- 2026: $19.86 -20.0% · H 27.64 L 15.19 · cap $199.7M (#55) · Binance $1.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance COMPUSDT daily (2020-06-25 → 2026-11-08)
