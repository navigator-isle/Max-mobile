---
tags: [trading, crypto, usdc_eth]
---
**USDC_ETH**
- Data: 2018-09-28 → 2026-05-23 (2,795 days)
- Last $0.9997 (2026-05-23) · all-time high $1.01 (2023-05-08) · now -0.9% from high · lowest $0.9706 (2023-03-11)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.9983 start · H 1.00 L 0.9976 · cap $250.8M (#25)
- 2019: $0.9989 +0.1% · H 1.01 L 0.9980 · cap $519.8M (#24)
- 2020: $1.00 +0.1% · H 1.00 L 0.9932 · cap $3.9B (#16)
- 2021: $0.9998 -0.0% · H 1.00 L 0.9982 · cap $37.7B (#10)
- 2022: $0.9999 +0.0% · H 1.00 L 0.9987 · cap $41.5B (#5)
- 2023: $0.9999 +0.0% · H 1.01 L 0.9706 · cap $22.2B (#8)
- 2024: $0.9998 -0.0% · H 1.00 L 0.9996 · cap $31.1B (#10)
- 2025: $0.9996 -0.0% · H 1.00 L 0.9990 · cap $51.7B (#8)
- 2026: $0.9997 +0.0% · H 1.00 L 0.9995 · cap $52.7B (#8)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
