---
tags: [trading, crypto, bchabc]
---
**BCHABC**
- Data: 2018-11-16 → 2019-11-28 (378 days)
- Last $220.1 (2019-11-28) · all-time high $488.6 (2019-06-26) · now -55.0% from high · lowest $76.75 (2018-12-15)
- Binance: stopped trading on Binance (delisted) after 2019-11-28

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $148.4 start · H 296.7 L 76.75 · Binance $25.7M/d
- 2019: $220.1 +48.3% · H 488.6 L 109.5 · Binance $27.8M/d

**Sources**
- Binance BCHABCUSDT daily (2018-11-16 → 2019-11-28)
