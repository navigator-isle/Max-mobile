---
tags: [trading, crypto, dgb]
---
**DGB**
- Data: 2015-02-10 → 2026-11-08 (4,290 days)
- Last $0.0033 (2026-11-08) · all-time high $0.1573 (2021-05-02) · now -97.9% from high · lowest $4.45e-05 (2015-08-24)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2015: $0.000138 start · H 0.000444 L 4.45e-05 · cap $778.3K (#13)
- 2016: $0.000252 +83.1% · H 0.000664 L 0.000121 · cap $2.0M (#17)
- 2017: $0.0695 +27427.9% · H 0.0842 L 0.000202 · cap $668.9M (#40)
- 2018: $0.0101 -85.5% · H 0.1262 L 0.0078 · cap $113.6M (#38)
- 2019: $0.00524 -48.1% · H 0.0166 L 0.00524 · cap $66.4M (#49)
- 2020: $0.0249 +375.7% · H 0.0369 L 0.00306 · cap $348.3M (#54) · Binance $1.1M/d
- 2021: $0.0332 +33.2% · H 0.1573 L 0.0224 · cap $497.0M (#78) · Binance $12.4M/d
- 2022: $0.0077 -76.8% · H 0.0383 L 0.00652 · cap $122.2M (#77) · Binance $3.1M/d
- 2023: $0.0095 +23.4% · H 0.0123 L 0.00593 · cap $158.0M (#85) · Binance $1.0M/d
- 2024: $0.0104 +9.9% · H 0.0204 L 0.00512 · cap $181.6M (#82) · Binance $2.9M/d
- 2025: $0.00581 -44.3% · H 0.0153 L 0.00542 · cap $104.9M (#72) · Binance $1.6M/d
- 2026: $0.0033 -43.2% · H 0.00678 L 0.00231 · cap $65.9M (#72) · Binance $311.6K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance DGBUSDT daily (2020-07-20 → 2026-11-08)
