---
tags: [trading, crypto, jup]
---
**JUP**
- Data: 2024-01-31 → 2026-11-08 (1,013 days)
- Last $0.2403 (2026-11-08) · all-time high $1.74 (2024-03-31) · now -86.2% from high · lowest $0.1375 (2026-02-11)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.8169 start · H 1.74 L 0.4692 · Binance $41.5M/d
- 2025: $0.1883 -76.9% · H 1.15 L 0.1743 · Binance $18.4M/d
- 2026: $0.2403 +27.6% · H 0.3749 L 0.1375 · Binance $3.1M/d

**Sources**
- Binance JUPUSDT daily (2024-01-31 → 2026-11-08)
