---
tags: [trading, crypto, sushi]
---
**SUSHI**
- Data: 2020-09-01 → 2026-11-08 (2,260 days)
- Last $0.1774 (2026-11-08) · all-time high $22.82 (2021-03-13) · now -99.2% from high · lowest $0.1473 (2026-06-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $2.87 start · H 8.80 L 0.4900 · cap $509.5M (#48) · Binance $32.1M/d
- 2021: $9.43 +228.6% · H 22.82 L 3.20 · cap $2.3B (#46) · Binance $79.7M/d
- 2022: $0.9240 -90.2% · H 9.14 L 0.9230 · cap $227.7M (#65) · Binance $17.8M/d
- 2023: $1.25 +35.5% · H 1.55 L 0.5300 · cap $313.2M (#69) · Binance $8.4M/d
- 2024: $1.36 +8.5% · H 2.66 L 0.5000 · cap $378.3M (#65) · Binance $10.6M/d
- 2025: $0.2744 -79.8% · H 1.85 L 0.2718 · cap $78.8M (#78) · Binance $5.5M/d
- 2026: $0.1774 -35.3% · H 0.3554 L 0.1473 · cap $60.4M (#75) · Binance $752.4K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance SUSHIUSDT daily (2020-09-01 → 2026-11-08)
