---
tags: [trading, crypto, ae_eth]
---
**AE_ETH**
- Data: 2017-09-02 → 2026-05-23 (3,186 days)
- Last $0.0063 (2026-05-23) · all-time high $4.91 (2018-04-29) · now -99.9% from high · lowest $0.00363 (2025-10-10)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $1.29 start · H 1.57 L 0.2034 · cap $353.7M (#48)
- 2018: $0.3837 -70.3% · H 4.91 L 0.3266 · cap $105.0M (#42)
- 2019: $0.1283 -66.6% · H 0.6799 L 0.1283 · cap $35.1M (#59)
- 2020: $0.0830 -35.3% · H 0.2612 L 0.0774 · cap $22.7M (#96)
- 2021: $0.1129 +36.0% · H 0.4998 L 0.0752 · cap $30.9M (#109)
- 2022: $0.0683 -39.5% · H 0.1540 L 0.0638 · cap $18.7M (#100)
- 2023: $0.0227 -66.8% · H 0.0945 L 0.0169 · cap $6.2M (#107)
- 2024: $0.0316 +39.3% · H 0.0624 L 0.0165 · cap $8.7M (#108)
- 2025: $0.00652 -79.4% · H 0.0341 L 0.00363 · cap $1.8M (#107)
- 2026: $0.0063 -3.4% · H 0.0115 L 0.00609 · cap $1.7M (#103)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
