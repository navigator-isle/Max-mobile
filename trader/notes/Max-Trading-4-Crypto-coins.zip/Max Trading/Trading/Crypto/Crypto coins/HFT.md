---
tags: [trading, crypto, hft]
---
**HFT**
- Data: 2022-11-07 → 2026-08-17 (1,380 days)
- Last $0.00711 (2026-08-17) · all-time high $1.03 (2022-11-07) · now -99.3% from high · lowest $0.00671 (2026-08-15)
- Binance: stopped trading on Binance (delisted) after 2026-08-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.2844 start · H 1.03 L 0.2844 · Binance $18.0M/d
- 2023: $0.3724 +30.9% · H 0.8322 L 0.2113 · Binance $8.0M/d
- 2024: $0.2018 -45.8% · H 0.5174 L 0.1124 · Binance $2.8M/d
- 2025: $0.0268 -86.7% · H 0.2262 L 0.0251 · Binance $3.4M/d
- 2026: $0.00711 -73.5% · H 0.0318 L 0.00671 · Binance $995.6K/d

**Sources**
- Binance HFTUSDT daily (2022-11-07 → 2026-08-17)
