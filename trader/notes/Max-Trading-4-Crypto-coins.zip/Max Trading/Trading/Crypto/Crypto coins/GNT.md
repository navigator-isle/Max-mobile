---
tags: [trading, crypto, gnt]
---
**GNT**
- Data: 2017-02-19 → 2026-05-23 (3,381 days)
- Last $0.1390 (2026-05-23) · all-time high $1.10 (2018-01-04) · now -87.3% from high · lowest $0.0198 (2017-03-09)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.8521 start · H 0.8754 L 0.0198 · cap $852.1M (#36)
- 2018: $0.0646 -92.4% · H 1.10 L 0.0545 · cap $64.6M (#53)
- 2019: $0.0289 -55.2% · H 0.1048 L 0.0287 · cap $28.9M (#65)
- 2020: $0.1220 +321.9% · H 0.1504 L 0.0254 · cap $80.0M (#84)
- 2021: $0.4572 +274.9% · H 0.7987 L 0.1094 · cap $202.3M (#92)
- 2022: $0.1766 -61.4% · H 0.5791 L 0.1766 · cap $47.9M (#92)
- 2023: $0.2381 +34.8% · H 0.3128 L 0.1591 · cap $54.8M (#96)
- 2024: $0.3655 +53.5% · H 0.7148 L 0.2013 · cap $76.5M (#92)
- 2025: $0.2171 -40.6% · H 0.4283 L 0.1727 · cap $44.3M (#85)
- 2026: $0.1390 -36.0% · H 0.3300 L 0.1228 · cap $28.3M (#86)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
