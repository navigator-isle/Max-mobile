---
tags: [trading, crypto, theta]
---
**THETA**
- Data: 2019-04-10 → 2026-11-08 (2,770 days)
- Last $0.1419 (2026-11-08) · all-time high $14.20 (2021-04-16) · now -99.0% from high · lowest $0.0517 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0868 start · H 0.1507 L 0.0686 · Binance $414.8K/d
- 2020: $1.86 +2044.4% · H 1.86 L 0.0517 · Binance $6.4M/d
- 2021: $4.71 +152.9% · H 14.20 L 1.74 · Binance $121.8M/d
- 2022: $0.7230 -84.6% · H 4.94 L 0.7230 · Binance $22.2M/d
- 2023: $1.25 +72.9% · H 1.41 L 0.5650 · Binance $4.5M/d
- 2024: $2.23 +78.1% · H 3.46 L 0.9370 · Binance $15.9M/d
- 2025: $0.2640 -88.1% · H 2.56 L 0.2600 · Binance $5.1M/d
- 2026: $0.1419 -46.2% · H 0.3450 L 0.1235 · Binance $1.1M/d

**Sources**
- Binance THETAUSDT daily (2019-04-10 → 2026-11-08)
