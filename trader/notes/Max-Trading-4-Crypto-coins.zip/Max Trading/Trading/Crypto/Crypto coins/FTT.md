---
tags: [trading, crypto, ftt]
---
**FTT**
- Data: 2019-08-20 → 2026-11-08 (2,328 days)
- Last $0.2236 (2026-11-08) · all-time high $79.57 (2021-09-09) · now -99.7% from high · lowest $0.1926 (2026-07-31)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $2.14 start · H 2.27 L 1.15 · cap $743.7M (#21) · Binance $905.9K/d
- 2020: $5.76 +168.6% · H 5.76 L 2.02 · cap $2.0B (#24) · Binance $1.0M/d
- 2021: $38.25 +564.3% · H 79.57 L 5.81 · cap $12.9B (#22) · Binance $60.7M/d
- 2022: $1.43 -96.3% · H 51.99 L 1.43 · cap $278.0M (#59) · Binance $24.8M/d
- 2023: $3.06 +113.9% · H 5.57 L 1.01 · cap $1.0B (#48) · Binance $51.6M/d
- 2024: $3.71 +21.1% · H 3.80 L 1.14 · cap $1.2B (#44) · Binance $14.2M/d
- 2025: $0.4617 -87.6% · H 3.87 L 0.4583 · cap $152.4M (#63) · Binance $3.7M/d
- 2026: $0.2236 -51.6% · H 0.5725 L 0.1926 · cap $107.2M (#65) · Binance $537.9K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance FTTUSDT daily (2019-12-20 → 2026-11-08)
