---
tags: [trading, crypto, lrc]
---
**LRC**
- Data: 2020-06-12 → 2026-04-01 (2,120 days)
- Last $0.0188 (2026-04-01) · all-time high $3.41 (2021-11-24) · now -99.4% from high · lowest $0.0188 (2026-04-01)
- Binance: stopped trading on Binance (delisted) after 2026-04-01

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.1696 start · H 0.2630 L 0.0745 · Binance $2.3M/d
- 2021: $2.08 +1129.7% · H 3.41 L 0.1750 · Binance $61.1M/d
- 2022: $0.1878 -91.0% · H 2.10 L 0.1878 · Binance $22.8M/d
- 2023: $0.2983 +58.8% · H 0.4500 L 0.1612 · Binance $6.0M/d
- 2024: $0.1945 -34.8% · H 0.5390 L 0.1098 · Binance $5.6M/d
- 2025: $0.0495 -74.6% · H 0.2192 L 0.0486 · Binance $2.1M/d
- 2026: $0.0188 -62.0% · H 0.0553 L 0.0188 · Binance $882.8K/d

**Sources**
- Binance LRCUSDT daily (2020-06-12 → 2026-04-01)
