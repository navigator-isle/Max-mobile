---
tags: [trading, crypto, gun]
---
**GUN**
- Data: 2025-03-31 → 2026-11-08 (588 days)
- Last $0.00177 (2026-11-08) · all-time high $0.0775 (2025-03-31) · now -97.7% from high · lowest $0.00175 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0111 start · H 0.0775 L 0.0108 · Binance $7.9M/d
- 2026: $0.00177 -84.1% · H 0.0348 L 0.00175 · Binance $2.3M/d

**Sources**
- Binance GUNUSDT daily (2025-03-31 → 2026-11-08)
