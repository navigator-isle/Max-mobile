---
tags: [trading, crypto, xaut]
---
**XAUT**
- Data: 2020-01-25 → 2026-11-08 (2,480 days)
- Last $4,060 (2026-11-08) · all-time high $5,510 (2026-01-28) · now -26.3% from high · lowest $1,479 (2020-03-20)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1,913 start · H 2,023 L 1,479 · cap $91.2M (#80)
- 2021: $1,829 -4.4% · H 1,949 L 1,685 · cap $303.3M (#90)
- 2022: $1,816 -0.7% · H 2,050 L 1,626 · cap $447.7M (#56)
- 2023: $2,062 +13.6% · H 2,108 L 1,810 · cap $508.4M (#55)
- 2024: $2,624 +27.2% · H 2,787 L 1,992 · cap $646.8M (#55)
- 2025: $4,323 +64.8% · H 4,541 L 2,624 · cap $2.2B (#31)
- 2026: $4,060 -6.1% · H 5,510 L 3,880 · cap $3.2B (#26) · Binance $31.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XAUTUSDT daily (2026-03-26 → 2026-11-08)
