---
tags: [trading, crypto, cyber]
---
**CYBER**
- Data: 2023-08-15 → 2026-11-08 (1,182 days)
- Last $0.2920 (2026-11-08) · all-time high $14.35 (2024-03-31) · now -98.0% from high · lowest $0.2490 (2026-11-03)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $6.79 start · H 11.62 L 3.65 · Binance $33.3M/d
- 2024: $3.22 -52.6% · H 14.35 L 2.61 · Binance $9.1M/d
- 2025: $0.8070 -74.9% · H 3.67 L 0.6390 · Binance $3.6M/d
- 2026: $0.2920 -63.8% · H 0.8430 L 0.2490 · Binance $1.1M/d

**Sources**
- Binance CYBERUSDT daily (2023-08-15 → 2026-11-08)
