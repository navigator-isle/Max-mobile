---
tags: [trading, crypto, neiro]
---
**NEIRO**
- Data: 2024-09-16 → 2026-11-08 (784 days)
- Last $5.94e-05 (2026-11-08) · all-time high $0.00271 (2024-11-10) · now -97.8% from high · lowest $5.41e-05 (2026-04-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.000967 start · H 0.00271 L 0.00036 · Binance $248.8M/d
- 2025: $0.000103 -89.4% · H 0.00115 L 0.000103 · Binance $30.3M/d
- 2026: $5.94e-05 -42.2% · H 0.000151 L 5.41e-05 · Binance $3.0M/d

**Sources**
- Binance NEIROUSDT daily (2024-09-16 → 2026-11-08)
