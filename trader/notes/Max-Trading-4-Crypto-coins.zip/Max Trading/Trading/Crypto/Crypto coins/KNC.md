---
tags: [trading, crypto, knc]
---
**KNC**
- Data: 2017-09-27 → 2026-11-08 (3,330 days)
- Last $0.1043 (2026-11-08) · all-time high $5.57 (2022-04-27) · now -98.1% from high · lowest $0.0996 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $2.61 start · H 2.71 L 0.9349 · cap $562.4M (#45)
- 2018: $0.1514 -94.2% · H 5.40 L 0.1163 · cap $32.6M (#63)
- 2019: $0.1847 +22.0% · H 0.3682 L 0.1141 · cap $39.2M (#56)
- 2020: $0.7990 +332.5% · H 1.88 L 0.1851 · cap $167.8M (#71) · Binance $4.0M/d
- 2021: $1.28 +60.6% · H 3.78 L 0.7840 · cap $94.4M (#99) · Binance $11.1M/d
- 2022: $0.4560 -64.5% · H 5.57 L 0.4560 · cap $13.1M (#103) · Binance $13.0M/d
- 2023: $0.7020 +53.9% · H 0.9370 L 0.4570 · cap $16.4M (#102) · Binance $3.1M/d
- 2024: $0.5288 -24.7% · H 1.12 L 0.3967 · cap $6.7M (#110) · Binance $2.6M/d
- 2025: $0.2297 -56.6% · H 0.6392 L 0.2142 · cap $2.6M (#106) · Binance $1.7M/d
- 2026: $0.1043 -54.6% · H 0.2495 L 0.0996 · cap $1.7M (#104) · Binance $427.6K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance KNCUSDT daily (2020-06-12 → 2026-11-08)
