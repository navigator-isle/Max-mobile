---
tags: [trading, crypto, rlusd]
---
**RLUSD**
- Data: 2026-01-22 → 2026-11-08 (291 days)
- Last $1.00 (2026-11-08) · all-time high $1.00 (2026-02-04) · now -0.0% from high · lowest $0.9996 (2026-04-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $1.00 start · H 1.00 L 0.9996 · Binance $36.7M/d

**Sources**
- Binance RLUSDUSDT daily (2026-01-22 → 2026-11-08)
