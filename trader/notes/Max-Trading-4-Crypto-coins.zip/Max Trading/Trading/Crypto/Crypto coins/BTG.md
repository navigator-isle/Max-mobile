---
tags: [trading, crypto, btg]
---
**BTG**
- Data: 2017-10-25 → 2022-10-24 (1,826 days)
- Last $17.65 (2022-10-24) · all-time high $470.2 (2017-11-11) · now -96.2% from high · lowest $4.91 (2019-12-17)
- Binance: stopped trading on Binance (delisted) after 2022-10-24

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $240.7 start · H 470.2 L 121.7 · cap $4.1B (#15)
- 2018: $12.33 -94.9% · H 318.3 L 10.70 · cap $216.2M (#28)
- 2019: $5.29 -57.1% · H 31.31 L 4.91 · cap $96.1M (#44)
- 2020: $8.29 +56.8% · H 15.38 L 5.08 · cap $154.3M (#73)
- 2021: $40.48 +388.2% · H 141.1 L 8.34 · cap $766.1M (#71) · Binance $4.7M/d
- 2022: $17.65 -56.4% · H 44.32 L 14.89 · cap $223.9M (#66) · Binance $1.0M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance BTGUSDT daily (2021-04-16 → 2022-10-24)
