---
tags: [trading, crypto, fil]
---
**FIL**
- Data: 2020-10-15 → 2026-11-08 (2,216 days)
- Last $0.7764 (2026-11-08) · all-time high $190.9 (2021-03-31) · now -99.6% from high · lowest $0.6320 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $24.33 start · H 62.54 L 20.44 · Binance $24.0M/d
- 2021: $34.24 +40.7% · H 190.9 L 21.04 · Binance $211.3M/d
- 2022: $3.01 -91.2% · H 36.17 L 2.81 · Binance $46.6M/d
- 2023: $6.92 +129.9% · H 8.53 L 3.03 · Binance $36.4M/d
- 2024: $4.95 -28.4% · H 11.45 L 3.24 · Binance $59.4M/d
- 2025: $1.30 -73.8% · H 5.99 L 1.19 · Binance $25.5M/d
- 2026: $0.7764 -40.2% · H 1.59 L 0.6320 · Binance $11.3M/d

**Sources**
- Binance FILUSDT daily (2020-10-15 → 2026-11-08)
