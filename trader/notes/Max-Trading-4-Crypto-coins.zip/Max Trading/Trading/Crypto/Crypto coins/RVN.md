---
tags: [trading, crypto, rvn]
---
**RVN**
- Data: 2019-09-25 → 2026-11-08 (2,602 days)
- Last $0.00127 (2026-11-08) · all-time high $0.2349 (2021-04-14) · now -99.5% from high · lowest $0.00124 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0230 start · H 0.0384 L 0.0207 · Binance $706.3K/d
- 2020: $0.0125 -45.4% · H 0.0403 L 0.0111 · Binance $1.5M/d
- 2021: $0.0987 +686.9% · H 0.2349 L 0.0129 · Binance $30.1M/d
- 2022: $0.0185 -81.2% · H 0.1332 L 0.0183 · Binance $10.0M/d
- 2023: $0.0211 +13.6% · H 0.0349 L 0.0137 · Binance $2.7M/d
- 2024: $0.0202 -4.3% · H 0.0582 L 0.0146 · Binance $5.3M/d
- 2025: $0.00684 -66.1% · H 0.0235 L 0.00663 · Binance $2.8M/d
- 2026: $0.00127 -81.4% · H 0.00818 L 0.00124 · Binance $664.5K/d

**Sources**
- Binance RVNUSDT daily (2019-09-25 → 2026-11-08)
