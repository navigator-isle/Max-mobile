---
tags: [trading, crypto, icp]
---
**ICP**
- Data: 2021-05-11 → 2026-11-08 (2,008 days)
- Last $2.40 (2026-11-08) · all-time high $364.0 (2021-05-11) · now -99.3% from high · lowest $2.02 (2026-08-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $24.40 start · H 364.0 L 21.76 · cap $11.7B (#24) · Binance $124.2M/d
- 2022: $3.93 -83.9% · H 36.15 L 3.50 · cap $1.9B (#28) · Binance $30.4M/d
- 2023: $13.29 +237.8% · H 13.29 L 2.90 · cap $6.8B (#20) · Binance $13.6M/d
- 2024: $9.88 -25.6% · H 19.02 L 6.68 · cap $5.2B (#24) · Binance $37.6M/d
- 2025: $2.84 -71.3% · H 12.39 L 2.80 · cap $1.5B (#39) · Binance $19.3M/d
- 2026: $2.40 -15.5% · H 4.54 L 2.02 · cap $1.4B (#36) · Binance $9.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ICPUSDT daily (2021-05-11 → 2026-11-08)
