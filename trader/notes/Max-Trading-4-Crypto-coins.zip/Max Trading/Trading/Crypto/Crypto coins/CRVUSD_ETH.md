---
tags: [trading, crypto, crvusd_eth]
---
**CRVUSD_ETH**
- Data: 2024-06-17 → 2026-05-23 (706 days)
- Last $0.9993 (2026-05-23) · all-time high $1.10 (2024-09-23) · now -9.3% from high · lowest $0.9297 (2024-09-07)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.9983 start · H 1.10 L 0.9297 · cap $715.0M (#52)
- 2025: $0.9988 +0.0% · H 1.01 L 0.9958 · cap $2.1B (#33)
- 2026: $0.9993 +0.1% · H 1.00 L 0.9883 · cap $2.1B (#31)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
