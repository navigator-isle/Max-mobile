---
tags: [trading, crypto, xrpup]
---
**XRPUP**
- Data: 2020-09-11 → 2023-05-12 (974 days)
- Last $0.0855 (2023-05-12) · all-time high $66.17 (2020-11-24) · now -99.9% from high · lowest $0.0716 (2022-11-09)
- Binance: stopped trading on Binance (delisted) after 2023-05-12

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.84 start · H 66.17 L 1.66 · Binance $13.3M/d
- 2021: $2.18 +18.4% · H 28.14 L 1.44 · Binance $19.3M/d
- 2022: $0.0775 -96.4% · H 2.34 L 0.0716 · Binance $2.3M/d
- 2023: $0.0855 +10.3% · H 0.1548 L 0.0774 · Binance $549.0K/d

**Sources**
- Binance XRPUPUSDT daily (2020-09-11 → 2023-05-12)
