---
tags: [trading, crypto, ordi]
---
**ORDI**
- Data: 2023-11-07 → 2026-11-08 (1,098 days)
- Last $3.16 (2026-11-08) · all-time high $87.20 (2024-03-04) · now -96.4% from high · lowest $2.15 (2026-03-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $78.46 start · H 78.97 L 12.56 · Binance $215.5M/d
- 2024: $27.04 -65.5% · H 87.20 L 23.64 · Binance $79.0M/d
- 2025: $4.16 -84.6% · H 29.59 L 3.57 · Binance $12.3M/d
- 2026: $3.16 -24.0% · H 8.52 L 2.15 · Binance $5.0M/d

**Sources**
- Binance ORDIUSDT daily (2023-11-07 → 2026-11-08)
