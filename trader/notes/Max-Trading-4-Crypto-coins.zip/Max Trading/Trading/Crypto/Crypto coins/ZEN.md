---
tags: [trading, crypto, zen]
---
**ZEN**
- Data: 2020-07-06 → 2026-11-08 (2,317 days)
- Last $5.00 (2026-11-08) · all-time high $148.3 (2021-05-14) · now -96.6% from high · lowest $3.82 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $11.61 start · H 15.05 L 5.13 · Binance $1.2M/d
- 2021: $60.39 +420.2% · H 148.3 L 11.70 · Binance $20.9M/d
- 2022: $9.22 -84.7% · H 65.06 L 8.26 · Binance $3.9M/d
- 2023: $9.04 -2.0% · H 14.87 L 6.02 · Binance $3.0M/d
- 2024: $29.00 +220.8% · H 38.91 L 6.29 · Binance $9.9M/d
- 2025: $9.17 -68.4% · H 31.80 L 6.25 · Binance $17.5M/d
- 2026: $5.00 -45.4% · H 12.65 L 3.82 · Binance $5.0M/d

**Sources**
- Binance ZENUSDT daily (2020-07-06 → 2026-11-08)
