---
tags: [trading, crypto, cati]
---
**CATI**
- Data: 2024-09-20 → 2026-11-08 (780 days)
- Last $0.0385 (2026-11-08) · all-time high $0.9112 (2024-09-20) · now -95.8% from high · lowest $0.0330 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.3732 start · H 0.9112 L 0.2831 · Binance $30.6M/d
- 2025: $0.0610 -83.7% · H 0.4065 L 0.0601 · Binance $2.6M/d
- 2026: $0.0385 -36.8% · H 0.0714 L 0.0330 · Binance $578.2K/d

**Sources**
- Binance CATIUSDT daily (2024-09-20 → 2026-11-08)
