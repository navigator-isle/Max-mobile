---
tags: [trading, crypto, celr]
---
**CELR**
- Data: 2019-03-25 → 2026-11-08 (2,786 days)
- Last $0.00246 (2026-11-08) · all-time high $0.1785 (2021-09-24) · now -98.6% from high · lowest $0.00111 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00355 start · H 0.0242 L 0.00336 · Binance $3.1M/d
- 2020: $0.00443 +24.8% · H 0.0132 L 0.00111 · Binance $685.9K/d
- 2021: $0.0731 +1549.2% · H 0.1785 L 0.00479 · Binance $36.7M/d
- 2022: $0.00947 -87.0% · H 0.0978 L 0.00938 · Binance $9.2M/d
- 2023: $0.0216 +128.6% · H 0.0284 L 0.0096 · Binance $3.5M/d
- 2024: $0.0194 -10.3% · H 0.0387 L 0.0097 · Binance $2.9M/d
- 2025: $0.00364 -81.3% · H 0.0208 L 0.00339 · Binance $996.3K/d
- 2026: $0.00246 -32.4% · H 0.00457 L 0.00148 · Binance $529.0K/d

**Sources**
- Binance CELRUSDT daily (2019-03-25 → 2026-11-08)
