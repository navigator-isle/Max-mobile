---
tags: [trading, crypto, hot]
---
**HOT**
- Data: 2019-02-18 → 2026-11-08 (2,821 days)
- Last $0.000356 (2026-11-08) · all-time high $0.0286 (2021-04-05) · now -98.8% from high · lowest $0.000281 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.000626 start · H 0.00241 L 0.000583 · Binance $1.3M/d
- 2020: $0.000585 -6.5% · H 0.000907 L 0.000281 · Binance $807.0K/d
- 2021: $0.0073 +1147.9% · H 0.0286 L 0.000602 · Binance $86.8M/d
- 2022: $0.00142 -80.5% · H 0.00747 L 0.0014 · Binance $9.1M/d
- 2023: $0.00242 +70.5% · H 0.00267 L 0.000992 · Binance $3.4M/d
- 2024: $0.00232 -4.3% · H 0.00445 L 0.00125 · Binance $6.1M/d
- 2025: $0.000461 -80.1% · H 0.00273 L 0.000453 · Binance $1.8M/d
- 2026: $0.000356 -22.8% · H 0.000569 L 0.000291 · Binance $583.6K/d

**Sources**
- Binance HOTUSDT daily (2019-02-18 → 2026-11-08)
