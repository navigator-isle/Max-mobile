---
tags: [trading, crypto, alice]
---
**ALICE**
- Data: 2021-03-15 → 2026-11-08 (2,065 days)
- Last $0.1192 (2026-11-08) · all-time high $27.22 (2021-11-24) · now -99.6% from high · lowest $0.0984 (2026-06-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $12.48 start · H 27.22 L 3.59 · Binance $102.8M/d
- 2022: $1.06 -91.5% · H 13.65 L 1.05 · Binance $15.5M/d
- 2023: $1.38 +30.9% · H 2.15 L 0.6490 · Binance $2.9M/d
- 2024: $1.11 -19.8% · H 2.35 L 0.8030 · Binance $4.8M/d
- 2025: $0.1640 -85.2% · H 1.31 L 0.1640 · Binance $2.6M/d
- 2026: $0.1192 -27.3% · H 0.2114 L 0.0984 · Binance $1.5M/d

**Sources**
- Binance ALICEUSDT daily (2021-03-15 → 2026-11-08)
