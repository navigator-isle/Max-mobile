---
tags: [trading, crypto, tut]
---
**TUT**
- Data: 2025-03-27 → 2026-11-08 (592 days)
- Last $0.0171 (2026-11-08) · all-time high $0.2014 (2026-08-09) · now -91.5% from high · lowest $0.00827 (2026-03-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0150 start · H 0.1197 L 0.0114 · Binance $7.9M/d
- 2026: $0.0171 +14.3% · H 0.2014 L 0.00827 · Binance $5.4M/d

**Sources**
- Binance TUTUSDT daily (2025-03-27 → 2026-11-08)
