---
tags: [trading, crypto, virtual]
---
**VIRTUAL**
- Data: 2025-04-11 → 2026-11-08 (577 days)
- Last $0.5625 (2026-11-08) · all-time high $2.45 (2025-05-27) · now -77.0% from high · lowest $0.5185 (2026-02-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.6458 start · H 2.45 L 0.5280 · Binance $32.3M/d
- 2026: $0.5625 -12.9% · H 1.14 L 0.5185 · Binance $7.5M/d

**Sources**
- Binance VIRTUALUSDT daily (2025-04-11 → 2026-11-08)
