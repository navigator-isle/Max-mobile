---
tags: [trading, crypto, frax_eth]
---
**FRAX_ETH**
- Data: 2020-12-21 → 2026-05-23 (1,980 days)
- Last $0.9921 (2026-05-23) · all-time high $1.76 (2022-06-15) · now -43.7% from high · lowest $0.8624 (2021-03-24)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.9935 start · H 1.02 L 0.9587 · cap $57.2M (#87)
- 2021: $0.9989 +0.5% · H 1.12 L 0.8624 · cap $1.8B (#50)
- 2022: $0.9812 -1.8% · H 1.76 L 0.9483 · cap $999.3M (#33)
- 2023: $1.01 +3.1% · H 1.05 L 0.9351 · cap $656.7M (#51)
- 2024: $0.9950 -1.6% · H 1.02 L 0.9753 · cap $646.2M (#56)
- 2025: $0.9915 -0.4% · H 1.00 L 0.9914 · cap $277.9M (#54)
- 2026: $0.9921 +0.1% · H 0.9944 L 0.9904 · cap $273.7M (#52)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
