---
tags: [trading, crypto, ren]
---
**REN**
- Data: 2018-12-07 → 2024-12-10 (2,196 days)
- Last $0.0427 (2024-12-10) · all-time high $1.75 (2021-02-19) · now -97.6% from high · lowest $0.0156 (2019-02-24)
- Binance: stopped trading on Binance (delisted) after 2024-12-10

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.0202 start · H 0.0264 L 0.0181 · cap $20.2M (#67)
- 2019: $0.0310 +53.7% · H 0.1360 L 0.0156 · cap $30.9M (#63) · Binance $182.3K/d
- 2020: $0.3220 +939.0% · H 0.5755 L 0.0295 · cap $316.9M (#57) · Binance $3.5M/d
- 2021: $0.5286 +64.2% · H 1.75 L 0.2793 · cap $530.6M (#76) · Binance $18.7M/d
- 2022: $0.0616 -88.3% · H 0.5815 L 0.0555 · cap $61.6M (#85) · Binance $4.6M/d
- 2023: $0.0711 +15.4% · H 0.1283 L 0.0412 · cap $70.9M (#92) · Binance $3.5M/d
- 2024: $0.0427 -39.9% · H 0.1139 L 0.0305 · cap $31.1M (#105) · Binance $2.7M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance RENUSDT daily (2019-09-25 → 2024-12-10)
