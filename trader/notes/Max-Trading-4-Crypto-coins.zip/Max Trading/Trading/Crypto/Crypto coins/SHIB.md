---
tags: [trading, crypto, shib]
---
**SHIB**
- Data: 2021-05-10 → 2026-11-08 (2,009 days)
- Last $4.47e-06 (2026-11-08) · all-time high $7.91e-05 (2021-10-27) · now -94.3% from high · lowest $4.11e-06 (2026-07-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $3.34e-05 start · H 7.91e-05 L 5.89e-06 · Binance $658.0M/d
- 2022: $8.08e-06 -75.8% · H 3.42e-05 L 7.71e-06 · Binance $127.8M/d
- 2023: $1.04e-05 +28.2% · H 1.47e-05 L 6.56e-06 · Binance $41.9M/d
- 2024: $2.12e-05 +104.4% · H 3.59e-05 L 8.83e-06 · Binance $165.6M/d
- 2025: $6.91e-06 -67.4% · H 2.44e-05 L 6.91e-06 · Binance $29.6M/d
- 2026: $4.47e-06 -35.3% · H 9.27e-06 L 4.11e-06 · Binance $6.4M/d

**Sources**
- Binance SHIBUSDT daily (2021-05-10 → 2026-11-08)
