---
tags: [trading, crypto, io]
---
**IO**
- Data: 2024-06-11 → 2026-11-08 (881 days)
- Last $0.1185 (2026-11-08) · all-time high $5.68 (2024-06-12) · now -97.9% from high · lowest $0.0960 (2026-04-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $2.92 start · H 5.68 L 1.40 · Binance $43.2M/d
- 2025: $0.1530 -94.8% · H 3.91 L 0.1340 · Binance $9.0M/d
- 2026: $0.1185 -22.5% · H 0.1947 L 0.0960 · Binance $2.1M/d

**Sources**
- Binance IOUSDT daily (2024-06-11 → 2026-11-08)
