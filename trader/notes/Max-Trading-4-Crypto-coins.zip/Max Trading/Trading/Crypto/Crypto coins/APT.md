---
tags: [trading, crypto, apt]
---
**APT**
- Data: 2022-10-19 → 2026-11-08 (1,482 days)
- Last $0.5906 (2026-11-08) · all-time high $18.38 (2023-01-25) · now -96.8% from high · lowest $0.5180 (2026-08-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $3.45 start · H 9.78 L 3.21 · Binance $61.4M/d
- 2023: $9.39 +172.3% · H 18.38 L 3.52 · Binance $49.3M/d
- 2024: $8.71 -7.2% · H 18.07 L 4.98 · Binance $52.0M/d
- 2025: $1.66 -81.0% · H 10.17 L 1.45 · Binance $31.6M/d
- 2026: $0.5906 -64.4% · H 1.97 L 0.5180 · Binance $7.9M/d

**Sources**
- Binance APTUSDT daily (2022-10-19 → 2026-11-08)
