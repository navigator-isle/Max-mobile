---
tags: [trading, crypto, allo]
---
**ALLO**
- Data: 2025-11-11 → 2026-11-08 (363 days)
- Last $0.1488 (2026-11-08) · all-time high $0.5173 (2026-07-24) · now -71.2% from high · lowest $0.0520 (2026-02-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1129 start · H 0.4703 L 0.1020 · Binance $22.9M/d
- 2026: $0.1488 +31.8% · H 0.5173 L 0.0520 · Binance $7.3M/d

**Sources**
- Binance ALLOUSDT daily (2025-11-11 → 2026-11-08)
