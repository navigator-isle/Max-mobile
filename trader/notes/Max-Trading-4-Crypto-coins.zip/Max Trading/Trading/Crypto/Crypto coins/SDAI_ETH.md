---
tags: [trading, crypto, sdai_eth]
---
**SDAI_ETH**
- Data: 2024-08-08 → 2026-05-23 (654 days)
- Last $1.18 (2026-05-23) · all-time high $1.27 (2025-01-04) · now -7.5% from high · lowest $1.05 (2024-10-08)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.17 start · H 1.21 L 1.05 · cap $655.9M (#53)
- 2025: $1.17 -0.2% · H 1.27 L 1.12 · cap $197.0M (#59)
- 2026: $1.18 +0.5% · H 1.18 L 1.17 · cap $188.2M (#57)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
