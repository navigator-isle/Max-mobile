---
tags: [trading, crypto, arb]
---
**ARB**
- Data: 2023-03-23 → 2026-11-08 (1,327 days)
- Last $0.1700 (2026-11-08) · all-time high $2.26 (2024-01-11) · now -92.5% from high · lowest $0.0728 (2026-08-15)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $1.56 start · H 1.70 L 0.7623 · Binance $93.1M/d
- 2024: $0.7222 -53.7% · H 2.26 L 0.4733 · Binance $96.9M/d
- 2025: $0.1868 -74.1% · H 0.9190 L 0.1759 · Binance $36.4M/d
- 2026: $0.1700 -9.0% · H 0.2353 L 0.0728 · Binance $11.3M/d

**Sources**
- Binance ARBUSDT daily (2023-03-23 → 2026-11-08)
