---
tags: [trading, crypto, ai]
---
**AI**
- Data: 2024-01-04 → 2026-11-08 (1,040 days)
- Last $0.0156 (2026-11-08) · all-time high $2.26 (2024-03-09) · now -99.3% from high · lowest $0.0156 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.5641 start · H 2.26 L 0.3000 · Binance $22.3M/d
- 2025: $0.0381 -93.2% · H 0.8084 L 0.0341 · Binance $4.5M/d
- 2026: $0.0156 -59.1% · H 0.0442 L 0.0156 · Binance $1.6M/d

**Sources**
- Binance AIUSDT daily (2024-01-04 → 2026-11-08)
