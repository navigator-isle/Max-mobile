---
tags: [trading, crypto, usde_eth]
---
**USDE_ETH**
- Data: 2024-06-17 → 2026-05-23 (706 days)
- Last $0.9991 (2026-05-23) · all-time high $1.00 (2024-12-06) · now -0.4% from high · lowest $0.9954 (2025-02-21)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.9976 start · H 1.00 L 0.9962 · cap $5.9B (#23)
- 2025: $0.9980 +0.0% · H 1.00 L 0.9954 · cap $6.3B (#22)
- 2026: $0.9991 +0.1% · H 1.00 L 0.9975 · cap $4.4B (#22)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
