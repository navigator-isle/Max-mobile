---
tags: [trading, crypto, flow]
---
**FLOW**
- Data: 2021-02-10 → 2026-11-08 (2,098 days)
- Last $0.0205 (2026-11-08) · all-time high $38.90 (2021-03-04) · now -99.9% from high · lowest $0.0205 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $8.82 start · H 38.90 L 7.08 · Binance $22.2M/d
- 2022: $0.6530 -92.6% · H 9.26 L 0.6530 · Binance $11.7M/d
- 2023: $0.9110 +39.5% · H 1.39 L 0.3990 · Binance $7.6M/d
- 2024: $0.6970 -23.5% · H 1.64 L 0.4780 · cap $1.1B (#45) · Binance $6.8M/d
- 2025: $0.0850 -87.8% · H 0.8380 L 0.0850 · cap $146.3M (#64) · Binance $2.3M/d
- 2026: $0.0205 -75.9% · H 0.0940 L 0.0205 · cap $58.5M (#77) · Binance $1.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance FLOWUSDT daily (2021-07-30 → 2026-11-08)
