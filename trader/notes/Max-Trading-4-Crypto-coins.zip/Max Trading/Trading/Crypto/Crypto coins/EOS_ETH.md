---
tags: [trading, crypto, eos_eth]
---
**EOS_ETH**
- Data: 2017-06-29 → 2018-06-02 (339 days)
- Last $14.82 (2018-06-02) · all-time high $21.17 (2018-04-29) · now -30.0% from high · lowest $0.4931 (2017-10-23)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $7.77 start · H 11.58 L 0.4931 · cap $7.8B (#10)
- 2018: $14.82 +90.7% · H 21.17 L 4.59 · cap $14.8B (#6)

**Sources**
- Coin Metrics community data (daily, to 2018-06-02)
