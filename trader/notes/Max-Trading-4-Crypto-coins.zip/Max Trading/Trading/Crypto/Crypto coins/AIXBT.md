---
tags: [trading, crypto, aixbt]
---
**AIXBT**
- Data: 2025-01-10 → 2026-11-08 (668 days)
- Last $0.0150 (2026-11-08) · all-time high $0.8739 (2025-01-15) · now -98.3% from high · lowest $0.0150 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0337 start · H 0.8739 L 0.0264 · Binance $19.8M/d
- 2026: $0.0150 -55.4% · H 0.0445 L 0.0150 · Binance $1.5M/d

**Sources**
- Binance AIXBTUSDT daily (2025-01-10 → 2026-11-08)
