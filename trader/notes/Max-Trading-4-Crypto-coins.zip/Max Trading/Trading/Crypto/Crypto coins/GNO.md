---
tags: [trading, crypto, gno]
---
**GNO**
- Data: 2017-05-02 → 2026-11-08 (3,478 days)
- Last $111.5 (2026-11-08) · all-time high $587.9 (2021-11-08) · now -81.0% from high · lowest $8.77 (2018-12-14)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $209.4 start · H 339.7 L 55.26 · cap $2.1B (#22)
- 2018: $10.47 -95.0% · H 396.5 L 8.77 · cap $104.7M (#43)
- 2019: $11.23 +7.3% · H 24.22 L 10.44 · cap $112.3M (#41)
- 2020: $76.78 +583.8% · H 76.78 L 9.20 · cap $767.8M (#40)
- 2021: $530.5 +591.0% · H 587.9 L 72.63 · cap $5.3B (#31) · Binance $1.8M/d
- 2022: $83.20 -84.3% · H 528.7 L 79.80 · cap $826.0M (#39) · Binance $556.4K/d
- 2023: $195.0 +134.4% · H 243.1 L 83.50 · cap $1.9B (#34) · Binance $297.2K/d
- 2024: $266.1 +36.5% · H 441.1 L 139.8 · cap $2.7B (#36) · Binance $1.1M/d
- 2025: $127.7 -52.0% · H 287.7 L 94.30 · cap $1.3B (#40) · Binance $578.2K/d
- 2026: $111.5 -12.7% · H 147.9 L 90.56 · cap $1.2B (#39) · Binance $207.1K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance GNOUSDT daily (2021-08-30 → 2026-11-08)
