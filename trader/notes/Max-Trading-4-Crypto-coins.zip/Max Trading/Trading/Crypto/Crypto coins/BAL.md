---
tags: [trading, crypto, bal]
---
**BAL**
- Data: 2020-06-25 → 2025-04-16 (1,757 days)
- Last $0.9670 (2025-04-16) · all-time high $72.01 (2021-05-03) · now -98.7% from high · lowest $0.7850 (2025-04-08)
- Binance: stopped trading on Binance (delisted) after 2025-04-16

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $13.69 start · H 34.78 L 8.11 · cap $534.4M (#47) · Binance $2.3M/d
- 2021: $17.54 +28.1% · H 72.01 L 13.65 · cap $822.2M (#68) · Binance $7.8M/d
- 2022: $5.17 -70.5% · H 20.25 L 3.96 · cap $280.6M (#58) · Binance $2.7M/d
- 2023: $4.26 -17.6% · H 7.55 L 2.95 · cap $258.5M (#76) · Binance $1.3M/d
- 2024: $2.50 -41.3% · H 6.04 L 1.66 · cap $166.1M (#84) · Binance $1.5M/d
- 2025: $0.9670 -61.4% · H 3.09 L 0.7850 · cap $42.7M (#86) · Binance $1.0M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance BALUSDT daily (2020-08-11 → 2025-04-16)
