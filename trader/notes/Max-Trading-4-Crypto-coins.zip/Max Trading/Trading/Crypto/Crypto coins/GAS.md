---
tags: [trading, crypto, gas]
---
**GAS**
- Data: 2017-08-08 → 2026-11-08 (3,380 days)
- Last $1.07 (2026-11-08) · all-time high $86.91 (2018-01-15) · now -98.8% from high · lowest $0.7503 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $30.05 start · H 38.85 L 9.04 · cap $276.7M (#51)
- 2018: $2.11 -93.0% · H 86.91 L 1.59 · cap $25.7M (#66)
- 2019: $0.9069 -57.0% · H 3.83 L 0.8916 · cap $15.6M (#75)
- 2020: $1.51 +66.7% · H 2.39 L 0.7503 · cap $33.0M (#91)
- 2021: $5.69 +276.7% · H 19.81 L 1.48 · cap $156.1M (#97)
- 2022: $1.97 -65.4% · H 6.19 L 1.79 · cap $56.7M (#86)
- 2023: $6.85 +247.4% · H 22.67 L 2.01 · cap $196.5M (#81) · Binance $13.5M/d
- 2024: $4.46 -34.8% · H 7.91 L 2.83 · cap $131.6M (#85) · Binance $6.4M/d
- 2025: $2.03 -54.5% · H 6.05 L 1.75 · cap $73.9M (#82) · Binance $2.5M/d
- 2026: $1.07 -47.2% · H 2.18 L 0.9140 · Binance $630.4K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance GASUSDT daily (2023-03-17 → 2026-11-08)
