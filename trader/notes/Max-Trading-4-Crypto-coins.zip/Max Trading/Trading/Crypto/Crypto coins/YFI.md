---
tags: [trading, crypto, yfi]
---
**YFI**
- Data: 2020-07-25 → 2026-11-08 (2,298 days)
- Last $2,002 (2026-11-08) · all-time high $82,885 (2021-05-11) · now -97.6% from high · lowest $1,622 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $22,688 start · H 43,194 L 2,853 · cap $685.2M (#43) · Binance $70.3M/d
- 2021: $33,058 +45.7% · H 82,885 L 19,576 · cap $1.2B (#57) · Binance $40.3M/d
- 2022: $5,089 -84.6% · H 39,101 L 4,375 · cap $186.5M (#68) · Binance $9.4M/d
- 2023: $8,076 +58.7% · H 14,544 L 4,906 · cap $295.6M (#71) · Binance $5.3M/d
- 2024: $8,011 -0.8% · H 13,968 L 4,485 · cap $293.0M (#72) · Binance $5.1M/d
- 2025: $3,265 -59.2% · H 9,037 L 3,133 · cap $119.6M (#71) · Binance $2.1M/d
- 2026: $2,002 -38.7% · H 3,820 L 1,622 · cap $92.1M (#68) · Binance $524.3K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance YFIUSDT daily (2020-08-10 → 2026-11-08)
