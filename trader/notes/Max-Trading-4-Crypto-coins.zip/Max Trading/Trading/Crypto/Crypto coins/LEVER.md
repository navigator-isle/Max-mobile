---
tags: [trading, crypto, lever]
---
**LEVER**
- Data: 2022-07-13 → 2025-07-04 (1,088 days)
- Last $0.000175 (2025-07-04) · all-time high $0.00499 (2022-07-16) · now -96.5% from high · lowest $0.000175 (2025-07-04)
- Binance: stopped trading on Binance (delisted) after 2025-07-04

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.00165 start · H 0.00499 L 0.000933 · Binance $8.7M/d
- 2023: $0.00169 +2.1% · H 0.00299 L 0.00106 · Binance $6.3M/d
- 2024: $0.00174 +3.0% · H 0.00417 L 0.00128 · Binance $8.1M/d
- 2025: $0.000175 -89.9% · H 0.00198 L 0.000175 · Binance $2.8M/d

**Sources**
- Binance LEVERUSDT daily (2022-07-13 → 2025-07-04)
