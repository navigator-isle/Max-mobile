---
tags: [trading, crypto, huma]
---
**HUMA**
- Data: 2025-05-26 → 2026-11-08 (532 days)
- Last $0.0117 (2026-11-08) · all-time high $0.0669 (2025-05-26) · now -82.5% from high · lowest $0.0114 (2026-02-26)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0246 start · H 0.0669 L 0.0202 · Binance $9.6M/d
- 2026: $0.0117 -52.4% · H 0.0356 L 0.0114 · Binance $2.1M/d

**Sources**
- Binance HUMAUSDT daily (2025-05-26 → 2026-11-08)
