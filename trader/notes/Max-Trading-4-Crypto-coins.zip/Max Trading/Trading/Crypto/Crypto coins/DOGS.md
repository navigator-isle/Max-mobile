---
tags: [trading, crypto, dogs]
---
**DOGS**
- Data: 2024-08-26 → 2026-11-08 (805 days)
- Last $3.02e-05 (2026-11-08) · all-time high $0.00148 (2024-08-28) · now -98.0% from high · lowest $2.5e-05 (2026-03-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.000524 start · H 0.00148 L 0.000487 · Binance $65.6M/d
- 2025: $3.83e-05 -92.7% · H 0.000574 L 3.83e-05 · Binance $4.3M/d
- 2026: $3.02e-05 -21.2% · H 8.71e-05 L 2.5e-05 · Binance $1.6M/d

**Sources**
- Binance DOGSUSDT daily (2024-08-26 → 2026-11-08)
