---
tags: [trading, crypto, bsw]
---
**BSW**
- Data: 2022-03-21 → 2025-07-04 (1,202 days)
- Last $0.0112 (2025-07-04) · all-time high $1.70 (2022-04-01) · now -99.3% from high · lowest $0.0112 (2025-04-15)
- Binance: stopped trading on Binance (delisted) after 2025-07-04

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.1639 start · H 1.70 L 0.1632 · Binance $17.3M/d
- 2023: $0.1132 -30.9% · H 0.2382 L 0.0584 · Binance $2.2M/d
- 2024: $0.0753 -33.5% · H 0.1820 L 0.0434 · Binance $3.5M/d
- 2025: $0.0112 -85.1% · H 0.0840 L 0.0112 · Binance $5.0M/d

**Sources**
- Binance BSWUSDT daily (2022-03-21 → 2025-07-04)
