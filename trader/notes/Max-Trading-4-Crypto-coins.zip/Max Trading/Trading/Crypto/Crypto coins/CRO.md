---
tags: [trading, crypto, cro]
---
**CRO**
- Data: 2019-03-20 → 2026-05-23 (2,622 days)
- Last $0.0694 (2026-05-23) · all-time high $0.8964 (2021-11-23) · now -92.3% from high · lowest $0.0260 (2019-12-02)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0333 start · H 0.1014 L 0.0260 · cap $3.3B (#7)
- 2020: $0.0586 +76.0% · H 0.1827 L 0.0308 · cap $5.9B (#12)
- 2021: $0.5595 +854.1% · H 0.8964 L 0.0596 · cap $56.0B (#5)
- 2022: $0.0555 -90.1% · H 0.5878 L 0.0552 · cap $5.6B (#16)
- 2023: $0.0989 +78.0% · H 0.1093 L 0.0490 · cap $9.9B (#15)
- 2024: $0.1410 +42.6% · H 0.2146 L 0.0705 · cap $14.1B (#15)
- 2025: $0.0906 -35.7% · H 0.3335 L 0.0734 · cap $9.1B (#16)
- 2026: $0.0694 -23.4% · H 0.1105 L 0.0679 · cap $6.9B (#17)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
