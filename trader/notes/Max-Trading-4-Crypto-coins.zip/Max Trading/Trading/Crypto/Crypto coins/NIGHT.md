---
tags: [trading, crypto, night]
---
**NIGHT**
- Data: 2026-03-11 → 2026-11-08 (243 days)
- Last $0.0403 (2026-11-08) · all-time high $0.0521 (2026-10-05) · now -22.6% from high · lowest $0.0170 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0403 start · H 0.0521 L 0.0170 · Binance $41.6M/d

**Sources**
- Binance NIGHTUSDT daily (2026-03-11 → 2026-11-08)
