---
tags: [trading, crypto, og]
---
**OG**
- Data: 2020-12-30 → 2026-11-08 (2,140 days)
- Last $2.12 (2026-11-08) · all-time high $23.44 (2025-09-10) · now -91.0% from high · lowest $1.23 (2022-05-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $6.27 start · H 8.93 L 6.27 · Binance $9.7M/d
- 2021: $4.51 -28.1% · H 16.05 L 2.59 · Binance $3.9M/d
- 2022: $2.36 -47.7% · H 7.44 L 1.23 · Binance $3.9M/d
- 2023: $4.68 +98.5% · H 14.37 L 2.31 · Binance $9.7M/d
- 2024: $4.76 +1.8% · H 11.52 L 2.38 · Binance $7.7M/d
- 2025: $11.57 +143.0% · H 23.44 L 3.32 · Binance $5.7M/d
- 2026: $2.12 -81.7% · H 11.64 L 2.10 · Binance $1.8M/d

**Sources**
- Binance OGUSDT daily (2020-12-30 → 2026-11-08)
