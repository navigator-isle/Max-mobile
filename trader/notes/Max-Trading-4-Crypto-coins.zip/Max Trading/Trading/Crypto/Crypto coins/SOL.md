---
tags: [trading, crypto, sol]
---
**SOL**
- Data: 2020-08-11 → 2026-11-08 (2,281 days)
- Last $89.28 (2026-11-08) · all-time high $262.0 (2025-01-18) · now -65.9% from high · lowest $1.20 (2020-12-23)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.51 start · H 4.74 L 1.20 · Binance $5.0M/d
- 2021: $170.0 +11177.8% · H 258.4 L 1.80 · Binance $345.7M/d
- 2022: $9.97 -94.1% · H 179.1 L 9.64 · Binance $189.9M/d
- 2023: $101.7 +920.3% · H 120.9 L 9.99 · Binance $183.0M/d
- 2024: $189.3 +86.1% · H 256.9 L 83.84 · Binance $713.0M/d
- 2025: $124.7 -34.2% · H 262.0 L 105.4 · Binance $708.4M/d
- 2026: $89.28 -28.4% · H 146.7 L 62.20 · Binance $243.4M/d

**Sources**
- Binance SOLUSDT daily (2020-08-11 → 2026-11-08)
