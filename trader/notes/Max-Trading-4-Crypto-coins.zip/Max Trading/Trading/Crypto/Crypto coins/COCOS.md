---
tags: [trading, crypto, cocos]
---
**COCOS**
- Data: 2019-08-21 → 2023-05-29 (1,375 days)
- Last $1.75 (2023-05-29) · all-time high $5.36 (2021-11-24) · now -67.2% from high · lowest $0.000217 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2023-05-29

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.000573 start · H 0.00225 L 0.000573 · Binance $539.7K/d
- 2020: $0.000246 -57.1% · H 0.000755 L 0.000217 · Binance $253.2K/d
- 2021: $2.04 +828477.2% · H 5.36 L 0.000241 · Binance $20.3M/d
- 2022: $0.5012 -75.4% · H 2.18 L 0.4545 · Binance $5.3M/d
- 2023: $1.75 +250.1% · H 2.73 L 0.5051 · Binance $14.9M/d

**Sources**
- Binance COCOSUSDT daily (2019-08-21 → 2023-05-29)
