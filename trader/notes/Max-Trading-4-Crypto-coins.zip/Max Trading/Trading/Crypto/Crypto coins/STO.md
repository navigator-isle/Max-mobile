---
tags: [trading, crypto, sto]
---
**STO**
- Data: 2025-05-02 → 2026-11-08 (556 days)
- Last $0.0268 (2026-11-08) · all-time high $0.4481 (2026-04-01) · now -94.0% from high · lowest $0.0260 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0758 start · H 0.1970 L 0.0625 · Binance $4.8M/d
- 2026: $0.0268 -64.6% · H 0.4481 L 0.0260 · Binance $4.9M/d

**Sources**
- Binance STOUSDT daily (2025-05-02 → 2026-11-08)
