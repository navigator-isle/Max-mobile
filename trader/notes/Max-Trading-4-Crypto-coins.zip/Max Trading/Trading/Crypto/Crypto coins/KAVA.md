---
tags: [trading, crypto, kava]
---
**KAVA**
- Data: 2019-10-25 → 2026-11-08 (2,572 days)
- Last $0.0676 (2026-11-08) · all-time high $8.72 (2021-08-23) · now -99.2% from high · lowest $0.0402 (2026-08-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $1.12 start · H 1.30 L 0.7999 · Binance $3.0M/d
- 2020: $1.29 +15.5% · H 5.09 L 0.3450 · Binance $4.6M/d
- 2021: $3.95 +205.6% · H 8.72 L 1.29 · Binance $37.8M/d
- 2022: $0.5730 -85.5% · H 5.62 L 0.5730 · Binance $12.8M/d
- 2023: $0.8740 +52.5% · H 1.18 L 0.5370 · Binance $7.3M/d
- 2024: $0.4462 -48.9% · H 1.11 L 0.2781 · Binance $6.7M/d
- 2025: $0.0752 -83.1% · H 0.5584 L 0.0725 · Binance $3.7M/d
- 2026: $0.0676 -10.1% · H 0.0936 L 0.0402 · Binance $867.4K/d

**Sources**
- Binance KAVAUSDT daily (2019-10-25 → 2026-11-08)
