---
tags: [trading, crypto, auction]
---
**AUCTION**
- Data: 2021-10-29 → 2026-11-08 (1,837 days)
- Last $3.02 (2026-11-08) · all-time high $51.60 (2025-03-21) · now -94.1% from high · lowest $2.73 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $24.40 start · H 40.92 L 23.69 · Binance $3.2M/d
- 2022: $3.96 -83.8% · H 24.67 L 3.90 · Binance $2.7M/d
- 2023: $30.10 +660.1% · H 44.70 L 3.58 · Binance $6.8M/d
- 2024: $18.30 -39.2% · H 35.16 L 11.34 · Binance $9.4M/d
- 2025: $5.36 -70.7% · H 51.60 L 4.61 · Binance $8.4M/d
- 2026: $3.02 -43.6% · H 8.41 L 2.73 · Binance $1.1M/d

**Sources**
- Binance AUCTIONUSDT daily (2021-10-29 → 2026-11-08)
