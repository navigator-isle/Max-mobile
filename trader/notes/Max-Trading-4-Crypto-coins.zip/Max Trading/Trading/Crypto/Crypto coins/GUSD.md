---
tags: [trading, crypto, gusd]
---
**GUSD**
- Data: 2018-09-16 → 2026-05-23 (2,807 days)
- Last $0.9998 (2026-05-23) · all-time high $1.82 (2018-09-17) · now -45.1% from high · lowest $0.9353 (2020-03-13)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $1.00 start · H 1.82 L 0.9692 · cap $91.3M (#46)
- 2019: $0.9891 -1.5% · H 1.04 L 0.9506 · cap $3.8M (#82)
- 2020: $1.01 +1.7% · H 1.06 L 0.9353 · cap $15.9M (#103)
- 2021: $0.9992 -0.7% · H 1.02 L 0.9585 · cap $180.9M (#95)
- 2022: $1.0000 +0.1% · H 1.01 L 0.9542 · cap $577.5M (#48)
- 2023: $0.9992 -0.1% · H 1.01 L 0.9853 · cap $38.9M (#97)
- 2024: $0.9998 +0.1% · H 1.00 L 0.9847 · cap $58.8M (#96)
- 2025: $0.9999 +0.0% · H 1.00 L 0.9976 · cap $45.6M (#83)
- 2026: $0.9998 -0.0% · H 1.00 L 0.9994 · cap $40.5M (#80)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
