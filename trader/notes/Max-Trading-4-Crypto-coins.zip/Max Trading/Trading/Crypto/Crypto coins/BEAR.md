---
tags: [trading, crypto, bear]
---
**BEAR**
- Data: 2020-01-17 → 2020-03-31 (75 days)
- Last $11.16 (2020-03-31) · all-time high $58.62 (2020-03-12) · now -81.0% from high · lowest $10.82 (2020-03-26)
- Binance: stopped trading on Binance (delisted) after 2020-03-31

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $11.16 start · H 58.62 L 10.82 · Binance $11.9M/d

**Sources**
- Binance BEARUSDT daily (2020-01-17 → 2020-03-31)
