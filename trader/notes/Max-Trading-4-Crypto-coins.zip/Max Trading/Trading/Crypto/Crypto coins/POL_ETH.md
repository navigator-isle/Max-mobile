---
tags: [trading, crypto, pol_eth]
---
**POL_ETH**
- Data: 2023-10-25 → 2026-05-23 (942 days)
- Last $0.0911 (2026-05-23) · all-time high $1.27 (2024-03-13) · now -92.8% from high · lowest $0.0818 (2026-04-12)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.9718 start · H 1.04 L 0.6126 · cap $9.8B (#16)
- 2024: $0.4511 -53.6% · H 1.27 L 0.2914 · cap $4.7B (#26)
- 2025: $0.1005 -77.7% · H 0.5242 L 0.1005 · cap $1.1B (#42)
- 2026: $0.0911 -9.3% · H 0.1773 L 0.0818 · cap $970.1M (#42)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
