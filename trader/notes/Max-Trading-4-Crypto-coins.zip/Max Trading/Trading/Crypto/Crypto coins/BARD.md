---
tags: [trading, crypto, bard]
---
**BARD**
- Data: 2025-09-18 → 2026-11-08 (417 days)
- Last $0.1107 (2026-11-08) · all-time high $1.70 (2026-03-05) · now -93.5% from high · lowest $0.1028 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.7927 start · H 1.51 L 0.6236 · Binance $20.5M/d
- 2026: $0.1107 -86.0% · H 1.70 L 0.1028 · Binance $5.5M/d

**Sources**
- Binance BARDUSDT daily (2025-09-18 → 2026-11-08)
