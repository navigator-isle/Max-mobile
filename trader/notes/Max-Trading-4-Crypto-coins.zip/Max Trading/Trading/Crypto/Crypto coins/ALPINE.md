---
tags: [trading, crypto, alpine]
---
**ALPINE**
- Data: 2022-02-21 → 2026-11-08 (1,722 days)
- Last $0.2900 (2026-11-08) · all-time high $9.54 (2022-03-18) · now -97.0% from high · lowest $0.2820 (2026-10-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $2.02 start · H 9.54 L 1.43 · Binance $15.0M/d
- 2023: $1.88 -7.2% · H 4.34 L 1.55 · Binance $3.0M/d
- 2024: $1.37 -27.1% · H 2.77 L 0.9670 · Binance $2.2M/d
- 2025: $0.5950 -56.5% · H 6.66 L 0.4930 · Binance $5.4M/d
- 2026: $0.2900 -51.3% · H 0.6210 L 0.2820 · Binance $490.2K/d

**Sources**
- Binance ALPINEUSDT daily (2022-02-21 → 2026-11-08)
