---
tags: [trading, crypto, usdc_trx]
---
**USDC_TRX**
- Data: 2021-06-09 → 2026-05-23 (1,810 days)
- Last $0.9997 (2026-05-23) · all-time high $1.01 (2023-05-08) · now -0.9% from high · lowest $0.9706 (2023-03-11)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.9998 start · H 1.00 L 0.9995 · cap $377.9M (#84)
- 2022: $0.9999 +0.0% · H 1.00 L 0.9987 · cap $1.1B (#31)
- 2023: $0.9999 +0.0% · H 1.01 L 0.9706 · cap $266.5M (#73)
- 2024: $0.9998 -0.0% · H 1.00 L 0.9996 · cap $55.1M (#98)
- 2025: $0.9996 -0.0% · H 1.00 L 0.9990 · cap $39.4M (#88)
- 2026: $0.9997 +0.0% · H 1.00 L 0.9995 · cap $28.4M (#85)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
