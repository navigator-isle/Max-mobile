---
tags: [trading, crypto, dar]
---
**DAR**
- Data: 2021-11-04 → 2025-01-06 (1,160 days)
- Last $0.2171 (2025-01-06) · all-time high $4.17 (2021-11-24) · now -94.8% from high · lowest $0.0772 (2023-10-19)
- Binance: stopped trading on Binance (delisted) after 2025-01-06

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $2.10 start · H 4.17 L 1.78 · Binance $103.0M/d
- 2022: $0.1152 -94.5% · H 2.09 L 0.1139 · Binance $21.1M/d
- 2023: $0.1504 +30.5% · H 0.2746 L 0.0772 · Binance $3.5M/d
- 2024: $0.1664 +10.6% · H 0.2818 L 0.1035 · Binance $5.5M/d
- 2025: $0.2171 +30.5% · H 0.2171 L 0.1718 · Binance $10.6M/d

**Sources**
- Binance DARUSDT daily (2021-11-04 → 2025-01-06)
