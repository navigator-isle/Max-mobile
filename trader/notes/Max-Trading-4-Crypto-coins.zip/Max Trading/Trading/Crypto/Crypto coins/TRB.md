---
tags: [trading, crypto, trb]
---
**TRB**
- Data: 2020-08-29 → 2026-11-08 (2,263 days)
- Last $15.26 (2026-11-08) · all-time high $262.2 (2023-12-30) · now -94.2% from high · lowest $8.28 (2022-05-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $17.74 start · H 74.99 L 13.88 · Binance $5.2M/d
- 2021: $33.06 +86.4% · H 146.2 L 17.74 · Binance $12.0M/d
- 2022: $12.18 -63.2% · H 45.21 L 8.28 · Binance $4.4M/d
- 2023: $192.9 +1483.8% · H 262.2 L 8.67 · Binance $14.3M/d
- 2024: $63.49 -67.1% · H 182.7 L 46.07 · Binance $29.6M/d
- 2025: $20.05 -68.4% · H 67.59 L 18.07 · Binance $8.0M/d
- 2026: $15.26 -23.9% · H 23.44 L 12.80 · Binance $1.4M/d

**Sources**
- Binance TRBUSDT daily (2020-08-29 → 2026-11-08)
