---
tags: [trading, crypto, near]
---
**NEAR**
- Data: 2020-10-14 → 2026-11-08 (2,217 days)
- Last $3.71 (2026-11-08) · all-time high $20.18 (2022-01-14) · now -81.6% from high · lowest $0.5338 (2020-11-04)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.39 start · H 1.39 L 0.5338 · Binance $9.2M/d
- 2021: $14.62 +950.9% · H 16.26 L 1.36 · Binance $63.3M/d
- 2022: $1.26 -91.4% · H 20.18 L 1.26 · Binance $94.8M/d
- 2023: $3.65 +190.6% · H 4.30 L 0.9870 · Binance $25.4M/d
- 2024: $4.91 +34.6% · H 8.86 L 2.65 · Binance $85.8M/d
- 2025: $1.51 -69.2% · H 6.02 L 1.43 · Binance $39.1M/d
- 2026: $3.71 +144.9% · H 5.90 L 0.9620 · Binance $57.2M/d

**Sources**
- Binance NEARUSDT daily (2020-10-14 → 2026-11-08)
