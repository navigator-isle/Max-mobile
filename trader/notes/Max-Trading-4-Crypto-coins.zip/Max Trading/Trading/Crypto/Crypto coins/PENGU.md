---
tags: [trading, crypto, pengu]
---
**PENGU**
- Data: 2024-12-17 → 2026-11-08 (692 days)
- Last $0.00634 (2026-11-08) · all-time high $0.0431 (2025-07-27) · now -85.3% from high · lowest $0.00387 (2025-04-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.0333 start · H 0.0382 L 0.0260 · Binance $200.4M/d
- 2025: $0.00868 -74.0% · H 0.0431 L 0.00387 · Binance $56.0M/d
- 2026: $0.00634 -26.9% · H 0.0133 L 0.00576 · Binance $11.8M/d

**Sources**
- Binance PENGUUSDT daily (2024-12-17 → 2026-11-08)
