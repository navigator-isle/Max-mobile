---
tags: [trading, crypto, cake]
---
**CAKE**
- Data: 2021-02-19 → 2026-11-08 (2,089 days)
- Last $1.89 (2026-11-08) · all-time high $42.68 (2021-04-29) · now -95.6% from high · lowest $1.05 (2023-10-19)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $11.74 start · H 42.68 L 9.38 · Binance $96.2M/d
- 2022: $3.17 -73.0% · H 12.34 L 2.67 · Binance $12.8M/d
- 2023: $3.47 +9.4% · H 4.69 L 1.05 · Binance $11.6M/d
- 2024: $2.51 -27.7% · H 5.17 L 1.42 · Binance $17.3M/d
- 2025: $1.89 -24.9% · H 4.37 L 1.37 · Binance $27.9M/d
- 2026: $1.89 +0.5% · H 2.83 L 1.16 · Binance $4.0M/d

**Sources**
- Binance CAKEUSDT daily (2021-02-19 → 2026-11-08)
