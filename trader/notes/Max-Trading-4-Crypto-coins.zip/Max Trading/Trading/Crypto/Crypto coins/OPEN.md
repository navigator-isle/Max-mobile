---
tags: [trading, crypto, open]
---
**OPEN**
- Data: 2025-09-08 → 2026-11-08 (427 days)
- Last $0.0896 (2026-11-08) · all-time high $1.43 (2025-09-08) · now -93.8% from high · lowest $0.0826 (2026-11-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1569 start · H 1.43 L 0.1569 · Binance $40.1M/d
- 2026: $0.0896 -42.9% · H 0.2764 L 0.0826 · Binance $1.8M/d

**Sources**
- Binance OPENUSDT daily (2025-09-08 → 2026-11-08)
