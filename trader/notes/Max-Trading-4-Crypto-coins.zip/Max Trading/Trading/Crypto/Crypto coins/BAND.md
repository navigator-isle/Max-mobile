---
tags: [trading, crypto, band]
---
**BAND**
- Data: 2019-09-18 → 2026-11-08 (2,609 days)
- Last $0.1777 (2026-11-08) · all-time high $20.96 (2021-04-16) · now -99.2% from high · lowest $0.1390 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.2225 start · H 0.8110 L 0.2167 · Binance $556.2K/d
- 2020: $5.35 +2304.1% · H 15.52 L 0.2189 · Binance $9.2M/d
- 2021: $5.01 -6.3% · H 20.96 L 4.39 · Binance $20.6M/d
- 2022: $1.41 -71.9% · H 6.24 L 1.02 · Binance $5.8M/d
- 2023: $2.20 +56.2% · H 2.25 L 0.9630 · Binance $3.1M/d
- 2024: $1.41 -35.8% · H 2.76 L 0.9340 · Binance $2.7M/d
- 2025: $0.3240 -77.0% · H 1.60 L 0.3030 · Binance $1.2M/d
- 2026: $0.1777 -45.2% · H 0.3670 L 0.1390 · Binance $279.2K/d

**Sources**
- Binance BANDUSDT daily (2019-09-18 → 2026-11-08)
