---
tags: [trading, crypto, usdm_eth]
---
**USDM_ETH**
- Data: 2024-06-18 → 2025-08-07 (416 days)
- Last $0.9997 (2025-08-07) · all-time high $1.09 (2025-04-25) · now -8.2% from high · lowest $0.9329 (2024-07-18)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.9930 start · H 1.02 L 0.9329 · cap $39.2M (#103)
- 2025: $0.9997 +0.7% · H 1.09 L 0.9924 · cap $2.4M (#109)

**Sources**
- Coin Metrics community data (daily, to 2025-08-07)
