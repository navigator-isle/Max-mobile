---
tags: [trading, crypto, rndr]
---
**RNDR**
- Data: 2021-11-27 → 2024-07-22 (969 days)
- Last $7.03 (2024-07-22) · all-time high $13.14 (2024-03-17) · now -46.5% from high · lowest $0.3230 (2022-06-18)
- Binance: stopped trading on Binance (delisted) after 2024-07-22

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $4.60 start · H 7.47 L 3.50 · Binance $15.9M/d
- 2022: $0.4030 -91.2% · H 5.26 L 0.3230 · Binance $5.4M/d
- 2023: $4.47 +1009.4% · H 5.17 L 0.4040 · Binance $25.0M/d
- 2024: $7.03 +57.2% · H 13.14 L 3.63 · Binance $71.8M/d

**Sources**
- Binance RNDRUSDT daily (2021-11-27 → 2024-07-22)
