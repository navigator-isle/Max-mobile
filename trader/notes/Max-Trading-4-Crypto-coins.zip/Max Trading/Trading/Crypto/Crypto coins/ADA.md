---
tags: [trading, crypto, ada]
---
**ADA**
- Data: 2017-12-01 → 2026-11-08 (3,265 days)
- Last $0.1798 (2026-11-08) · all-time high $2.97 (2021-09-03) · now -93.9% from high · lowest $0.0233 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.7276 start · H 0.7276 L 0.1072 · cap $22.6B (#6)
- 2018: $0.0405 -94.4% · H 1.16 L 0.0281 · cap $1.3B (#10) · Binance $15.8M/d
- 2019: $0.0328 -19.0% · H 0.0981 L 0.0317 · cap $1.0B (#16) · Binance $8.7M/d
- 2020: $0.1813 +452.0% · H 0.1907 L 0.0233 · cap $5.8B (#13) · Binance $36.9M/d
- 2021: $1.31 +621.3% · H 2.97 L 0.1751 · cap $43.2B (#6) · Binance $590.4M/d
- 2022: $0.2458 -81.2% · H 1.60 L 0.2440 · cap $8.3B (#11) · Binance $114.8M/d
- 2023: $0.5940 +141.7% · H 0.6675 L 0.2421 · cap $20.5B (#9) · Binance $45.0M/d
- 2024: $0.8451 +42.3% · H 1.23 L 0.3119 · cap $29.9B (#11) · Binance $107.3M/d
- 2025: $0.3335 -60.5% · H 1.14 L 0.3335 · cap $12.1B (#12) · Binance $134.5M/d
- 2026: $0.1798 -46.1% · H 0.4218 L 0.1438 · cap $9.0B (#13) · Binance $33.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ADAUSDT daily (2018-04-17 → 2026-11-08)
