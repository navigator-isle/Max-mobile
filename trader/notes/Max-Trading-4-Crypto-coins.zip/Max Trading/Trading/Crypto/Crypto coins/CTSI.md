---
tags: [trading, crypto, ctsi]
---
**CTSI**
- Data: 2020-04-23 → 2026-11-08 (2,391 days)
- Last $0.0246 (2026-11-08) · all-time high $1.72 (2021-05-08) · now -98.6% from high · lowest $0.0208 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.0403 start · H 0.1058 L 0.0275 · Binance $1.2M/d
- 2021: $0.6869 +1602.8% · H 1.72 L 0.0418 · Binance $26.5M/d
- 2022: $0.1028 -85.0% · H 0.7142 L 0.0956 · Binance $3.9M/d
- 2023: $0.2123 +106.5% · H 0.3194 L 0.1048 · Binance $4.2M/d
- 2024: $0.1532 -27.8% · H 0.4243 L 0.1114 · Binance $4.2M/d
- 2025: $0.0315 -79.4% · H 0.1751 L 0.0304 · Binance $1.5M/d
- 2026: $0.0246 -21.9% · H 0.0424 L 0.0208 · Binance $844.5K/d

**Sources**
- Binance CTSIUSDT daily (2020-04-23 → 2026-11-08)
