---
tags: [trading, crypto, hmstr]
---
**HMSTR**
- Data: 2024-09-26 → 2026-11-08 (774 days)
- Last $0.000143 (2026-11-08) · all-time high $0.0068 (2024-09-27) · now -97.9% from high · lowest $0.000126 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.00298 start · H 0.0068 L 0.00231 · Binance $33.4M/d
- 2025: $0.000212 -92.9% · H 0.00342 L 0.000198 · Binance $3.1M/d
- 2026: $0.000143 -32.9% · H 0.000393 L 0.000126 · Binance $1.8M/d

**Sources**
- Binance HMSTRUSDT daily (2024-09-26 → 2026-11-08)
