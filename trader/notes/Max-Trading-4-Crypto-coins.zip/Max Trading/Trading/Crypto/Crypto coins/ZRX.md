---
tags: [trading, crypto, zrx]
---
**ZRX**
- Data: 2017-08-11 → 2026-11-08 (3,377 days)
- Last $0.0907 (2026-11-08) · all-time high $2.34 (2018-01-13) · now -96.1% from high · lowest $0.0747 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.9038 start · H 0.9038 L 0.1240 · cap $903.8M (#33)
- 2018: $0.2926 -67.6% · H 2.34 L 0.2619 · cap $292.6M (#20)
- 2019: $0.1815 -38.0% · H 0.3743 L 0.1545 · cap $180.3M (#36) · Binance $537.9K/d
- 2020: $0.3548 +95.5% · H 0.7305 L 0.1381 · cap $353.6M (#53) · Binance $3.4M/d
- 2021: $0.8042 +126.7% · H 2.30 L 0.3604 · cap $805.7M (#70) · Binance $16.2M/d
- 2022: $0.1479 -81.6% · H 1.10 L 0.1479 · cap $148.0M (#72) · Binance $4.8M/d
- 2023: $0.3715 +151.2% · H 0.5254 L 0.1506 · cap $369.0M (#65) · Binance $4.1M/d
- 2024: $0.4572 +23.1% · H 1.36 L 0.2610 · cap $455.3M (#62) · Binance $8.0M/d
- 2025: $0.1412 -69.1% · H 0.5484 L 0.1165 · cap $140.9M (#67) · Binance $2.4M/d
- 2026: $0.0907 -35.8% · H 0.1556 L 0.0747 · cap $107.3M (#63) · Binance $357.7K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ZRXUSDT daily (2019-02-28 → 2026-11-08)
