---
tags: [trading, crypto, arkm]
---
**ARKM**
- Data: 2023-07-18 → 2026-11-08 (1,210 days)
- Last $0.0994 (2026-11-08) · all-time high $3.98 (2024-03-09) · now -97.5% from high · lowest $0.0861 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.5860 start · H 0.7480 L 0.2906 · Binance $11.4M/d
- 2024: $1.39 +136.5% · H 3.98 L 0.4955 · Binance $30.1M/d
- 2025: $0.1750 -87.4% · H 1.70 L 0.1750 · Binance $11.7M/d
- 2026: $0.0994 -43.2% · H 0.2260 L 0.0861 · Binance $1.7M/d

**Sources**
- Binance ARKMUSDT daily (2023-07-18 → 2026-11-08)
