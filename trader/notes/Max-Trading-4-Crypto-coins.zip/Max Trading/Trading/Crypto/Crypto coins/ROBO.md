---
tags: [trading, crypto, robo]
---
**ROBO**
- Data: 2026-03-04 → 2026-11-08 (250 days)
- Last $0.00466 (2026-11-08) · all-time high $0.0441 (2026-03-09) · now -89.4% from high · lowest $0.00456 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.00466 start · H 0.0441 L 0.00456 · Binance $5.7M/d

**Sources**
- Binance ROBOUSDT daily (2026-03-04 → 2026-11-08)
