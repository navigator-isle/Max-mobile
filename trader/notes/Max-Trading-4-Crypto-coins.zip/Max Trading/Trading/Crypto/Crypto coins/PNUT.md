---
tags: [trading, crypto, pnut]
---
**PNUT**
- Data: 2024-11-11 → 2026-11-08 (728 days)
- Last $0.0339 (2026-11-08) · all-time high $1.79 (2024-11-17) · now -98.1% from high · lowest $0.0339 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.6734 start · H 1.79 L 0.3908 · Binance $404.0M/d
- 2025: $0.0688 -89.8% · H 0.7597 L 0.0678 · Binance $39.0M/d
- 2026: $0.0339 -50.7% · H 0.0967 L 0.0339 · Binance $1.8M/d

**Sources**
- Binance PNUTUSDT daily (2024-11-11 → 2026-11-08)
