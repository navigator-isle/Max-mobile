---
tags: [trading, crypto, prove]
---
**PROVE**
- Data: 2025-08-05 → 2026-11-08 (461 days)
- Last $0.1786 (2026-11-08) · all-time high $1.60 (2025-08-11) · now -88.9% from high · lowest $0.1456 (2026-08-14)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.3982 start · H 1.60 L 0.3487 · Binance $19.1M/d
- 2026: $0.1786 -55.1% · H 0.4669 L 0.1456 · Binance $2.6M/d

**Sources**
- Binance PROVEUSDT daily (2025-08-05 → 2026-11-08)
