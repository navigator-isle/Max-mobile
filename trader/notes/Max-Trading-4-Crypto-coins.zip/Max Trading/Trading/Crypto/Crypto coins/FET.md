---
tags: [trading, crypto, fet]
---
**FET**
- Data: 2019-02-28 → 2026-11-08 (2,811 days)
- Last $0.1431 (2026-11-08) · all-time high $3.26 (2024-03-28) · now -95.6% from high · lowest $0.00987 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0371 start · H 0.4426 L 0.0336 · Binance $6.5M/d
- 2020: $0.0515 +38.9% · H 0.1576 L 0.00987 · Binance $2.0M/d
- 2021: $0.5025 +875.3% · H 0.9497 L 0.0513 · Binance $26.4M/d
- 2022: $0.0917 -81.8% · H 0.5690 L 0.0547 · Binance $5.5M/d
- 2023: $0.6725 +633.4% · H 0.7666 L 0.0915 · Binance $24.7M/d
- 2024: $1.27 +89.1% · H 3.26 L 0.5245 · Binance $75.5M/d
- 2025: $0.1986 -84.4% · H 1.61 L 0.1953 · Binance $28.0M/d
- 2026: $0.1431 -27.9% · H 0.2955 L 0.1215 · Binance $13.0M/d

**Sources**
- Binance FETUSDT daily (2019-02-28 → 2026-11-08)
