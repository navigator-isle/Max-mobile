---
tags: [trading, crypto, stmx]
---
**STMX**
- Data: 2020-06-11 → 2025-02-24 (1,720 days)
- Last $0.00456 (2025-02-24) · all-time high $0.0850 (2021-04-02) · now -94.6% from high · lowest $0.0018 (2020-11-04)
- Binance: stopped trading on Binance (delisted) after 2025-02-24

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.00223 start · H 0.00368 L 0.0018 · Binance $579.3K/d
- 2021: $0.0210 +843.9% · H 0.0850 L 0.00242 · Binance $22.0M/d
- 2022: $0.00352 -83.2% · H 0.0248 L 0.00348 · Binance $2.5M/d
- 2023: $0.00879 +149.5% · H 0.0102 L 0.00333 · Binance $4.8M/d
- 2024: $0.00596 -32.2% · H 0.0133 L 0.00427 · Binance $5.4M/d
- 2025: $0.00456 -23.5% · H 0.00672 L 0.00358 · Binance $3.9M/d

**Sources**
- Binance STMXUSDT daily (2020-06-11 → 2025-02-24)
