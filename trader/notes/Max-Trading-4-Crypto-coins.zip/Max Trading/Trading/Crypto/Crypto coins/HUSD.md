---
tags: [trading, crypto, husd]
---
**HUSD**
- Data: 2019-07-18 → 2022-11-17 (1,219 days)
- Last $0.9904 (2022-11-17) · all-time high $1.01 (2019-07-21) · now -2.3% from high · lowest $0.9591 (2022-08-17)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.9993 start · H 1.01 L 0.9973 · cap $97.0M (#42)
- 2020: $1.00 +0.1% · H 1.01 L 0.9970 · cap $143.1M (#75)
- 2021: $1.00 -0.0% · H 1.00 L 0.9992 · cap $323.2M (#89)
- 2022: $0.9904 -1.0% · H 1.00 L 0.9591 · cap $186.0M (#71)

**Sources**
- Coin Metrics community data (daily, to 2022-11-17)
