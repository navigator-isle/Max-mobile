---
tags: [trading, crypto, mmt]
---
**MMT**
- Data: 2025-11-04 → 2026-11-08 (370 days)
- Last $0.1217 (2026-11-08) · all-time high $2.64 (2025-11-04) · now -95.4% from high · lowest $0.1019 (2026-06-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.2286 start · H 2.64 L 0.1812 · Binance $52.7M/d
- 2026: $0.1217 -46.8% · H 0.2573 L 0.1019 · Binance $3.1M/d

**Sources**
- Binance MMTUSDT daily (2025-11-04 → 2026-11-08)
