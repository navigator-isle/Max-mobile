---
tags: [trading, crypto, lunc]
---
**LUNC**
- Data: 2022-09-09 → 2026-11-08 (1,522 days)
- Last $3.98e-05 (2026-11-08) · all-time high $0.000437 (2022-09-10) · now -90.9% from high · lowest $2.67e-05 (2025-11-23)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.000145 start · H 0.000437 L 0.000129 · Binance $43.0M/d
- 2023: $0.000139 -4.3% · H 0.000258 L 5.54e-05 · Binance $21.5M/d
- 2024: $0.000108 -22.1% · H 0.000202 L 6.39e-05 · Binance $21.2M/d
- 2025: $4.22e-05 -61.0% · H 0.000121 L 2.67e-05 · Binance $6.1M/d
- 2026: $3.98e-05 -5.6% · H 0.000115 L 3.26e-05 · Binance $4.2M/d

**Sources**
- Binance LUNCUSDT daily (2022-09-09 → 2026-11-08)
