---
tags: [trading, crypto, fun]
---
**FUN**
- Data: 2017-09-02 → 2026-04-23 (3,156 days)
- Last $0.000342 (2026-04-23) · all-time high $0.1842 (2018-01-08) · now -99.8% from high · lowest $0.000326 (2026-04-22)
- Binance: stopped trading on Binance (delisted) after 2026-04-23

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.0865 start · H 0.0872 L 0.0128 · cap $951.3M (#32)
- 2018: $0.00405 -95.3% · H 0.1842 L 0.00344 · cap $44.5M (#59)
- 2019: $0.00317 -21.7% · H 0.00666 L 0.00221 · cap $35.3M (#58) · Binance $49.4K/d
- 2020: $0.00496 +56.7% · H 0.00568 L 0.00126 · cap $57.1M (#88) · Binance $144.2K/d
- 2021: $0.0147 +196.3% · H 0.0522 L 0.00552 · cap $160.9M (#96) · Binance $11.7M/d
- 2022: $0.006 -59.2% · H 0.0136 L 0.006 · cap $65.6M (#84) · Binance $685.7K/d
- 2023: $0.00646 +7.6% · H 0.00936 L 0.00365 · cap $70.0M (#93) · Binance $1.7M/d
- 2024: $0.00472 -26.9% · H 0.00734 L 0.00285 · cap $51.0M (#99) · Binance $2.0M/d
- 2025: $0.00182 -61.5% · H 0.0229 L 0.00164 · cap $19.6M (#94) · Binance $6.2M/d
- 2026: $0.000342 -81.2% · H 0.00204 L 0.000326 · cap $8.3M (#95) · Binance $1.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance FUNUSDT daily (2019-08-27 → 2026-04-23)
