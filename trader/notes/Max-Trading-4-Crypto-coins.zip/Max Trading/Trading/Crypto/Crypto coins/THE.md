---
tags: [trading, crypto, the]
---
**THE**
- Data: 2024-11-27 → 2026-11-08 (712 days)
- Last $0.0363 (2026-11-08) · all-time high $3.28 (2024-11-28) · now -98.9% from high · lowest $0.0363 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.69 start · H 3.28 L 1.21 · Binance $127.9M/d
- 2025: $0.2078 -87.7% · H 1.61 L 0.1319 · Binance $7.6M/d
- 2026: $0.0363 -82.5% · H 0.2916 L 0.0363 · Binance $2.5M/d

**Sources**
- Binance THEUSDT daily (2024-11-27 → 2026-11-08)
