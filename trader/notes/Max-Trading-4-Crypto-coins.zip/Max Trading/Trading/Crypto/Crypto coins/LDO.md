---
tags: [trading, crypto, ldo]
---
**LDO**
- Data: 2021-09-11 → 2026-11-08 (1,885 days)
- Last $0.3217 (2026-11-08) · all-time high $5.79 (2021-09-19) · now -94.4% from high · lowest $0.2399 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $3.11 start · H 5.79 L 2.53 · cap $3.1B (#40)
- 2022: $0.9530 -69.3% · H 5.00 L 0.4530 · cap $952.6M (#35) · Binance $11.6M/d
- 2023: $2.64 +177.4% · H 3.27 L 1.08 · cap $2.6B (#30) · Binance $25.8M/d
- 2024: $1.75 -34.0% · H 3.79 L 0.9130 · cap $1.7B (#41) · Binance $25.7M/d
- 2025: $0.5764 -67.0% · H 2.30 L 0.5058 · cap $576.6M (#46) · Binance $20.8M/d
- 2026: $0.3217 -44.2% · H 0.6651 L 0.2399 · cap $349.9M (#48) · Binance $3.7M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance LDOUSDT daily (2022-05-09 → 2026-11-08)
