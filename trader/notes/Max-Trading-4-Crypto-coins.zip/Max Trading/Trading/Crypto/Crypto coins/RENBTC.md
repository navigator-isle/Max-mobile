---
tags: [trading, crypto, renbtc]
---
**RENBTC**
- Data: 2020-05-13 → 2026-05-23 (2,202 days)
- Last $76,620 (2026-05-23) · all-time high $124,824 (2025-10-06) · now -38.6% from high · lowest $8,806 (2020-05-24)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $29,023 start · H 29,023 L 8,806 · cap $382.0M (#52)
- 2021: $46,355 +59.7% · H 67,542 L 29,381 · cap $809.6M (#69)
- 2022: $16,524 -64.4% · H 47,560 L 15,758 · cap $7.8M (#108)
- 2023: $42,217 +155.5% · H 44,205 L 16,607 · cap $12.9M (#103)
- 2024: $93,390 +121.2% · H 106,116 L 39,577 · cap $28.4M (#106)
- 2025: $87,517 -6.3% · H 124,824 L 76,351 · cap $26.6M (#92)
- 2026: $76,620 -12.5% · H 97,044 L 63,495 · cap $23.3M (#87)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
