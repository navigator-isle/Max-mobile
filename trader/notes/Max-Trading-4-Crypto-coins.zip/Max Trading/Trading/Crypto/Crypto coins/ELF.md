---
tags: [trading, crypto, elf]
---
**ELF**
- Data: 2017-12-22 → 2025-04-16 (2,673 days)
- Last $0.2272 (2025-04-16) · all-time high $2.41 (2018-01-07) · now -90.6% from high · lowest $0.0448 (2020-03-12)
- Binance: stopped trading on Binance (delisted) after 2025-04-16

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $1.00 start · H 1.16 L 0.8585 · cap $260.7M (#52)
- 2018: $0.1059 -89.4% · H 2.41 L 0.0965 · cap $31.9M (#64)
- 2019: $0.0496 -53.2% · H 0.2525 L 0.0478 · cap $43.6M (#54)
- 2020: $0.1023 +106.3% · H 0.2459 L 0.0448 · cap $90.0M (#81)
- 2021: $0.3721 +263.8% · H 1.00 L 0.1063 · cap $328.8M (#86) · Binance $7.3M/d
- 2022: $0.1561 -58.0% · H 0.5052 L 0.1071 · cap $137.5M (#75) · Binance $2.2M/d
- 2023: $0.5814 +272.5% · H 0.9528 L 0.1569 · cap $510.8M (#54) · Binance $2.6M/d
- 2024: $0.4413 -24.1% · H 0.7822 L 0.3147 · cap $387.4M (#64) · Binance $3.7M/d
- 2025: $0.2272 -48.5% · H 0.5132 L 0.2062 · cap $76.3M (#79) · Binance $2.8M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ELFUSDT daily (2021-09-08 → 2025-04-16)
