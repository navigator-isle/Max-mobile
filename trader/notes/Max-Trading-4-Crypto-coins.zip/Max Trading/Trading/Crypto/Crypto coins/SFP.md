---
tags: [trading, crypto, sfp]
---
**SFP**
- Data: 2021-02-08 → 2026-11-08 (2,100 days)
- Last $0.2047 (2026-11-08) · all-time high $3.53 (2021-03-22) · now -94.2% from high · lowest $0.2027 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $1.51 start · H 3.53 L 0.6411 · Binance $36.4M/d
- 2022: $0.3956 -73.9% · H 1.55 L 0.2842 · Binance $6.1M/d
- 2023: $0.7733 +95.5% · H 0.8268 L 0.3546 · Binance $3.3M/d
- 2024: $0.7271 -6.0% · H 0.8817 L 0.6260 · Binance $2.2M/d
- 2025: $0.3215 -55.8% · H 0.7521 L 0.2929 · Binance $840.0K/d
- 2026: $0.2047 -36.3% · H 0.3879 L 0.2027 · Binance $211.6K/d

**Sources**
- Binance SFPUSDT daily (2021-02-08 → 2026-11-08)
