---
tags: [trading, crypto, poly]
---
**POLY**
- Data: 2018-06-15 → 2022-10-10 (1,579 days)
- Last $0.2696 (2022-10-10) · all-time high $0.9243 (2021-11-27) · now -70.8% from high · lowest $0.0131 (2020-03-12)
- Binance: stopped trading on Binance (delisted) after 2022-10-10

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.1352 start · H 0.5034 L 0.1122 · cap $135.2M (#36)
- 2019: $0.0160 -88.1% · H 0.1464 L 0.0160 · cap $16.0M (#72)
- 2020: $0.0808 +403.3% · H 0.0848 L 0.0131 · cap $80.8M (#83)
- 2021: $0.4788 +492.9% · H 0.9243 L 0.0830 · cap $479.2M (#80) · Binance $10.1M/d
- 2022: $0.2696 -43.7% · H 0.5872 L 0.1674 · cap $141.5M (#74) · Binance $2.9M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance POLYUSDT daily (2021-09-09 → 2022-10-10)
