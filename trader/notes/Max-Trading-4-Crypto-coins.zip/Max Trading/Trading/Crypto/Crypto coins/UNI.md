---
tags: [trading, crypto, uni]
---
**UNI**
- Data: 2020-09-17 → 2026-11-08 (2,244 days)
- Last $7.03 (2026-11-08) · all-time high $43.11 (2021-05-04) · now -83.7% from high · lowest $1.93 (2020-11-04)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $5.15 start · H 6.90 L 1.93 · cap $5.2B (#14) · Binance $65.3M/d
- 2021: $17.00 +230.1% · H 43.11 L 4.74 · cap $17.1B (#19) · Binance $97.7M/d
- 2022: $5.17 -69.6% · H 18.46 L 3.64 · cap $5.2B (#17) · Binance $19.9M/d
- 2023: $7.22 +39.8% · H 7.81 L 3.89 · cap $7.2B (#19) · Binance $11.9M/d
- 2024: $13.24 +83.4% · H 18.60 L 5.37 · cap $13.2B (#16) · Binance $41.8M/d
- 2025: $5.64 -57.4% · H 15.28 L 4.78 · cap $5.6B (#24) · Binance $51.9M/d
- 2026: $7.03 +24.6% · H 10.23 L 2.40 · cap $3.5B (#25) · Binance $27.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance UNIUSDT daily (2020-09-17 → 2026-11-08)
