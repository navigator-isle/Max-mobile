---
tags: [trading, crypto, saga]
---
**SAGA**
- Data: 2024-04-09 → 2026-11-08 (944 days)
- Last $0.0160 (2026-11-08) · all-time high $6.56 (2024-04-09) · now -99.8% from high · lowest $0.0120 (2026-06-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.43 start · H 6.56 L 0.8977 · Binance $33.9M/d
- 2025: $0.0564 -96.0% · H 1.68 L 0.0559 · Binance $6.0M/d
- 2026: $0.0160 -71.6% · H 0.0739 L 0.0120 · Binance $3.9M/d

**Sources**
- Binance SAGAUSDT daily (2024-04-09 → 2026-11-08)
