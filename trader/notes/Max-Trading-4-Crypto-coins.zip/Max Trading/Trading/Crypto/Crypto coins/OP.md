---
tags: [trading, crypto, op]
---
**OP**
- Data: 2022-06-01 → 2026-11-08 (1,622 days)
- Last $0.1023 (2026-11-08) · all-time high $4.70 (2024-03-09) · now -97.8% from high · lowest $0.0821 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.9170 start · H 1.99 L 0.4500 · Binance $40.3M/d
- 2023: $3.71 +304.1% · H 3.96 L 0.9240 · Binance $49.1M/d
- 2024: $1.75 -52.7% · H 4.70 L 1.17 · Binance $55.7M/d
- 2025: $0.2678 -84.7% · H 2.11 L 0.2521 · Binance $22.5M/d
- 2026: $0.1023 -61.8% · H 0.3669 L 0.0821 · Binance $5.1M/d

**Sources**
- Binance OPUSDT daily (2022-06-01 → 2026-11-08)
