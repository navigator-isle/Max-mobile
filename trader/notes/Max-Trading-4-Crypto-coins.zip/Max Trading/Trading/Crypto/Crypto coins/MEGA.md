---
tags: [trading, crypto, mega]
---
**MEGA**
- Data: 2026-04-30 → 2026-11-08 (193 days)
- Last $0.0511 (2026-11-08) · all-time high $0.1666 (2026-04-30) · now -69.3% from high · lowest $0.0312 (2026-08-14)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0511 start · H 0.1666 L 0.0312 · Binance $8.6M/d

**Sources**
- Binance MEGAUSDT daily (2026-04-30 → 2026-11-08)
