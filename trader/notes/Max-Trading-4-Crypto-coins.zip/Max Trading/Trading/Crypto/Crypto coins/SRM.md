---
tags: [trading, crypto, srm]
---
**SRM**
- Data: 2020-08-11 → 2022-11-28 (840 days)
- Last $0.2444 (2022-11-28) · all-time high $12.48 (2021-09-12) · now -98.0% from high · lowest $0.1336 (2022-11-13)
- Binance: stopped trading on Binance (delisted) after 2022-11-28

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.04 start · H 3.59 L 0.8319 · cap $167.1M (#72) · Binance $11.2M/d
- 2021: $3.41 +226.9% · H 12.48 L 1.06 · cap $551.2M (#74) · Binance $41.0M/d
- 2022: $0.2444 -92.8% · H 3.80 L 0.1336 · cap $35.7M (#96) · Binance $7.6M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance SRMUSDT daily (2020-08-11 → 2022-11-28)
