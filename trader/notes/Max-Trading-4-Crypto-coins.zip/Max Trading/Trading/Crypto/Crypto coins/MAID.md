---
tags: [trading, crypto, maid]
---
**MAID**
- Data: 2014-07-10 → 2025-01-23 (3,851 days)
- Last $0.3176 (2025-01-23) · all-time high $1.28 (2021-04-12) · now -75.2% from high · lowest $0.0116 (2015-11-24)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $0.0544 start · H 0.0576 L 0.0166 · cap $24.6M (#4)
- 2015: $0.0146 -73.2% · H 0.0550 L 0.0116 · cap $6.6M (#8)
- 2016: $0.0999 +584.4% · H 0.1182 L 0.0144 · cap $45.2M (#9)
- 2017: $0.9151 +816.3% · H 0.9197 L 0.0842 · cap $414.1M (#47)
- 2018: $0.1311 -85.7% · H 1.16 L 0.1235 · cap $59.3M (#55)
- 2019: $0.0784 -40.2% · H 0.2694 L 0.0708 · cap $35.5M (#57)
- 2020: $0.3099 +295.4% · H 0.3510 L 0.0452 · cap $140.2M (#76)
- 2021: $0.4023 +29.8% · H 1.28 L 0.2767 · cap $182.1M (#94)
- 2022: $0.1083 -73.1% · H 0.4979 L 0.0827 · cap $49.0M (#91)
- 2023: $0.1432 +32.2% · H 0.2731 L 0.0458 · cap $64.8M (#94)
- 2024: $0.4471 +212.2% · H 0.9099 L 0.0984 · cap $202.3M (#80)
- 2025: $0.3176 -29.0% · H 0.6592 L 0.3176 · cap $143.7M (#84)

**Sources**
- Coin Metrics community data (daily, to 2025-01-23)
