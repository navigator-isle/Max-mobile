---
tags: [trading, crypto, vtc]
---
**VTC**
- Data: 2014-01-29 → 2023-12-10 (3,603 days)
- Last $0.0394 (2023-12-10) · all-time high $9.48 (2017-12-05) · now -99.6% from high · lowest $0.00589 (2015-05-05)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $0.0208 start · H 5.37 L 0.0208 · cap $228.2K (#8)
- 2015: $0.0196 -5.9% · H 0.4195 L 0.00589 · cap $420.3K (#14)
- 2016: $0.0351 +79.7% · H 0.0859 L 0.0173 · cap $1.1M (#18)
- 2017: $6.66 +18839.9% · H 9.48 L 0.0271 · cap $281.5M (#50)
- 2018: $0.2450 -96.3% · H 7.29 L 0.2135 · cap $11.6M (#69)
- 2019: $0.1493 -39.1% · H 0.5856 L 0.1493 · cap $7.9M (#79)
- 2020: $0.1614 +8.1% · H 0.3655 L 0.1382 · cap $9.4M (#106)
- 2021: $0.4394 +172.3% · H 1.98 L 0.1597 · cap $27.8M (#111)
- 2022: $0.1412 -67.9% · H 0.4926 L 0.1232 · cap $9.3M (#106)
- 2023: $0.0394 -72.1% · H 0.1829 L 0.0272 · cap $2.7M (#110)

**Sources**
- Coin Metrics community data (daily, to 2023-12-10)
