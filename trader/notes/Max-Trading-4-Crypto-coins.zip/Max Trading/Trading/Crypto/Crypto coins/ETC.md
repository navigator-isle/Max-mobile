---
tags: [trading, crypto, etc]
---
**ETC**
- Data: 2016-07-25 → 2026-11-08 (3,759 days)
- Last $6.85 (2026-11-08) · all-time high $133.9 (2021-05-06) · now -94.9% from high · lowest $0.6090 (2016-07-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2016: $1.42 start · H 2.69 L 0.6090 · cap $124.4M (#7)
- 2017: $26.36 +1756.8% · H 38.86 L 1.17 · cap $2.6B (#18)
- 2018: $4.98 -81.1% · H 42.93 L 3.52 · cap $532.4M (#17) · Binance $12.5M/d
- 2019: $4.49 -9.7% · H 9.53 L 3.47 · cap $522.2M (#23) · Binance $4.4M/d
- 2020: $5.66 +25.8% · H 12.33 L 3.72 · cap $706.7M (#42) · Binance $19.8M/d
- 2021: $34.06 +502.2% · H 133.9 L 5.69 · cap $4.5B (#33) · Binance $183.6M/d
- 2022: $15.69 -53.9% · H 49.66 L 13.67 · cap $2.2B (#27) · Binance $70.6M/d
- 2023: $21.92 +39.7% · H 23.81 L 14.71 · cap $3.2B (#27) · Binance $16.3M/d
- 2024: $25.06 +14.3% · H 38.27 L 17.30 · cap $3.8B (#31) · Binance $36.3M/d
- 2025: $11.48 -54.2% · H 29.02 L 11.48 · cap $1.8B (#36) · Binance $14.7M/d
- 2026: $6.85 -40.3% · H 13.37 L 6.08 · cap $1.4B (#37) · Binance $3.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ETCUSDT daily (2018-06-12 → 2026-11-08)
