---
tags: [trading, crypto, init]
---
**INIT**
- Data: 2025-04-24 → 2026-11-08 (564 days)
- Last $0.1234 (2026-11-08) · all-time high $1.34 (2025-05-13) · now -90.8% from high · lowest $0.0481 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0880 start · H 1.34 L 0.0776 · Binance $13.2M/d
- 2026: $0.1234 +40.2% · H 0.2232 L 0.0481 · Binance $1.5M/d

**Sources**
- Binance INITUSDT daily (2025-04-24 → 2026-11-08)
