---
tags: [trading, crypto, lina]
---
**LINA**
- Data: 2021-03-18 → 2025-03-28 (1,472 days)
- Last $0.000337 (2025-03-28) · all-time high $0.2054 (2021-03-18) · now -99.8% from high · lowest $0.000332 (2025-03-27)
- Binance: stopped trading on Binance (delisted) after 2025-03-28

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.0431 start · H 0.2054 L 0.0218 · Binance $26.5M/d
- 2022: $0.00489 -88.7% · H 0.0494 L 0.00484 · Binance $7.0M/d
- 2023: $0.0107 +118.9% · H 0.0232 L 0.00501 · Binance $13.4M/d
- 2024: $0.00494 -53.9% · H 0.0156 L 0.00349 · Binance $4.6M/d
- 2025: $0.000337 -93.2% · H 0.00563 L 0.000332 · Binance $2.7M/d

**Sources**
- Binance LINAUSDT daily (2021-03-18 → 2025-03-28)
