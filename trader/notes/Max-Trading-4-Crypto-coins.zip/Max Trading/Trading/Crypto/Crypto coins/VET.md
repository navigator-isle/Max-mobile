---
tags: [trading, crypto, vet]
---
**VET**
- Data: 2018-07-25 → 2026-11-08 (3,029 days)
- Last $0.00516 (2026-11-08) · all-time high $0.2533 (2021-04-18) · now -98.0% from high · lowest $0.00226 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.00393 start · H 0.0265 L 0.00334 · Binance $6.9M/d
- 2019: $0.00524 +33.5% · H 0.00933 L 0.00299 · Binance $3.6M/d
- 2020: $0.0188 +257.8% · H 0.0219 L 0.00226 · Binance $19.8M/d
- 2021: $0.0827 +340.8% · H 0.2533 L 0.0191 · Binance $189.2M/d
- 2022: $0.0158 -80.9% · H 0.0871 L 0.0156 · Binance $28.8M/d
- 2023: $0.0343 +117.2% · H 0.0381 L 0.0147 · Binance $8.2M/d
- 2024: $0.0431 +25.7% · H 0.0779 L 0.0194 · Binance $18.1M/d
- 2025: $0.0104 -75.8% · H 0.0561 L 0.0098 · Binance $10.7M/d
- 2026: $0.00516 -50.5% · H 0.0129 L 0.00438 · Binance $1.7M/d

**Sources**
- Binance VETUSDT daily (2018-07-25 → 2026-11-08)
