---
tags: [trading, crypto, sndkb]
---
**SNDKB**
- Data: 2026-06-11 → 2026-11-08 (151 days)
- Last $836.4 (2026-11-08) · all-time high $2,319 (2026-06-25) · now -63.9% from high · lowest $810.7 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $836.4 start · H 2,319 L 810.7 · Binance $23.7M/d

**Sources**
- Binance SNDKBUSDT daily (2026-06-11 → 2026-11-08)
