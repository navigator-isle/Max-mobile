---
tags: [trading, crypto, crv]
---
**CRV**
- Data: 2020-08-15 → 2026-11-08 (2,277 days)
- Last $0.2630 (2026-11-08) · all-time high $6.91 (2020-08-15) · now -96.2% from high · lowest $0.1822 (2026-06-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.6270 start · H 6.91 L 0.3370 · cap $883.4M (#38) · Binance $15.9M/d
- 2021: $5.32 +748.3% · H 5.93 L 0.6130 · cap $9.0B (#26) · Binance $62.6M/d
- 2022: $0.5240 -90.1% · H 6.52 L 0.5020 · cap $986.0M (#34) · Binance $29.2M/d
- 2023: $0.6053 +15.5% · H 1.27 L 0.4016 · cap $1.2B (#43) · Binance $12.2M/d
- 2024: $0.8942 +47.7% · H 1.25 L 0.2091 · cap $2.0B (#39) · Binance $31.1M/d
- 2025: $0.3594 -59.8% · H 1.10 L 0.3388 · cap $838.8M (#44) · Binance $28.6M/d
- 2026: $0.2630 -26.8% · H 0.4384 L 0.1822 · cap $557.8M (#45) · Binance $4.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance CRVUSDT daily (2020-08-15 → 2026-11-08)
