---
tags: [trading, crypto, win]
---
**WIN**
- Data: 2019-08-01 → 2026-11-08 (2,657 days)
- Last $6.63e-05 (2026-11-08) · all-time high $0.00269 (2021-04-05) · now -97.5% from high · lowest $1.68e-05 (2026-06-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $9.23e-05 start · H 0.000443 L 9.18e-05 · Binance $3.6M/d
- 2020: $5.88e-05 -36.3% · H 0.000142 L 4.93e-05 · Binance $1.1M/d
- 2021: $0.000454 +671.5% · H 0.00269 L 5.92e-05 · Binance $101.2M/d
- 2022: $7.48e-05 -83.5% · H 0.000465 L 7.35e-05 · Binance $10.3M/d
- 2023: $9.69e-05 +29.5% · H 0.000112 L 5.87e-05 · Binance $1.2M/d
- 2024: $9.86e-05 +1.8% · H 0.000214 L 7.21e-05 · Binance $3.2M/d
- 2025: $2.67e-05 -72.9% · H 0.000118 L 2.67e-05 · Binance $1.2M/d
- 2026: $6.63e-05 +148.3% · H 6.91e-05 L 1.68e-05 · Binance $308.5K/d

**Sources**
- Binance WINUSDT daily (2019-08-01 → 2026-11-08)
