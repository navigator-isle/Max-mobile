---
tags: [trading, crypto, edu]
---
**EDU**
- Data: 2023-04-28 → 2026-11-08 (1,291 days)
- Last $0.0441 (2026-11-08) · all-time high $1.42 (2023-05-28) · now -96.9% from high · lowest $0.0262 (2026-06-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.7058 start · H 1.42 L 0.3762 · Binance $19.7M/d
- 2024: $0.5257 -25.5% · H 1.26 L 0.4311 · Binance $6.3M/d
- 2025: $0.1631 -69.0% · H 0.6226 L 0.0928 · Binance $2.5M/d
- 2026: $0.0441 -73.0% · H 0.1675 L 0.0262 · Binance $1.2M/d

**Sources**
- Binance EDUUSDT daily (2023-04-28 → 2026-11-08)
