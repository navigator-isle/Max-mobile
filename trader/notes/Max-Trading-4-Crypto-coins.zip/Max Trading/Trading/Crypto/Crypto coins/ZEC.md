---
tags: [trading, crypto, zec]
---
**ZEC**
- Data: 2016-10-29 → 2026-11-08 (3,663 days)
- Last $1,268 (2026-11-08) · all-time high $2,042 (2016-10-29) · now -37.9% from high · lowest $18.30 (2024-07-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2016: $48.03 start · H 2,042 L 34.31 · cap $16.5M (#13)
- 2017: $480.5 +900.5% · H 668.6 L 27.23 · cap $1.4B (#26)
- 2018: $55.25 -88.5% · H 750.6 L 48.48 · cap $307.9M (#19)
- 2019: $27.54 -50.1% · H 114.1 L 26.66 · cap $224.4M (#33) · Binance $1.3M/d
- 2020: $63.91 +132.1% · H 97.46 L 24.68 · cap $683.0M (#44) · Binance $13.1M/d
- 2021: $146.5 +129.2% · H 320.0 L 56.60 · cap $1.8B (#51) · Binance $58.1M/d
- 2022: $37.30 -74.5% · H 210.3 L 35.20 · cap $494.4M (#52) · Binance $14.8M/d
- 2023: $26.92 -27.8% · H 50.30 L 23.90 · cap $391.0M (#60) · Binance $3.7M/d
- 2024: $56.27 +109.0% · H 74.59 L 18.30 · cap $885.5M (#50) · Binance $5.8M/d
- 2025: $512.3 +810.4% · H 699.0 L 29.17 · cap $8.4B (#17) · Binance $94.3M/d
- 2026: $1,268 +147.4% · H 1,653 L 197.2 · cap $10.6B (#11) · Binance $132.8M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ZECUSDT daily (2019-03-21 → 2026-11-08)
