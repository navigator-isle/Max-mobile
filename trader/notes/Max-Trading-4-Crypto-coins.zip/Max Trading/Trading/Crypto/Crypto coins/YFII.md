---
tags: [trading, crypto, yfii]
---
**YFII**
- Data: 2020-09-01 → 2023-08-22 (1,086 days)
- Last $435.5 (2023-08-22) · all-time high $8,550 (2020-09-01) · now -94.9% from high · lowest $355.0 (2022-06-12)
- Binance: stopped trading on Binance (delisted) after 2023-08-22

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1,621 start · H 8,550 L 1,067 · Binance $36.4M/d
- 2021: $2,814 +73.6% · H 6,310 L 1,475 · Binance $12.0M/d
- 2022: $1,145 -59.3% · H 3,521 L 355.0 · Binance $6.5M/d
- 2023: $435.5 -62.0% · H 1,458 L 433.6 · Binance $2.0M/d

**Sources**
- Binance YFIIUSDT daily (2020-09-01 → 2023-08-22)
