---
tags: [trading, crypto, grin]
---
**GRIN**
- Data: 2019-01-29 → 2026-05-23 (2,672 days)
- Last $0.0267 (2026-05-23) · all-time high $7.93 (2019-01-29) · now -99.7% from high · lowest $0.0136 (2025-03-30)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $1.04 start · H 7.93 L 0.8825 · cap $31.3M (#61)
- 2020: $0.2941 -71.7% · H 1.51 L 0.2237 · cap $18.1M (#100)
- 2021: $0.2263 -23.1% · H 1.55 L 0.2215 · cap $21.1M (#112)
- 2022: $0.0742 -67.2% · H 0.2953 L 0.0358 · cap $9.2M (#107)
- 2023: $0.0750 +1.0% · H 0.0787 L 0.0252 · cap $11.7M (#104)
- 2024: $0.0311 -58.5% · H 0.0990 L 0.0235 · cap $5.8M (#112)
- 2025: $0.0351 +12.8% · H 0.0686 L 0.0136 · cap $7.7M (#101)
- 2026: $0.0267 -23.8% · H 0.0471 L 0.0267 · cap $6.2M (#97)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
