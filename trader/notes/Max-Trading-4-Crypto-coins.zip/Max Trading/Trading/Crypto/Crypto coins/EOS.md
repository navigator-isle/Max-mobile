---
tags: [trading, crypto, eos]
---
**EOS**
- Data: 2018-05-28 → 2025-05-26 (2,556 days)
- Last $0.7799 (2025-05-26) · all-time high $14.72 (2018-06-07) · now -94.7% from high · lowest $0.4093 (2024-11-04)
- Binance: stopped trading on Binance (delisted) after 2025-05-26

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $2.53 start · H 14.72 L 1.73 · Binance $55.8M/d
- 2019: $2.58 +2.0% · H 8.56 L 2.19 · Binance $29.6M/d
- 2020: $2.59 +0.3% · H 5.37 L 1.77 · Binance $38.0M/d
- 2021: $3.03 +17.1% · H 14.52 L 2.50 · Binance $191.9M/d
- 2022: $0.8620 -71.6% · H 3.25 L 0.8240 · Binance $26.4M/d
- 2023: $0.8450 -2.0% · H 1.32 L 0.5350 · Binance $11.4M/d
- 2024: $0.7748 -8.3% · H 1.37 L 0.4093 · Binance $16.0M/d
- 2025: $0.7799 +0.7% · H 0.9862 L 0.4595 · Binance $23.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance EOSUSDT daily (2018-05-28 → 2025-05-26)
