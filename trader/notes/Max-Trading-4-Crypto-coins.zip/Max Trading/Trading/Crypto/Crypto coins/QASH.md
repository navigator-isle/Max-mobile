---
tags: [trading, crypto, qash]
---
**QASH**
- Data: 2017-11-06 → 2024-12-12 (2,594 days)
- Last $0.0183 (2024-12-12) · all-time high $2.42 (2018-01-13) · now -99.2% from high · lowest $0.00693 (2022-08-16)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.8623 start · H 1.37 L 0.2293 · cap $862.3M (#35)
- 2018: $0.1079 -87.5% · H 2.42 L 0.1079 · cap $107.9M (#40)
- 2019: $0.0442 -59.0% · H 0.1612 L 0.0440 · cap $44.2M (#53)
- 2020: $0.0310 -29.9% · H 0.0645 L 0.0287 · cap $31.0M (#93)
- 2021: $0.0566 +82.7% · H 0.1701 L 0.0334 · cap $56.6M (#104)
- 2022: $0.0167 -70.6% · H 0.1068 L 0.00693 · cap $16.7M (#101)
- 2023: $0.0309 +85.4% · H 0.0489 L 0.0116 · cap $30.9M (#99)
- 2024: $0.0183 -40.6% · H 0.0366 L 0.0106 · cap $18.3M (#107)

**Sources**
- Coin Metrics community data (daily, to 2024-12-12)
