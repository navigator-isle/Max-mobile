---
tags: [trading, crypto, rev_eth]
---
**REV_ETH**
- Data: 2020-03-26 → 2024-03-27 (1,463 days)
- Last $5.98e-05 (2024-03-27) · all-time high $0.0487 (2021-05-11) · now -99.9% from high · lowest $3.61e-05 (2024-03-15)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.0121 start · H 0.0409 L 0.00782 · cap $730.4M (#41)
- 2021: $0.00846 -29.8% · H 0.0487 L 0.00573 · cap $512.5M (#77)
- 2022: $0.000524 -93.8% · H 0.0105 L 0.000514 · cap $31.7M (#97)
- 2023: $7.74e-05 -85.2% · H 0.00682 L 3.73e-05 · cap $4.7M (#108)
- 2024: $5.98e-05 -22.8% · H 0.000177 L 3.61e-05 · cap $3.6M (#109)

**Sources**
- Coin Metrics community data (daily, to 2024-03-27)
