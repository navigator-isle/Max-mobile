---
tags: [trading, crypto, sand]
---
**SAND**
- Data: 2020-08-14 → 2026-11-08 (2,278 days)
- Last $0.0420 (2026-11-08) · all-time high $7.51 (2021-11-28) · now -99.4% from high · lowest $0.0309 (2020-11-03)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.0357 start · H 0.0740 L 0.0309 · Binance $3.4M/d
- 2021: $5.84 +16261.1% · H 7.51 L 0.0370 · Binance $160.1M/d
- 2022: $0.3830 -93.4% · H 5.97 L 0.3830 · Binance $72.7M/d
- 2023: $0.5947 +55.3% · H 0.9113 L 0.2814 · Binance $17.4M/d
- 2024: $0.5461 -8.2% · H 0.9345 L 0.2275 · Binance $25.1M/d
- 2025: $0.1088 -80.1% · H 0.6989 L 0.1088 · Binance $9.1M/d
- 2026: $0.0420 -61.4% · H 0.1645 L 0.0335 · Binance $3.1M/d

**Sources**
- Binance SANDUSDT daily (2020-08-14 → 2026-11-08)
