---
tags: [trading, crypto, xem]
---
**XEM**
- Data: 2015-04-01 → 2024-06-17 (3,366 days)
- Last $0.0160 (2024-06-17) · all-time high $1.79 (2018-01-07) · now -99.1% from high · lowest $8.7e-05 (2015-08-25)
- Binance: stopped trading on Binance (delisted) after 2024-06-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2015: $0.000152 start · H 0.000314 L 8.7e-05 · cap $1.4M (#10)
- 2016: $0.0037 +2335.9% · H 0.0127 L 0.00016 · cap $33.3M (#11)
- 2017: $1.03 +27635.9% · H 1.04 L 0.00329 · cap $9.2B (#8)
- 2018: $0.0632 -93.8% · H 1.79 L 0.0580 · cap $568.4M (#16)
- 2019: $0.0319 -49.5% · H 0.0984 L 0.0311 · cap $287.2M (#29)
- 2020: $0.2057 +544.6% · H 0.3043 L 0.0307 · cap $1.8B (#25) · Binance $8.2M/d
- 2021: $0.1229 -40.3% · H 0.7881 L 0.0962 · cap $1.1B (#59) · Binance $31.6M/d
- 2022: $0.0285 -76.8% · H 0.1303 L 0.0281 · cap $256.2M (#62) · Binance $1.9M/d
- 2023: $0.0391 +37.1% · H 0.0637 L 0.0236 · cap $351.0M (#68) · Binance $1.5M/d
- 2024: $0.0160 -59.2% · H 0.0605 L 0.0160 · cap $211.8M (#79) · Binance $3.0M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XEMUSDT daily (2020-11-24 → 2024-06-17)
