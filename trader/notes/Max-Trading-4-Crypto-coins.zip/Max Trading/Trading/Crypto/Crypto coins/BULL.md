---
tags: [trading, crypto, bull]
---
**BULL**
- Data: 2020-01-17 → 2020-03-31 (75 days)
- Last $1,370 (2020-03-31) · all-time high $17,987 (2020-02-12) · now -92.4% from high · lowest $765.0 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2020-03-31

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1,370 start · H 17,987 L 765.0 · Binance $9.8M/d

**Sources**
- Binance BULLUSDT daily (2020-01-17 → 2020-03-31)
