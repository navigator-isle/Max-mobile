---
tags: [trading, crypto, not]
---
**NOT**
- Data: 2024-05-16 → 2026-11-08 (907 days)
- Last $0.00032 (2026-11-08) · all-time high $0.0228 (2024-06-04) · now -98.6% from high · lowest $0.000319 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.0063 start · H 0.0228 L 0.00485 · Binance $121.0M/d
- 2025: $0.000517 -91.8% · H 0.00685 L 0.000488 · Binance $6.8M/d
- 2026: $0.00032 -38.1% · H 0.000705 L 0.000319 · Binance $1.3M/d

**Sources**
- Binance NOTUSDT daily (2024-05-16 → 2026-11-08)
