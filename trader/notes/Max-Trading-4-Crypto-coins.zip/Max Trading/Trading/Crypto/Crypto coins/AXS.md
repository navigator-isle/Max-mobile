---
tags: [trading, crypto, axs]
---
**AXS**
- Data: 2020-11-04 → 2026-11-08 (2,196 days)
- Last $0.8180 (2026-11-08) · all-time high $160.4 (2021-11-07) · now -99.5% from high · lowest $0.1345 (2020-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.5379 start · H 0.8244 L 0.1345 · Binance $5.6M/d
- 2021: $93.25 +17237.5% · H 160.4 L 0.4496 · Binance $143.5M/d
- 2022: $6.04 -93.5% · H 96.38 L 5.98 · Binance $33.8M/d
- 2023: $8.85 +46.5% · H 12.56 L 4.13 · Binance $11.5M/d
- 2024: $6.22 -29.7% · H 12.68 L 4.21 · Binance $10.5M/d
- 2025: $0.8050 -87.1% · H 7.29 L 0.8050 · Binance $4.0M/d
- 2026: $0.8180 +1.6% · H 2.94 L 0.8180 · Binance $5.3M/d

**Sources**
- Binance AXSUSDT daily (2020-11-04 → 2026-11-08)
