---
tags: [trading, crypto, alpaca]
---
**ALPACA**
- Data: 2021-08-11 → 2025-05-02 (1,361 days)
- Last $0.2244 (2025-05-02) · all-time high $1.44 (2021-08-20) · now -84.4% from high · lowest $0.0295 (2025-04-17)
- Binance: stopped trading on Binance (delisted) after 2025-05-02

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.5954 start · H 1.44 L 0.5004 · Binance $8.4M/d
- 2022: $0.2438 -59.1% · H 0.6819 L 0.1898 · Binance $2.3M/d
- 2023: $0.1884 -22.7% · H 0.3338 L 0.1267 · Binance $1.2M/d
- 2024: $0.1654 -12.2% · H 0.2885 L 0.0847 · Binance $3.3M/d
- 2025: $0.2244 +35.7% · H 0.5690 L 0.0295 · Binance $11.3M/d

**Sources**
- Binance ALPACAUSDT daily (2021-08-11 → 2025-05-02)
