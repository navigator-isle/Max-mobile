---
tags: [trading, crypto, beta]
---
**BETA**
- Data: 2021-10-08 → 2025-04-16 (1,287 days)
- Last $0.00036 (2025-04-16) · all-time high $3.45 (2021-10-09) · now -100.0% from high · lowest $0.00036 (2025-04-16)
- Binance: stopped trading on Binance (delisted) after 2025-04-16

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.6088 start · H 3.45 L 0.6088 · Binance $47.0M/d
- 2022: $0.0676 -88.9% · H 0.7054 L 0.0583 · Binance $8.6M/d
- 2023: $0.0804 +19.0% · H 0.1209 L 0.0573 · Binance $2.1M/d
- 2024: $0.0461 -42.7% · H 0.1194 L 0.0389 · Binance $4.5M/d
- 2025: $0.00036 -99.2% · H 0.0480 L 0.00036 · Binance $1.8M/d

**Sources**
- Binance BETAUSDT daily (2021-10-08 → 2025-04-16)
