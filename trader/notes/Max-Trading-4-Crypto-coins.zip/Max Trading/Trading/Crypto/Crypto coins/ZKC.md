---
tags: [trading, crypto, zkc]
---
**ZKC**
- Data: 2025-09-15 → 2026-11-08 (420 days)
- Last $0.0280 (2026-11-08) · all-time high $0.9394 (2025-09-15) · now -97.0% from high · lowest $0.0280 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1115 start · H 0.9394 L 0.0956 · Binance $21.7M/d
- 2026: $0.0280 -74.9% · H 0.1513 L 0.0280 · Binance $2.0M/d

**Sources**
- Binance ZKCUSDT daily (2025-09-15 → 2026-11-08)
