---
tags: [trading, crypto, pepe]
---
**PEPE**
- Data: 2023-05-05 → 2026-11-08 (1,284 days)
- Last $4.92e-06 (2026-11-08) · all-time high $2.65e-05 (2024-12-09) · now -81.4% from high · lowest $6.2e-07 (2023-09-17)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $1.3e-06 start · H 3.73e-06 L 6.2e-07 · Binance $41.1M/d
- 2024: $2e-05 +1435.4% · H 2.65e-05 L 8.8e-07 · Binance $384.1M/d
- 2025: $4.03e-06 -79.8% · H 2.16e-05 L 3.72e-06 · Binance $176.7M/d
- 2026: $4.92e-06 +22.1% · H 7.18e-06 L 2.33e-06 · Binance $38.0M/d

**Sources**
- Binance PEPEUSDT daily (2023-05-05 → 2026-11-08)
