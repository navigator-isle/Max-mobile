---
tags: [trading, crypto, pixel]
---
**PIXEL**
- Data: 2024-02-19 → 2026-11-08 (994 days)
- Last $0.00405 (2026-11-08) · all-time high $0.9076 (2024-03-10) · now -99.6% from high · lowest $0.00394 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.1545 start · H 0.9076 L 0.1180 · Binance $32.3M/d
- 2025: $0.00825 -94.7% · H 0.1778 L 0.00776 · Binance $3.8M/d
- 2026: $0.00405 -50.9% · H 0.0145 L 0.00394 · Binance $1.8M/d

**Sources**
- Binance PIXELUSDT daily (2024-02-19 → 2026-11-08)
