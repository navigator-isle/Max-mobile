---
tags: [trading, crypto, tao]
---
**TAO**
- Data: 2024-04-11 → 2026-11-08 (942 days)
- Last $222.7 (2026-11-08) · all-time high $712.9 (2024-12-08) · now -68.8% from high · lowest $145.9 (2026-02-11)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $441.0 start · H 712.9 L 216.2 · Binance $41.3M/d
- 2025: $219.2 -50.3% · H 562.7 L 183.7 · Binance $45.5M/d
- 2026: $222.7 +1.6% · H 347.0 L 145.9 · Binance $32.7M/d

**Sources**
- Binance TAOUSDT daily (2024-04-11 → 2026-11-08)
