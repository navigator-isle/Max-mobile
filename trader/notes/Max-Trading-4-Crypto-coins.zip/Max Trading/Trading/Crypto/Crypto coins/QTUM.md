---
tags: [trading, crypto, qtum]
---
**QTUM**
- Data: 2018-03-19 → 2026-11-08 (3,157 days)
- Last $0.7080 (2026-11-08) · all-time high $27.36 (2021-05-09) · now -97.4% from high · lowest $0.6340 (2026-08-11)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $2.12 start · H 23.00 L 1.57 · Binance $2.7M/d
- 2019: $1.61 -24.0% · H 5.57 L 1.53 · Binance $1.9M/d
- 2020: $2.22 +37.8% · H 4.16 L 1.04 · Binance $7.3M/d
- 2021: $8.72 +292.3% · H 27.36 L 2.25 · Binance $48.1M/d
- 2022: $1.83 -79.0% · H 9.23 L 1.83 · Binance $5.5M/d
- 2023: $3.71 +102.8% · H 3.72 L 1.88 · Binance $2.6M/d
- 2024: $3.01 -19.0% · H 5.74 L 1.99 · Binance $3.4M/d
- 2025: $1.35 -55.2% · H 3.79 L 1.21 · Binance $3.6M/d
- 2026: $0.7080 -47.5% · H 1.57 L 0.6340 · Binance $450.0K/d

**Sources**
- Binance QTUMUSDT daily (2018-03-19 → 2026-11-08)
