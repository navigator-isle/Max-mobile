---
tags: [trading, crypto, cvc]
---
**CVC**
- Data: 2017-09-11 → 2026-11-08 (3,193 days)
- Last $0.0209 (2026-11-08) · all-time high $1.33 (2018-01-03) · now -98.4% from high · lowest $0.0136 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.8705 start · H 1.01 L 0.2662 · cap $870.5M (#34)
- 2018: $0.0501 -94.2% · H 1.33 L 0.0467 · cap $50.1M (#57)
- 2019: $0.0183 -63.5% · H 0.0960 L 0.0174 · cap $18.1M (#70) · Binance $37.8K/d
- 2020: $0.0842 +361.1% · H 0.1307 L 0.0136 · cap $84.4M (#82) · Binance $1.9M/d
- 2021: $0.3281 +289.7% · H 0.9443 L 0.0846 · cap $329.2M (#85) · Binance $14.1M/d
- 2022: $0.0978 -70.2% · H 0.3956 L 0.0808 · cap $76.0M (#82) · Binance $2.7M/d
- 2023: $0.1044 +6.7% · H 0.1995 L 0.0652 · cap $104.2M (#91) · Binance $1.2M/d
- 2024: $0.2127 +103.7% · H 0.2607 L 0.0785 · cap $213.9M (#78) · Binance $4.6M/d
- 2025: $0.0424 -80.1% · H 0.1901 L 0.0387 · cap $42.2M (#87) · Binance $1.8M/d
- 2026: $0.0209 -50.7% · H 0.0493 L 0.0165 · cap $30.3M (#83) · Binance $532.0K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance CVCUSDT daily (2019-08-27 → 2026-11-08)
