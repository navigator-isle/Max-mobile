---
tags: [trading, crypto, eth]
---
**ETH**
- Data: 2015-08-08 → 2026-11-08 (4,111 days)
- Last $2,238 (2026-11-08) · all-time high $4,832 (2025-08-22) · now -53.7% from high · lowest $0.4200 (2015-10-21)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2015: $0.9488 start · H 1.88 L 0.4200 · cap $72.2M (#5)
- 2016: $8.13 +756.4% · H 20.73 L 0.9204 · cap $710.7M (#2)
- 2017: $734.0 +8932.1% · H 798.0 L 8.18 · cap $71.8B (#3) · Binance $10.6M/d
- 2018: $131.4 -82.1% · H 1,388 L 83.76 · cap $13.6B (#3) · Binance $83.4M/d
- 2019: $129.2 -1.7% · H 339.4 L 104.5 · cap $14.0B (#3) · Binance $73.1M/d
- 2020: $736.4 +470.2% · H 752.2 L 107.8 · cap $84.3B (#2) · Binance $277.7M/d
- 2021: $3,676 +399.2% · H 4,808 L 728.9 · cap $435.2B (#2) · Binance $2.1B/d
- 2022: $1,196 -67.5% · H 3,828 L 995.1 · cap $144.1B (#2) · Binance $1.3B/d
- 2023: $2,282 +90.8% · H 2,378 L 1,200 · cap $273.9B (#2) · Binance $667.1M/d
- 2024: $3,338 +46.3% · H 4,065 L 2,210 · cap $401.5B (#2) · Binance $1.3B/d
- 2025: $2,972 -11.0% · H 4,832 L 1,473 · cap $360.1B (#2) · Binance $1.7B/d
- 2026: $2,238 -24.7% · H 3,355 L 1,568 · cap $257.6B (#2) · Binance $747.6M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ETHUSDT daily (2017-08-17 → 2026-11-08)
