---
tags: [trading, crypto, mav]
---
**MAV**
- Data: 2023-06-28 → 2026-11-08 (1,230 days)
- Last $0.00766 (2026-11-08) · all-time high $0.7954 (2024-04-01) · now -99.0% from high · lowest $0.00755 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.3876 start · H 0.5228 L 0.2004 · Binance $9.3M/d
- 2024: $0.1979 -48.9% · H 0.7954 L 0.1278 · Binance $7.8M/d
- 2025: $0.0271 -86.3% · H 0.2325 L 0.0249 · Binance $3.8M/d
- 2026: $0.00766 -71.7% · H 0.0298 L 0.00755 · Binance $532.9K/d

**Sources**
- Binance MAVUSDT daily (2023-06-28 → 2026-11-08)
