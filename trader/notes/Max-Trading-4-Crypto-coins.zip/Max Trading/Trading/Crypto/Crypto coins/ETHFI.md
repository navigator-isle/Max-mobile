---
tags: [trading, crypto, ethfi]
---
**ETHFI**
- Data: 2024-03-18 → 2026-11-08 (966 days)
- Last $0.5921 (2026-11-08) · all-time high $7.92 (2024-03-27) · now -92.5% from high · lowest $0.2870 (2026-06-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $2.18 start · H 7.92 L 1.22 · Binance $56.2M/d
- 2025: $0.6880 -68.4% · H 2.40 L 0.4220 · Binance $22.9M/d
- 2026: $0.5921 -13.9% · H 0.8070 L 0.2870 · Binance $4.2M/d

**Sources**
- Binance ETHFIUSDT daily (2024-03-18 → 2026-11-08)
