---
tags: [trading, crypto, bank]
---
**BANK**
- Data: 2025-11-13 → 2026-11-08 (361 days)
- Last $0.0239 (2026-11-08) · all-time high $0.3797 (2026-07-26) · now -93.7% from high · lowest $0.0236 (2026-10-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0444 start · H 0.0567 L 0.0346 · Binance $3.9M/d
- 2026: $0.0239 -46.2% · H 0.3797 L 0.0236 · Binance $6.2M/d

**Sources**
- Binance BANKUSDT daily (2025-11-13 → 2026-11-08)
