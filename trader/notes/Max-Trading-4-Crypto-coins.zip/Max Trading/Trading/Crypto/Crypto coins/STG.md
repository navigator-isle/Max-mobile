---
tags: [trading, crypto, stg]
---
**STG**
- Data: 2022-08-19 → 2026-10-06 (1,510 days)
- Last $0.1840 (2026-10-06) · all-time high $1.24 (2023-02-18) · now -85.1% from high · lowest $0.1061 (2025-12-31)
- Binance: stopped trading on Binance (delisted) after 2026-10-06

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.3624 start · H 1.03 L 0.3495 · Binance $15.0M/d
- 2023: $0.6099 +68.3% · H 1.24 L 0.3542 · Binance $9.1M/d
- 2024: $0.3694 -39.4% · H 0.8437 L 0.2462 · Binance $6.5M/d
- 2025: $0.1061 -71.3% · H 0.5246 L 0.1061 · Binance $2.7M/d
- 2026: $0.1840 +73.4% · H 0.6462 L 0.1111 · Binance $1.7M/d

**Sources**
- Binance STGUSDT daily (2022-08-19 → 2026-10-06)
