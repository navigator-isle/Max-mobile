---
tags: [trading, crypto, xai]
---
**XAI**
- Data: 2024-01-09 → 2026-11-08 (1,035 days)
- Last $0.00621 (2026-11-08) · all-time high $1.53 (2024-02-25) · now -99.6% from high · lowest $0.00594 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.2250 start · H 1.53 L 0.1707 · Binance $23.9M/d
- 2025: $0.0159 -92.9% · H 0.2674 L 0.0150 · Binance $5.0M/d
- 2026: $0.00621 -61.0% · H 0.0219 L 0.00594 · Binance $1.1M/d

**Sources**
- Binance XAIUSDT daily (2024-01-09 → 2026-11-08)
