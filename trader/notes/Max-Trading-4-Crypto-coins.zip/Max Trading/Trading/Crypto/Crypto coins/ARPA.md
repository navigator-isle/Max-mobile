---
tags: [trading, crypto, arpa]
---
**ARPA**
- Data: 2019-11-06 → 2026-11-08 (2,560 days)
- Last $0.00938 (2026-11-08) · all-time high $0.2115 (2021-11-12) · now -95.6% from high · lowest $0.00437 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0103 start · H 0.0272 L 0.00804 · Binance $682.5K/d
- 2020: $0.0239 +132.2% · H 0.0505 L 0.00437 · Binance $1.6M/d
- 2021: $0.0972 +307.0% · H 0.2115 L 0.0207 · Binance $20.0M/d
- 2022: $0.0261 -73.1% · H 0.1039 L 0.0247 · Binance $4.5M/d
- 2023: $0.0537 +105.3% · H 0.1142 L 0.0265 · Binance $7.4M/d
- 2024: $0.0485 -9.7% · H 0.1089 L 0.0305 · Binance $6.0M/d
- 2025: $0.0123 -74.6% · H 0.0535 L 0.0115 · Binance $2.4M/d
- 2026: $0.00938 -23.9% · H 0.0198 L 0.0077 · Binance $946.8K/d

**Sources**
- Binance ARPAUSDT daily (2019-11-06 → 2026-11-08)
