---
tags: [trading, crypto, bond]
---
**BOND**
- Data: 2021-07-05 → 2024-07-22 (1,114 days)
- Last $2.15 (2024-07-22) · all-time high $37.27 (2021-11-09) · now -94.2% from high · lowest $1.32 (2024-07-10)
- Binance: stopped trading on Binance (delisted) after 2024-07-22

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $16.49 start · H 37.27 L 15.01 · Binance $5.4M/d
- 2022: $3.30 -80.0% · H 21.65 L 2.33 · Binance $5.7M/d
- 2023: $4.35 +31.9% · H 6.83 L 1.63 · Binance $5.5M/d
- 2024: $2.15 -50.5% · H 5.04 L 1.32 · Binance $5.9M/d

**Sources**
- Binance BONDUSDT daily (2021-07-05 → 2024-07-22)
