---
tags: [trading, crypto, weth]
---
**WETH**
- Data: 2017-12-12 → 2026-05-23 (3,085 days)
- Last $2,116 (2026-05-23) · all-time high $4,831 (2025-08-22) · now -56.2% from high · lowest $82.83 (2018-12-15)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $742.3 start · H 823.8 L 682.3 · cap $25.3M (#56)
- 2018: $130.8 -82.4% · H 1,380 L 82.83 · cap $264.8M (#24)
- 2019: $128.5 -1.7% · H 334.0 L 103.3 · cap $338.1M (#28)
- 2020: $739.0 +475.1% · H 751.2 L 110.3 · cap $4.0B (#15)
- 2021: $3,687 +398.9% · H 4,811 L 730.9 · cap $27.6B (#15)
- 2022: $1,195 -67.6% · H 3,832 L 992.8 · cap $4.6B (#20)
- 2023: $2,279 +90.7% · H 2,379 L 1,200 · cap $7.5B (#18)
- 2024: $3,332 +46.2% · H 4,073 L 2,207 · cap $9.8B (#19)
- 2025: $2,968 -10.9% · H 4,831 L 1,471 · cap $7.8B (#19)
- 2026: $2,116 -28.7% · H 3,356 L 1,850 · cap $4.8B (#21)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
