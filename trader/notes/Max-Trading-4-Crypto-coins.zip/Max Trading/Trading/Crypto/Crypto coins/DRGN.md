---
tags: [trading, crypto, drgn]
---
**DRGN**
- Data: 2018-01-03 → 2026-05-23 (3,063 days)
- Last $0.0121 (2026-05-23) · all-time high $5.49 (2018-01-09) · now -99.8% from high · lowest $0.0052 (2023-05-10)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.0810 start · H 5.49 L 0.0647 · cap $35.1M (#61)
- 2019: $0.0265 -67.3% · H 0.1262 L 0.0235 · cap $11.5M (#77)
- 2020: $0.0411 +55.3% · H 0.1295 L 0.0211 · cap $17.8M (#101)
- 2021: $0.0725 +76.3% · H 0.3466 L 0.0418 · cap $31.4M (#108)
- 2022: $0.0120 -83.4% · H 0.1435 L 0.0109 · cap $5.2M (#109)
- 2023: $0.0210 +74.4% · H 0.0237 L 0.0052 · cap $9.1M (#106)
- 2024: $0.0498 +137.1% · H 0.0855 L 0.0101 · cap $21.6M (#107)
- 2025: $0.00896 -82.0% · H 0.1011 L 0.00794 · cap $3.9M (#104)
- 2026: $0.0121 +35.0% · H 0.0151 L 0.00731 · cap $5.2M (#100)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
