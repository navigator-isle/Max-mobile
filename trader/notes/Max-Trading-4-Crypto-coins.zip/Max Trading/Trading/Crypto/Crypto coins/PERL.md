---
tags: [trading, crypto, perl]
---
**PERL**
- Data: 2019-08-26 → 2023-12-07 (1,565 days)
- Last $0.0046 (2023-12-07) · all-time high $0.2316 (2021-04-08) · now -98.0% from high · lowest $0.0046 (2023-12-07)
- Binance: stopped trading on Binance (delisted) after 2023-12-07

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0210 start · H 0.1151 L 0.0180 · Binance $581.5K/d
- 2020: $0.0233 +11.1% · H 0.0839 L 0.0108 · Binance $836.2K/d
- 2021: $0.0807 +245.9% · H 0.2316 L 0.0236 · Binance $7.7M/d
- 2022: $0.0138 -82.9% · H 0.0850 L 0.0121 · Binance $1.8M/d
- 2023: $0.0046 -66.6% · H 0.0401 L 0.0046 · Binance $2.8M/d

**Sources**
- Binance PERLUSDT daily (2019-08-26 → 2023-12-07)
