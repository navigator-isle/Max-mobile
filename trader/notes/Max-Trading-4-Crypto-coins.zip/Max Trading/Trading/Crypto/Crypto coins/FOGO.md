---
tags: [trading, crypto, fogo]
---
**FOGO**
- Data: 2026-01-15 → 2026-11-08 (298 days)
- Last $0.00205 (2026-11-08) · all-time high $0.0488 (2026-01-15) · now -95.8% from high · lowest $0.00205 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.00205 start · H 0.0488 L 0.00205 · Binance $9.3M/d

**Sources**
- Binance FOGOUSDT daily (2026-01-15 → 2026-11-08)
