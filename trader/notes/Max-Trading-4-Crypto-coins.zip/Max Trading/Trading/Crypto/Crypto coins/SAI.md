---
tags: [trading, crypto, sai]
---
**SAI**
- Data: 2017-12-23 → 2019-11-30 (708 days)
- Last $1.00 (2019-11-30) · all-time high $1.11 (2018-03-07) · now -9.4% from high · lowest $0.9509 (2019-04-12)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $1.10 start · H 1.10 L 1.00 · cap $6.5M (#57)
- 2018: $0.9894 -10.1% · H 1.11 L 0.9636 · cap $68.8M (#51)
- 2019: $1.00 +1.3% · H 1.02 L 0.9509 · cap $84.6M (#49)

**Sources**
- Coin Metrics community data (daily, to 2019-11-30)
