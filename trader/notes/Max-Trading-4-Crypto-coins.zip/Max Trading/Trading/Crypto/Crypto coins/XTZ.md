---
tags: [trading, crypto, xtz]
---
**XTZ**
- Data: 2018-06-30 → 2026-11-08 (3,054 days)
- Last $0.2578 (2026-11-08) · all-time high $8.71 (2021-10-03) · now -97.0% from high · lowest $0.1947 (2026-08-11)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.4529 start · H 4.39 L 0.3485 · cap $276.8M (#22)
- 2019: $1.35 +198.8% · H 1.86 L 0.3618 · cap $1.0B (#17) · Binance $2.1M/d
- 2020: $2.01 +48.6% · H 4.36 L 1.24 · cap $1.7B (#26) · Binance $18.6M/d
- 2021: $4.34 +115.8% · H 8.71 L 2.00 · cap $3.8B (#37) · Binance $54.8M/d
- 2022: $0.7160 -83.5% · H 5.04 L 0.7160 · cap $2.5B (#39) · Binance $10.1M/d
- 2023: $1.01 +40.8% · H 1.44 L 0.6250 · Binance $2.8M/d
- 2024: $1.29 +27.6% · H 1.79 L 0.5930 · Binance $8.1M/d
- 2025: $0.4956 -61.5% · H 1.45 L 0.4295 · Binance $4.1M/d
- 2026: $0.2578 -48.0% · H 0.6191 L 0.1947 · Binance $960.0K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XTZUSDT daily (2019-09-24 → 2026-11-08)
