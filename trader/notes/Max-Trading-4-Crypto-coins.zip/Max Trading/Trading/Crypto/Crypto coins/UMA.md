---
tags: [trading, crypto, uma]
---
**UMA**
- Data: 2020-09-08 → 2026-11-08 (2,253 days)
- Last $0.3160 (2026-11-08) · all-time high $33.90 (2021-02-04) · now -99.1% from high · lowest $0.3160 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $7.62 start · H 18.58 L 5.99 · cap $772.1M (#39) · Binance $1.6M/d
- 2021: $9.11 +19.5% · H 33.90 L 7.61 · cap $970.6M (#62) · Binance $9.1M/d
- 2022: $1.49 -83.6% · H 11.03 L 1.49 · cap $167.6M (#71) · Binance $5.7M/d
- 2023: $2.23 +49.1% · H 2.96 L 1.25 · cap $260.4M (#75) · Binance $2.3M/d
- 2024: $2.65 +18.9% · H 5.77 L 1.67 · cap $324.8M (#69) · Binance $8.5M/d
- 2025: $0.7010 -73.5% · H 3.15 L 0.6700 · cap $89.0M (#75) · Binance $2.7M/d
- 2026: $0.3160 -54.9% · H 0.8130 L 0.3160 · cap $60.1M (#76) · Binance $487.4K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance UMAUSDT daily (2020-09-09 → 2026-11-08)
