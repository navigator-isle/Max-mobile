---
tags: [trading, crypto, doge]
---
**DOGE**
- Data: 2014-01-23 → 2026-11-08 (4,673 days)
- Last $0.0709 (2026-11-08) · all-time high $0.6898 (2021-05-07) · now -89.7% from high · lowest $8.09e-05 (2015-05-07)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $0.000187 start · H 0.00194 L 0.000103 · cap $18.2M (#5)
- 2015: $0.000136 -27.3% · H 0.000212 L 8.09e-05 · cap $13.9M (#7)
- 2016: $0.00023 +69.3% · H 0.000448 L 0.000135 · cap $24.7M (#12)
- 2017: $0.00903 +3823.5% · H 0.00944 L 0.000196 · cap $1.0B (#31)
- 2018: $0.00231 -74.4% · H 0.0168 L 0.00202 · cap $271.8M (#23)
- 2019: $0.00201 -12.9% · H 0.00387 L 0.00178 · cap $242.3M (#32) · Binance $415.0K/d
- 2020: $0.00467 +132.0% · H 0.00478 L 0.00158 · cap $604.3M (#45) · Binance $2.5M/d
- 2021: $0.1703 +3546.0% · H 0.6898 L 0.00568 · cap $22.6B (#17) · Binance $920.1M/d
- 2022: $0.0703 -58.7% · H 0.1845 L 0.0529 · cap $9.7B (#10) · Binance $138.8M/d
- 2023: $0.0896 +27.5% · H 0.1019 L 0.0579 · cap $12.7B (#13) · Binance $87.9M/d
- 2024: $0.3160 +252.9% · H 0.4663 L 0.0780 · cap $46.5B (#7) · Binance $423.2M/d
- 2025: $0.1175 -62.8% · H 0.4153 L 0.1175 · cap $17.9B (#10) · Binance $290.2M/d
- 2026: $0.0709 -39.7% · H 0.1517 L 0.0691 · cap $15.9B (#9) · Binance $75.9M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance DOGEUSDT daily (2019-07-05 → 2026-11-08)
