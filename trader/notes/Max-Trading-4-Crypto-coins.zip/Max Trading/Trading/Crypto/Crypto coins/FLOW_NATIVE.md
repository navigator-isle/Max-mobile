---
tags: [trading, crypto, flow_native]
---
**FLOW_NATIVE**
- Data: 2021-02-10 → 2026-05-23 (1,929 days)
- Last $0.0352 (2026-05-23) · all-time high $38.90 (2021-03-04) · now -99.9% from high · lowest $0.0285 (2026-03-29)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $8.81 start · H 38.90 L 7.08
- 2022: $0.6517 -92.6% · H 9.28 L 0.6517
- 2023: $0.9109 +39.8% · H 1.39 L 0.3985
- 2024: $0.6946 -23.7% · H 1.64 L 0.4774 · cap $1.1B (#45)
- 2025: $0.0896 -87.1% · H 0.8353 L 0.0896 · cap $146.3M (#64)
- 2026: $0.0352 -60.7% · H 0.0995 L 0.0285 · cap $58.5M (#77)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
