---
tags: [trading, crypto, voxel]
---
**VOXEL**
- Data: 2021-12-14 → 2025-12-17 (1,465 days)
- Last $0.0140 (2025-12-17) · all-time high $4.02 (2022-01-02) · now -99.7% from high · lowest $0.0139 (2025-12-16)
- Binance: stopped trading on Binance (delisted) after 2025-12-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $3.61 start · H 3.78 L 2.79 · Binance $123.7M/d
- 2022: $0.1643 -95.4% · H 4.02 L 0.1529 · Binance $8.5M/d
- 2023: $0.2330 +41.8% · H 0.4029 L 0.1263 · Binance $2.3M/d
- 2024: $0.1763 -24.3% · H 0.4154 L 0.0993 · Binance $3.9M/d
- 2025: $0.0140 -92.1% · H 0.2007 L 0.0139 · Binance $3.4M/d

**Sources**
- Binance VOXELUSDT daily (2021-12-14 → 2025-12-17)
