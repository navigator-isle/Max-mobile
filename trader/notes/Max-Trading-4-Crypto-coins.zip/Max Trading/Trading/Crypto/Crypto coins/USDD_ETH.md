---
tags: [trading, crypto, usdd_eth]
---
**USDD_ETH**
- Data: 2022-06-13 → 2026-05-23 (1,441 days)
- Last $0.9984 (2026-05-23) · all-time high $1.01 (2023-10-22) · now -0.7% from high · lowest $0.9567 (2022-06-20)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.9819 start · H 1.00 L 0.9567 · cap $121.9M (#78)
- 2023: $0.9814 -0.1% · H 1.01 L 0.9634 · cap $121.8M (#87)
- 2024: $0.9946 +1.3% · H 1.00 L 0.9705 · cap $123.5M (#86)
- 2025: $0.9983 +0.4% · H 1.00 L 0.9812 · cap $123.9M (#70)
- 2026: $0.9984 +0.0% · H 1.00 L 0.9932 · cap $123.9M (#62)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
