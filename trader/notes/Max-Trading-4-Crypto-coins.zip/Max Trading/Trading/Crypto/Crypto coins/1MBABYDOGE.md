---
tags: [trading, crypto, 1mbabydoge]
---
**1MBABYDOGE**
- Data: 2024-09-16 → 2026-11-08 (784 days)
- Last $0.000301 (2026-11-08) · all-time high $0.00567 (2024-12-11) · now -94.7% from high · lowest $0.000286 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.0031 start · H 0.00567 L 0.00183 · Binance $58.3M/d
- 2025: $0.000632 -79.6% · H 0.0035 L 0.000558 · Binance $4.9M/d
- 2026: $0.000301 -52.4% · H 0.000747 L 0.000286 · Binance $735.9K/d

**Sources**
- Binance 1MBABYDOGEUSDT daily (2024-09-16 → 2026-11-08)
