---
tags: [trading, crypto, bome]
---
**BOME**
- Data: 2024-03-16 → 2026-11-08 (968 days)
- Last $0.000614 (2026-11-08) · all-time high $0.0208 (2024-03-16) · now -97.0% from high · lowest $0.000366 (2026-03-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.0064 start · H 0.0208 L 0.00563 · Binance $120.7M/d
- 2025: $0.000542 -91.5% · H 0.00703 L 0.000534 · Binance $10.1M/d
- 2026: $0.000614 +13.4% · H 0.00122 L 0.000366 · Binance $1.9M/d

**Sources**
- Binance BOMEUSDT daily (2024-03-16 → 2026-11-08)
