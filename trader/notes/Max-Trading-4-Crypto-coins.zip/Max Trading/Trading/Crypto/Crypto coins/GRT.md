---
tags: [trading, crypto, grt]
---
**GRT**
- Data: 2020-12-17 → 2026-11-08 (2,153 days)
- Last $0.0187 (2026-11-08) · all-time high $2.33 (2021-02-13) · now -99.2% from high · lowest $0.0132 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.3505 start · H 0.7383 L 0.1227 · Binance $319.0M/d
- 2021: $0.6419 +83.2% · H 2.33 L 0.2777 · Binance $65.0M/d
- 2022: $0.0554 -91.4% · H 0.6787 L 0.0539 · Binance $15.0M/d
- 2023: $0.1839 +231.9% · H 0.2085 L 0.0566 · Binance $14.5M/d
- 2024: $0.1997 +8.6% · H 0.4522 L 0.1287 · Binance $19.2M/d
- 2025: $0.0332 -83.4% · H 0.2480 L 0.0332 · Binance $5.1M/d
- 2026: $0.0187 -43.8% · H 0.0435 L 0.0132 · Binance $1.2M/d

**Sources**
- Binance GRTUSDT daily (2020-12-17 → 2026-11-08)
