---
tags: [trading, crypto, alt]
---
**ALT**
- Data: 2024-01-25 → 2026-11-08 (1,019 days)
- Last $0.00534 (2026-11-08) · all-time high $0.6654 (2024-03-28) · now -99.2% from high · lowest $0.00527 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.1105 start · H 0.6654 L 0.0732 · Binance $32.3M/d
- 2025: $0.0115 -89.6% · H 0.1300 L 0.0108 · Binance $5.0M/d
- 2026: $0.00534 -53.4% · H 0.0138 L 0.00527 · Binance $2.0M/d

**Sources**
- Binance ALTUSDT daily (2024-01-25 → 2026-11-08)
