---
tags: [trading, crypto, fdusd_eth]
---
**FDUSD_ETH**
- Data: 2023-07-26 → 2026-05-23 (1,033 days)
- Last $0.9972 (2026-05-23) · all-time high $1.01 (2024-04-04) · now -1.0% from high · lowest $0.9842 (2025-04-02)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.9983 start · H 1.00 L 0.9965 · cap $1.7B (#36)
- 2024: $0.9972 -0.1% · H 1.01 L 0.9959 · cap $2.1B (#38)
- 2025: $0.9976 +0.0% · H 1.00 L 0.9842 · cap $376.0M (#49)
- 2026: $0.9972 -0.0% · H 1.00 L 0.9968 · cap $259.5M (#53)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
