---
tags: [trading, crypto, ant]
---
**ANT**
- Data: 2017-08-29 → 2024-02-20 (2,367 days)
- Last $7.41 (2024-02-20) · all-time high $13.54 (2021-12-31) · now -45.3% from high · lowest $0.2792 (2018-11-24)
- Binance: stopped trading on Binance (delisted) after 2024-02-20

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $3.77 start · H 4.03 L 0.9186 · cap $149.2M (#55)
- 2018: $0.3563 -90.5% · H 7.72 L 0.2792 · cap $14.1M (#68)
- 2019: $0.4014 +12.7% · H 0.9514 L 0.3003 · cap $15.9M (#74)
- 2020: $3.06 +661.3% · H 9.62 L 0.3841 · cap $120.4M (#78) · Binance $2.5M/d
- 2021: $13.54 +343.1% · H 13.54 L 3.06 · cap $531.1M (#75) · Binance $11.9M/d
- 2022: $2.24 -83.5% · H 13.08 L 1.23 · cap $88.4M (#81) · Binance $8.3M/d
- 2023: $5.78 +158.6% · H 6.03 L 2.05 · cap $229.0M (#78) · Binance $2.1M/d
- 2024: $7.41 +28.1% · H 7.45 L 5.61 · cap $252.3M (#71) · Binance $1.1M/d

**Sources**
- Coin Metrics community data (daily, to 2024-11-07)
- Binance ANTUSDT daily (2020-08-13 → 2024-02-20)
