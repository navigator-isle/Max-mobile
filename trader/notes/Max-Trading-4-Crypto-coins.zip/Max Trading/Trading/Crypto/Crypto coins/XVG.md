---
tags: [trading, crypto, xvg]
---
**XVG**
- Data: 2017-09-30 → 2026-11-08 (3,327 days)
- Last $0.00201 (2026-11-08) · all-time high $0.2534 (2017-12-24) · now -99.2% from high · lowest $0.0014 (2023-06-15)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.2282 start · H 0.2534 L 0.00452 · cap $3.3B (#16)
- 2018: $0.00672 -97.1% · H 0.1897 L 0.00543 · cap $103.8M (#44)
- 2019: $0.00343 -48.9% · H 0.0114 L 0.00312 · cap $55.3M (#51)
- 2020: $0.00751 +118.9% · H 0.00922 L 0.00188 · cap $123.2M (#77)
- 2021: $0.0170 +126.8% · H 0.0695 L 0.00729 · cap $280.3M (#91) · Binance $7.4M/d
- 2022: $0.00267 -84.3% · H 0.0177 L 0.00216 · cap $43.9M (#93) · Binance $1.2M/d
- 2023: $0.00397 +48.7% · H 0.00841 L 0.0014 · cap $6.6B (#22) · Binance $5.4M/d
- 2024: $0.0131 +231.2% · H 0.0203 L 0.00304 · cap $21.7B (#12) · Binance $10.8M/d
- 2025: $0.00576 -56.2% · H 0.0153 L 0.00356 · cap $9.5B (#15) · Binance $4.1M/d
- 2026: $0.00201 -65.0% · H 0.00783 L 0.00189 · cap $5.6B (#20) · Binance $1.0M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XVGUSDT daily (2021-06-06 → 2026-11-08)
