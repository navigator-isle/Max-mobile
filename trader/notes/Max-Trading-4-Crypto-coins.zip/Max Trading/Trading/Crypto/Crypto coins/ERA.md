---
tags: [trading, crypto, era]
---
**ERA**
- Data: 2025-07-17 → 2026-11-08 (480 days)
- Last $0.0778 (2026-11-08) · all-time high $1.71 (2025-07-17) · now -95.4% from high · lowest $0.0555 (2026-08-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1943 start · H 1.71 L 0.1820 · Binance $33.9M/d
- 2026: $0.0778 -60.0% · H 0.2298 L 0.0555 · Binance $2.7M/d

**Sources**
- Binance ERAUSDT daily (2025-07-17 → 2026-11-08)
