---
tags: [trading, crypto, nas_eth]
---
**NAS_ETH**
- Data: 2017-12-26 → 2024-12-12 (2,544 days)
- Last $0.00403 (2024-12-12) · all-time high $16.03 (2018-01-09) · now -100.0% from high · lowest $0.00387 (2024-11-30)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $5.49 start · H 6.52 L 5.14 · cap $247.1M (#53)
- 2018: $0.5729 -89.6% · H 16.03 L 0.4852 · cap $25.8M (#65)
- 2019: $0.3542 -38.2% · H 1.79 L 0.3462 · cap $15.9M (#73)
- 2020: $0.2345 -33.8% · H 0.6801 L 0.1773 · cap $10.6M (#105)
- 2021: $0.3392 +44.7% · H 1.51 L 0.2412 · cap $15.3M (#113)
- 2022: $0.0233 -93.1% · H 0.3555 L 0.0201 · cap $1.0M (#113)
- 2023: $0.0134 -42.4% · H 0.0462 L 0.00791 · cap $604.1K (#111)
- 2024: $0.00403 -70.0% · H 0.0153 L 0.00387 · cap $181.5K (#116)

**Sources**
- Coin Metrics community data (daily, to 2024-12-12)
