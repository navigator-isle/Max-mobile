---
tags: [trading, crypto, usdt_omni]
---
**USDT_OMNI**
- Data: 2014-10-06 → 2026-05-23 (4,248 days)
- Last $0.9987 (2026-05-23) · all-time high $1.11 (2017-12-12) · now -10.2% from high · lowest $0.8238 (2015-06-04)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $0.9830 start · H 1.01 L 0.9741 · cap $98 (#9)
- 2015: $0.9727 -1.1% · H 1.04 L 0.8238 · cap $925.6K (#11)
- 2016: $1.01 +3.7% · H 1.10 L 0.9535 · cap $10.0M (#14)
- 2017: $1.01 +0.5% · H 1.11 L 0.8493 · cap $1.4B (#28)
- 2018: $0.9987 -1.5% · H 1.03 L 0.9503 · cap $2.5B (#7)
- 2019: $0.9954 -0.3% · H 1.01 L 0.9702 · cap $1.5B (#14)
- 2020: $1.00 +0.6% · H 1.01 L 0.9950 · cap $1.3B (#31)
- 2021: $1.00 -0.1% · H 1.00 L 0.9989 · cap $1.3B (#53)
- 2022: $0.9995 -0.1% · H 1.00 L 0.9954 · cap $887.5M (#36)
- 2023: $0.9998 +0.0% · H 1.01 L 0.9984 · cap $887.8M (#49)
- 2024: $0.9980 -0.2% · H 1.00 L 0.9980 · cap $886.2M (#49)
- 2025: $0.9983 +0.0% · H 1.00 L 0.9978 · cap $886.5M (#43)
- 2026: $0.9987 +0.0% · H 1.00 L 0.9977 · cap $886.9M (#43)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
