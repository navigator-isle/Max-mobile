---
tags: [trading, crypto, mana]
---
**MANA**
- Data: 2017-08-25 → 2026-11-08 (3,363 days)
- Last $0.0710 (2026-11-08) · all-time high $5.19 (2021-11-25) · now -98.6% from high · lowest $0.00884 (2017-10-28)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.1015 start · H 0.1265 L 0.00884 · cap $284.9M (#49)
- 2018: $0.0437 -56.9% · H 0.2429 L 0.0419 · cap $110.9M (#39)
- 2019: $0.0301 -31.2% · H 0.0653 L 0.0206 · cap $76.2M (#48)
- 2020: $0.0778 +158.6% · H 0.1094 L 0.0186 · cap $170.9M (#70) · Binance $1.5M/d
- 2021: $3.27 +4104.0% · H 5.19 L 0.0789 · cap $7.2B (#29) · Binance $148.2M/d
- 2022: $0.2971 -90.9% · H 3.47 L 0.2927 · cap $649.9M (#44) · Binance $44.6M/d
- 2023: $0.5207 +75.3% · H 0.8083 L 0.2691 · cap $1.1B (#45) · Binance $11.1M/d
- 2024: $0.4670 -10.3% · H 0.7798 L 0.2485 · cap $1.0B (#47) · Binance $9.6M/d
- 2025: $0.1215 -74.0% · H 0.5760 L 0.1166 · cap $266.1M (#55) · Binance $3.7M/d
- 2026: $0.0710 -41.6% · H 0.1683 L 0.0622 · cap $192.9M (#56) · Binance $971.1K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance MANAUSDT daily (2020-08-06 → 2026-11-08)
