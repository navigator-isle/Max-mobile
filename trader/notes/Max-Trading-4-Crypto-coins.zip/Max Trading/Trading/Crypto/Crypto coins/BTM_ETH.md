---
tags: [trading, crypto, btm_eth]
---
**BTM_ETH**
- Data: 2017-10-02 → 2025-06-25 (2,824 days)
- Last $0.000412 (2025-06-25) · all-time high $1.15 (2018-04-23) · now -100.0% from high · lowest $0.000387 (2025-06-11)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.3573 start · H 0.4466 L 0.0661 · cap $502.7M (#46)
- 2018: $0.0756 -78.9% · H 1.15 L 0.0655 · cap $106.3M (#41)
- 2019: $0.0652 -13.7% · H 0.2041 L 0.0523 · cap $91.8M (#45)
- 2020: $0.0530 -18.8% · H 0.1265 L 0.0462 · cap $74.6M (#86)
- 2021: $0.0377 -28.8% · H 0.2638 L 0.0375 · cap $53.1M (#105)
- 2022: $0.0134 -64.5% · H 0.0396 L 0.00727 · cap $18.8M (#99)
- 2023: $0.0116 -13.1% · H 0.0353 L 0.0103 · cap $16.4M (#101)
- 2024: $0.0039 -66.5% · H 0.0138 L 0.00381 · cap $5.5M (#113)
- 2025: $0.000412 -89.4% · H 0.00488 L 0.000387 · cap $579.2K (#113)

**Sources**
- Coin Metrics community data (daily, to 2025-06-25)
