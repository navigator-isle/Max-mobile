---
tags: [trading, crypto, aave]
---
**AAVE**
- Data: 2020-10-10 → 2026-11-08 (2,221 days)
- Last $130.2 (2026-11-08) · all-time high $628.8 (2021-05-18) · now -79.3% from high · lowest $27.69 (2020-11-04)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $88.48 start · H 92.71 L 27.69 · cap $1.4B (#30) · Binance $19.5M/d
- 2021: $253.9 +187.0% · H 628.8 L 85.77 · cap $4.1B (#35) · Binance $77.3M/d
- 2022: $52.00 -79.5% · H 267.2 L 49.60 · cap $830.1M (#38) · Binance $22.0M/d
- 2023: $108.7 +109.0% · H 118.9 L 50.10 · cap $1.7B (#37) · Binance $11.8M/d
- 2024: $308.8 +184.1% · H 383.5 L 78.20 · cap $4.9B (#25) · Binance $34.1M/d
- 2025: $146.0 -52.7% · H 370.8 L 125.3 · cap $2.3B (#30) · Binance $44.9M/d
- 2026: $130.2 -10.8% · H 184.1 L 60.96 · cap $1.4B (#38) · Binance $16.2M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance AAVEUSDT daily (2020-10-15 → 2026-11-08)
