---
tags: [trading, crypto, baby]
---
**BABY**
- Data: 2025-04-10 → 2026-11-08 (578 days)
- Last $0.0107 (2026-11-08) · all-time high $0.1406 (2025-04-12) · now -92.4% from high · lowest $0.00966 (2026-08-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0164 start · H 0.1406 L 0.0164 · Binance $7.2M/d
- 2026: $0.0107 -34.8% · H 0.0205 L 0.00966 · Binance $4.7M/d

**Sources**
- Binance BABYUSDT daily (2025-04-10 → 2026-11-08)
