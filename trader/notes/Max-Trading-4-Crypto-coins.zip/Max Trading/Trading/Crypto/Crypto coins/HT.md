---
tags: [trading, crypto, ht]
---
**HT**
- Data: 2019-03-06 → 2026-05-23 (2,636 days)
- Last $0.1429 (2026-05-23) · all-time high $36.08 (2021-05-12) · now -99.6% from high · lowest $0.1429 (2026-05-23)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $2.73 start · H 5.15 L 1.64 · cap $1.4B (#15)
- 2020: $4.38 +60.0% · H 5.05 L 2.45 · cap $2.2B (#22)
- 2021: $9.39 +114.7% · H 36.08 L 4.65 · cap $4.7B (#32)
- 2022: $5.17 -44.9% · H 10.11 L 4.00 · cap $2.6B (#24)
- 2023: $2.60 -49.7% · H 6.19 L 2.27 · cap $1.3B (#41)
- 2024: $1.20 -53.9% · H 3.07 L 0.3476 · cap $599.5M (#57)
- 2025: $0.2049 -82.9% · H 1.35 L 0.1585 · cap $102.4M (#73)
- 2026: $0.1429 -30.2% · H 0.2542 L 0.1429 · cap $71.5M (#70)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
