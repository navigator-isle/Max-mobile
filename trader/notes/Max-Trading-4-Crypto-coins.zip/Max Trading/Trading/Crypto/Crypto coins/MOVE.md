---
tags: [trading, crypto, move]
---
**MOVE**
- Data: 2024-12-09 → 2026-11-08 (700 days)
- Last $0.00582 (2026-11-08) · all-time high $1.13 (2024-12-27) · now -99.5% from high · lowest $0.00575 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.8617 start · H 1.13 L 0.6202 · Binance $194.6M/d
- 2025: $0.0339 -96.1% · H 1.11 L 0.0318 · Binance $10.7M/d
- 2026: $0.00582 -82.8% · H 0.0400 L 0.00575 · Binance $1.2M/d

**Sources**
- Binance MOVEUSDT daily (2024-12-09 → 2026-11-08)
