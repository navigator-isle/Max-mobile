---
tags: [trading, crypto, ygg]
---
**YGG**
- Data: 2021-09-24 → 2026-11-08 (1,872 days)
- Last $0.0217 (2026-11-08) · all-time high $9.67 (2021-11-20) · now -99.8% from high · lowest $0.0172 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $5.29 start · H 9.67 L 4.87 · Binance $23.5M/d
- 2022: $0.1624 -96.9% · H 5.61 L 0.1594 · Binance $4.8M/d
- 2023: $0.4255 +162.0% · H 0.5449 L 0.1321 · Binance $8.6M/d
- 2024: $0.4901 +15.2% · H 1.68 L 0.2856 · Binance $17.7M/d
- 2025: $0.0642 -86.9% · H 0.5493 L 0.0578 · Binance $4.0M/d
- 2026: $0.0217 -66.2% · H 0.0746 L 0.0172 · Binance $910.9K/d

**Sources**
- Binance YGGUSDT daily (2021-09-24 → 2026-11-08)
