---
tags: [trading, crypto, eurc_eth]
---
**EURC_ETH**
- Data: 2024-12-13 → 2026-05-23 (527 days)
- Last $1.16 (2026-05-23) · all-time high $1.20 (2026-01-27) · now -3.7% from high · lowest $1.02 (2025-01-10)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.04 start · H 1.05 L 1.04 · cap $39.8M (#102)
- 2025: $1.18 +13.5% · H 1.19 L 1.02 · cap $223.9M (#57)
- 2026: $1.16 -1.3% · H 1.20 L 1.14 · cap $314.0M (#50)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
