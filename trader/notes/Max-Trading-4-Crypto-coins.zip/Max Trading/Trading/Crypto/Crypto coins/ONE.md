---
tags: [trading, crypto, one]
---
**ONE**
- Data: 2019-06-01 → 2026-11-08 (2,718 days)
- Last $0.00223 (2026-11-08) · all-time high $0.3559 (2022-01-14) · now -99.4% from high · lowest $0.00064 (2026-09-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00457 start · H 0.0284 L 0.00403 · Binance $4.6M/d
- 2020: $0.00423 -7.4% · H 0.0133 L 0.00161 · Binance $1.2M/d
- 2021: $0.2335 +5420.8% · H 0.3459 L 0.00423 · Binance $68.5M/d
- 2022: $0.0100 -95.7% · H 0.3559 L 0.00975 · Binance $24.6M/d
- 2023: $0.0188 +87.2% · H 0.0282 L 0.00881 · Binance $4.4M/d
- 2024: $0.0263 +40.4% · H 0.0457 L 0.0100 · Binance $6.6M/d
- 2025: $0.00356 -86.5% · H 0.0322 L 0.00327 · Binance $2.4M/d
- 2026: $0.00223 -37.2% · H 0.00446 L 0.00064 · Binance $2.1M/d

**Sources**
- Binance ONEUSDT daily (2019-06-01 → 2026-11-08)
