---
tags: [trading, crypto, iota]
---
**IOTA**
- Data: 2018-05-31 → 2026-11-08 (3,084 days)
- Last $0.0354 (2026-11-08) · all-time high $2.51 (2021-04-16) · now -98.6% from high · lowest $0.0318 (2026-08-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.3490 start · H 1.92 L 0.2122 · Binance $7.2M/d
- 2019: $0.1596 -54.3% · H 0.5114 L 0.1550 · Binance $1.7M/d
- 2020: $0.2964 +85.7% · H 0.4232 L 0.1086 · Binance $2.9M/d
- 2021: $1.37 +360.8% · H 2.51 L 0.2863 · Binance $42.5M/d
- 2022: $0.1688 -87.6% · H 1.41 L 0.1600 · Binance $6.4M/d
- 2023: $0.3102 +83.8% · H 0.3313 L 0.1391 · Binance $4.2M/d
- 2024: $0.2809 -9.4% · H 0.4942 L 0.1031 · Binance $10.4M/d
- 2025: $0.0809 -71.2% · H 0.3987 L 0.0809 · Binance $6.3M/d
- 2026: $0.0354 -56.2% · H 0.1127 L 0.0318 · Binance $1.3M/d

**Sources**
- Binance IOTAUSDT daily (2018-05-31 → 2026-11-08)
