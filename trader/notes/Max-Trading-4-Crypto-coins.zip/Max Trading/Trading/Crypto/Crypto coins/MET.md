---
tags: [trading, crypto, met]
---
**MET**
- Data: 2025-11-13 → 2026-11-08 (361 days)
- Last $0.3085 (2026-11-08) · all-time high $0.4589 (2025-11-14) · now -32.8% from high · lowest $0.0973 (2026-06-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.2520 start · H 0.4589 L 0.2080 · Binance $31.6M/d
- 2026: $0.3085 +22.4% · H 0.4454 L 0.0973 · Binance $2.1M/d

**Sources**
- Binance METUSDT daily (2025-11-13 → 2026-11-08)
