---
tags: [trading, crypto, lit]
---
**LIT**
- Data: 2021-02-04 → 2025-02-10 (1,468 days)
- Last $0.7430 (2025-02-10) · all-time high $13.40 (2021-02-15) · now -94.5% from high · lowest $0.4640 (2022-05-12)
- Binance: stopped trading on Binance (delisted) after 2025-02-10

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $2.97 start · H 13.40 L 2.17 · Binance $24.9M/d
- 2022: $0.7110 -76.0% · H 3.18 L 0.4640 · Binance $7.8M/d
- 2023: $1.01 +42.3% · H 1.70 L 0.5380 · Binance $4.1M/d
- 2024: $0.9130 -9.8% · H 1.79 L 0.5270 · Binance $3.1M/d
- 2025: $0.7430 -18.6% · H 1.21 L 0.5320 · Binance $12.4M/d

**Sources**
- Binance LITUSDT daily (2021-02-04 → 2025-02-10)
