---
tags: [trading, crypto, xrp]
---
**XRP**
- Data: 2014-08-15 → 2026-11-08 (4,469 days)
- Last $1.16 (2026-11-08) · all-time high $3.55 (2025-07-22) · now -67.2% from high · lowest $0.00407 (2015-12-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $0.0246 start · H 0.0281 L 0.00429 · cap $2.5B (#2)
- 2015: $0.00596 -75.8% · H 0.0246 L 0.00407 · cap $595.5M (#2)
- 2016: $0.00652 +9.5% · H 0.00922 L 0.00502 · cap $652.1M (#3)
- 2017: $1.98 +30281.0% · H 1.98 L 0.00533 · cap $198.1B (#2)
- 2018: $0.3485 -82.4% · H 2.75 L 0.2631 · cap $34.8B (#2) · Binance $34.3M/d
- 2019: $0.1930 -44.6% · H 0.4773 L 0.1831 · cap $19.2B (#2) · Binance $31.2M/d
- 2020: $0.2196 +13.8% · H 0.6940 L 0.1355 · cap $22.1B (#3) · Binance $111.0M/d
- 2021: $0.8297 +277.8% · H 1.83 L 0.2206 · cap $83.1B (#3) · Binance $699.2M/d
- 2022: $0.3389 -59.2% · H 0.8763 L 0.3075 · cap $33.9B (#7) · Binance $177.0M/d
- 2023: $0.6156 +81.6% · H 0.8199 L 0.3380 · cap $61.3B (#4) · Binance $191.2M/d
- 2024: $2.08 +238.5% · H 2.72 L 0.4195 · cap $207.8B (#3) · Binance $384.5M/d
- 2025: $1.84 -11.6% · H 3.55 L 1.80 · cap $183.9B (#4) · Binance $504.5M/d
- 2026: $1.16 -36.8% · H 2.35 L 0.9936 · cap $135.8B (#4) · Binance $162.6M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XRPUSDT daily (2018-05-04 → 2026-11-08)
