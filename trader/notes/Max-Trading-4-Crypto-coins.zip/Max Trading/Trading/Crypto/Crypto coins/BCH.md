---
tags: [trading, crypto, bch]
---
**BCH**
- Data: 2017-08-01 → 2026-11-08 (3,387 days)
- Last $246.0 (2026-11-08) · all-time high $3,678 (2017-12-20) · now -93.3% from high · lowest $76.07 (2018-12-15)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $2,385 start · H 3,678 L 193.4 · cap $40.3B (#4)
- 2018: $148.4 -93.8% · H 2,876 L 76.07 · cap $2.6B (#5)
- 2019: $204.5 +37.8% · H 481.1 L 109.1 · cap $3.7B (#6) · Binance $10.9M/d
- 2020: $342.1 +67.3% · H 493.8 L 144.1 · cap $6.4B (#11) · Binance $53.0M/d
- 2021: $430.2 +25.7% · H 1,548 L 341.8 · cap $8.2B (#28) · Binance $138.2M/d
- 2022: $97.00 -77.5% · H 447.7 L 89.00 · cap $1.9B (#29) · Binance $16.8M/d
- 2023: $259.7 +167.7% · H 304.2 L 96.80 · cap $5.1B (#24) · Binance $24.4M/d
- 2024: $434.5 +67.3% · H 693.9 L 229.6 · cap $8.6B (#20) · Binance $47.6M/d
- 2025: $599.5 +38.0% · H 624.9 L 269.2 · cap $12.0B (#13) · Binance $28.8M/d
- 2026: $246.0 -59.0% · H 654.5 L 190.4 · cap $7.1B (#15) · Binance $15.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance BCHUSDT daily (2019-11-28 → 2026-11-08)
