---
tags: [trading, crypto, tusd_trx]
---
**TUSD_TRX**
- Data: 2021-03-23 → 2026-05-23 (1,888 days)
- Last $0.9987 (2026-05-23) · all-time high $1.03 (2024-03-24) · now -2.7% from high · lowest $0.9597 (2024-02-28)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.9998 start · H 1.00 L 0.9958 · cap $325.4M (#88)
- 2022: $0.9986 -0.1% · H 1.00 L 0.9911 · cap $250.8M (#63)
- 2023: $0.9966 -0.2% · H 1.01 L 0.9942 · cap $1.9B (#35)
- 2024: $0.9985 +0.2% · H 1.03 L 0.9597 · cap $168.4M (#83)
- 2025: $0.9961 -0.2% · H 1.00 L 0.9903 · cap $169.5M (#62)
- 2026: $0.9987 +0.3% · H 1.00 L 0.9965 · cap $169.9M (#59)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
