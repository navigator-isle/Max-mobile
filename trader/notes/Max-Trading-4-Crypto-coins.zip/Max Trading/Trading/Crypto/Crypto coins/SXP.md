---
tags: [trading, crypto, sxp]
---
**SXP**
- Data: 2020-07-20 → 2026-04-01 (2,082 days)
- Last $0.0022 (2026-04-01) · all-time high $5.47 (2021-05-03) · now -100.0% from high · lowest $0.0022 (2026-04-01)
- Binance: stopped trading on Binance (delisted) after 2026-04-01

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.7420 start · H 4.32 L 0.6220 · Binance $33.3M/d
- 2021: $2.03 +173.0% · H 5.47 L 0.7120 · Binance $100.3M/d
- 2022: $0.2017 -90.0% · H 2.25 L 0.1962 · Binance $8.8M/d
- 2023: $0.3950 +95.8% · H 0.9325 L 0.2025 · Binance $8.2M/d
- 2024: $0.3360 -14.9% · H 0.5541 L 0.1806 · Binance $5.2M/d
- 2025: $0.0604 -82.0% · H 0.3712 L 0.0495 · Binance $1.9M/d
- 2026: $0.0022 -96.4% · H 0.0767 L 0.0022 · Binance $1.2M/d

**Sources**
- Binance SXPUSDT daily (2020-07-20 → 2026-04-01)
