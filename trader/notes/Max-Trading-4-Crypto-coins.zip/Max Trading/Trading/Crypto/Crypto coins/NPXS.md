---
tags: [trading, crypto, npxs]
---
**NPXS**
- Data: 2019-08-13 → 2021-04-05 (602 days)
- Last $0.00703 (2021-04-05) · all-time high $0.00822 (2021-03-26) · now -14.4% from high · lowest $8.58e-05 (2020-03-12)
- Binance: stopped trading on Binance (delisted) after 2021-04-05

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.000125 start · H 0.000482 L 0.000123 · Binance $509.6K/d
- 2020: $0.000172 +37.1% · H 0.000238 L 8.58e-05 · Binance $288.0K/d
- 2021: $0.00703 +3996.8% · H 0.00822 L 0.000173 · Binance $50.3M/d

**Sources**
- Binance NPXSUSDT daily (2019-08-13 → 2021-04-05)
