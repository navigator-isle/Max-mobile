---
tags: [trading, crypto, mbox]
---
**MBOX**
- Data: 2021-08-19 → 2026-06-19 (1,766 days)
- Last $0.0021 (2026-06-19) · all-time high $12.65 (2021-11-30) · now -100.0% from high · lowest $0.0021 (2026-06-18)
- Binance: stopped trading on Binance (delisted) after 2026-06-19

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $5.19 start · H 12.65 L 3.62 · Binance $79.1M/d
- 2022: $0.3710 -92.8% · H 5.39 L 0.3690 · Binance $9.4M/d
- 2023: $0.3724 +0.4% · H 0.6130 L 0.2048 · Binance $3.2M/d
- 2024: $0.1907 -48.8% · H 0.5943 L 0.1270 · Binance $5.6M/d
- 2025: $0.0303 -84.1% · H 0.2179 L 0.0289 · Binance $2.4M/d
- 2026: $0.0021 -93.1% · H 0.0354 L 0.0021 · Binance $1.3M/d

**Sources**
- Binance MBOXUSDT daily (2021-08-19 → 2026-06-19)
