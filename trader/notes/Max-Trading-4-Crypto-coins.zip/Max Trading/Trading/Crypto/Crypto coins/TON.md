---
tags: [trading, crypto, ton]
---
**TON**
- Data: 2024-08-08 → 2026-06-30 (692 days)
- Last $1.60 (2026-06-30) · all-time high $6.90 (2024-12-04) · now -76.8% from high · lowest $1.20 (2026-03-01)
- Binance: stopped trading on Binance (delisted) after 2026-06-30

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $5.51 start · H 6.90 L 4.62 · Binance $49.9M/d
- 2025: $1.66 -69.9% · H 5.80 L 1.44 · Binance $23.0M/d
- 2026: $1.60 -3.6% · H 2.71 L 1.20 · Binance $21.5M/d

**Sources**
- Binance TONUSDT daily (2024-08-08 → 2026-06-30)
