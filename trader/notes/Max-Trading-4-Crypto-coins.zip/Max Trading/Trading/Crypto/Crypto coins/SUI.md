---
tags: [trading, crypto, sui]
---
**SUI**
- Data: 2023-05-03 → 2026-11-08 (1,286 days)
- Last $0.8490 (2026-11-08) · all-time high $5.29 (2025-01-04) · now -84.0% from high · lowest $0.3703 (2023-10-19)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.7752 start · H 1.40 L 0.3703 · Binance $37.7M/d
- 2024: $4.12 +431.8% · H 4.78 L 0.5348 · Binance $136.2M/d
- 2025: $1.40 -65.9% · H 5.29 L 1.35 · Binance $189.3M/d
- 2026: $0.8490 -39.5% · H 1.90 L 0.6517 · Binance $48.2M/d

**Sources**
- Binance SUIUSDT daily (2023-05-03 → 2026-11-08)
