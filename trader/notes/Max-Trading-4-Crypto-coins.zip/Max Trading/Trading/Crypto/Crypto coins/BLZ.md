---
tags: [trading, crypto, blz]
---
**BLZ**
- Data: 2020-08-11 → 2024-12-25 (1,598 days)
- Last $0.0582 (2024-12-25) · all-time high $0.5507 (2021-04-08) · now -89.4% from high · lowest $0.0489 (2023-06-18)
- Binance: stopped trading on Binance (delisted) after 2024-12-25

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.0604 start · H 0.1782 L 0.0492 · Binance $1.1M/d
- 2021: $0.2198 +263.7% · H 0.5507 L 0.0629 · Binance $12.4M/d
- 2022: $0.0493 -77.6% · H 0.2401 L 0.0493 · Binance $5.2M/d
- 2023: $0.3375 +584.6% · H 0.3620 L 0.0489 · Binance $9.1M/d
- 2024: $0.0582 -82.8% · H 0.4565 L 0.0563 · Binance $5.0M/d

**Sources**
- Binance BLZUSDT daily (2020-08-11 → 2024-12-25)
