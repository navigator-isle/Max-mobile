---
tags: [trading, crypto, people]
---
**PEOPLE**
- Data: 2021-12-23 → 2026-11-08 (1,782 days)
- Last $0.00588 (2026-11-08) · all-time high $0.1681 (2021-12-23) · now -96.5% from high · lowest $0.00496 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.1177 start · H 0.1681 L 0.1136 · Binance $43.2M/d
- 2022: $0.0203 -82.8% · H 0.1249 L 0.0140 · Binance $28.6M/d
- 2023: $0.0128 -36.8% · H 0.0314 L 0.00875 · Binance $4.2M/d
- 2024: $0.0461 +260.2% · H 0.1350 L 0.0134 · Binance $56.8M/d
- 2025: $0.00946 -79.5% · H 0.0498 L 0.00824 · Binance $8.0M/d
- 2026: $0.00588 -37.8% · H 0.0117 L 0.00496 · Binance $1.0M/d

**Sources**
- Binance PEOPLEUSDT daily (2021-12-23 → 2026-11-08)
