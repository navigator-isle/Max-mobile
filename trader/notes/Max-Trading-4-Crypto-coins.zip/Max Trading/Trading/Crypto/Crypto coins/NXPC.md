---
tags: [trading, crypto, nxpc]
---
**NXPC**
- Data: 2025-05-15 → 2026-11-08 (543 days)
- Last $0.1502 (2026-11-08) · all-time high $2.62 (2025-05-15) · now -94.3% from high · lowest $0.1492 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.3547 start · H 2.62 L 0.3091 · Binance $9.8M/d
- 2026: $0.1502 -57.7% · H 0.4325 L 0.1492 · Binance $729.7K/d

**Sources**
- Binance NXPCUSDT daily (2025-05-15 → 2026-11-08)
