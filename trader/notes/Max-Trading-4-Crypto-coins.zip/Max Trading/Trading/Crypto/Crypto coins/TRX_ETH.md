---
tags: [trading, crypto, trx_eth]
---
**TRX_ETH**
- Data: 2017-10-07 → 2018-06-25 (262 days)
- Last $0.0421 (2018-06-25) · all-time high $0.2105 (2018-01-05) · now -80.0% from high · lowest $0.00184 (2017-11-12)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.0439 start · H 0.0520 L 0.00184 · cap $4.4B (#14)
- 2018: $0.0421 -4.1% · H 0.2105 L 0.0282 · cap $4.2B (#7)

**Sources**
- Coin Metrics community data (daily, to 2018-06-25)
