---
tags: [trading, crypto, bcc]
---
**BCC**
- Data: 2017-11-11 → 2018-11-20 (371 days)
- Last $448.7 (2018-11-20) · all-time high $3,700 (2017-12-20) · now -87.9% from high · lowest $417.3 (2018-09-17)
- Binance: stopped trading on Binance (delisted) after 2018-11-20

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $2,352 start · H 3,700 L 899.4 · Binance $11.8M/d
- 2018: $448.7 -80.9% · H 2,884 L 417.3 · Binance $22.4M/d

**Sources**
- Binance BCCUSDT daily (2017-11-11 → 2018-11-20)
