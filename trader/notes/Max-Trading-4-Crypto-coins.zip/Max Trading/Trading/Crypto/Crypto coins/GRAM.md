---
tags: [trading, crypto, gram]
---
**GRAM**
- Data: 2026-07-02 → 2026-11-08 (130 days)
- Last $1.07 (2026-11-08) · all-time high $1.78 (2026-07-06) · now -39.9% from high · lowest $1.07 (2026-11-07)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $1.07 start · H 1.78 L 1.07 · Binance $11.2M/d

**Sources**
- Binance GRAMUSDT daily (2026-07-02 → 2026-11-08)
