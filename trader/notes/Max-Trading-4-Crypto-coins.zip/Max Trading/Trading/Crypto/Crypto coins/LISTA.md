---
tags: [trading, crypto, lista]
---
**LISTA**
- Data: 2024-06-20 → 2026-11-08 (872 days)
- Last $0.0730 (2026-11-08) · all-time high $0.7925 (2024-06-26) · now -90.8% from high · lowest $0.0441 (2026-07-24)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.4090 start · H 0.7925 L 0.2906 · Binance $16.2M/d
- 2025: $0.1716 -58.0% · H 0.5295 L 0.1198 · Binance $4.7M/d
- 2026: $0.0730 -57.5% · H 0.1833 L 0.0441 · Binance $479.5K/d

**Sources**
- Binance LISTAUSDT daily (2024-06-20 → 2026-11-08)
