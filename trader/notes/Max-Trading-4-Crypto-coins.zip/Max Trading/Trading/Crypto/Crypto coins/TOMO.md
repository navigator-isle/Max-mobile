---
tags: [trading, crypto, tomo]
---
**TOMO**
- Data: 2019-08-24 → 2023-11-20 (1,550 days)
- Last $1.38 (2023-11-20) · all-time high $3.76 (2021-09-06) · now -63.2% from high · lowest $0.1859 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2023-11-20

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.4403 start · H 0.7049 L 0.2417 · Binance $1.5M/d
- 2020: $0.6754 +53.4% · H 1.42 L 0.1859 · Binance $1.9M/d
- 2021: $1.87 +177.0% · H 3.76 L 0.6750 · Binance $11.8M/d
- 2022: $0.2553 -86.4% · H 1.99 L 0.2553 · Binance $1.7M/d
- 2023: $1.38 +441.3% · H 1.88 L 0.2608 · Binance $6.5M/d

**Sources**
- Binance TOMOUSDT daily (2019-08-24 → 2023-11-20)
