---
tags: [trading, crypto, perp]
---
**PERP**
- Data: 2021-02-04 → 2025-11-12 (1,743 days)
- Last $0.1250 (2025-11-12) · all-time high $21.50 (2021-09-06) · now -99.4% from high · lowest $0.1227 (2025-11-11)
- Binance: stopped trading on Binance (delisted) after 2025-11-12

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $8.77 start · H 21.50 L 4.12 · cap $1.3B (#55) · Binance $12.0M/d
- 2022: $0.3634 -95.9% · H 9.51 L 0.3310 · cap $54.5M (#89) · Binance $3.1M/d
- 2023: $1.14 +213.7% · H 1.30 L 0.3694 · cap $170.1M (#84) · Binance $5.4M/d
- 2024: $0.7828 -31.3% · H 1.81 L 0.4480 · cap $117.1M (#87) · Binance $4.9M/d
- 2025: $0.1250 -84.0% · H 0.8459 L 0.1227 · cap $13.9M (#95) · Binance $1.7M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance PERPUSDT daily (2021-03-19 → 2025-11-12)
