---
tags: [trading, crypto, usdt_trx]
---
**USDT_TRX**
- Data: 2019-04-16 → 2026-05-23 (2,595 days)
- Last $0.9987 (2026-05-23) · all-time high $1.01 (2020-03-13) · now -1.1% from high · lowest $0.9702 (2019-04-28)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.9954 start · H 1.01 L 0.9702 · cap $912.3M (#18)
- 2020: $1.00 +0.6% · H 1.01 L 0.9950 · cap $6.8B (#10)
- 2021: $1.00 -0.1% · H 1.00 L 0.9989 · cap $39.5B (#9)
- 2022: $0.9995 -0.1% · H 1.00 L 0.9954 · cap $37.1B (#6)
- 2023: $0.9998 +0.0% · H 1.01 L 0.9984 · cap $48.8B (#5)
- 2024: $0.9980 -0.2% · H 1.00 L 0.9980 · cap $59.6B (#6)
- 2025: $0.9983 +0.0% · H 1.00 L 0.9978 · cap $81.4B (#6)
- 2026: $0.9987 +0.0% · H 1.00 L 0.9977 · cap $89.2B (#6)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
