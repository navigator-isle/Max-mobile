---
tags: [trading, crypto, iotx]
---
**IOTX**
- Data: 2019-11-14 → 2026-11-08 (2,552 days)
- Last $0.00296 (2026-11-08) · all-time high $0.2368 (2021-11-10) · now -98.7% from high · lowest $0.00164 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00334 start · H 0.0049 L 0.00325 · Binance $24.8K/d
- 2020: $0.00637 +90.8% · H 0.0119 L 0.00164 · Binance $709.7K/d
- 2021: $0.1211 +1800.3% · H 0.2368 L 0.00652 · Binance $42.3M/d
- 2022: $0.0210 -82.7% · H 0.1281 L 0.0190 · Binance $8.0M/d
- 2023: $0.0505 +140.9% · H 0.0606 L 0.0135 · Binance $4.1M/d
- 2024: $0.0384 -24.1% · H 0.0860 L 0.0309 · Binance $7.4M/d
- 2025: $0.00758 -80.2% · H 0.0431 L 0.00692 · Binance $2.2M/d
- 2026: $0.00296 -60.9% · H 0.00917 L 0.00205 · Binance $464.6K/d

**Sources**
- Binance IOTXUSDT daily (2019-11-14 → 2026-11-08)
