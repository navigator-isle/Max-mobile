---
tags: [trading, crypto, slp]
---
**SLP**
- Data: 2021-04-30 → 2026-11-08 (2,019 days)
- Last $0.000469 (2026-11-08) · all-time high $0.3638 (2021-05-01) · now -99.9% from high · lowest $0.000452 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.0269 start · H 0.3638 L 0.0269 · Binance $89.2M/d
- 2022: $0.00206 -92.3% · H 0.0346 L 0.00206 · Binance $42.5M/d
- 2023: $0.00304 +47.6% · H 0.00359 L 0.00132 · Binance $3.7M/d
- 2024: $0.00381 +25.3% · H 0.00766 L 0.0021 · Binance $6.3M/d
- 2025: $0.000767 -79.9% · H 0.00439 L 0.000737 · Binance $1.4M/d
- 2026: $0.000469 -38.9% · H 0.0011 L 0.000452 · Binance $609.9K/d

**Sources**
- Binance SLPUSDT daily (2021-04-30 → 2026-11-08)
