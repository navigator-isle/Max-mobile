---
tags: [trading, crypto, bchsv]
---
**BCHSV**
- Data: 2018-11-16 → 2019-04-22 (158 days)
- Last $58.90 (2019-04-22) · all-time high $143.2 (2018-11-17) · now -58.9% from high · lowest $44.11 (2018-11-22)
- Binance: stopped trading on Binance (delisted) after 2019-04-22

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $83.88 start · H 143.2 L 44.11 · Binance $30.2M/d
- 2019: $58.90 -29.8% · H 92.81 L 55.00 · Binance $5.3M/d

**Sources**
- Binance BCHSVUSDT daily (2018-11-16 → 2019-04-22)
