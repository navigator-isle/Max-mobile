---
tags: [trading, crypto, spcxb]
---
**SPCXB**
- Data: 2026-06-12 → 2026-11-08 (150 days)
- Last $135.2 (2026-11-08) · all-time high $205.8 (2026-06-16) · now -34.3% from high · lowest $108.0 (2026-07-31)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $135.2 start · H 205.8 L 108.0 · Binance $20.8M/d

**Sources**
- Binance SPCXBUSDT daily (2026-06-12 → 2026-11-08)
