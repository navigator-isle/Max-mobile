---
tags: [trading, crypto, wld]
---
**WLD**
- Data: 2023-07-24 → 2026-11-08 (1,204 days)
- Last $0.3282 (2026-11-08) · all-time high $11.69 (2024-03-09) · now -97.2% from high · lowest $0.2341 (2026-05-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $3.63 start · H 4.21 L 1.01 · Binance $39.1M/d
- 2024: $2.09 -42.5% · H 11.69 L 1.34 · Binance $98.8M/d
- 2025: $0.4806 -77.0% · H 2.62 L 0.4791 · Binance $52.5M/d
- 2026: $0.3282 -31.7% · H 0.6751 L 0.2341 · Binance $32.4M/d

**Sources**
- Binance WLDUSDT daily (2023-07-24 → 2026-11-08)
