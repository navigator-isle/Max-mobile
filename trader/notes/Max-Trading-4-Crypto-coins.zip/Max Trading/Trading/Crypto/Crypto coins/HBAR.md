---
tags: [trading, crypto, hbar]
---
**HBAR**
- Data: 2019-09-29 → 2026-11-08 (2,598 days)
- Last $0.0665 (2026-11-08) · all-time high $0.5050 (2021-09-15) · now -86.8% from high · lowest $0.0100 (2020-01-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0102 start · H 0.0419 L 0.0102 · Binance $285.3K/d
- 2020: $0.0318 +210.9% · H 0.0685 L 0.0100 · Binance $2.1M/d
- 2021: $0.2904 +812.1% · H 0.5050 L 0.0324 · Binance $40.6M/d
- 2022: $0.0365 -87.4% · H 0.3250 L 0.0365 · Binance $7.8M/d
- 2023: $0.0859 +135.3% · H 0.0924 L 0.0381 · Binance $9.2M/d
- 2024: $0.2690 +213.2% · H 0.3675 L 0.0425 · Binance $52.7M/d
- 2025: $0.1063 -60.5% · H 0.3745 L 0.1049 · Binance $56.4M/d
- 2026: $0.0665 -37.4% · H 0.1317 L 0.0646 · Binance $12.0M/d

**Sources**
- Binance HBARUSDT daily (2019-09-29 → 2026-11-08)
