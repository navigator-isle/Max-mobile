---
tags: [trading, crypto, aster]
---
**ASTER**
- Data: 2025-10-06 → 2026-11-08 (399 days)
- Last $0.6795 (2026-11-08) · all-time high $2.06 (2025-10-06) · now -67.1% from high · lowest $0.4680 (2026-02-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.6930 start · H 2.06 L 0.6680 · Binance $168.1M/d
- 2026: $0.6795 -1.9% · H 0.7920 L 0.4680 · Binance $15.7M/d

**Sources**
- Binance ASTERUSDT daily (2025-10-06 → 2026-11-08)
