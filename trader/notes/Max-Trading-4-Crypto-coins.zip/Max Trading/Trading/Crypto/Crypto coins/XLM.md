---
tags: [trading, crypto, xlm]
---
**XLM**
- Data: 2015-09-30 → 2026-11-08 (4,058 days)
- Last $0.1503 (2026-11-08) · all-time high $0.8802 (2018-01-03) · now -82.9% from high · lowest $0.00139 (2016-05-28)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2015: $0.00176 start · H 0.00235 L 0.0016 · cap $178.2M (#3)
- 2016: $0.00246 +40.2% · H 0.00318 L 0.00139 · cap $252.5M (#4)
- 2017: $0.3556 +14330.3% · H 0.3556 L 0.00168 · cap $36.8B (#5)
- 2018: $0.1100 -69.1% · H 0.8802 L 0.0945 · cap $11.5B (#4) · Binance $9.2M/d
- 2019: $0.0449 -59.1% · H 0.1426 L 0.0433 · cap $4.7B (#5) · Binance $4.6M/d
- 2020: $0.1276 +183.9% · H 0.2070 L 0.0317 · cap $13.5B (#5) · Binance $20.4M/d
- 2021: $0.2665 +108.8% · H 0.7347 L 0.1275 · cap $28.2B (#14) · Binance $110.9M/d
- 2022: $0.0710 -73.4% · H 0.2921 L 0.0710 · cap $7.5B (#14) · Binance $11.7M/d
- 2023: $0.1290 +81.7% · H 0.1632 L 0.0726 · cap $13.6B (#11) · Binance $8.6M/d
- 2024: $0.3327 +157.9% · H 0.5607 L 0.0839 · cap $34.9B (#9) · Binance $40.3M/d
- 2025: $0.2010 -39.6% · H 0.4973 L 0.2010 · cap $21.1B (#9) · Binance $36.2M/d
- 2026: $0.1503 -25.2% · H 0.2599 L 0.1435 · cap $15.5B (#10) · Binance $18.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XLMUSDT daily (2018-05-31 → 2026-11-08)
