---
tags: [trading, crypto, xmr]
---
**XMR**
- Data: 2014-05-20 → 2024-02-20 (3,564 days)
- Last $118.7 (2024-02-20) · all-time high $484.0 (2021-05-09) · now -75.5% from high · lowest $0.2222 (2015-01-14)
- Binance: stopped trading on Binance (delisted) after 2024-02-20

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2014: $0.4348 start · H 5.01 L 0.3136 · cap $2.4M (#7)
- 2015: $0.4523 +4.0% · H 0.9918 L 0.2222 · cap $4.6M (#9)
- 2016: $13.88 +2968.9% · H 14.16 L 0.4284 · cap $183.0M (#6)
- 2017: $333.5 +2302.7% · H 477.1 L 10.60 · cap $5.0B (#13)
- 2018: $45.50 -86.4% · H 416.0 L 38.10 · cap $736.6M (#14)
- 2019: $44.69 -1.8% · H 117.9 L 42.11 · cap $750.5M (#20) · Binance $1.4M/d
- 2020: $156.2 +249.6% · H 168.2 L 31.81 · cap $2.7B (#21) · Binance $8.4M/d
- 2021: $228.7 +46.4% · H 484.0 L 125.5 · cap $4.0B (#36) · Binance $35.5M/d
- 2022: $147.3 -35.6% · H 278.5 L 104.4 · cap $2.6B (#23) · Binance $17.0M/d
- 2023: $164.9 +11.9% · H 186.3 L 133.9 · cap $2.9B (#29) · Binance $10.5M/d
- 2024: $118.7 -28.0% · H 169.5 L 105.4 · cap $3.5B (#32) · Binance $15.7M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance XMRUSDT daily (2019-03-15 → 2024-02-20)
