---
tags: [trading, crypto, om]
---
**OM**
- Data: 2021-03-08 → 2026-03-02 (1,821 days)
- Last $0.0669 (2026-03-02) · all-time high $8.50 (2025-02-23) · now -99.2% from high · lowest $0.0176 (2023-10-12)
- Binance: stopped trading on Binance (delisted) after 2026-03-02

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.1474 start · H 0.7360 L 0.0959 · Binance $8.1M/d
- 2022: $0.0282 -80.9% · H 0.1528 L 0.0281 · Binance $1.6M/d
- 2023: $0.0583 +106.6% · H 0.0583 L 0.0176 · Binance $1.2M/d
- 2024: $3.83 +6479.2% · H 4.26 L 0.0572 · Binance $24.8M/d
- 2025: $0.0692 -98.2% · H 8.50 L 0.0658 · Binance $25.8M/d
- 2026: $0.0669 -3.3% · H 0.0827 L 0.0420 · Binance $3.2M/d

**Sources**
- Binance OMUSDT daily (2021-03-08 → 2026-03-02)
