---
tags: [trading, crypto, genius]
---
**GENIUS**
- Data: 2026-05-22 → 2026-11-08 (171 days)
- Last $0.2875 (2026-11-08) · all-time high $0.7248 (2026-05-24) · now -60.3% from high · lowest $0.2776 (2026-09-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.2875 start · H 0.7248 L 0.2776 · Binance $5.5M/d

**Sources**
- Binance GENIUSUSDT daily (2026-05-22 → 2026-11-08)
