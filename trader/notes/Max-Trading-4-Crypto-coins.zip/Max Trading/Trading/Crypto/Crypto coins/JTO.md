---
tags: [trading, crypto, jto]
---
**JTO**
- Data: 2023-12-07 → 2026-11-08 (1,068 days)
- Last $0.3298 (2026-11-08) · all-time high $4.87 (2024-04-03) · now -93.2% from high · lowest $0.2377 (2026-02-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $1.88 start · H 3.58 L 1.88 · Binance $149.5M/d
- 2024: $3.33 +76.6% · H 4.87 L 1.55 · Binance $28.3M/d
- 2025: $0.3920 -88.2% · H 3.39 L 0.3210 · Binance $6.8M/d
- 2026: $0.3298 -15.9% · H 0.8220 L 0.2377 · Binance $3.6M/d

**Sources**
- Binance JTOUSDT daily (2023-12-07 → 2026-11-08)
