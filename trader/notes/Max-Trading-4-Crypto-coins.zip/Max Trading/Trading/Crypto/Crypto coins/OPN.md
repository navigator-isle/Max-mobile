---
tags: [trading, crypto, opn]
---
**OPN**
- Data: 2026-03-05 → 2026-11-08 (249 days)
- Last $0.0375 (2026-11-08) · all-time high $0.3675 (2026-03-05) · now -89.8% from high · lowest $0.0375 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0375 start · H 0.3675 L 0.0375 · Binance $10.1M/d

**Sources**
- Binance OPNUSDT daily (2026-03-05 → 2026-11-08)
