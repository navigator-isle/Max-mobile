---
tags: [trading, crypto, btc]
---
**BTC**
- Data: 2010-07-18 → 2026-11-08 (5,958 days)
- Last $75,956 (2026-11-08) · all-time high $124,659 (2025-10-06) · now -39.1% from high · lowest $0.0505 (2010-07-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2010: $0.3000 start · H 0.4010 L 0.0505 · cap $1.5M (#1)
- 2011: $4.71 +1471.4% · H 29.03 L 0.2950 · cap $37.7M (#1)
- 2012: $13.55 +187.3% · H 13.76 L 4.26 · cap $143.8M (#1)
- 2013: $729.6 +5286.0% · H 1,135 L 13.28 · cap $8.9B (#1)
- 2014: $320.7 -56.0% · H 914.5 L 310.4 · cap $4.4B (#1)
- 2015: $429.7 +34.0% · H 464.6 L 175.6 · cap $6.5B (#1)
- 2016: $969.0 +125.5% · H 980.0 L 366.3 · cap $15.6B (#1)
- 2017: $13,716 +1315.6% · H 19,103 L 788.3 · cap $233.5B (#1) · Binance $52.9M/d
- 2018: $3,703 -73.0% · H 17,070 L 3,212 · cap $64.4B (#1) · Binance $262.4M/d
- 2019: $7,195 +94.3% · H 13,094 L 3,398 · cap $130.0B (#1) · Binance $332.7M/d
- 2020: $28,924 +302.0% · H 28,924 L 4,800 · cap $539.4B (#1) · Binance $782.7M/d
- 2021: $46,217 +59.8% · H 67,526 L 29,332 · cap $876.9B (#1) · Binance $3.2B/d
- 2022: $16,542 -64.2% · H 47,723 L 15,781 · cap $318.1B (#1) · Binance $3.3B/d
- 2023: $42,284 +155.6% · H 44,171 L 16,617 · cap $826.9B (#1) · Binance $2.5B/d
- 2024: $93,576 +121.3% · H 106,134 L 39,568 · cap $1,849.5B (#1) · Binance $2.3B/d
- 2025: $87,648 -6.3% · H 124,659 L 76,322 · cap $1,747.7B (#1) · Binance $2.1B/d
- 2026: $75,956 -13.3% · H 96,952 L 58,625 · cap $1,535.0B (#1) · Binance $1.3B/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance BTCUSDT daily (2017-08-17 → 2026-11-08)
