---
tags: [trading, crypto, snx]
---
**SNX**
- Data: 2020-04-09 → 2026-11-08 (2,405 days)
- Last $0.1633 (2026-11-08) · all-time high $27.13 (2021-02-12) · now -99.4% from high · lowest $0.1627 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $7.23 start · H 8.07 L 0.6316 · cap $1.6B (#27) · Binance $6.5M/d
- 2021: $5.49 -24.1% · H 27.13 L 4.91 · cap $1.3B (#54) · Binance $26.0M/d
- 2022: $1.44 -73.8% · H 7.71 L 1.43 · cap $450.1M (#55) · Binance $11.7M/d
- 2023: $3.87 +169.2% · H 4.53 L 1.48 · cap $1.3B (#42) · Binance $12.3M/d
- 2024: $1.92 -50.4% · H 5.11 L 1.21 · cap $654.6M (#54) · Binance $8.3M/d
- 2025: $0.4110 -78.6% · H 2.29 L 0.3900 · cap $142.2M (#66) · Binance $5.6M/d
- 2026: $0.1633 -60.3% · H 0.5340 L 0.1627 · cap $107.2M (#64) · Binance $1.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance SNXUSDT daily (2020-07-09 → 2026-11-08)
