---
tags: [trading, crypto, pay]
---
**PAY**
- Data: 2017-10-03 → 2025-06-25 (2,823 days)
- Last $0.0014 (2025-06-25) · all-time high $4.72 (2017-12-24) · now -100.0% from high · lowest $0.000849 (2025-06-15)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $4.10 start · H 4.72 L 1.52 · cap $842.3M (#37)
- 2018: $0.2433 -94.1% · H 4.61 L 0.2410 · cap $49.9M (#58)
- 2019: $0.0476 -80.4% · H 0.4419 L 0.0476 · cap $9.8M (#78)
- 2020: $0.0527 +10.6% · H 0.1074 L 0.0230 · cap $10.8M (#104)
- 2021: $0.0508 -3.6% · H 0.2310 L 0.0408 · cap $10.4M (#115)
- 2022: $0.0116 -77.2% · H 0.0582 L 0.0116 · cap $2.4M (#111)
- 2023: $0.00845 -27.1% · H 0.0257 L 0.00689 · cap $1.7M (#110)
- 2024: $0.00812 -3.9% · H 0.0124 L 0.00547 · cap $1.7M (#115)
- 2025: $0.0014 -82.8% · H 0.0084 L 0.000849 · cap $287.4K (#114)

**Sources**
- Coin Metrics community data (daily, to 2025-06-25)
