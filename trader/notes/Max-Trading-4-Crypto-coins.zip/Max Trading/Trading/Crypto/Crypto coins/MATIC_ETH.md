---
tags: [trading, crypto, matic_eth]
---
**MATIC_ETH**
- Data: 2019-04-27 → 2025-10-22 (2,371 days)
- Last $0.1965 (2025-10-22) · all-time high $2.87 (2021-12-26) · now -93.2% from high · lowest $0.00313 (2019-05-09)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0137 start · H 0.0415 L 0.00313 · cap $137.2M (#40)
- 2020: $0.0175 +27.7% · H 0.0302 L 0.0081 · cap $175.2M (#69)
- 2021: $2.54 +14378.1% · H 2.87 L 0.0178 · cap $25.4B (#16)
- 2022: $0.7577 -70.1% · H 2.56 L 0.3457 · cap $7.6B (#13)
- 2023: $0.9698 +28.0% · H 1.53 L 0.5027 · cap $9.7B (#17)
- 2024: $0.4503 -53.6% · H 1.27 L 0.2909 · cap $4.5B (#27)
- 2025: $0.1965 -56.4% · H 0.5234 L 0.1669 · cap $2.0B (#36)

**Sources**
- Coin Metrics community data (daily, to 2025-10-22)
