---
tags: [trading, crypto, nxm]
---
**NXM**
- Data: 2020-08-26 → 2026-05-23 (2,097 days)
- Last $54.01 (2026-05-23) · all-time high $117.9 (2021-05-09) · now -54.2% from high · lowest $7.95 (2023-01-05)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $22.82 start · H 75.39 L 15.84 · cap $153.1M (#74)
- 2021: $59.14 +159.2% · H 117.9 L 23.03 · cap $407.7M (#83)
- 2022: $8.13 -86.3% · H 67.65 L 7.97 · cap $55.1M (#88)
- 2023: $48.27 +493.8% · H 50.09 L 7.95 · cap $222.4M (#79)
- 2024: $75.35 +56.1% · H 87.20 L 46.97 · cap $246.4M (#77)
- 2025: $70.66 -6.2% · H 108.3 L 31.38 · cap $134.5M (#68)
- 2026: $54.01 -23.6% · H 81.89 L 47.46 · cap $93.8M (#66)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
