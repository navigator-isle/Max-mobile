---
tags: [trading, crypto, hook]
---
**HOOK**
- Data: 2022-12-01 → 2026-04-01 (1,218 days)
- Last $0.0078 (2026-04-01) · all-time high $3.85 (2023-02-07) · now -99.8% from high · lowest $0.0078 (2026-04-01)
- Binance: stopped trading on Binance (delisted) after 2026-04-01

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $1.20 start · H 2.55 L 1.11 · Binance $37.4M/d
- 2023: $1.26 +5.2% · H 3.85 L 0.7093 · Binance $16.3M/d
- 2024: $0.4236 -66.3% · H 1.65 L 0.3315 · Binance $5.4M/d
- 2025: $0.0374 -91.2% · H 0.4627 L 0.0326 · Binance $2.4M/d
- 2026: $0.0078 -79.1% · H 0.0417 L 0.0078 · Binance $635.6K/d

**Sources**
- Binance HOOKUSDT daily (2022-12-01 → 2026-04-01)
