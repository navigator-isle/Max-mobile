---
tags: [trading, crypto, zil]
---
**ZIL**
- Data: 2019-02-19 → 2026-11-08 (2,820 days)
- Last $0.00169 (2026-11-08) · all-time high $0.2366 (2021-04-16) · now -99.3% from high · lowest $0.00164 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00447 start · H 0.0254 L 0.00441 · Binance $1.2M/d
- 2020: $0.0826 +1747.2% · H 0.0893 L 0.00314 · Binance $8.1M/d
- 2021: $0.0747 -9.5% · H 0.2366 L 0.0534 · Binance $35.2M/d
- 2022: $0.0158 -78.8% · H 0.1845 L 0.0158 · Binance $43.4M/d
- 2023: $0.0248 +56.5% · H 0.0354 L 0.0150 · Binance $6.7M/d
- 2024: $0.0201 -18.8% · H 0.0405 L 0.0124 · Binance $7.2M/d
- 2025: $0.00467 -76.8% · H 0.0244 L 0.00437 · Binance $1.7M/d
- 2026: $0.00169 -63.9% · H 0.00588 L 0.00164 · Binance $1.0M/d

**Sources**
- Binance ZILUSDT daily (2019-02-19 → 2026-11-08)
