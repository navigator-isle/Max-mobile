---
tags: [trading, crypto, pump]
---
**PUMP**
- Data: 2025-09-11 → 2026-11-08 (424 days)
- Last $0.00367 (2026-11-08) · all-time high $0.00863 (2025-09-15) · now -57.5% from high · lowest $0.0012 (2026-06-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.00192 start · H 0.00863 L 0.00173 · Binance $71.8M/d
- 2026: $0.00367 +91.6% · H 0.00652 L 0.0012 · Binance $18.0M/d

**Sources**
- Binance PUMPUSDT daily (2025-09-11 → 2026-11-08)
