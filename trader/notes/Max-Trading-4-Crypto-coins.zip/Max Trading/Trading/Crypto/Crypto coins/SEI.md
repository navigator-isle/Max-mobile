---
tags: [trading, crypto, sei]
---
**SEI**
- Data: 2023-08-15 → 2026-11-08 (1,182 days)
- Last $0.0450 (2026-11-08) · all-time high $1.05 (2024-03-15) · now -95.7% from high · lowest $0.0386 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.5601 start · H 0.5908 L 0.0968 · Binance $40.1M/d
- 2024: $0.3967 -29.2% · H 1.05 L 0.2274 · Binance $60.2M/d
- 2025: $0.1110 -72.0% · H 0.4709 L 0.1070 · Binance $31.0M/d
- 2026: $0.0450 -59.5% · H 0.1313 L 0.0386 · Binance $5.4M/d

**Sources**
- Binance SEIUSDT daily (2023-08-15 → 2026-11-08)
