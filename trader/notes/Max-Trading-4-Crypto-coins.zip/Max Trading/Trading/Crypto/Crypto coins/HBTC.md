---
tags: [trading, crypto, hbtc]
---
**HBTC**
- Data: 2019-12-09 → 2026-05-23 (2,358 days)
- Last $76,620 (2026-05-23) · all-time high $124,824 (2025-10-06) · now -38.6% from high · lowest $4,959 (2020-03-12)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $7,167 start · H 7,479 L 6,609 · cap $0 (#84)
- 2020: $29,023 +304.9% · H 29,023 L 4,959 · cap $258.5M (#62)
- 2021: $46,355 +59.7% · H 67,542 L 29,381 · cap $1.8B (#48)
- 2022: $16,524 -64.4% · H 47,560 L 15,758 · cap $214.3M (#67)
- 2023: $42,217 +155.5% · H 44,205 L 16,607 · cap $378.7M (#62)
- 2024: $93,390 +121.2% · H 106,116 L 39,577 · cap $90.5M (#89)
- 2025: $87,517 -6.3% · H 124,824 L 76,351 · cap $84.8M (#76)
- 2026: $76,620 -12.5% · H 97,044 L 63,495 · cap $74.3M (#69)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
