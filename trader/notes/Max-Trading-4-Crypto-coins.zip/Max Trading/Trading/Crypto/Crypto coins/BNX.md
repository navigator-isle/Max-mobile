---
tags: [trading, crypto, bnx]
---
**BNX**
- Data: 2021-11-04 → 2025-03-18 (1,226 days)
- Last $1.78 (2025-03-18) · all-time high $200.0 (2021-11-14) · now -99.1% from high · lowest $0.1637 (2025-02-06)
- Binance: stopped trading on Binance (delisted) after 2025-03-18

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $63.60 start · H 200.0 L 63.00 · Binance $11.3M/d
- 2022: $71.20 +11.9% · H 171.3 L 17.70 · Binance $9.1M/d
- 2023: $0.3006 -99.6% · H 175.5 L 0.1862 · Binance $6.1M/d
- 2024: $0.4015 +33.6% · H 1.67 L 0.2786 · Binance $11.2M/d
- 2025: $1.78 +343.8% · H 2.00 L 0.1637 · Binance $43.3M/d

**Sources**
- Binance BNXUSDT daily (2021-11-04 → 2025-03-18)
