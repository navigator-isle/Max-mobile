---
tags: [trading, crypto, opg]
---
**OPG**
- Data: 2026-05-22 → 2026-11-08 (171 days)
- Last $0.1181 (2026-11-08) · all-time high $0.3044 (2026-06-14) · now -61.2% from high · lowest $0.0867 (2026-08-28)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.1181 start · H 0.3044 L 0.0867 · Binance $5.2M/d

**Sources**
- Binance OPGUSDT daily (2026-05-22 → 2026-11-08)
