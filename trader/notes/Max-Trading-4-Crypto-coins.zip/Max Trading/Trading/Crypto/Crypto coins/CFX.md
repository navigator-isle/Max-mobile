---
tags: [trading, crypto, cfx]
---
**CFX**
- Data: 2021-03-29 → 2026-11-08 (2,051 days)
- Last $0.0418 (2026-11-08) · all-time high $1.38 (2021-03-29) · now -97.0% from high · lowest $0.0219 (2022-12-31)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.1986 start · H 1.38 L 0.1820 · Binance $10.9M/d
- 2022: $0.0219 -89.0% · H 0.2264 L 0.0219 · Binance $2.8M/d
- 2023: $0.1946 +788.6% · H 0.4551 L 0.0221 · Binance $40.6M/d
- 2024: $0.1566 -19.5% · H 0.5164 L 0.1156 · Binance $19.5M/d
- 2025: $0.0703 -55.1% · H 0.2291 L 0.0637 · Binance $12.7M/d
- 2026: $0.0418 -40.6% · H 0.0824 L 0.0381 · Binance $2.0M/d

**Sources**
- Binance CFXUSDT daily (2021-03-29 → 2026-11-08)
