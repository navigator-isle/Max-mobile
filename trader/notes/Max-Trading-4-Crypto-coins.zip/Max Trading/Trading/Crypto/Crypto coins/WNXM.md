---
tags: [trading, crypto, wnxm]
---
**WNXM**
- Data: 2020-08-26 → 2024-06-17 (1,392 days)
- Last $73.26 (2024-06-17) · all-time high $118.1 (2021-05-09) · now -38.0% from high · lowest $7.96 (2023-01-05)
- Binance: stopped trading on Binance (delisted) after 2024-06-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $23.07 start · H 75.42 L 16.05 · cap $40.3M (#89) · Binance $2.2M/d
- 2021: $59.27 +156.9% · H 118.1 L 22.97 · cap $145.0M (#98) · Binance $3.2M/d
- 2022: $8.10 -86.3% · H 67.33 L 7.98 · cap $20.9M (#98) · Binance $1.7M/d
- 2023: $48.35 +496.9% · H 49.82 L 7.96 · cap $61.3M (#95) · Binance $266.8K/d
- 2024: $73.26 +51.5% · H 84.11 L 47.07 · cap $82.6M (#90) · Binance $718.1K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance WNXMUSDT daily (2020-08-28 → 2024-06-17)
