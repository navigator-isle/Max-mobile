---
tags: [trading, crypto, zro]
---
**ZRO**
- Data: 2024-06-20 → 2026-11-08 (872 days)
- Last $1.61 (2026-11-08) · all-time high $7.18 (2024-12-06) · now -77.5% from high · lowest $0.7160 (2026-08-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $5.00 start · H 7.18 L 2.51 · Binance $37.3M/d
- 2025: $1.23 -75.5% · H 5.89 L 1.23 · Binance $9.7M/d
- 2026: $1.61 +31.5% · H 2.31 L 0.7160 · Binance $7.8M/d

**Sources**
- Binance ZROUSDT daily (2024-06-20 → 2026-11-08)
