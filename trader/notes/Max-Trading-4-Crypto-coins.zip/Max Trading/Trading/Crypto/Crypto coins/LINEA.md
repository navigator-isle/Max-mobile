---
tags: [trading, crypto, linea]
---
**LINEA**
- Data: 2025-09-10 → 2026-11-08 (425 days)
- Last $0.00215 (2026-11-08) · all-time high $0.0329 (2025-09-21) · now -93.5% from high · lowest $0.00209 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.00634 start · H 0.0329 L 0.00605 · Binance $45.1M/d
- 2026: $0.00215 -66.1% · H 0.00742 L 0.00209 · Binance $1.8M/d

**Sources**
- Binance LINEAUSDT daily (2025-09-10 → 2026-11-08)
