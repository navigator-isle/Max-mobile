---
tags: [trading, crypto, avax]
---
**AVAX**
- Data: 2020-09-22 → 2026-11-08 (2,239 days)
- Last $8.16 (2026-11-08) · all-time high $134.8 (2021-11-22) · now -94.0% from high · lowest $2.90 (2020-12-27)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $3.19 start · H 5.32 L 2.90 · Binance $5.0M/d
- 2021: $109.4 +3334.8% · H 134.8 L 3.47 · Binance $185.1M/d
- 2022: $10.90 -90.0% · H 114.1 L 10.87 · Binance $108.5M/d
- 2023: $38.55 +253.7% · H 48.18 L 8.78 · Binance $55.0M/d
- 2024: $35.71 -7.4% · H 60.65 L 19.54 · Binance $104.7M/d
- 2025: $12.32 -65.5% · H 44.05 L 11.44 · Binance $69.2M/d
- 2026: $8.16 -33.8% · H 14.75 L 5.90 · Binance $24.2M/d

**Sources**
- Binance AVAXUSDT daily (2020-09-22 → 2026-11-08)
