---
tags: [trading, crypto, unfi]
---
**UNFI**
- Data: 2020-11-19 → 2024-11-06 (1,449 days)
- Last $1.34 (2024-11-06) · all-time high $41.92 (2021-03-01) · now -96.8% from high · lowest $1.34 (2024-11-06)
- Binance: stopped trading on Binance (delisted) after 2024-11-06

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $5.34 start · H 14.06 L 2.86 · Binance $14.1M/d
- 2021: $7.91 +48.1% · H 41.92 L 4.85 · Binance $13.2M/d
- 2022: $3.68 -53.4% · H 18.88 L 1.75 · Binance $17.3M/d
- 2023: $7.31 +98.5% · H 14.60 L 3.05 · Binance $8.5M/d
- 2024: $1.34 -81.7% · H 9.00 L 1.34 · Binance $7.3M/d

**Sources**
- Binance UNFIUSDT daily (2020-11-19 → 2024-11-06)
