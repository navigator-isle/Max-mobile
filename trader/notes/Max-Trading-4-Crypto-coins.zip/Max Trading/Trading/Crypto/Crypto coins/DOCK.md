---
tags: [trading, crypto, dock]
---
**DOCK**
- Data: 2019-08-27 → 2024-07-22 (1,792 days)
- Last $0.0039 (2024-07-22) · all-time high $0.1451 (2021-04-05) · now -97.3% from high · lowest $0.00291 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2024-07-22

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00799 start · H 0.0134 L 0.00533 · Binance $840.3K/d
- 2020: $0.0183 +129.3% · H 0.0333 L 0.00291 · Binance $525.2K/d
- 2021: $0.0660 +260.1% · H 0.1451 L 0.0176 · Binance $7.6M/d
- 2022: $0.0144 -78.1% · H 0.0683 L 0.0127 · Binance $1.0M/d
- 2023: $0.0222 +53.8% · H 0.0283 L 0.0128 · Binance $722.4K/d
- 2024: $0.0039 -82.4% · H 0.0475 L 0.0039 · Binance $2.8M/d

**Sources**
- Binance DOCKUSDT daily (2019-08-27 → 2024-07-22)
