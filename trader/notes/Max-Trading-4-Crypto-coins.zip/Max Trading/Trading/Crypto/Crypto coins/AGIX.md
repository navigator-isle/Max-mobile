---
tags: [trading, crypto, agix]
---
**AGIX**
- Data: 2023-02-17 → 2024-07-01 (501 days)
- Last $0.6141 (2024-07-01) · all-time high $1.39 (2024-03-09) · now -55.8% from high · lowest $0.1595 (2023-10-19)
- Binance: stopped trading on Binance (delisted) after 2024-07-01

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.3195 start · H 0.5574 L 0.1595 · Binance $18.6M/d
- 2024: $0.6141 +92.2% · H 1.39 L 0.2513 · Binance $35.9M/d

**Sources**
- Binance AGIXUSDT daily (2023-02-17 → 2024-07-01)
