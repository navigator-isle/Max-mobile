---
tags: [trading, crypto, inj]
---
**INJ**
- Data: 2020-10-21 → 2026-11-08 (2,210 days)
- Last $8.22 (2026-11-08) · all-time high $51.85 (2024-03-12) · now -84.1% from high · lowest $0.6776 (2020-10-28)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $4.05 start · H 4.80 L 0.6776 · Binance $6.6M/d
- 2021: $8.25 +103.7% · H 22.19 L 3.61 · Binance $11.1M/d
- 2022: $1.27 -84.5% · H 8.55 L 1.17 · Binance $7.2M/d
- 2023: $35.76 +2704.3% · H 43.35 L 1.27 · Binance $26.9M/d
- 2024: $19.62 -45.1% · H 51.85 L 14.93 · Binance $44.0M/d
- 2025: $4.19 -78.6% · H 25.96 L 4.19 · Binance $14.6M/d
- 2026: $8.22 +96.2% · H 8.95 L 2.75 · Binance $8.2M/d

**Sources**
- Binance INJUSDT daily (2020-10-21 → 2026-11-08)
