---
tags: [trading, crypto, brev]
---
**BREV**
- Data: 2026-01-06 → 2026-11-08 (307 days)
- Last $0.0723 (2026-11-08) · all-time high $0.4355 (2026-01-07) · now -83.4% from high · lowest $0.0641 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0723 start · H 0.4355 L 0.0641 · Binance $5.1M/d

**Sources**
- Binance BREVUSDT daily (2026-01-06 → 2026-11-08)
