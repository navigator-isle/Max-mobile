---
tags: [trading, crypto, wtc]
---
**WTC**
- Data: 2017-08-28 → 2023-12-07 (2,293 days)
- Last $0.0103 (2023-12-07) · all-time high $41.49 (2018-01-27) · now -100.0% from high · lowest $0.0103 (2023-12-07)
- Binance: stopped trading on Binance (delisted) after 2023-12-07

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $10.56 start · H 14.86 L 0.6107 · cap $739.1M (#39)
- 2018: $1.08 -89.8% · H 41.49 L 0.8787 · cap $75.4M (#50)
- 2019: $0.3425 -68.2% · H 2.85 L 0.3425 · cap $24.0M (#68)
- 2020: $0.2750 -19.7% · H 0.7469 L 0.1612 · cap $19.3M (#98) · Binance $528.1K/d
- 2021: $0.9630 +250.2% · H 2.26 L 0.2803 · cap $67.7M (#102) · Binance $8.1M/d
- 2022: $0.1852 -80.8% · H 0.9808 L 0.1278 · cap $13.0M (#104) · Binance $1.7M/d
- 2023: $0.0103 -94.4% · H 0.2988 L 0.0103 · cap $595.7K (#112) · Binance $1.3M/d

**Sources**
- Coin Metrics community data (daily, to 2024-06-16)
- Binance WTCUSDT daily (2020-04-07 → 2023-12-07)
