---
tags: [trading, crypto, usdk]
---
**USDK**
- Data: 2020-06-13 → 2023-04-17 (1,039 days)
- Last $1.00 (2023-04-17) · all-time high $1.01 (2021-01-29) · now -0.6% from high · lowest $0.9975 (2022-11-20)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.00 start · H 1.01 L 0.9976 · cap $32.5M (#92)
- 2021: $0.9998 -0.1% · H 1.01 L 0.9988 · cap $42.5M (#107)
- 2022: $0.9990 -0.1% · H 1.00 L 0.9975 · cap $42.4M (#94)
- 2023: $1.00 +0.5% · H 1.01 L 0.9985 · cap $490.7K (#112)

**Sources**
- Coin Metrics community data (daily, to 2023-04-17)
