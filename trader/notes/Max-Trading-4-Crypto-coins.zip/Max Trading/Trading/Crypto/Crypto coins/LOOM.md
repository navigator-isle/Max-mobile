---
tags: [trading, crypto, loom]
---
**LOOM**
- Data: 2018-05-03 → 2024-08-26 (2,308 days)
- Last $0.0483 (2024-08-26) · all-time high $0.6608 (2018-05-07) · now -92.7% from high · lowest $0.01 (2020-03-12)
- Binance: stopped trading on Binance (delisted) after 2024-08-26

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.0444 start · H 0.6608 L 0.0372 · cap $44.4M (#60)
- 2019: $0.0154 -65.4% · H 0.0869 L 0.0152 · cap $15.4M (#76)
- 2020: $0.0285 +85.5% · H 0.0463 L 0.01 · cap $28.5M (#95)
- 2021: $0.0857 +200.4% · H 0.2427 L 0.0289 · cap $85.7M (#100)
- 2022: $0.0395 -54.0% · H 0.1102 L 0.0345 · cap $39.5M (#95)
- 2023: $0.1056 +167.6% · H 0.3432 L 0.0376 · cap $105.4M (#90) · Binance $12.5M/d
- 2024: $0.0483 -54.3% · H 0.1369 L 0.0455 · cap $56.7M (#97) · Binance $4.5M/d

**Sources**
- Coin Metrics community data (daily, to 2025-12-08)
- Binance LOOMUSDT daily (2023-03-24 → 2024-08-26)
