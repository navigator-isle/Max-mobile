---
tags: [trading, crypto, shib_eth]
---
**SHIB_ETH**
- Data: 2021-05-11 → 2026-05-23 (1,839 days)
- Last $5.66e-06 (2026-05-23) · all-time high $8.23e-05 (2021-10-27) · now -93.1% from high · lowest $5.29e-06 (2026-03-08)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $3.35e-05 start · H 8.23e-05 L 5.9e-06 · cap $33.5B (#12)
- 2022: $8.08e-06 -75.9% · H 3.41e-05 L 7.7e-06 · cap $8.1B (#12)
- 2023: $1.03e-05 +27.9% · H 1.48e-05 L 6.55e-06 · cap $10.3B (#14)
- 2024: $2.11e-05 +104.6% · H 3.54e-05 L 8.81e-06 · cap $21.1B (#13)
- 2025: $6.9e-06 -67.4% · H 2.44e-05 L 6.9e-06 · cap $6.9B (#20)
- 2026: $5.66e-06 -17.9% · H 9.22e-06 L 5.29e-06 · cap $5.7B (#19)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
