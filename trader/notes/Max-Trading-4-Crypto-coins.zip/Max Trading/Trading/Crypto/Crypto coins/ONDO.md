---
tags: [trading, crypto, ondo]
---
**ONDO**
- Data: 2025-04-11 → 2026-11-08 (577 days)
- Last $0.3605 (2026-11-08) · all-time high $1.14 (2025-07-22) · now -68.5% from high · lowest $0.2251 (2026-02-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.3591 start · H 1.14 L 0.3591 · Binance $18.6M/d
- 2026: $0.3605 +0.4% · H 0.5877 L 0.2251 · Binance $13.2M/d

**Sources**
- Binance ONDOUSDT daily (2025-04-11 → 2026-11-08)
