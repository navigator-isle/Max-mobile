---
tags: [trading, crypto, bonk]
---
**BONK**
- Data: 2023-12-15 → 2026-11-08 (1,060 days)
- Last $2.77e-06 (2026-11-08) · all-time high $5.37e-05 (2024-11-21) · now -94.8% from high · lowest $2.23e-06 (2026-08-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $1.33e-05 start · H 2.37e-05 L 1.33e-05 · Binance $136.9M/d
- 2024: $3.06e-05 +129.4% · H 5.37e-05 L 9.92e-06 · Binance $87.8M/d
- 2025: $7.47e-06 -75.6% · H 3.86e-05 L 7.47e-06 · Binance $44.2M/d
- 2026: $2.77e-06 -62.9% · H 1.21e-05 L 2.23e-06 · Binance $6.5M/d

**Sources**
- Binance BONKUSDT daily (2023-12-15 → 2026-11-08)
