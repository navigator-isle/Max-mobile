---
tags: [trading, crypto, u]
---
**U**
- Data: 2026-01-13 → 2026-11-08 (300 days)
- Last $1.00 (2026-11-08) · all-time high $1.00 (2026-02-04) · now -0.1% from high · lowest $0.9993 (2026-09-04)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $1.00 start · H 1.00 L 0.9993 · Binance $21.9M/d

**Sources**
- Binance UUSDT daily (2026-01-13 → 2026-11-08)
