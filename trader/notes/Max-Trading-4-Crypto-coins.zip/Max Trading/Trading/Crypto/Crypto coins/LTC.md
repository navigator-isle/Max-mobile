---
tags: [trading, crypto, ltc]
---
**LTC**
- Data: 2013-04-01 → 2026-11-08 (4,970 days)
- Last $51.86 (2026-11-08) · all-time high $387.8 (2021-05-09) · now -86.6% from high · lowest $1.16 (2015-01-14)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2013: $23.79 start · H 47.18 L 1.26 · cap $581.6M (#2)
- 2014: $2.76 -88.4% · H 28.49 L 2.71 · cap $97.2M (#3)
- 2015: $3.47 +25.8% · H 7.71 L 1.16 · cap $152.2M (#4)
- 2016: $4.35 +25.4% · H 5.70 L 2.98 · cap $213.9M (#5)
- 2017: $223.7 +5037.4% · H 352.0 L 3.69 · cap $12.5B (#7) · Binance $7.4M/d
- 2018: $29.90 -86.6% · H 275.3 L 23.08 · cap $1.8B (#8) · Binance $15.6M/d
- 2019: $41.30 +38.1% · H 142.3 L 29.59 · cap $2.6B (#8) · Binance $25.7M/d
- 2020: $124.2 +200.8% · H 130.1 L 29.83 · cap $8.3B (#9) · Binance $55.6M/d
- 2021: $146.3 +17.8% · H 387.8 L 107.3 · cap $10.2B (#25) · Binance $242.6M/d
- 2022: $70.14 -52.1% · H 151.2 L 43.50 · cap $5.0B (#19) · Binance $47.3M/d
- 2023: $72.83 +3.8% · H 113.6 L 58.85 · cap $5.4B (#23) · Binance $56.1M/d
- 2024: $103.3 +41.8% · H 135.9 L 55.99 · cap $7.8B (#21) · Binance $62.4M/d
- 2025: $76.85 -25.6% · H 137.0 L 69.15 · cap $5.9B (#23) · Binance $74.3M/d
- 2026: $51.86 -32.5% · H 83.96 L 40.92 · cap $4.1B (#24) · Binance $20.4M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance LTCUSDT daily (2017-12-13 → 2026-11-08)
