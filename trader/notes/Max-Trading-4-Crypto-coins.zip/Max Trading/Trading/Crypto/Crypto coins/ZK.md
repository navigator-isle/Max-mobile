---
tags: [trading, crypto, zk]
---
**ZK**
- Data: 2024-06-17 → 2026-11-08 (875 days)
- Last $0.00916 (2026-11-08) · all-time high $0.2618 (2024-12-07) · now -96.5% from high · lowest $0.00723 (2026-08-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.1843 start · H 0.2618 L 0.0949 · Binance $26.8M/d
- 2025: $0.0290 -84.3% · H 0.2245 L 0.0255 · Binance $10.3M/d
- 2026: $0.00916 -68.4% · H 0.0367 L 0.00723 · Binance $3.2M/d

**Sources**
- Binance ZKUSDT daily (2024-06-17 → 2026-11-08)
