---
tags: [trading, crypto, hifi]
---
**HIFI**
- Data: 2023-01-12 → 2025-09-17 (980 days)
- Last $0.1270 (2025-09-17) · all-time high $2.32 (2023-09-16) · now -94.5% from high · lowest $0.0556 (2025-09-08)
- Binance: stopped trading on Binance (delisted) after 2025-09-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.7356 start · H 2.32 L 0.2559 · Binance $7.2M/d
- 2024: $0.5302 -27.9% · H 1.35 L 0.3601 · Binance $5.6M/d
- 2025: $0.1270 -76.0% · H 0.6593 L 0.0556 · Binance $5.8M/d

**Sources**
- Binance HIFIUSDT daily (2023-01-12 → 2025-09-17)
