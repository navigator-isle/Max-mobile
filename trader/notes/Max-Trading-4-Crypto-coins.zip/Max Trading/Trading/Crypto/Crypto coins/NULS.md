---
tags: [trading, crypto, nuls]
---
**NULS**
- Data: 2018-07-23 → 2025-04-16 (2,460 days)
- Last $0.0258 (2025-04-16) · all-time high $2.63 (2018-07-29) · now -99.0% from high · lowest $0.0253 (2025-04-15)
- Binance: stopped trading on Binance (delisted) after 2025-04-16

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.3912 start · H 2.63 L 0.3779 · Binance $695.2K/d
- 2019: $0.2221 -43.2% · H 1.05 L 0.2221 · Binance $418.4K/d
- 2020: $0.2112 -4.9% · H 0.6666 L 0.1140 · Binance $325.1K/d
- 2021: $0.8150 +285.9% · H 1.51 L 0.2058 · Binance $8.5M/d
- 2022: $0.1832 -77.5% · H 0.8085 L 0.1393 · Binance $3.3M/d
- 2023: $0.2757 +50.5% · H 0.3277 L 0.1693 · Binance $746.5K/d
- 2024: $0.3953 +43.4% · H 0.9005 L 0.2147 · Binance $4.6M/d
- 2025: $0.0258 -93.5% · H 0.4287 L 0.0253 · Binance $1.1M/d

**Sources**
- Binance NULSUSDT daily (2018-07-23 → 2025-04-16)
