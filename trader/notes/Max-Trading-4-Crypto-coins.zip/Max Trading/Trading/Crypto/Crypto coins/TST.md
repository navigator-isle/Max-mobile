---
tags: [trading, crypto, tst]
---
**TST**
- Data: 2025-02-09 → 2026-11-08 (638 days)
- Last $0.0118 (2026-11-08) · all-time high $0.2245 (2025-02-09) · now -94.7% from high · lowest $0.00788 (2026-03-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0159 start · H 0.2245 L 0.0131 · Binance $17.9M/d
- 2026: $0.0118 -25.5% · H 0.0261 L 0.00788 · Binance $2.3M/d

**Sources**
- Binance TSTUSDT daily (2025-02-09 → 2026-11-08)
