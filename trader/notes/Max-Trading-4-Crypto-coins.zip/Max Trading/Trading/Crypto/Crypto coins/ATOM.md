---
tags: [trading, crypto, atom]
---
**ATOM**
- Data: 2019-04-29 → 2026-11-08 (2,751 days)
- Last $1.36 (2026-11-08) · all-time high $44.27 (2021-09-19) · now -96.9% from high · lowest $1.22 (2026-08-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $4.23 start · H 7.01 L 1.94 · Binance $3.9M/d
- 2020: $6.46 +52.9% · H 8.53 L 1.61 · Binance $10.1M/d
- 2021: $32.39 +401.0% · H 44.27 L 5.42 · Binance $97.0M/d
- 2022: $9.35 -71.1% · H 43.65 L 6.08 · Binance $73.4M/d
- 2023: $10.60 +13.3% · H 15.15 L 6.26 · Binance $21.7M/d
- 2024: $6.19 -41.6% · H 14.22 L 3.67 · Binance $24.9M/d
- 2025: $1.93 -68.8% · H 7.45 L 1.85 · Binance $10.0M/d
- 2026: $1.36 -29.5% · H 2.64 L 1.22 · Binance $3.0M/d

**Sources**
- Binance ATOMUSDT daily (2019-04-29 → 2026-11-08)
