---
tags: [trading, crypto, icx_eth]
---
**ICX_ETH**
- Data: 2017-09-23 → 2026-05-23 (3,165 days)
- Last $0.0381 (2026-05-23) · all-time high $11.97 (2018-01-09) · now -99.7% from high · lowest $0.0327 (2026-03-29)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $5.41 start · H 6.99 L 0.0938 · cap $2.2B (#21)
- 2018: $0.2331 -95.7% · H 11.97 L 0.1841 · cap $93.3M (#45)
- 2019: $0.1129 -51.6% · H 0.4438 L 0.1090 · cap $45.2M (#52)
- 2020: $0.4650 +311.8% · H 0.6470 L 0.1094 · cap $186.1M (#66)
- 2021: $1.22 +163.2% · H 3.05 L 0.4337 · cap $489.7M (#79)
- 2022: $0.1412 -88.5% · H 1.26 L 0.1412 · cap $56.5M (#87)
- 2023: $0.2647 +87.5% · H 0.3924 L 0.1429 · cap $106.0M (#89)
- 2024: $0.1807 -31.8% · H 0.3754 L 0.1159 · cap $72.3M (#93)
- 2025: $0.0533 -70.5% · H 0.2144 L 0.0503 · cap $21.3M (#93)
- 2026: $0.0381 -28.6% · H 0.0608 L 0.0327 · cap $15.2M (#91)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
