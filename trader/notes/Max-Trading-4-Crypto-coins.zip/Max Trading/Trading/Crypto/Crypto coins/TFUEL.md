---
tags: [trading, crypto, tfuel]
---
**TFUEL**
- Data: 2019-05-24 → 2026-11-08 (2,726 days)
- Last $0.00743 (2026-11-08) · all-time high $0.5888 (2021-06-20) · now -98.7% from high · lowest $0.00112 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00237 start · H 0.0220 L 0.00234 · Binance $1.1M/d
- 2020: $0.0333 +1306.9% · H 0.0350 L 0.00112 · Binance $2.9M/d
- 2021: $0.1910 +473.1% · H 0.5888 L 0.0248 · Binance $37.8M/d
- 2022: $0.0316 -83.5% · H 0.2227 L 0.0313 · Binance $4.2M/d
- 2023: $0.0469 +48.3% · H 0.0628 L 0.0298 · Binance $1.3M/d
- 2024: $0.0627 +33.8% · H 0.1314 L 0.0405 · Binance $4.0M/d
- 2025: $0.0174 -72.3% · H 0.0765 L 0.0171 · Binance $1.3M/d
- 2026: $0.00743 -57.2% · H 0.0204 L 0.00714 · Binance $243.6K/d

**Sources**
- Binance TFUELUSDT daily (2019-05-24 → 2026-11-08)
