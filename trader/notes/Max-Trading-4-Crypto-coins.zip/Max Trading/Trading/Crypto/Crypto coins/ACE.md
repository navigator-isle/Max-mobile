---
tags: [trading, crypto, ace]
---
**ACE**
- Data: 2023-12-18 → 2026-11-08 (1,057 days)
- Last $0.1224 (2026-11-08) · all-time high $15.39 (2023-12-21) · now -99.2% from high · lowest $0.0631 (2026-07-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $9.33 start · H 15.39 L 9.33 · Binance $132.1M/d
- 2024: $2.08 -77.7% · H 13.42 L 1.72 · Binance $12.9M/d
- 2025: $0.2720 -86.9% · H 2.27 L 0.2130 · Binance $2.8M/d
- 2026: $0.1224 -55.0% · H 0.3010 L 0.0631 · Binance $3.9M/d

**Sources**
- Binance ACEUSDT daily (2023-12-18 → 2026-11-08)
