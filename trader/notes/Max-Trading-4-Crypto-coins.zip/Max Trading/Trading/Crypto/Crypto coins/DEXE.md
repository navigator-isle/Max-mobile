---
tags: [trading, crypto, dexe]
---
**DEXE**
- Data: 2021-07-23 → 2026-11-08 (1,935 days)
- Last $1.27 (2026-11-08) · all-time high $47.89 (2026-07-12) · now -97.3% from high · lowest $1.25 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $11.78 start · H 19.51 L 7.17 · Binance $13.5M/d
- 2022: $2.41 -79.6% · H 11.76 L 1.93 · Binance $1.5M/d
- 2023: $3.84 +59.6% · H 5.25 L 1.91 · Binance $1.1M/d
- 2024: $14.95 +289.0% · H 16.40 L 2.81 · Binance $2.4M/d
- 2025: $3.24 -78.3% · H 23.98 L 2.88 · Binance $3.3M/d
- 2026: $1.27 -60.8% · H 47.89 L 1.25 · Binance $6.0M/d

**Sources**
- Binance DEXEUSDT daily (2021-07-23 → 2026-11-08)
