---
tags: [trading, crypto, bnb]
---
**BNB**
- Data: 2017-07-15 → 2026-11-08 (3,404 days)
- Last $698.6 (2026-11-08) · all-time high $1,307 (2025-10-08) · now -46.6% from high · lowest $0.0748 (2017-07-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $8.53 start · H 10.07 L 0.0748 · cap $1.7B (#23) · Binance $3.8M/d
- 2018: $6.11 -28.4% · H 22.60 L 4.52 · cap $1.2B (#11) · Binance $23.2M/d
- 2019: $13.72 +124.4% · H 38.68 L 5.47 · cap $4.5B (#8) · Binance $47.9M/d
- 2020: $37.36 +172.4% · H 39.07 L 9.26 · Binance $61.7M/d
- 2021: $511.4 +1268.9% · H 676.1 L 37.78 · Binance $911.8M/d
- 2022: $246.3 -51.8% · H 531.0 L 197.0 · Binance $213.1M/d
- 2023: $311.8 +26.6% · H 347.7 L 205.1 · Binance $134.8M/d
- 2024: $702.3 +125.2% · H 749.7 L 292.1 · Binance $281.5M/d
- 2025: $864.3 +23.1% · H 1,307 L 531.5 · Binance $252.5M/d
- 2026: $698.6 -19.2% · H 948.5 L 546.5 · Binance $96.0M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance BNBUSDT daily (2017-11-06 → 2026-11-08)
