---
tags: [trading, crypto, matic]
---
**MATIC**
- Data: 2019-04-26 → 2024-09-10 (1,965 days)
- Last $0.3794 (2024-09-10) · all-time high $2.88 (2021-12-26) · now -86.8% from high · lowest $0.00314 (2019-05-09)
- Binance: stopped trading on Binance (delisted) after 2024-09-10

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0138 start · H 0.0415 L 0.00314 · Binance $12.0M/d
- 2020: $0.0176 +27.5% · H 0.0301 L 0.00813 · Binance $6.8M/d
- 2021: $2.52 +14257.2% · H 2.88 L 0.0178 · Binance $324.4M/d
- 2022: $0.7583 -70.0% · H 2.57 L 0.3460 · Binance $98.4M/d
- 2023: $0.9707 +28.0% · H 1.52 L 0.5035 · Binance $71.0M/d
- 2024: $0.3794 -60.9% · H 1.27 L 0.3659 · Binance $62.3M/d

**Sources**
- Binance MATICUSDT daily (2019-04-26 → 2024-09-10)
