---
tags: [trading, crypto, giggle]
---
**GIGGLE**
- Data: 2025-10-25 → 2026-11-08 (380 days)
- Last $28.29 (2026-11-08) · all-time high $259.9 (2025-11-05) · now -89.1% from high · lowest $21.37 (2026-04-03)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $66.49 start · H 259.9 L 58.38 · Binance $70.6M/d
- 2026: $28.29 -57.5% · H 78.69 L 21.37 · Binance $6.1M/d

**Sources**
- Binance GIGGLEUSDT daily (2025-10-25 → 2026-11-08)
