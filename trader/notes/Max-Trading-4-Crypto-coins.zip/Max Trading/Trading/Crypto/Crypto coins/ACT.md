---
tags: [trading, crypto, act]
---
**ACT**
- Data: 2024-11-11 → 2026-11-08 (728 days)
- Last $0.0112 (2026-11-08) · all-time high $0.7560 (2024-11-14) · now -98.5% from high · lowest $0.00776 (2026-06-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.2812 start · H 0.7560 L 0.2617 · Binance $191.2M/d
- 2025: $0.0327 -88.4% · H 0.3678 L 0.0164 · Binance $16.6M/d
- 2026: $0.0112 -65.6% · H 0.0291 L 0.00776 · Binance $1.4M/d

**Sources**
- Binance ACTUSDT daily (2024-11-11 → 2026-11-08)
