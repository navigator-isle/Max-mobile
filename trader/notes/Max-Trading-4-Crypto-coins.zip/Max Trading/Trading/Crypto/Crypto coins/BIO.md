---
tags: [trading, crypto, bio]
---
**BIO**
- Data: 2025-01-03 → 2026-11-08 (675 days)
- Last $0.0196 (2026-11-08) · all-time high $0.8144 (2025-01-03) · now -97.6% from high · lowest $0.0161 (2026-03-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0437 start · H 0.8144 L 0.0406 · Binance $18.7M/d
- 2026: $0.0196 -55.2% · H 0.0605 L 0.0161 · Binance $4.7M/d

**Sources**
- Binance BIOUSDT daily (2025-01-03 → 2026-11-08)
