---
tags: [trading, crypto, alpha]
---
**ALPHA**
- Data: 2020-10-10 → 2025-07-04 (1,729 days)
- Last $0.0097 (2025-07-04) · all-time high $2.62 (2021-02-05) · now -99.6% from high · lowest $0.0097 (2025-07-04)
- Binance: stopped trading on Binance (delisted) after 2025-07-04

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.1846 start · H 0.2829 L 0.0276 · cap $185.0M (#67) · Binance $5.9M/d
- 2021: $0.6590 +256.9% · H 2.62 L 0.2167 · cap $662.2M (#73) · Binance $30.3M/d
- 2022: $0.0667 -89.9% · H 0.7019 L 0.0667 · cap $66.6M (#83) · Binance $4.9M/d
- 2023: $0.1258 +88.6% · H 0.1535 L 0.0644 · cap $125.6M (#86) · Binance $3.9M/d
- 2024: $0.0801 -36.3% · H 0.1996 L 0.0475 · cap $79.8M (#91) · Binance $3.7M/d
- 2025: $0.0097 -87.9% · H 0.0908 L 0.0097 · cap $4.7M (#103) · Binance $2.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ALPHAUSDT daily (2020-10-10 → 2025-07-04)
