---
tags: [trading, crypto, gala]
---
**GALA**
- Data: 2021-09-13 → 2026-11-08 (1,883 days)
- Last $0.00154 (2026-11-08) · all-time high $0.7422 (2021-11-25) · now -99.8% from high · lowest $0.00139 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.4505 start · H 0.7422 L 0.0439 · Binance $329.3M/d
- 2022: $0.0166 -96.3% · H 0.4614 L 0.0162 · Binance $87.2M/d
- 2023: $0.0303 +82.4% · H 0.0591 L 0.0127 · Binance $35.6M/d
- 2024: $0.0344 +13.2% · H 0.0827 L 0.0157 · Binance $44.0M/d
- 2025: $0.00584 -83.0% · H 0.0434 L 0.00584 · Binance $16.0M/d
- 2026: $0.00154 -73.6% · H 0.0078 L 0.00139 · Binance $3.0M/d

**Sources**
- Binance GALAUSDT daily (2021-09-13 → 2026-11-08)
