---
tags: [trading, crypto, luna]
---
**LUNA**
- Data: 2020-08-21 → 2026-11-08 (2,254 days)
- Last $0.0368 (2026-11-08) · all-time high $116.4 (2022-04-04) · now -100.0% from high · lowest $5e-05 (2022-05-13)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.6540 start · H 0.6675 L 0.2846 · Binance $1.7M/d
- 2021: $85.46 +12967.3% · H 99.58 L 0.6299 · Binance $186.0M/d
- 2022: $1.26 -98.5% · H 116.4 L 5e-05 · Binance $208.1M/d
- 2023: $0.8276 -34.3% · H 2.30 L 0.3880 · Binance $14.3M/d
- 2024: $0.4147 -49.9% · H 1.26 L 0.2874 · Binance $16.4M/d
- 2025: $0.0953 -77.0% · H 0.5124 L 0.0679 · Binance $5.3M/d
- 2026: $0.0368 -61.4% · H 0.0965 L 0.0365 · Binance $1.4M/d

**Sources**
- Binance LUNAUSDT daily (2020-08-21 → 2026-11-08)
