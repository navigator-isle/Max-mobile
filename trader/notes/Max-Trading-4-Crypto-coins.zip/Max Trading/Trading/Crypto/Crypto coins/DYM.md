---
tags: [trading, crypto, dym]
---
**DYM**
- Data: 2024-02-06 → 2026-11-08 (1,007 days)
- Last $0.0141 (2026-11-08) · all-time high $8.28 (2024-02-14) · now -99.8% from high · lowest $0.0129 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.32 start · H 8.28 L 0.9980 · Binance $14.9M/d
- 2025: $0.0652 -95.1% · H 1.53 L 0.0652 · Binance $2.8M/d
- 2026: $0.0141 -78.3% · H 0.0773 L 0.0129 · Binance $1.3M/d

**Sources**
- Binance DYMUSDT daily (2024-02-06 → 2026-11-08)
