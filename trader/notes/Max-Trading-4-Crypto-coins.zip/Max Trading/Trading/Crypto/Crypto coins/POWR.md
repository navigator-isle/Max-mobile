---
tags: [trading, crypto, powr]
---
**POWR**
- Data: 2017-11-02 → 2026-11-08 (3,294 days)
- Last $0.0529 (2026-11-08) · all-time high $1.79 (2018-01-07) · now -97.0% from high · lowest $0.0347 (2019-12-31)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $1.02 start · H 1.18 L 0.1064 · cap $1.0B (#30)
- 2018: $0.0802 -92.2% · H 1.79 L 0.0609 · cap $80.2M (#48)
- 2019: $0.0347 -56.8% · H 0.1320 L 0.0347 · cap $34.7M (#60)
- 2020: $0.0940 +171.1% · H 0.1224 L 0.0348 · cap $94.0M (#79)
- 2021: $0.4157 +342.1% · H 0.7920 L 0.0941 · cap $415.2M (#82) · Binance $10.9M/d
- 2022: $0.1225 -70.5% · H 0.7608 L 0.1191 · cap $121.3M (#79) · Binance $3.5M/d
- 2023: $0.3676 +200.1% · H 0.4095 L 0.1222 · cap $366.0M (#67) · Binance $2.7M/d
- 2024: $0.2740 -25.5% · H 0.9658 L 0.1634 · cap $272.7M (#73) · Binance $8.1M/d
- 2025: $0.0834 -69.6% · H 0.3040 L 0.0738 · cap $83.0M (#77) · Binance $895.1K/d
- 2026: $0.0529 -36.6% · H 0.0980 L 0.0362 · cap $65.0M (#73) · Binance $284.1K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance POWRUSDT daily (2021-11-17 → 2026-11-08)
