---
tags: [trading, crypto, avaxx]
---
**AVAXX**
- Data: 2020-09-23 → 2026-05-23 (2,069 days)
- Last $9.38 (2026-05-23) · all-time high $135.0 (2021-11-22) · now -93.0% from high · lowest $2.92 (2020-12-26)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $3.03 start · H 4.70 L 2.92 · cap $0 (#109)
- 2021: $109.9 +3525.0% · H 135.0 L 3.50 · cap $0 (#118)
- 2022: $10.89 -90.1% · H 113.8 L 10.86 · cap $0 (#114)
- 2023: $38.51 +253.7% · H 48.33 L 8.79 · cap $1.1B (#46)
- 2024: $35.63 -7.5% · H 60.79 L 19.62 · cap $912.3M (#48)
- 2025: $12.31 -65.4% · H 43.94 L 11.44 · cap $301.0M (#52)
- 2026: $9.38 -23.8% · H 14.74 L 8.30 · cap $217.0M (#54)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
