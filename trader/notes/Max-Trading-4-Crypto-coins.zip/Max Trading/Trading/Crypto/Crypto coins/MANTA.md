---
tags: [trading, crypto, manta]
---
**MANTA**
- Data: 2024-01-18 → 2026-11-08 (1,026 days)
- Last $0.0524 (2026-11-08) · all-time high $3.93 (2024-03-12) · now -98.7% from high · lowest $0.0518 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.8040 start · H 3.93 L 0.5700 · Binance $33.1M/d
- 2025: $0.0770 -90.4% · H 0.9570 L 0.0711 · Binance $4.8M/d
- 2026: $0.0524 -32.0% · H 0.0879 L 0.0518 · Binance $1.1M/d

**Sources**
- Binance MANTAUSDT daily (2024-01-18 → 2026-11-08)
