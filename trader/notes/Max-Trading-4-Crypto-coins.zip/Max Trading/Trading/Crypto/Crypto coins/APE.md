---
tags: [trading, crypto, ape]
---
**APE**
- Data: 2022-03-17 → 2026-11-08 (1,698 days)
- Last $0.1052 (2026-11-08) · all-time high $23.71 (2022-04-28) · now -99.6% from high · lowest $0.0828 (2026-04-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $3.64 start · H 23.71 L 2.88 · Binance $141.7M/d
- 2023: $1.62 -55.4% · H 6.29 L 1.03 · Binance $17.0M/d
- 2024: $1.20 -25.7% · H 2.42 L 0.5460 · Binance $21.0M/d
- 2025: $0.1964 -83.7% · H 1.37 L 0.1955 · Binance $6.2M/d
- 2026: $0.1052 -46.4% · H 0.2367 L 0.0828 · Binance $2.4M/d

**Sources**
- Binance APEUSDT daily (2022-03-17 → 2026-11-08)
