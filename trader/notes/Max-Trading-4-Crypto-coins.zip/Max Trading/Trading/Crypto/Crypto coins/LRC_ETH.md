---
tags: [trading, crypto, lrc_eth]
---
**LRC_ETH**
- Data: 2017-09-02 → 2026-05-23 (3,186 days)
- Last $0.0164 (2026-05-23) · all-time high $3.32 (2021-11-23) · now -99.5% from high · lowest $0.0158 (2026-04-12)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.4588 start · H 0.4588 L 0.0389 · cap $640.0M (#42)
- 2018: $0.0393 -91.4% · H 2.03 L 0.0321 · cap $54.8M (#56)
- 2019: $0.0215 -45.2% · H 0.1077 L 0.0202 · cap $30.0M (#64)
- 2020: $0.1697 +687.9% · H 0.2691 L 0.0217 · cap $236.7M (#63)
- 2021: $2.11 +1144.9% · H 3.32 L 0.1748 · cap $2.9B (#41)
- 2022: $0.1874 -91.1% · H 2.09 L 0.1874 · cap $261.5M (#61)
- 2023: $0.2976 +58.8% · H 0.4504 L 0.1611 · cap $415.1M (#57)
- 2024: $0.1936 -34.9% · H 0.5429 L 0.1098 · cap $270.1M (#75)
- 2025: $0.0494 -74.5% · H 0.2184 L 0.0485 · cap $68.9M (#81)
- 2026: $0.0164 -66.7% · H 0.0554 L 0.0158 · cap $22.9M (#89)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
