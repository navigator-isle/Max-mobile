---
tags: [trading, crypto, floki]
---
**FLOKI**
- Data: 2023-05-05 → 2026-11-08 (1,284 days)
- Last $2.12e-05 (2026-11-08) · all-time high $0.000321 (2024-06-06) · now -93.4% from high · lowest $1.54e-05 (2023-09-21)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $3.5e-05 start · H 4.78e-05 L 1.54e-05 · Binance $7.7M/d
- 2024: $0.000177 +406.8% · H 0.000321 L 2.74e-05 · Binance $91.5M/d
- 2025: $3.94e-05 -77.7% · H 0.000202 L 3.84e-05 · Binance $24.6M/d
- 2026: $2.12e-05 -46.2% · H 5.8e-05 L 2e-05 · Binance $3.1M/d

**Sources**
- Binance FLOKIUSDT daily (2023-05-05 → 2026-11-08)
