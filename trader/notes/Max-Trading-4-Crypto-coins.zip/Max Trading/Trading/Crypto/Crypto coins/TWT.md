---
tags: [trading, crypto, twt]
---
**TWT**
- Data: 2021-01-27 → 2026-11-08 (2,112 days)
- Last $0.3949 (2026-11-08) · all-time high $2.64 (2022-12-11) · now -85.0% from high · lowest $0.2647 (2021-06-21)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.7078 start · H 1.52 L 0.2647 · Binance $18.2M/d
- 2022: $1.42 +100.9% · H 2.64 L 0.4580 · Binance $10.0M/d
- 2023: $1.22 -14.1% · H 1.78 L 0.7321 · Binance $6.1M/d
- 2024: $1.22 -0.3% · H 1.66 L 0.7795 · Binance $4.5M/d
- 2025: $0.8681 -28.7% · H 1.63 L 0.6694 · Binance $3.8M/d
- 2026: $0.3949 -54.5% · H 0.9577 L 0.3308 · Binance $989.1K/d

**Sources**
- Binance TWTUSDT daily (2021-01-27 → 2026-11-08)
