---
tags: [trading, crypto, icx]
---
**ICX**
- Data: 2018-06-13 → 2026-09-03 (3,005 days)
- Last $0.00841 (2026-09-03) · all-time high $3.03 (2021-03-31) · now -99.7% from high · lowest $0.00841 (2026-09-03)
- Binance: stopped trading on Binance (delisted) after 2026-09-03

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.2338 start · H 2.30 L 0.1860 · Binance $5.9M/d
- 2019: $0.1139 -51.3% · H 0.4425 L 0.1096 · Binance $2.0M/d
- 2020: $0.4665 +309.6% · H 0.6455 L 0.1096 · Binance $3.6M/d
- 2021: $1.22 +162.2% · H 3.03 L 0.4340 · Binance $22.2M/d
- 2022: $0.1413 -88.4% · H 1.26 L 0.1413 · Binance $4.0M/d
- 2023: $0.2669 +88.9% · H 0.3957 L 0.1430 · Binance $3.8M/d
- 2024: $0.1808 -32.3% · H 0.3776 L 0.1158 · Binance $2.6M/d
- 2025: $0.0533 -70.5% · H 0.2154 L 0.0504 · Binance $1.1M/d
- 2026: $0.00841 -84.2% · H 0.0608 L 0.00841 · Binance $241.2K/d

**Sources**
- Binance ICXUSDT daily (2018-06-13 → 2026-09-03)
