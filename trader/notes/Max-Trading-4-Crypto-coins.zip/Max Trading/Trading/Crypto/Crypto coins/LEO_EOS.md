---
tags: [trading, crypto, leo_eos]
---
**LEO_EOS**
- Data: 2019-05-21 → 2026-05-23 (2,560 days)
- Last $10.06 (2026-05-23) · all-time high $10.38 (2026-04-28) · now -3.1% from high · lowest $0.8102 (2019-12-28)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.8157 start · H 1.97 L 0.8102 · cap $269.2M (#31)
- 2020: $1.39 +70.9% · H 1.39 L 0.8118 · cap $460.0M (#51)
- 2021: $3.77 +170.4% · H 3.88 L 1.33 · cap $1.2B (#58)
- 2022: $3.61 -4.1% · H 7.49 L 3.47 · cap $1.1B (#32)
- 2023: $3.98 +10.3% · H 4.16 L 3.32 · cap $1.2B (#44)
- 2024: $9.01 +126.2% · H 9.64 L 3.89 · cap $2.8B (#35)
- 2025: $9.58 +6.2% · H 9.92 L 6.78 · cap $2.9B (#28)
- 2026: $10.06 +5.1% · H 10.38 L 6.83 · cap $3.1B (#27)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
