---
tags: [trading, crypto, algo]
---
**ALGO**
- Data: 2019-06-22 → 2026-11-08 (2,697 days)
- Last $0.0957 (2026-11-08) · all-time high $2.38 (2021-09-12) · now -96.0% from high · lowest $0.0775 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.2168 start · H 2.19 L 0.1890 · cap $2.2B (#10) · Binance $3.6M/d
- 2020: $0.3353 +54.7% · H 0.6699 L 0.1266 · cap $3.3B (#18) · Binance $6.8M/d
- 2021: $1.66 +394.8% · H 2.38 L 0.3978 · cap $16.7B (#20) · Binance $73.4M/d
- 2022: $0.1725 -89.6% · H 1.79 L 0.1648 · cap $1.7B (#30) · Binance $24.2M/d
- 2023: $0.2229 +29.2% · H 0.2899 L 0.0887 · cap $2.2B (#33) · Binance $8.7M/d
- 2024: $0.3345 +50.1% · H 0.5091 L 0.1094 · cap $3.3B (#34) · Binance $19.7M/d
- 2025: $0.1105 -67.0% · H 0.4686 L 0.1073 · cap $1.1B (#41) · Binance $13.7M/d
- 2026: $0.0957 -13.4% · H 0.1423 L 0.0775 · cap $1.1B (#40) · Binance $3.5M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance ALGOUSDT daily (2019-06-22 → 2026-11-08)
