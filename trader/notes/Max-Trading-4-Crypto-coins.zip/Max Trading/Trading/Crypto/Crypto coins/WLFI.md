---
tags: [trading, crypto, wlfi]
---
**WLFI**
- Data: 2025-09-01 → 2026-11-08 (434 days)
- Last $0.0463 (2026-11-08) · all-time high $0.2436 (2025-09-21) · now -81.0% from high · lowest $0.0454 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1435 start · H 0.2436 L 0.1136 · Binance $74.4M/d
- 2026: $0.0463 -67.7% · H 0.1801 L 0.0454 · Binance $9.9M/d

**Sources**
- Binance WLFIUSDT daily (2025-09-01 → 2026-11-08)
