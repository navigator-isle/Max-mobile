---
tags: [trading, crypto, egld]
---
**EGLD**
- Data: 2020-09-03 → 2026-11-08 (2,258 days)
- Last $2.97 (2026-11-08) · all-time high $491.0 (2021-11-22) · now -99.4% from high · lowest $2.51 (2026-06-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $24.67 start · H 28.05 L 6.93 · Binance $8.5M/d
- 2021: $238.6 +867.1% · H 491.0 L 25.88 · Binance $62.8M/d
- 2022: $32.80 -86.3% · H 245.2 L 32.80 · Binance $21.4M/d
- 2023: $67.92 +107.1% · H 72.78 L 22.71 · Binance $8.5M/d
- 2024: $33.45 -50.8% · H 75.27 L 22.12 · Binance $9.5M/d
- 2025: $5.54 -83.4% · H 38.36 L 5.54 · Binance $3.3M/d
- 2026: $2.97 -46.4% · H 6.68 L 2.51 · Binance $755.9K/d

**Sources**
- Binance EGLDUSDT daily (2020-09-03 → 2026-11-08)
