---
tags: [trading, crypto, layer]
---
**LAYER**
- Data: 2025-02-11 → 2026-11-08 (636 days)
- Last $0.0527 (2026-11-08) · all-time high $3.27 (2025-05-04) · now -98.4% from high · lowest $0.0525 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1684 start · H 3.27 L 0.1602 · Binance $14.4M/d
- 2026: $0.0527 -68.7% · H 0.1825 L 0.0525 · Binance $1.8M/d

**Sources**
- Binance LAYERUSDT daily (2025-02-11 → 2026-11-08)
