---
tags: [trading, crypto, 1inch]
---
**1INCH**
- Data: 2020-12-25 → 2026-11-08 (2,145 days)
- Last $0.0790 (2026-11-08) · all-time high $7.48 (2021-05-08) · now -98.9% from high · lowest $0.0657 (2026-06-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.36 start · H 2.30 L 0.8845 · cap $2.0B (#23) · Binance $102.8M/d
- 2021: $2.39 +75.3% · H 7.48 L 1.02 · cap $3.6B (#38) · Binance $50.0M/d
- 2022: $0.3830 -84.0% · H 2.56 L 0.3760 · cap $575.3M (#49) · Binance $7.8M/d
- 2023: $0.4277 +11.7% · H 0.6870 L 0.2242 · cap $638.5M (#52) · Binance $4.3M/d
- 2024: $0.3834 -10.4% · H 0.6837 L 0.2225 · cap $573.2M (#58) · Binance $7.1M/d
- 2025: $0.1416 -63.1% · H 0.4367 L 0.1416 · cap $211.9M (#58) · Binance $3.3M/d
- 2026: $0.0790 -44.2% · H 0.1673 L 0.0657 · cap $137.6M (#61) · Binance $693.5K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance 1INCHUSDT daily (2020-12-25 → 2026-11-08)
