---
tags: [trading, crypto, xpl]
---
**XPL**
- Data: 2025-09-25 → 2026-11-08 (410 days)
- Last $0.0556 (2026-11-08) · all-time high $1.63 (2025-09-27) · now -96.6% from high · lowest $0.0556 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1614 start · H 1.63 L 0.1192 · Binance $217.7M/d
- 2026: $0.0556 -65.5% · H 0.2095 L 0.0556 · Binance $15.7M/d

**Sources**
- Binance XPLUSDT daily (2025-09-25 → 2026-11-08)
