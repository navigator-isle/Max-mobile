---
tags: [trading, crypto, sent]
---
**SENT**
- Data: 2026-01-22 → 2026-11-08 (291 days)
- Last $0.0176 (2026-11-08) · all-time high $0.0480 (2026-01-31) · now -63.4% from high · lowest $0.0116 (2026-07-27)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0176 start · H 0.0480 L 0.0116 · Binance $14.2M/d

**Sources**
- Binance SENTUSDT daily (2026-01-22 → 2026-11-08)
