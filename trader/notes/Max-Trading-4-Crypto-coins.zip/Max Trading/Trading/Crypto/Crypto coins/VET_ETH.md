---
tags: [trading, crypto, vet_eth]
---
**VET_ETH**
- Data: 2018-07-14 → 2026-05-23 (2,871 days)
- Last $0.00676 (2026-05-23) · all-time high $0.2514 (2021-04-20) · now -97.3% from high · lowest $0.00228 (2020-03-16)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.00391 start · H 0.0266 L 0.0033 · cap $3.9M (#71)
- 2019: $0.00519 +32.5% · H 0.00917 L 0.00299 · cap $5.2M (#80)
- 2020: $0.0187 +261.3% · H 0.0219 L 0.00228 · cap $18.7M (#99)
- 2021: $0.0831 +343.5% · H 0.2514 L 0.0191 · cap $83.1M (#101)
- 2022: $0.0158 -81.0% · H 0.0872 L 0.0156 · cap $15.8M (#102)
- 2023: $0.0342 +116.8% · H 0.0382 L 0.0147 · cap $34.2M (#98)
- 2024: $0.0430 +25.8% · H 0.0759 L 0.0194 · cap $43.0M (#101)
- 2025: $0.0104 -75.8% · H 0.0562 L 0.00979 · cap $10.4M (#99)
- 2026: $0.00676 -35.1% · H 0.0128 L 0.00653 · cap $6.8M (#96)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
