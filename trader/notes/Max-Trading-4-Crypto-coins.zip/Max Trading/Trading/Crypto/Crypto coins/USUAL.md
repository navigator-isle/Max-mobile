---
tags: [trading, crypto, usual]
---
**USUAL**
- Data: 2024-11-19 → 2026-11-08 (720 days)
- Last $0.0101 (2026-11-08) · all-time high $1.44 (2024-12-19) · now -99.3% from high · lowest $0.0076 (2026-07-30)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.9025 start · H 1.44 L 0.2189 · Binance $157.7M/d
- 2025: $0.0246 -97.3% · H 1.02 L 0.0230 · Binance $15.3M/d
- 2026: $0.0101 -59.1% · H 0.0309 L 0.0076 · Binance $833.7K/d

**Sources**
- Binance USUALUSDT daily (2024-11-19 → 2026-11-08)
