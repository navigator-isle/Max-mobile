---
tags: [trading, crypto, mira]
---
**MIRA**
- Data: 2025-09-26 → 2026-11-08 (409 days)
- Last $0.0366 (2026-11-08) · all-time high $1.45 (2025-09-26) · now -97.5% from high · lowest $0.0366 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.1467 start · H 1.45 L 0.1154 · Binance $41.4M/d
- 2026: $0.0366 -75.1% · H 0.1526 L 0.0366 · Binance $2.3M/d

**Sources**
- Binance MIRAUSDT daily (2025-09-26 → 2026-11-08)
