---
tags: [trading, crypto, trump]
---
**TRUMP**
- Data: 2025-01-19 → 2026-11-08 (659 days)
- Last $1.17 (2026-11-08) · all-time high $46.50 (2025-01-19) · now -97.5% from high · lowest $1.17 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $4.80 start · H 46.50 L 4.80 · Binance $190.7M/d
- 2026: $1.17 -75.7% · H 5.67 L 1.17 · Binance $16.3M/d

**Sources**
- Binance TRUMPUSDT daily (2025-01-19 → 2026-11-08)
