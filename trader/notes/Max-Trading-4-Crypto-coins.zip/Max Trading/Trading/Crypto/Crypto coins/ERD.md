---
tags: [trading, crypto, erd]
---
**ERD**
- Data: 2019-07-04 → 2020-08-31 (425 days)
- Last $0.0197 (2020-08-31) · all-time high $0.0278 (2020-07-28) · now -29.1% from high · lowest $0.000707 (2020-03-16)
- Binance: stopped trading on Binance (delisted) after 2020-08-31

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00181 start · H 0.00677 L 0.00134 · Binance $2.2M/d
- 2020: $0.0197 +991.8% · H 0.0278 L 0.000707 · Binance $4.5M/d

**Sources**
- Binance ERDUSDT daily (2019-07-04 → 2020-08-31)
