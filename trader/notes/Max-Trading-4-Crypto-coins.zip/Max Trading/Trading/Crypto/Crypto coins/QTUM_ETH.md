---
tags: [trading, crypto, qtum_eth]
---
**QTUM_ETH**
- Data: 2017-07-28 → 2026-05-23 (3,222 days)
- Last $0.9294 (2026-05-23) · all-time high $72.76 (2018-01-06) · now -98.7% from high · lowest $0.7992 (2026-03-29)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $53.38 start · H 62.28 L 5.50 · cap $5.3B (#12)
- 2018: $2.13 -96.0% · H 72.76 L 1.55 · cap $213.1M (#29)
- 2019: $1.60 -24.8% · H 5.62 L 1.53 · cap $160.2M (#37)
- 2020: $2.23 +38.9% · H 4.17 L 1.04 · cap $222.5M (#64)
- 2021: $8.74 +292.9% · H 26.82 L 2.25 · cap $874.4M (#65)
- 2022: $1.84 -79.0% · H 9.23 L 1.83 · cap $183.8M (#69)
- 2023: $3.71 +101.8% · H 3.71 L 1.88 · cap $370.9M (#64)
- 2024: $3.00 -19.0% · H 5.50 L 2.00 · cap $300.4M (#71)
- 2025: $1.34 -55.3% · H 3.79 L 1.21 · cap $134.2M (#69)
- 2026: $0.9294 -30.8% · H 1.57 L 0.7992 · cap $92.9M (#67)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
