---
tags: [trading, crypto, buidl_eth]
---
**BUIDL_ETH**
- Data: 2025-11-06 → 2026-05-23 (199 days)
- Last $0.9996 (2026-05-23) · all-time high $1.00 (2026-03-23) · now -0.2% from high · lowest $0.9995 (2026-02-05)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $1.0000 start · H 1.00 L 0.9996 · cap $171.6M (#61)
- 2026: $0.9996 -0.0% · H 1.00 L 0.9995 · cap $178.3M (#58)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
