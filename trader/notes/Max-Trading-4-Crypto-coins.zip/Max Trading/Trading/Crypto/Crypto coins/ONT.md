---
tags: [trading, crypto, ont]
---
**ONT**
- Data: 2018-06-08 → 2026-11-08 (3,076 days)
- Last $0.0411 (2026-11-08) · all-time high $8.28 (2018-06-08) · now -99.5% from high · lowest $0.0352 (2026-08-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $0.5808 start · H 8.28 L 0.4500 · Binance $12.0M/d
- 2019: $0.5185 -10.7% · H 1.78 L 0.5122 · Binance $4.3M/d
- 2020: $0.4413 -14.9% · H 1.07 L 0.3062 · Binance $9.0M/d
- 2021: $0.6568 +48.8% · H 2.69 L 0.4491 · Binance $56.2M/d
- 2022: $0.1498 -77.2% · H 0.7029 L 0.1485 · Binance $4.2M/d
- 2023: $0.3363 +124.5% · H 0.3363 L 0.1500 · Binance $3.6M/d
- 2024: $0.2299 -31.6% · H 0.4652 L 0.1445 · Binance $4.0M/d
- 2025: $0.0642 -72.1% · H 0.2718 L 0.0528 · Binance $1.8M/d
- 2026: $0.0411 -36.1% · H 0.1118 L 0.0352 · Binance $1.6M/d

**Sources**
- Binance ONTUSDT daily (2018-06-08 → 2026-11-08)
