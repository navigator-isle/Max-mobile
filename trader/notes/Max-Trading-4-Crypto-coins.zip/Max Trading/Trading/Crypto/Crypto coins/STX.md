---
tags: [trading, crypto, stx]
---
**STX**
- Data: 2019-10-25 → 2026-11-08 (2,572 days)
- Last $0.3367 (2026-11-08) · all-time high $3.66 (2024-03-24) · now -90.8% from high · lowest $0.0588 (2020-03-16)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0955 start · H 0.3760 L 0.0811 · Binance $684.0K/d
- 2020: $0.3960 +314.7% · H 0.4133 L 0.0588 · Binance $866.6K/d
- 2021: $2.17 +447.0% · H 2.87 L 0.4260 · Binance $12.4M/d
- 2022: $0.2090 -90.4% · H 2.40 L 0.2070 · Binance $3.3M/d
- 2023: $1.50 +616.6% · H 1.63 L 0.2130 · Binance $18.6M/d
- 2024: $1.54 +2.6% · H 3.66 L 1.23 · Binance $30.8M/d
- 2025: $0.2445 -84.1% · H 1.83 L 0.2408 · Binance $5.9M/d
- 2026: $0.3367 +37.7% · H 0.4349 L 0.1200 · Binance $1.9M/d

**Sources**
- Binance STXUSDT daily (2019-10-25 → 2026-11-08)
