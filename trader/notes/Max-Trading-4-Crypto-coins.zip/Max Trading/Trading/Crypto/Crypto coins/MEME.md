---
tags: [trading, crypto, meme]
---
**MEME**
- Data: 2023-11-03 → 2026-11-08 (1,102 days)
- Last $0.000389 (2026-11-08) · all-time high $0.0532 (2024-03-03) · now -99.3% from high · lowest $0.000389 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.0273 start · H 0.0431 L 0.0178 · Binance $98.7M/d
- 2024: $0.0107 -60.9% · H 0.0532 L 0.00862 · Binance $27.0M/d
- 2025: $0.000988 -90.7% · H 0.0117 L 0.000898 · Binance $8.9M/d
- 2026: $0.000389 -60.6% · H 0.00125 L 0.000389 · Binance $1.8M/d

**Sources**
- Binance MEMEUSDT daily (2023-11-03 → 2026-11-08)
