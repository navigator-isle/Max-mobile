---
tags: [trading, crypto, eigen]
---
**EIGEN**
- Data: 2024-10-01 → 2026-11-08 (769 days)
- Last $0.1641 (2026-11-08) · all-time high $5.50 (2024-12-16) · now -97.0% from high · lowest $0.1510 (2026-04-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $3.52 start · H 5.50 L 2.22 · Binance $55.0M/d
- 2025: $0.3490 -90.1% · H 4.12 L 0.3490 · Binance $18.1M/d
- 2026: $0.1641 -53.0% · H 0.4530 L 0.1510 · Binance $3.7M/d

**Sources**
- Binance EIGENUSDT daily (2024-10-01 → 2026-11-08)
