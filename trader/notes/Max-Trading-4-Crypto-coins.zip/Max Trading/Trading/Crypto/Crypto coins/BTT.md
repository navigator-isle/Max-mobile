---
tags: [trading, crypto, btt]
---
**BTT**
- Data: 2019-01-31 → 2022-01-17 (1,083 days)
- Last $0.00278 (2022-01-17) · all-time high $0.0103 (2021-04-04) · now -73.0% from high · lowest $0.000179 (2020-03-12)
- Binance: stopped trading on Binance (delisted) after 2022-01-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.000287 start · H 0.00179 L 0.00027 · Binance $14.9M/d
- 2020: $0.000288 +0.3% · H 0.000577 L 0.000179 · Binance $3.4M/d
- 2021: $0.00272 +845.1% · H 0.0103 L 0.000293 · Binance $127.4M/d
- 2022: $0.00278 +2.0% · H 0.0029 L 0.00242 · Binance $30.9M/d

**Sources**
- Binance BTTUSDT daily (2019-01-31 → 2022-01-17)
