---
tags: [trading, crypto, bat]
---
**BAT**
- Data: 2017-10-06 → 2026-11-08 (3,321 days)
- Last $0.1212 (2026-11-08) · all-time high $1.77 (2021-11-27) · now -93.1% from high · lowest $0.0567 (2026-08-14)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.4148 start · H 0.4148 L 0.1267 · cap $622.2M (#43)
- 2018: $0.1259 -69.7% · H 0.8638 L 0.1250 · cap $188.8M (#32)
- 2019: $0.1803 +43.2% · H 0.4375 L 0.1043 · cap $270.4M (#30) · Binance $1.6M/d
- 2020: $0.1996 +10.7% · H 0.4024 L 0.1100 · cap $299.3M (#58) · Binance $4.6M/d
- 2021: $1.20 +503.6% · H 1.77 L 0.2037 · cap $1.8B (#49) · Binance $33.1M/d
- 2022: $0.1662 -86.2% · H 1.30 L 0.1654 · cap $248.4M (#64) · Binance $7.6M/d
- 2023: $0.2568 +54.5% · H 0.3274 L 0.1604 · cap $384.4M (#61) · Binance $2.5M/d
- 2024: $0.2328 -9.3% · H 0.3758 L 0.1493 · cap $348.0M (#67) · Binance $3.0M/d
- 2025: $0.2066 -11.3% · H 0.2824 L 0.1123 · cap $310.1M (#51) · Binance $2.7M/d
- 2026: $0.1212 -41.3% · H 0.2281 L 0.0567 · cap $151.6M (#60) · Binance $1.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance BATUSDT daily (2019-03-04 → 2026-11-08)
