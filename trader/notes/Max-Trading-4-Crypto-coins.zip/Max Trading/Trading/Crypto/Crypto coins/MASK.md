---
tags: [trading, crypto, mask]
---
**MASK**
- Data: 2021-05-25 → 2026-11-08 (1,994 days)
- Last $0.3710 (2026-11-08) · all-time high $19.20 (2021-11-26) · now -98.1% from high · lowest $0.3390 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $12.25 start · H 19.20 L 3.06 · Binance $25.1M/d
- 2022: $2.08 -83.0% · H 14.01 L 1.02 · Binance $13.4M/d
- 2023: $3.60 +73.3% · H 6.77 L 2.10 · Binance $19.7M/d
- 2024: $3.02 -16.2% · H 5.73 L 1.79 · Binance $14.4M/d
- 2025: $0.6000 -80.1% · H 3.21 L 0.5360 · Binance $5.7M/d
- 2026: $0.3710 -38.2% · H 0.7030 L 0.3390 · Binance $659.8K/d

**Sources**
- Binance MASKUSDT daily (2021-05-25 → 2026-11-08)
