---
tags: [trading, crypto, front]
---
**FRONT**
- Data: 2021-10-04 → 2024-08-27 (1,059 days)
- Last $0.8800 (2024-08-27) · all-time high $2.80 (2024-03-17) · now -68.6% from high · lowest $0.1313 (2023-06-14)
- Binance: stopped trading on Binance (delisted) after 2024-08-27

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $0.6888 start · H 1.31 L 0.6322 · Binance $4.0M/d
- 2022: $0.1801 -73.9% · H 0.7157 L 0.1618 · Binance $2.6M/d
- 2023: $0.4126 +129.1% · H 0.6086 L 0.1313 · Binance $3.7M/d
- 2024: $0.8800 +113.3% · H 2.80 L 0.3959 · Binance $14.5M/d

**Sources**
- Binance FRONTUSDT daily (2021-10-04 → 2024-08-27)
