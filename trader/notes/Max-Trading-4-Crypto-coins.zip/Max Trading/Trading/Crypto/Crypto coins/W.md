---
tags: [trading, crypto, w]
---
**W**
- Data: 2024-04-03 → 2026-11-08 (950 days)
- Last $0.0107 (2026-11-08) · all-time high $1.31 (2024-04-03) · now -99.2% from high · lowest $0.00795 (2026-08-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.2859 start · H 1.31 L 0.1752 · Binance $24.7M/d
- 2025: $0.0329 -88.5% · H 0.3182 L 0.0324 · Binance $8.0M/d
- 2026: $0.0107 -67.4% · H 0.0397 L 0.00795 · Binance $2.3M/d

**Sources**
- Binance WUSDT daily (2024-04-03 → 2026-11-08)
