---
tags: [trading, crypto, chz]
---
**CHZ**
- Data: 2019-09-06 → 2026-11-08 (2,621 days)
- Last $0.0112 (2026-11-08) · all-time high $0.7700 (2021-04-16) · now -98.5% from high · lowest $0.00408 (2019-09-27)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00704 start · H 0.0171 L 0.00408 · Binance $532.3K/d
- 2020: $0.0213 +201.8% · H 0.0284 L 0.0052 · Binance $1.8M/d
- 2021: $0.2834 +1233.3% · H 0.7700 L 0.0175 · Binance $178.7M/d
- 2022: $0.1003 -64.6% · H 0.3116 L 0.0870 · Binance $41.9M/d
- 2023: $0.0863 -13.9% · H 0.1616 L 0.0545 · Binance $11.0M/d
- 2024: $0.0820 -5.0% · H 0.1665 L 0.0487 · Binance $17.8M/d
- 2025: $0.0423 -48.4% · H 0.0953 L 0.0278 · Binance $4.3M/d
- 2026: $0.0112 -73.5% · H 0.0621 L 0.0112 · Binance $4.5M/d

**Sources**
- Binance CHZUSDT daily (2019-09-06 → 2026-11-08)
