---
tags: [trading, crypto, rep]
---
**REP**
- Data: 2016-10-04 → 2022-12-22 (2,271 days)
- Last $4.73 (2022-12-22) · all-time high $105.6 (2018-01-12) · now -95.5% from high · lowest $2.51 (2016-12-23)
- Binance: stopped trading on Binance (delisted) after 2022-12-22

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2016: $3.82 start · H 12.42 L 2.51 · cap $42.0M (#10)
- 2017: $70.33 +1741.4% · H 98.21 L 3.82 · cap $773.6M (#38)
- 2018: $7.61 -89.2% · H 105.6 L 5.53 · cap $83.7M (#47)
- 2019: $8.78 +15.3% · H 24.11 L 7.37 · cap $96.6M (#43)
- 2020: $16.55 +88.5% · H 27.64 L 6.72 · cap $184.5M (#68) · Binance $807.6K/d
- 2021: $18.11 +9.4% · H 57.30 L 10.97 · cap $199.8M (#93) · Binance $3.8M/d
- 2022: $4.73 -73.9% · H 19.13 L 4.56 · cap $51.2M (#90) · Binance $1.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance REPUSDT daily (2020-06-12 → 2022-12-22)
