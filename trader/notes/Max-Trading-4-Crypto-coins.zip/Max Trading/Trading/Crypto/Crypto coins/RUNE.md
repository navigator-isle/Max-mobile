---
tags: [trading, crypto, rune]
---
**RUNE**
- Data: 2020-09-04 → 2026-11-08 (2,257 days)
- Last $0.5830 (2026-11-08) · all-time high $20.34 (2021-05-18) · now -97.1% from high · lowest $0.3210 (2026-06-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $1.17 start · H 1.21 L 0.3389 · Binance $3.8M/d
- 2021: $6.79 +480.8% · H 20.34 L 1.29 · Binance $52.4M/d
- 2022: $1.27 -81.3% · H 12.36 L 1.03 · Binance $33.2M/d
- 2023: $5.16 +305.5% · H 7.09 L 0.7970 · Binance $24.2M/d
- 2024: $4.48 -13.2% · H 10.60 L 2.94 · Binance $76.2M/d
- 2025: $0.5590 -87.5% · H 5.17 L 0.5450 · Binance $28.4M/d
- 2026: $0.5830 +4.3% · H 0.8000 L 0.3210 · Binance $2.4M/d

**Sources**
- Binance RUNEUSDT daily (2020-09-04 → 2026-11-08)
