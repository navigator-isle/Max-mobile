---
tags: [trading, crypto, bb]
---
**BB**
- Data: 2024-05-13 → 2026-11-08 (910 days)
- Last $0.00643 (2026-11-08) · all-time high $0.8515 (2024-06-05) · now -99.2% from high · lowest $0.0063 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.4185 start · H 0.8515 L 0.2453 · Binance $25.8M/d
- 2025: $0.0551 -86.8% · H 0.4691 L 0.0521 · Binance $5.1M/d
- 2026: $0.00643 -88.3% · H 0.0714 L 0.0063 · Binance $1.3M/d

**Sources**
- Binance BBUSDT daily (2024-05-13 → 2026-11-08)
