---
tags: [trading, crypto, magic]
---
**MAGIC**
- Data: 2022-12-12 → 2026-11-08 (1,428 days)
- Last $0.0848 (2026-11-08) · all-time high $2.12 (2023-02-07) · now -96.0% from high · lowest $0.0394 (2026-07-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.4914 start · H 0.7649 L 0.4664 · Binance $8.7M/d
- 2023: $1.08 +120.7% · H 2.12 L 0.4254 · Binance $18.3M/d
- 2024: $0.4241 -60.9% · H 1.44 L 0.3000 · Binance $7.9M/d
- 2025: $0.0941 -77.8% · H 0.6147 L 0.0683 · Binance $6.5M/d
- 2026: $0.0848 -9.9% · H 0.1376 L 0.0394 · Binance $1.5M/d

**Sources**
- Binance MAGICUSDT daily (2022-12-12 → 2026-11-08)
