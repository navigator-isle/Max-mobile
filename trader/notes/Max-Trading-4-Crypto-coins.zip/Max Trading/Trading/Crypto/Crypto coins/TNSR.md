---
tags: [trading, crypto, tnsr]
---
**TNSR**
- Data: 2024-04-08 → 2026-11-08 (945 days)
- Last $0.0254 (2026-11-08) · all-time high $1.82 (2024-04-09) · now -98.6% from high · lowest $0.0254 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $0.4353 start · H 1.82 L 0.2752 · Binance $15.7M/d
- 2025: $0.0786 -81.9% · H 0.5249 L 0.0343 · Binance $5.5M/d
- 2026: $0.0254 -67.7% · H 0.0824 L 0.0254 · Binance $1.4M/d

**Sources**
- Binance TNSRUSDT daily (2024-04-08 → 2026-11-08)
