---
tags: [trading, crypto, snt]
---
**SNT**
- Data: 2017-06-19 → 2025-04-16 (2,859 days)
- Last $0.0272 (2025-04-16) · all-time high $0.6348 (2018-01-03) · now -95.7% from high · lowest $0.00822 (2020-03-12)
- Binance: stopped trading on Binance (delisted) after 2025-04-16

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.2267 start · H 0.3254 L 0.0202 · cap $1.5B (#25)
- 2018: $0.0169 -92.5% · H 0.6348 L 0.0133 · cap $115.1M (#37)
- 2019: $0.00899 -46.8% · H 0.0307 L 0.00887 · cap $61.2M (#50)
- 2020: $0.0305 +238.6% · H 0.0472 L 0.00822 · cap $207.2M (#65)
- 2021: $0.0685 +125.0% · H 0.2748 L 0.0305 · cap $466.3M (#81)
- 2022: $0.0186 -72.8% · H 0.0784 L 0.0185 · cap $126.6M (#76)
- 2023: $0.0450 +141.9% · H 0.0593 L 0.0189 · cap $305.5M (#70) · Binance $2.1M/d
- 2024: $0.0401 -10.9% · H 0.0695 L 0.0181 · cap $272.7M (#74) · Binance $3.0M/d
- 2025: $0.0272 -32.2% · H 0.0508 L 0.0169 · cap $92.9M (#74) · Binance $1.9M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance SNTUSDT daily (2023-05-19 → 2025-04-16)
