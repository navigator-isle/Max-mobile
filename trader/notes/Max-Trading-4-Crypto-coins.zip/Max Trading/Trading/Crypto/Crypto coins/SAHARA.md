---
tags: [trading, crypto, sahara]
---
**SAHARA**
- Data: 2025-06-26 → 2026-11-08 (501 days)
- Last $0.00646 (2026-11-08) · all-time high $0.1478 (2025-07-23) · now -95.6% from high · lowest $0.00637 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0250 start · H 0.1478 L 0.0250 · Binance $11.8M/d
- 2026: $0.00646 -74.2% · H 0.0440 L 0.00637 · Binance $4.9M/d

**Sources**
- Binance SAHARAUSDT daily (2025-06-26 → 2026-11-08)
