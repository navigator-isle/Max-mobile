---
tags: [trading, crypto, ong]
---
**ONG**
- Data: 2019-02-16 → 2026-11-08 (2,823 days)
- Last $0.0643 (2026-11-08) · all-time high $2.43 (2021-05-20) · now -97.4% from high · lowest $0.0406 (2026-08-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0951 start · H 0.8691 L 0.0901 · Binance $601.6K/d
- 2020: $0.1860 +95.6% · H 0.3840 L 0.0554 · Binance $755.8K/d
- 2021: $0.7476 +301.9% · H 2.43 L 0.1908 · Binance $7.3M/d
- 2022: $0.2128 -71.5% · H 0.9040 L 0.2112 · Binance $1.8M/d
- 2023: $0.3991 +87.5% · H 0.4433 L 0.1945 · Binance $1.8M/d
- 2024: $0.3151 -21.0% · H 0.7421 L 0.2508 · Binance $3.8M/d
- 2025: $0.0840 -73.3% · H 0.3879 L 0.0760 · Binance $1.2M/d
- 2026: $0.0643 -23.5% · H 0.2386 L 0.0406 · Binance $1.6M/d

**Sources**
- Binance ONGUSDT daily (2019-02-16 → 2026-11-08)
