---
tags: [trading, crypto, omg]
---
**OMG**
- Data: 2017-07-15 → 2024-06-17 (2,530 days)
- Last $0.3830 (2024-06-17) · all-time high $25.59 (2018-01-13) · now -98.5% from high · lowest $0.3720 (2024-06-14)
- Binance: stopped trading on Binance (delisted) after 2024-06-17

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $19.92 start · H 19.92 L 0.3786 · cap $2.8B (#17)
- 2018: $1.33 -93.3% · H 25.59 L 1.09 · cap $186.5M (#33)
- 2019: $0.6058 -54.4% · H 2.83 L 0.5914 · cap $84.7M (#47) · Binance $441.0K/d
- 2020: $2.47 +308.3% · H 6.41 L 0.4069 · cap $347.9M (#55) · Binance $8.2M/d
- 2021: $5.87 +137.2% · H 19.22 L 2.54 · cap $827.0M (#66) · Binance $86.1M/d
- 2022: $1.03 -82.5% · H 6.73 L 0.9590 · cap $144.1M (#73) · Binance $9.8M/d
- 2023: $0.8290 -19.4% · H 2.32 L 0.4240 · cap $115.9M (#88) · Binance $3.4M/d
- 2024: $0.3830 -53.8% · H 1.32 L 0.3720 · cap $45.2M (#100) · Binance $4.0M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance OMGUSDT daily (2019-04-03 → 2024-06-17)
