---
tags: [trading, crypto, dot]
---
**DOT**
- Data: 2020-08-18 → 2026-11-08 (2,274 days)
- Last $0.8940 (2026-11-08) · all-time high $53.82 (2021-11-04) · now -98.3% from high · lowest $0.7520 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $9.26 start · H 9.26 L 2.83 · cap $9.5B (#8) · Binance $53.8M/d
- 2021: $26.66 +187.8% · H 53.82 L 8.27 · cap $30.2B (#13) · Binance $429.0M/d
- 2022: $4.31 -83.8% · H 30.11 L 4.29 · cap $10.9B (#13) · Binance $84.7M/d
- 2023: $8.20 +90.3% · H 9.19 L 3.65 · Binance $27.5M/d
- 2024: $6.64 -19.0% · H 11.56 L 3.75 · Binance $51.8M/d
- 2025: $1.79 -73.1% · H 7.77 L 1.69 · Binance $30.2M/d
- 2026: $0.8940 -50.0% · H 2.28 L 0.7520 · Binance $9.1M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance DOTUSDT daily (2020-08-18 → 2026-11-08)
