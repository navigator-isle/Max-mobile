---
tags: [trading, crypto, dydx]
---
**DYDX**
- Data: 2021-09-09 → 2026-11-08 (1,887 days)
- Last $0.0927 (2026-11-08) · all-time high $26.75 (2021-09-29) · now -99.7% from high · lowest $0.0799 (2026-03-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $8.10 start · H 26.75 L 7.40 · Binance $131.3M/d
- 2022: $1.10 -86.4% · H 8.70 L 1.04 · Binance $21.9M/d
- 2023: $2.95 +167.5% · H 3.98 L 1.14 · Binance $28.2M/d
- 2024: $1.44 -51.2% · H 4.37 L 0.8400 · Binance $23.0M/d
- 2025: $0.1680 -88.3% · H 1.64 L 0.1607 · Binance $7.5M/d
- 2026: $0.0927 -44.8% · H 0.2148 L 0.0799 · Binance $2.0M/d

**Sources**
- Binance DYDXUSDT daily (2021-09-09 → 2026-11-08)
