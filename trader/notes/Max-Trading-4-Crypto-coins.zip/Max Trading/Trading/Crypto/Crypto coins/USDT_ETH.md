---
tags: [trading, crypto, usdt_eth]
---
**USDT_ETH**
- Data: 2017-11-28 → 2026-05-23 (3,099 days)
- Last $0.9987 (2026-05-23) · all-time high $1.11 (2017-12-12) · now -10.2% from high · lowest $0.9503 (2018-11-14)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $1.01 start · H 1.11 L 0.9966 · cap $111.4K (#58)
- 2018: $0.9987 -1.5% · H 1.03 L 0.9503 · cap $60.0M (#54)
- 2019: $0.9954 -0.3% · H 1.01 L 0.9702 · cap $2.3B (#9)
- 2020: $1.00 +0.6% · H 1.01 L 0.9950 · cap $13.3B (#6)
- 2021: $1.00 -0.1% · H 1.00 L 0.9989 · cap $39.8B (#8)
- 2022: $0.9995 -0.1% · H 1.00 L 0.9954 · cap $32.3B (#8)
- 2023: $0.9998 +0.0% · H 1.01 L 0.9984 · cap $42.0B (#6)
- 2024: $0.9980 -0.2% · H 1.00 L 0.9980 · cap $76.8B (#5)
- 2025: $0.9983 +0.0% · H 1.00 L 0.9978 · cap $102.5B (#5)
- 2026: $0.9987 +0.0% · H 1.00 L 0.9977 · cap $96.9B (#5)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
