---
tags: [trading, crypto, tia]
---
**TIA**
- Data: 2023-10-31 → 2026-11-08 (1,105 days)
- Last $0.4275 (2026-11-08) · all-time high $20.15 (2024-02-08) · now -97.9% from high · lowest $0.2853 (2026-04-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $11.88 start · H 14.14 L 2.28 · Binance $107.4M/d
- 2024: $4.62 -61.1% · H 20.15 L 3.91 · Binance $51.7M/d
- 2025: $0.4559 -90.1% · H 5.57 L 0.4384 · Binance $19.2M/d
- 2026: $0.4275 -6.2% · H 0.6885 L 0.2853 · Binance $5.1M/d

**Sources**
- Binance TIAUSDT daily (2023-10-31 → 2026-11-08)
