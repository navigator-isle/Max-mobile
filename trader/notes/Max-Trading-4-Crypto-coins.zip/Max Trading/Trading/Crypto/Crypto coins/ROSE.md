---
tags: [trading, crypto, rose]
---
**ROSE**
- Data: 2020-11-19 → 2026-11-08 (2,181 days)
- Last $0.00553 (2026-11-08) · all-time high $0.5654 (2022-01-14) · now -99.0% from high · lowest $0.00512 (2026-07-27)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.0416 start · H 0.0562 L 0.0352 · Binance $9.4M/d
- 2021: $0.4279 +928.9% · H 0.4279 L 0.0410 · Binance $27.3M/d
- 2022: $0.0341 -92.0% · H 0.5654 L 0.0340 · Binance $34.4M/d
- 2023: $0.1374 +302.3% · H 0.1376 L 0.0348 · Binance $8.8M/d
- 2024: $0.0803 -41.6% · H 0.1819 L 0.0494 · Binance $10.3M/d
- 2025: $0.0102 -87.3% · H 0.0937 L 0.0101 · Binance $3.9M/d
- 2026: $0.00553 -45.6% · H 0.0215 L 0.00512 · Binance $2.0M/d

**Sources**
- Binance ROSEUSDT daily (2020-11-19 → 2026-11-08)
