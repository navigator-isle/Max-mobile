---
tags: [trading, crypto, hive]
---
**HIVE**
- Data: 2020-04-27 → 2026-11-08 (2,387 days)
- Last $0.0431 (2026-11-08) · all-time high $2.95 (2021-11-29) · now -98.5% from high · lowest $0.0380 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.1150 start · H 0.4480 L 0.1099 · Binance $779.6K/d
- 2021: $1.49 +1195.3% · H 2.95 L 0.1128 · Binance $10.3M/d
- 2022: $0.2584 -82.7% · H 1.72 L 0.2556 · Binance $2.4M/d
- 2023: $0.3638 +40.8% · H 0.5206 L 0.2600 · Binance $898.7K/d
- 2024: $0.3841 +5.6% · H 0.4786 L 0.1623 · Binance $3.1M/d
- 2025: $0.0965 -74.9% · H 0.6623 L 0.0854 · Binance $4.7M/d
- 2026: $0.0431 -55.3% · H 0.1103 L 0.0380 · Binance $587.5K/d

**Sources**
- Binance HIVEUSDT daily (2020-04-27 → 2026-11-08)
