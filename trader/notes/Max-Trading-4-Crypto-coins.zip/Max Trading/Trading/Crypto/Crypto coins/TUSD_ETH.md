---
tags: [trading, crypto, tusd_eth]
---
**TUSD_ETH**
- Data: 2018-07-06 → 2026-05-23 (2,879 days)
- Last $0.9987 (2026-05-23) · all-time high $1.03 (2024-03-24) · now -2.7% from high · lowest $0.9597 (2024-02-28)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $1.00 start · H 1.01 L 0.9801 · cap $205.3M (#30)
- 2019: $0.9989 -0.3% · H 1.01 L 0.9968 · cap $153.9M (#38)
- 2020: $1.00 +0.2% · H 1.00 L 0.9982 · cap $282.4M (#59)
- 2021: $0.9998 -0.1% · H 1.00 L 0.9958 · cap $949.2M (#64)
- 2022: $0.9986 -0.1% · H 1.00 L 0.9911 · cap $499.3M (#50)
- 2023: $0.9966 -0.2% · H 1.01 L 0.9942 · cap $400.3M (#59)
- 2024: $0.9985 +0.2% · H 1.03 L 0.9597 · cap $315.7M (#70)
- 2025: $0.9961 -0.2% · H 1.00 L 0.9903 · cap $313.9M (#50)
- 2026: $0.9987 +0.3% · H 1.00 L 0.9965 · cap $314.7M (#49)

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
