---
tags: [trading, crypto, ff]
---
**FF**
- Data: 2025-09-29 → 2026-11-08 (406 days)
- Last $0.0857 (2026-11-08) · all-time high $0.2817 (2025-09-29) · now -69.6% from high · lowest $0.0583 (2026-07-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0863 start · H 0.2817 L 0.0863 · Binance $73.5M/d
- 2026: $0.0857 -0.8% · H 0.1686 L 0.0583 · Binance $2.9M/d

**Sources**
- Binance FFUSDT daily (2025-09-29 → 2026-11-08)
