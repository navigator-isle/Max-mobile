---
tags: [trading, crypto, qnt]
---
**QNT**
- Data: 2019-03-16 → 2026-11-08 (2,795 days)
- Last $195.9 (2026-11-08) · all-time high $394.9 (2021-09-10) · now -50.4% from high · lowest $1.54 (2020-03-12)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $3.57 start · H 13.40 L 1.74 · cap $87.2M (#46)
- 2020: $11.29 +216.3% · H 15.98 L 1.54 · cap $275.9M (#61)
- 2021: $178.7 +1482.5% · H 394.9 L 10.86 · cap $4.4B (#34) · Binance $19.3M/d
- 2022: $105.4 -41.0% · H 209.9 L 44.40 · cap $2.6B (#25) · Binance $8.1M/d
- 2023: $137.8 +30.7% · H 155.3 L 84.10 · cap $3.4B (#26) · Binance $4.5M/d
- 2024: $106.5 -22.7% · H 165.9 L 56.10 · cap $2.6B (#37) · Binance $5.5M/d
- 2025: $69.50 -34.7% · H 135.0 L 59.90 · cap $1.7B (#37) · Binance $3.5M/d
- 2026: $195.9 +181.9% · H 287.1 L 55.89 · cap $1.9B (#32) · Binance $6.8M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance QNTUSDT daily (2021-07-29 → 2026-11-08)
