---
tags: [trading, crypto, gmt]
---
**GMT**
- Data: 2022-03-09 → 2026-11-08 (1,706 days)
- Last $0.00601 (2026-11-08) · all-time high $3.82 (2022-04-29) · now -99.8% from high · lowest $0.00591 (2026-11-05)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.2297 start · H 3.82 L 0.1168 · Binance $220.0M/d
- 2023: $0.3187 +38.7% · H 0.6140 L 0.1414 · Binance $13.6M/d
- 2024: $0.1528 -52.1% · H 0.4014 L 0.0940 · Binance $18.3M/d
- 2025: $0.0151 -90.1% · H 0.1668 L 0.0135 · Binance $7.6M/d
- 2026: $0.00601 -60.3% · H 0.0221 L 0.00591 · Binance $985.5K/d

**Sources**
- Binance GMTUSDT daily (2022-03-09 → 2026-11-08)
