---
tags: [trading, crypto, newt]
---
**NEWT**
- Data: 2025-06-24 → 2026-11-08 (503 days)
- Last $0.0386 (2026-11-08) · all-time high $0.5774 (2025-07-24) · now -93.3% from high · lowest $0.0360 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0955 start · H 0.5774 L 0.0905 · Binance $10.0M/d
- 2026: $0.0386 -59.6% · H 0.1075 L 0.0360 · Binance $683.8K/d

**Sources**
- Binance NEWTUSDT daily (2025-06-24 → 2026-11-08)
