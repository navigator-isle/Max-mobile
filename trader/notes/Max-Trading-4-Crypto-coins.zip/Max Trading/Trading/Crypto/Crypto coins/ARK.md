---
tags: [trading, crypto, ark]
---
**ARK**
- Data: 2023-09-22 → 2026-11-08 (1,144 days)
- Last $0.1565 (2026-11-08) · all-time high $1.79 (2023-11-10) · now -91.3% from high · lowest $0.0859 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $0.9262 start · H 1.79 L 0.4353 · Binance $21.9M/d
- 2024: $0.5159 -44.3% · H 1.26 L 0.2715 · Binance $4.4M/d
- 2025: $0.2583 -49.9% · H 0.6712 L 0.2423 · Binance $2.5M/d
- 2026: $0.1565 -39.4% · H 0.2972 L 0.0859 · Binance $810.8K/d

**Sources**
- Binance ARKUSDT daily (2023-09-22 → 2026-11-08)
