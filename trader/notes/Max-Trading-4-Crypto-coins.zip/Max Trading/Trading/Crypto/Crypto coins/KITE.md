---
tags: [trading, crypto, kite]
---
**KITE**
- Data: 2025-11-03 → 2026-11-08 (371 days)
- Last $0.1079 (2026-11-08) · all-time high $0.3005 (2026-03-09) · now -64.1% from high · lowest $0.0688 (2025-11-06)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0896 start · H 0.1155 L 0.0688 · Binance $30.3M/d
- 2026: $0.1079 +20.4% · H 0.3005 L 0.0868 · Binance $8.2M/d

**Sources**
- Binance KITEUSDT daily (2025-11-03 → 2026-11-08)
