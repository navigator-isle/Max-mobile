---
tags: [trading, crypto, s]
---
**S**
- Data: 2025-01-16 → 2026-11-08 (662 days)
- Last $0.0376 (2026-11-08) · all-time high $0.8665 (2025-02-20) · now -95.7% from high · lowest $0.0201 (2026-06-25)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2025: $0.0739 start · H 0.8665 L 0.0713 · Binance $31.3M/d
- 2026: $0.0376 -49.1% · H 0.0977 L 0.0201 · Binance $2.6M/d

**Sources**
- Binance SUSDT daily (2025-01-16 → 2026-11-08)
