---
tags: [trading, crypto, lpt]
---
**LPT**
- Data: 2018-12-20 → 2026-11-08 (2,881 days)
- Last $1.33 (2026-11-08) · all-time high $74.62 (2021-11-10) · now -98.2% from high · lowest $0.5019 (2020-04-20)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2018: $3.06 start · H 9.27 L 3.06 · cap $34.7M (#62)
- 2019: $1.31 -57.1% · H 8.92 L 1.20 · cap $24.0M (#67)
- 2020: $1.45 +10.6% · H 5.04 L 0.5019 · cap $33.3M (#90)
- 2021: $39.66 +2630.1% · H 74.62 L 1.40 · cap $984.8M (#61) · Binance $13.2M/d
- 2022: $4.54 -88.6% · H 42.80 L 4.43 · cap $113.1M (#80) · Binance $2.9M/d
- 2023: $7.96 +75.3% · H 10.35 L 3.73 · cap $196.9M (#80) · Binance $4.5M/d
- 2024: $15.02 +88.7% · H 27.20 L 6.42 · cap $373.0M (#66) · Binance $13.9M/d
- 2025: $2.90 -80.7% · H 17.13 L 2.81 · cap $72.3M (#80) · Binance $6.7M/d
- 2026: $1.33 -54.1% · H 3.66 L 1.18 · cap $55.1M (#79) · Binance $1.3M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance LPTUSDT daily (2021-05-28 → 2026-11-08)
