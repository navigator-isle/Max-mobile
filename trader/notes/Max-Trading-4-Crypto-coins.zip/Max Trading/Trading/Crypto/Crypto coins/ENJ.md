---
tags: [trading, crypto, enj]
---
**ENJ**
- Data: 2019-04-18 → 2026-11-08 (2,762 days)
- Last $0.0228 (2026-11-08) · all-time high $4.49 (2021-11-24) · now -99.5% from high · lowest $0.0177 (2026-03-07)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.0804 start · H 0.2012 L 0.0520 · Binance $652.9K/d
- 2020: $0.1298 +61.3% · H 0.2447 L 0.0426 · Binance $1.7M/d
- 2021: $2.58 +1884.3% · H 4.49 L 0.1316 · Binance $77.5M/d
- 2022: $0.2408 -90.6% · H 2.85 L 0.2373 · Binance $11.4M/d
- 2023: $0.3790 +57.4% · H 0.5459 L 0.2064 · Binance $4.0M/d
- 2024: $0.2092 -44.8% · H 0.6606 L 0.1256 · Binance $5.3M/d
- 2025: $0.0277 -86.7% · H 0.2501 L 0.0258 · Binance $2.2M/d
- 2026: $0.0228 -17.9% · H 0.0898 L 0.0177 · Binance $2.8M/d

**Sources**
- Binance ENJUSDT daily (2019-04-18 → 2026-11-08)
