---
tags: [trading, crypto, marscoin]
---
**MARSCOIN**
- Data: 2026-09-04 → 2026-11-08 (66 days)
- Last $0.0425 (2026-11-08) · all-time high $0.2408 (2026-09-05) · now -82.4% from high · lowest $0.0425 (2026-11-08)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.0425 start · H 0.2408 L 0.0425 · Binance $17.2M/d

**Sources**
- Binance MARSCOINUSDT daily (2026-09-04 → 2026-11-08)
