---
tags: [trading, crypto, gal]
---
**GAL**
- Data: 2022-05-05 → 2024-07-15 (803 days)
- Last $2.54 (2024-07-15) · all-time high $17.38 (2022-05-05) · now -85.4% from high · lowest $0.9570 (2023-06-10)
- Binance: stopped trading on Binance (delisted) after 2024-07-15

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $1.03 start · H 17.38 L 1.02 · Binance $27.1M/d
- 2023: $2.33 +126.6% · H 2.56 L 0.9570 · Binance $4.6M/d
- 2024: $2.54 +9.3% · H 5.62 L 1.72 · Binance $9.2M/d

**Sources**
- Binance GALUSDT daily (2022-05-05 → 2024-07-15)
