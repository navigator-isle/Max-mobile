---
tags: [trading, crypto, aero]
---
**AERO**
- Data: 2026-07-17 → 2026-11-08 (115 days)
- Last $0.6018 (2026-11-08) · all-time high $0.9440 (2026-10-11) · now -36.2% from high · lowest $0.3996 (2026-08-02)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2026: $0.6018 start · H 0.9440 L 0.3996 · Binance $11.4M/d

**Sources**
- Binance AEROUSDT daily (2026-07-17 → 2026-11-08)
