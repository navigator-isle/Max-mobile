---
tags: [trading, crypto, lqty]
---
**LQTY**
- Data: 2023-02-28 → 2026-11-08 (1,350 days)
- Last $0.1755 (2026-11-08) · all-time high $2.96 (2023-03-14) · now -94.1% from high · lowest $0.1570 (2026-07-20)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2023: $1.48 start · H 2.96 L 0.7530 · Binance $12.9M/d
- 2024: $1.80 +22.3% · H 2.73 L 0.5650 · Binance $6.4M/d
- 2025: $0.3790 -79.0% · H 2.15 L 0.3480 · Binance $2.4M/d
- 2026: $0.1755 -53.7% · H 0.4250 L 0.1570 · Binance $308.0K/d

**Sources**
- Binance LQTYUSDT daily (2023-02-28 → 2026-11-08)
