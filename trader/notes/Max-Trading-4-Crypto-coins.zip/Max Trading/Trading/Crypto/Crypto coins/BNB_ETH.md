---
tags: [trading, crypto, bnb_eth]
---
**BNB_ETH**
- Data: 2017-07-15 → 2019-04-22 (647 days)
- Last $23.88 (2019-04-22) · all-time high $24.93 (2019-04-20) · now -4.2% from high · lowest $0.0748 (2017-07-16)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $8.66 start · H 9.81 L 0.0748 · cap $1.7B (#23)
- 2018: $6.07 -29.9% · H 22.35 L 4.46 · cap $1.2B (#11)
- 2019: $23.88 +293.7% · H 24.93 L 5.51 · cap $4.5B (#8)

**Sources**
- Coin Metrics community data (daily, to 2019-04-22)
