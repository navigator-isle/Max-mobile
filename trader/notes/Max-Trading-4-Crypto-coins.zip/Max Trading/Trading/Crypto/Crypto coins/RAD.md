---
tags: [trading, crypto, rad]
---
**RAD**
- Data: 2021-10-07 → 2026-11-08 (1,859 days)
- Last $0.2270 (2026-11-08) · all-time high $17.98 (2021-10-07) · now -98.7% from high · lowest $0.2020 (2026-08-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2021: $10.85 start · H 17.98 L 9.35 · Binance $18.6M/d
- 2022: $1.52 -86.0% · H 11.27 L 1.36 · Binance $3.7M/d
- 2023: $1.94 +27.2% · H 4.16 L 1.21 · Binance $5.0M/d
- 2024: $1.33 -31.4% · H 3.29 L 0.9370 · Binance $5.4M/d
- 2025: $0.3400 -74.4% · H 1.42 L 0.2510 · Binance $2.5M/d
- 2026: $0.2270 -33.2% · H 0.3440 L 0.2020 · Binance $1.1M/d

**Sources**
- Binance RADUSDT daily (2021-10-07 → 2026-11-08)
