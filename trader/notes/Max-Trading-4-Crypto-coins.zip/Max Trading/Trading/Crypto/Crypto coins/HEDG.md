---
tags: [trading, crypto, hedg]
---
**HEDG**
- Data: 2019-11-02 → 2022-01-27 (818 days)
- Last $0.6099 (2022-01-27) · all-time high $2.93 (2020-02-18) · now -79.2% from high · lowest $0.4077 (2020-12-24)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $1.74 start · H 1.80 L 0.5790 · cap $1.7B (#13)
- 2020: $0.4612 -73.4% · H 2.93 L 0.4077 · cap $461.2M (#50)
- 2021: $0.7140 +54.8% · H 2.20 L 0.4083 · cap $714.0M (#72)
- 2022: $0.6099 -14.6% · H 0.7717 L 0.5484 · cap $609.9M (#64)

**Sources**
- Coin Metrics community data (daily, to 2022-01-27)
