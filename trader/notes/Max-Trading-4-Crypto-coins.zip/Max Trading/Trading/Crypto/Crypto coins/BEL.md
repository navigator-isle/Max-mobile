---
tags: [trading, crypto, bel]
---
**BEL**
- Data: 2020-09-15 → 2026-11-08 (2,246 days)
- Last $0.0943 (2026-11-08) · all-time high $6.21 (2020-09-15) · now -98.5% from high · lowest $0.0804 (2026-06-10)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.8622 start · H 6.21 L 0.6628 · Binance $5.1M/d
- 2021: $1.54 +78.8% · H 5.49 L 0.8373 · Binance $10.2M/d
- 2022: $0.3880 -74.8% · H 1.80 L 0.2430 · Binance $7.4M/d
- 2023: $0.7088 +82.7% · H 1.12 L 0.3930 · Binance $4.2M/d
- 2024: $0.5579 -21.3% · H 2.09 L 0.3482 · Binance $4.6M/d
- 2025: $0.1285 -77.0% · H 1.05 L 0.1171 · Binance $3.5M/d
- 2026: $0.0943 -26.6% · H 0.1946 L 0.0804 · Binance $901.0K/d

**Sources**
- Binance BELUSDT daily (2020-09-15 → 2026-11-08)
