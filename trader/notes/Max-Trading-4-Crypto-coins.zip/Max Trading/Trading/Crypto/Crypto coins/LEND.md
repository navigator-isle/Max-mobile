---
tags: [trading, crypto, lend]
---
**LEND**
- Data: 2017-12-09 → 2020-10-12 (1,039 days)
- Last $0.5143 (2020-10-12) · all-time high $0.8202 (2020-08-26) · now -37.3% from high · lowest $0.00332 (2019-08-17)
- Binance: stopped trading on Binance (delisted) after 2020-10-12

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.1735 start · H 0.2162 L 0.0217 · cap $225.5M (#54)
- 2018: $0.00727 -95.8% · H 0.3743 L 0.00652 · cap $9.5M (#70)
- 2019: $0.0164 +126.2% · H 0.0210 L 0.00332 · cap $21.4M (#69)
- 2020: $0.5143 +3026.8% · H 0.8202 L 0.0153 · cap $1.1B (#33) · Binance $10.2M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance LENDUSDT daily (2020-05-15 → 2020-10-12)
