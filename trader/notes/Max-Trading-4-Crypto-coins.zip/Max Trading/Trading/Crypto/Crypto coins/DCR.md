---
tags: [trading, crypto, dcr]
---
**DCR**
- Data: 2016-05-17 → 2026-11-08 (3,828 days)
- Last $12.50 (2026-11-08) · all-time high $246.0 (2021-04-16) · now -94.9% from high · lowest $0.4347 (2016-12-26)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2016: $0.4787 start · H 2.09 L 0.4347 · cap $2.1M (#16)
- 2017: $95.98 +19950.7% · H 99.36 L 0.4580 · cap $660.6M (#41)
- 2018: $16.35 -83.0% · H 121.5 L 14.22 · cap $148.3M (#34)
- 2019: $16.78 +2.6% · H 35.12 L 12.94 · cap $182.7M (#35)
- 2020: $40.73 +142.7% · H 40.78 L 9.29 · cap $506.8M (#49) · Binance $426.0K/d
- 2021: $69.90 +71.6% · H 246.0 L 41.13 · cap $962.5M (#63) · Binance $2.2M/d
- 2022: $18.40 -73.7% · H 74.80 L 18.40 · cap $272.8M (#60) · Binance $1.2M/d
- 2023: $18.02 -2.1% · H 27.02 L 11.70 · cap $284.5M (#72) · Binance $739.8K/d
- 2024: $15.21 -15.6% · H 31.09 L 9.51 · cap $253.4M (#76) · Binance $1.4M/d
- 2025: $16.76 +10.2% · H 43.87 L 10.40 · cap $290.6M (#53) · Binance $1.3M/d
- 2026: $12.50 -25.4% · H 34.24 L 10.77 · cap $293.1M (#51) · Binance $747.6K/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance DCRUSDT daily (2020-07-30 → 2026-11-08)
