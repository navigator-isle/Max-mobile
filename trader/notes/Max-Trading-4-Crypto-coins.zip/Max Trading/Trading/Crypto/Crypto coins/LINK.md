---
tags: [trading, crypto, link]
---
**LINK**
- Data: 2017-09-29 → 2026-11-08 (3,328 days)
- Last $10.77 (2026-11-08) · all-time high $52.27 (2021-05-09) · now -79.4% from high · lowest $0.1465 (2017-11-29)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $0.6003 start · H 0.6256 L 0.1465 · cap $600.3M (#44)
- 2018: $0.2846 -52.6% · H 1.36 L 0.1641 · cap $284.6M (#21)
- 2019: $1.77 +521.0% · H 3.75 L 0.2966 · cap $1.8B (#12) · Binance $10.0M/d
- 2020: $11.24 +535.8% · H 19.23 L 1.74 · cap $11.2B (#7) · Binance $82.0M/d
- 2021: $19.51 +73.6% · H 52.27 L 11.85 · cap $19.6B (#18) · Binance $214.4M/d
- 2022: $5.58 -71.4% · H 27.98 L 5.47 · cap $5.6B (#15) · Binance $66.7M/d
- 2023: $14.94 +168.0% · H 16.93 L 5.13 · cap $14.9B (#10) · Binance $47.3M/d
- 2024: $20.01 +33.9% · H 29.26 L 9.48 · cap $20.0B (#14) · Binance $79.6M/d
- 2025: $12.21 -39.0% · H 26.79 L 10.93 · cap $12.2B (#11) · Binance $84.9M/d
- 2026: $10.77 -11.8% · H 15.45 L 7.20 · cap $9.6B (#12) · Binance $26.6M/d

**Sources**
- Coin Metrics community data (daily, to 2026-05-23)
- Binance LINKUSDT daily (2019-01-16 → 2026-11-08)
