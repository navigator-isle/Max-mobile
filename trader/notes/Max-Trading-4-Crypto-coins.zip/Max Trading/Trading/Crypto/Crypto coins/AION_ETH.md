---
tags: [trading, crypto, aion_eth]
---
**AION_ETH**
- Data: 2017-12-22 → 2023-03-03 (1,898 days)
- Last $0.0101 (2023-03-03) · all-time high $10.39 (2018-01-09) · now -99.9% from high · lowest $0.0101 (2023-02-27)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2017: $5.19 start · H 5.69 L 3.58 · cap $2.4B (#19)
- 2018: $0.1388 -97.3% · H 10.39 L 0.1080 · cap $64.7M (#52)
- 2019: $0.0530 -61.8% · H 0.2430 L 0.0474 · cap $24.7M (#66)
- 2020: $0.0619 +16.9% · H 0.1640 L 0.0487 · cap $28.9M (#94)
- 2021: $0.1392 +124.7% · H 0.5330 L 0.0639 · cap $64.8M (#103)
- 2022: $0.0263 -81.1% · H 0.1539 L 0.0237 · cap $12.3M (#105)
- 2023: $0.0101 -61.5% · H 0.0488 L 0.0101 · cap $4.7M (#109)

**Sources**
- Coin Metrics community data (daily, to 2023-03-03)
