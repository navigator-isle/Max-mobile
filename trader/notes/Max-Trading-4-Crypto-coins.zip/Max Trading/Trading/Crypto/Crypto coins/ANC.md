---
tags: [trading, crypto, anc]
---
**ANC**
- Data: 2022-01-25 → 2022-12-27 (337 days)
- Last $0.0315 (2022-12-27) · all-time high $5.82 (2022-03-05) · now -99.5% from high · lowest $0.0281 (2022-12-24)
- Binance: stopped trading on Binance (delisted) after 2022-12-27

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2022: $0.0315 start · H 5.82 L 0.0281 · Binance $21.3M/d

**Sources**
- Binance ANCUSDT daily (2022-01-25 → 2022-12-27)
