---
tags: [trading, crypto, cos]
---
**COS**
- Data: 2019-08-03 → 2026-06-19 (2,513 days)
- Last $0.000251 (2026-06-19) · all-time high $0.0497 (2021-12-03) · now -99.5% from high · lowest $0.000223 (2026-06-18)
- Binance: stopped trading on Binance (delisted) after 2026-06-19

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00928 start · H 0.0372 L 0.00928 · Binance $538.6K/d
- 2020: $0.00706 -23.9% · H 0.0120 L 0.00438 · Binance $482.5K/d
- 2021: $0.0267 +277.5% · H 0.0497 L 0.00682 · Binance $11.9M/d
- 2022: $0.00436 -83.6% · H 0.0272 L 0.00395 · Binance $3.0M/d
- 2023: $0.00853 +95.6% · H 0.00899 L 0.00423 · Binance $1.2M/d
- 2024: $0.00751 -12.0% · H 0.0313 L 0.00597 · Binance $7.2M/d
- 2025: $0.00122 -83.7% · H 0.0083 L 0.00116 · Binance $1.2M/d
- 2026: $0.000251 -79.4% · H 0.00231 L 0.000223 · Binance $1.8M/d

**Sources**
- Binance COSUSDT daily (2019-08-03 → 2026-06-19)
