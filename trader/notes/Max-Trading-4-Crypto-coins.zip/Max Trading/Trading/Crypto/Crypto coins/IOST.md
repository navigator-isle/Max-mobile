---
tags: [trading, crypto, iost]
---
**IOST**
- Data: 2019-03-22 → 2026-11-08 (2,789 days)
- Last $0.000678 (2026-11-08) · all-time high $0.0798 (2021-09-09) · now -99.2% from high · lowest $0.000532 (2026-08-18)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2019: $0.00468 start · H 0.0180 L 0.00395 · Binance $2.0M/d
- 2020: $0.00567 +21.3% · H 0.00837 L 0.00229 · Binance $5.8M/d
- 2021: $0.0313 +451.9% · H 0.0798 L 0.00562 · Binance $48.1M/d
- 2022: $0.00673 -78.5% · H 0.0421 L 0.00666 · Binance $8.6M/d
- 2023: $0.00992 +47.4% · H 0.0143 L 0.00672 · Binance $2.3M/d
- 2024: $0.00638 -35.7% · H 0.0142 L 0.00424 · Binance $3.0M/d
- 2025: $0.00181 -71.5% · H 0.00827 L 0.00145 · Binance $2.1M/d
- 2026: $0.000678 -62.6% · H 0.00204 L 0.000532 · Binance $952.1K/d

**Sources**
- Binance IOSTUSDT daily (2019-03-22 → 2026-11-08)
