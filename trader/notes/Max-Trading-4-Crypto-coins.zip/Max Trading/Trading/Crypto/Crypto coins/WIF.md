---
tags: [trading, crypto, wif]
---
**WIF**
- Data: 2024-03-05 → 2026-11-08 (979 days)
- Last $0.1600 (2026-11-08) · all-time high $4.58 (2024-03-31) · now -96.5% from high · lowest $0.1356 (2026-08-01)
- Binance: trading now

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2024: $1.86 start · H 4.58 L 1.26 · Binance $197.4M/d
- 2025: $0.2700 -85.5% · H 2.18 L 0.2700 · Binance $56.9M/d
- 2026: $0.1600 -40.7% · H 0.4200 L 0.1356 · Binance $5.5M/d

**Sources**
- Binance WIFUSDT daily (2024-03-05 → 2026-11-08)
