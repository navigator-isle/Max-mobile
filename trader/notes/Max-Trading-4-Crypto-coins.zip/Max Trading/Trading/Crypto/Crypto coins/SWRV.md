---
tags: [trading, crypto, swrv]
---
**SWRV**
- Data: 2020-09-22 → 2025-03-27 (1,648 days)
- Last $0.00424 (2025-03-27) · all-time high $3.13 (2021-04-11) · now -99.9% from high · lowest $0.004 (2025-03-11)
- Binance: not on Binance USDT

**Year by year** (USD: year-end close, change, H high, L low, cap = year-end market cap and rank among coins in data, Binance = average traded value per day)
- 2020: $0.3911 start · H 1.03 L 0.3873 · cap $4.3M (#107)
- 2021: $0.3067 -21.6% · H 3.13 L 0.2501 · cap $5.6M (#116)
- 2022: $0.1189 -61.2% · H 0.4429 L 0.0405 · cap $2.4M (#110)
- 2023: $0.0240 -79.8% · H 0.2178 L 0.0129 · cap $508.4K (#113)
- 2024: $0.00634 -73.6% · H 0.0510 L 0.00412 · cap $134.6K (#116)
- 2025: $0.00424 -33.1% · H 0.00875 L 0.004 · cap $90.1K (#115)

**Sources**
- Coin Metrics community data (daily, to 2025-03-27)
