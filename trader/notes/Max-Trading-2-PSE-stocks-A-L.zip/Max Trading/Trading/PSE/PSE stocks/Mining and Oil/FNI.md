---
tags: [trading, pse, stock, fni]
---
**FNI — Global Ferronickel Holdings, Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Dec 14, 1994
- Data: 2006-04-03 → 2026-11-06 (4,735 trading days)
- Last close ₱1.54 (2026-11-06) · all-time high ₱9.00 (2014-09-08) · low ₱0.4600 (2016-01-18) · now -82.9% from high
- Cash dividends last 12 months ₱0.0603 = 3.9% yield
- Dividend events on record (2013 → 2026): 4
- Splits / stock dividends detected (prices before these dates are as traded then): 2013-06-13 (÷1.5), 2016-11-15 (÷0.333)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱2.97 start · H 3.54 L 0.8100 · ₱10.1M/d
- 2007: ₱3.00 +1.0% · H 5.70 L 2.76 · ₱21.1M/d
- 2008: ₱0.8700 -71.0% · H 3.00 L 0.8100 · ₱2.0M/d
- 2009: ₱2.58 +196.6% · H 3.60 L 0.7200 · ₱5.7M/d
- 2010: ₱6.06 +134.9% · H 6.51 L 2.19 · ₱10.8M/d
- 2011: ₱4.80 -20.8% · H 5.94 L 3.78 · ₱7.9M/d
- 2012: ₱7.20 +50.0% · H 8.97 L 4.26 · ₱13.4M/d
- 2013: ₱2.91 -59.6% · H 4.80 L 2.85 · ₱650.5K/d
- 2014: ₱8.22 +182.5% · H 9.00 L 2.91 · ₱28.3M/d
- 2015: ₱0.6900 -91.6% · H 3.47 L 0.6700 · ₱75.3M/d
- 2016: ₱2.86 +314.5% · H 3.85 L 0.4600 · ₱37.7M/d
- 2017: ₱2.63 -8.0% · H 3.30 L 2.34 · ₱18.7M/d
- 2018: ₱1.66 -36.9% · H 2.70 L 1.66 · ₱12.5M/d
- 2019: ₱1.79 +7.8% · H 2.05 L 1.42 · ₱24.2M/d
- 2020: ₱2.72 +52.0% · H 2.72 L 0.4700 · ₱19.7M/d
- 2021: ₱2.15 -21.0% · H 3.15 L 2.04 · ₱19.6M/d · div ₱0.1000 (4.7%): 10Jun 0.1
- 2022: ₱2.51 +16.7% · H 3.47 L 2.03 · ₱12.9M/d · div ₱0.2000 (8.0%): 13Apr 0.2
- 2023: ₱2.06 -17.9% · H 2.95 L 1.98 · ₱8.2M/d · div ₱0.1000 (4.9%): 29May 0.1
- 2024: ₱1.04 -49.5% · H 2.19 L 1.03 · ₱1.7M/d
- 2025: ₱1.35 +29.8% · H 1.69 L 0.9900 · ₱1.7M/d
- 2026*: ₱1.54 +14.1% · H 2.57 L 1.46 · ₱5.1M/d · div ₱0.0603 (3.9%): 29Jul 0.0603

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
