---
tags: [trading, pse, stock, geo]
---
**GEO — GEOGRACE Resources Philippines, Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Feb 07, 1972
- Data: 1995-03-01 → 2026-11-06 (6,794 trading days)
- Last close ₱0.0790 (2026-11-06) · all-time high ₱2.95 (2007-06-22) · low ₱0.0270 (2023-12-28) · now -97.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱1.39 start · H 1.62 L 1.12 · ₱410.8K/d
- 1996: ₱1.68 +21.3% · H 2.91 L 1.47 · ₱4.9M/d
- 1997: ₱0.7667 -54.5% · H 1.73 L 0.7667 · ₱2.2M/d
- 1998: ₱0.5333 -30.4% · H 0.7356 L 0.3778 · ₱492.9K/d
- 1999: ₱0.5800 +8.8% · H 0.8367 L 0.4944 · ₱530.3K/d
- 2000: ₱0.5022 -13.4% · H 1.17 L 0.4478 · ₱4.8M/d
- 2001: ₱0.3156 -37.2% · H 0.5567 L 0.2844 · ₱313.2K/d
- 2002: ₱0.2689 -14.8% · H 0.3778 L 0.2611 · ₱502.7K/d
- 2003: ₱0.2689 +0.0% · H 0.3389 L 0.2533 · ₱536.4K/d
- 2004: ₱0.2689 +0.0% · H 0.2844 L 0.2611 · ₱1.8M/d
- 2005: ₱0.2689 +0.0% · H 0.3389 L 0.2689 · ₱4.7M/d
- 2006: ₱0.7100 +164.0% · H 0.8100 L 0.2689 · ₱13.6M/d
- 2007: ₱1.80 +153.5% · H 2.95 L 0.6900 · ₱144.9M/d
- 2008: ₱0.4000 -77.8% · H 1.78 L 0.3500 · ₱23.0M/d
- 2009: ₱0.8000 +100.0% · H 0.9500 L 0.3800 · ₱14.1M/d
- 2010: ₱0.6200 -22.5% · H 0.8300 L 0.5900 · ₱5.2M/d
- 2011: ₱0.5300 -14.5% · H 0.7800 L 0.5100 · ₱9.4M/d
- 2012: ₱0.5000 -5.7% · H 1.13 L 0.4900 · ₱17.3M/d
- 2013: ₱0.4000 -20.0% · H 0.5800 L 0.4000 · ₱638.5K/d
- 2014: ₱0.3850 -3.7% · H 0.4500 L 0.3800 · ₱366.7K/d
- 2015: ₱0.2750 -28.6% · H 0.4650 L 0.2750 · ₱764.3K/d
- 2016: ₱0.2600 -5.5% · H 0.3150 L 0.2350 · ₱545.4K/d
- 2017: ₱0.2100 -19.2% · H 0.3350 L 0.2100 · ₱520.4K/d
- 2018: ₱0.2060 -1.9% · H 0.2550 L 0.1750 · ₱227.4K/d
- 2019: ₱0.2020 -1.9% · H 0.3350 L 0.2010 · ₱1.0M/d
- 2020: ₱0.2850 +41.1% · H 0.2950 L 0.1760 · ₱401.9K/d
- 2021: ₱0.1820 -36.1% · H 0.6000 L 0.1810 · ₱2.1M/d
- 2022: ₱0.1850 +1.6% · H 0.2230 L 0.1700 · ₱142.5K/d
- 2023: ₱0.0270 -85.4% · H 0.2110 L 0.0270 · ₱435.0K/d
- 2024: ₱0.0850 +214.8% · H 0.1800 L 0.0270 · ₱352.9K/d
- 2025: ₱0.0870 +2.4% · H 0.1470 L 0.0580 · ₱185.2K/d
- 2026*: ₱0.0790 -9.2% · H 0.1250 L 0.0690 · ₱149.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
