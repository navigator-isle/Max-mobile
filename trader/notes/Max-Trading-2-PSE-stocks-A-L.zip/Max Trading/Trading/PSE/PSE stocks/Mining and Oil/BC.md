---
tags: [trading, pse, stock, bc]
---
**BC — Benguet Corporation**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Jan 04, 1950
- Data: 1985-02-12 → 2026-11-06 (6,506 trading days)
- Last close ₱6.00 (2026-11-06) · all-time high ₱15.20 (1989-08-10) · low ₱0.0300 (2002-11-05) · now -60.5% from high
- Cash dividends last 12 months ₱0.1500 = 2.5% yield
- Dividend events on record (2013 → 2026): 2
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-06 (÷0.333)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1985: ₱1.90 start · H 2.53 L 1.90 · ₱45.4K/d
- 1986: ₱5.38 +183.3% · H 6.22 L 1.90 · ₱802.6K/d
- 1987: ₱7.80 +45.1% · H 14.12 L 5.64 · ₱1.5M/d
- 1988: ₱8.58 +10.0% · H 9.17 L 7.38 · ₱799.7K/d
- 1989: ₱11.87 +38.3% · H 15.20 L 7.30 · ₱1.7M/d
- 1990: ₱3.33 -71.9% · H 11.47 L 3.17 · ₱348.9K/d
- 1991: ₱4.17 +25.0% · H 7.50 L 3.07 · ₱293.8K/d
- 1992: ₱3.83 -8.0% · H 7.58 L 3.67 · ₱529.8K/d
- 1993: ₱6.17 +60.9% · H 6.33 L 2.50 · ₱461.8K/d
- 1994: ₱4.00 -35.1% · H 6.50 L 3.67 · ₱5.1M/d
- 1995: ₱4.83 +20.8% · H 5.17 L 2.70 · ₱584.8K/d
- 1996: ₱4.33 -10.3% · H 4.83 L 3.00 · ₱93.8K/d
- 1997: ₱0.7000 -83.8% · H 3.33 L 0.4667 · ₱132.1K/d
- 1998: ₱1.47 +109.5% · H 1.47 L 0.4333 · ₱58.5K/d
- 1999: ₱0.8333 -43.2% · H 1.70 L 0.8333 · ₱86.7K/d
- 2000: ₱0.2667 -68.0% · H 1.23 L 0.2667 · ₱15.8K/d
- 2001: ₱0.2000 -25.0% · H 0.2000 L 0.2000 · ₱90.0K/d
- 2002: ₱0.0300 -85.0% · H 0.1667 L 0.0300 · ₱22.5K/d
- 2004: ₱1.15 start · H 1.15 L 0.0467 · ₱126.9K/d
- 2005: ₱2.33 +102.9% · H 3.42 L 1.00 · ₱398.7K/d
- 2006: ₱3.10 +32.9% · H 5.08 L 1.97 · ₱1.1M/d
- 2007: ₱7.00 +125.8% · H 7.00 L 3.00 · ₱1.5M/d
- 2008: ₱2.20 -68.6% · H 10.17 L 1.62 · ₱2.1M/d
- 2009: ₱4.83 +119.7% · H 5.58 L 2.07 · ₱330.7K/d
- 2010: ₱4.00 -17.2% · H 5.23 L 3.10 · ₱259.8K/d
- 2011: ₱8.83 +120.8% · H 9.93 L 3.75 · ₱2.1M/d
- 2012: ₱6.33 -28.3% · H 9.17 L 6.20 · ₱1.4M/d
- 2013: ₱2.30 -63.7% · H 6.50 L 2.07 · ₱281.1K/d
- 2014: ₱2.81 +22.2% · H 4.23 L 2.13 · ₱295.6K/d
- 2015: ₱5.50 +95.7% · H 9.26 L 3.50 · ₱203.0K/d
- 2016: ₱2.23 -59.5% · H 10.92 L 1.99 · ₱433.8K/d
- 2017: ₱1.73 -22.4% · H 2.48 L 1.69 · ₱163.3K/d
- 2018: ₱1.50 -13.3% · H 1.85 L 0.9700 · ₱78.5K/d
- 2019: ₱1.13 -24.7% · H 1.70 L 0.9800 · ₱73.4K/d
- 2020: ₱3.10 +174.3% · H 3.38 L 0.7000 · ₱555.6K/d
- 2021: ₱5.34 +72.3% · H 6.40 L 2.42 · ₱1.1M/d
- 2022: ₱4.10 -23.2% · H 7.60 L 4.05 · ₱370.8K/d
- 2023: ₱4.87 +18.8% · H 5.26 L 3.80 · ₱1.1M/d
- 2024: ₱3.97 -18.5% · H 4.85 L 3.41 · ₱461.3K/d · div ₱0.2000 (5.0%): 13Nov 0.2
- 2025: ₱5.00 +25.9% · H 5.80 L 3.45 · ₱893.7K/d
- 2026*: ₱6.00 +20.0% · H 7.77 L 5.11 · ₱1.1M/d · div ₱0.1500 (2.5%): 15Apr 0.15

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
