---
tags: [trading, pse, stock, diz]
---
**DIZ — Dizon Copper-Silver Mines, Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Feb 10, 1988
- Data: 1988-02-12 → 2026-11-04 (6,599 trading days)
- Last close ₱3.25 (2026-11-04) · all-time high ₱59.60 (2012-05-02) · low ₱0.9000 (2002-06-07) · now -94.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2004-01-16 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1988: ₱13.45 start · H 13.91 L 4.99 · ₱306.7K/d
- 1989: ₱17.25 +28.3% · H 30.61 L 12.99 · ₱745.5K/d
- 1990: ₱12.24 -29.0% · H 18.92 L 11.13 · ₱254.7K/d
- 1991: ₱10.24 -16.4% · H 15.58 L 8.63 · ₱134.5K/d
- 1992: ₱7.00 -31.6% · H 12.80 L 6.60 · ₱273.7K/d
- 1993: ₱13.00 +85.7% · H 14.00 L 4.60 · ₱783.6K/d
- 1994: ₱11.00 -15.4% · H 15.00 L 8.25 · ₱2.2M/d
- 1995: ₱6.50 -40.9% · H 11.50 L 6.00 · ₱722.2K/d
- 1996: ₱6.50 +0.0% · H 8.75 L 6.00 · ₱710.4K/d
- 1997: ₱3.00 -53.8% · H 7.00 L 2.20 · ₱601.3K/d
- 1998: ₱3.20 +6.7% · H 3.20 L 1.00 · ₱159.2K/d
- 1999: ₱9.30 +190.6% · H 12.00 L 2.80 · ₱4.2M/d
- 2000: ₱3.40 -63.4% · H 12.00 L 1.28 · ₱961.4K/d
- 2001: ₱1.30 -61.8% · H 6.20 L 1.00 · ₱61.5K/d
- 2002: ₱0.9000 -30.8% · H 1.84 L 0.9000 · ₱38.8K/d
- 2003: ₱1.80 +100.0% · H 2.02 L 1.00 · ₱204.5K/d
- 2004: ₱3.60 +100.0% · H 3.70 L 1.00 · ₱346.1K/d
- 2005: ₱1.50 -58.3% · H 4.60 L 1.50 · ₱173.4K/d
- 2006: ₱3.00 +100.0% · H 3.20 L 1.10 · ₱429.6K/d
- 2007: ₱8.00 +166.7% · H 12.50 L 2.42 · ₱5.1M/d
- 2008: ₱1.20 -85.0% · H 8.00 L 1.20 · ₱396.1K/d
- 2009: ₱3.95 +229.2% · H 4.70 L 1.50 · ₱243.7K/d
- 2010: ₱4.70 +19.0% · H 6.00 L 3.40 · ₱280.4K/d
- 2011: ₱11.38 +142.1% · H 13.88 L 4.16 · ₱6.8M/d
- 2012: ₱15.10 +32.7% · H 59.60 L 11.70 · ₱38.7M/d
- 2013: ₱5.10 -66.2% · H 15.80 L 4.95 · ₱1.3M/d
- 2014: ₱6.32 +23.9% · H 9.96 L 5.10 · ₱749.4K/d
- 2015: ₱7.22 +14.2% · H 9.26 L 5.62 · ₱526.0K/d
- 2016: ₱12.38 +71.5% · H 14.88 L 5.68 · ₱968.4K/d
- 2017: ₱7.10 -42.6% · H 12.50 L 7.09 · ₱294.2K/d
- 2018: ₱7.27 +2.4% · H 8.52 L 6.80 · ₱124.8K/d
- 2019: ₱6.93 -4.7% · H 8.65 L 6.88 · ₱231.3K/d
- 2020: ₱8.22 +18.6% · H 8.51 L 5.76 · ₱262.3K/d
- 2021: ₱5.02 -38.9% · H 12.78 L 4.91 · ₱763.3K/d
- 2022: ₱4.00 -20.3% · H 5.87 L 3.00 · ₱70.2K/d
- 2023: ₱3.00 -25.0% · H 5.00 L 3.00 · ₱63.2K/d
- 2024: ₱2.09 -30.3% · H 3.04 L 2.01 · ₱37.2K/d
- 2025: ₱5.00 +139.2% · H 5.16 L 2.00 · ₱604.0K/d
- 2026*: ₱3.25 -35.0% · H 5.40 L 2.80 · ₱154.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
