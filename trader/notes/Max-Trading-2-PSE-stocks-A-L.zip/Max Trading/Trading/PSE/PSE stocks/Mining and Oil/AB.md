---
tags: [trading, pse, stock, ab]
---
**AB — Atok-Big Wedge Co., Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Jan 08, 1948
- Data: 2006-11-17 → 2026-11-06 (3,245 trading days)
- Last close ₱2.05 (2026-11-06) · all-time high ₱113.0 (2009-12-14) · low ₱1.28 (2009-05-28) · now -98.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱6.50 start · H 7.20 L 4.50 · ₱17.7K/d
- 2007: ₱9.00 +38.5% · H 15.25 L 5.80 · ₱36.1K/d
- 2008: ₱2.10 -76.7% · H 10.25 L 2.10 · ₱90.4K/d
- 2009: ₱101.0 +4709.5% · H 113.0 L 1.28 · ₱1.3M/d
- 2010: ₱42.90 -57.5% · H 101.0 L 36.00 · ₱1.4M/d
- 2011: ₱24.00 -44.1% · H 42.90 L 21.75 · ₱149.5K/d
- 2012: ₱19.90 -17.1% · H 38.60 L 16.70 · ₱12.1M/d
- 2013: ₱18.00 -9.5% · H 24.35 L 17.00 · ₱81.2K/d
- 2014: ₱11.78 -34.6% · H 18.00 L 10.12 · ₱91.2K/d
- 2015: ₱11.78 +0.0% · H 16.40 L 10.30 · ₱70.0K/d
- 2016: ₱10.38 -11.9% · H 14.00 L 9.62 · ₱63.6K/d
- 2017: ₱15.00 +44.5% · H 17.70 L 9.63 · ₱119.3K/d
- 2018: ₱15.48 +3.2% · H 34.70 L 12.62 · ₱860.3K/d
- 2019: ₱10.96 -29.2% · H 16.50 L 10.06 · ₱162.9K/d
- 2020: ₱7.99 -27.1% · H 13.02 L 7.17 · ₱810.5K/d
- 2021: ₱6.05 -24.3% · H 10.50 L 5.50 · ₱6.9M/d
- 2022: ₱7.48 +23.6% · H 8.45 L 5.50 · ₱1.1M/d
- 2023: ₱5.32 -28.9% · H 7.55 L 4.50 · ₱149.4K/d
- 2024: ₱5.44 +2.3% · H 5.79 L 2.53 · ₱239.3K/d
- 2025: ₱2.06 -62.1% · H 6.90 L 2.00 · ₱381.3K/d
- 2026*: ₱2.05 -0.5% · H 2.60 L 1.42 · ₱187.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
