---
tags: [trading, pse, stock, cpm]
---
**CPM — Century Peak Holdings Corporation**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Oct 06, 2009
- Data: 2009-10-06 → 2026-11-06 (3,557 trading days)
- Last close ₱1.88 (2026-11-06) · all-time high ₱7.10 (2009-12-17) · low ₱0.4500 (2016-01-18) · now -73.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2009: ₱6.50 start · H 7.10 L 1.50 · ₱190.8M/d
- 2010: ₱2.34 -64.0% · H 6.60 L 1.96 · ₱29.1M/d
- 2011: ₱1.82 -22.2% · H 2.46 L 1.70 · ₱4.5M/d
- 2012: ₱0.8400 -53.8% · H 2.02 L 0.8400 · ₱1.8M/d
- 2013: ₱0.5000 -40.5% · H 1.25 L 0.5000 · ₱1.0M/d
- 2014: ₱0.9100 +82.0% · H 1.11 L 0.5500 · ₱2.0M/d
- 2015: ₱0.6000 -34.1% · H 1.14 L 0.5800 · ₱1.7M/d
- 2016: ₱0.5500 -8.3% · H 0.8100 L 0.4500 · ₱699.1K/d
- 2017: ₱1.63 +196.4% · H 1.78 L 0.4500 · ₱5.6M/d
- 2018: ₱2.08 +27.6% · H 2.08 L 1.58 · ₱3.9M/d
- 2019: ₱2.88 +38.5% · H 2.89 L 1.99 · ₱2.0M/d
- 2020: ₱2.94 +2.1% · H 3.25 L 2.35 · ₱1.8M/d
- 2021: ₱2.94 +0.0% · H 2.94 L 2.48 · ₱698.3K/d
- 2022: ₱3.50 +19.0% · H 3.50 L 2.50 · ₱1.7M/d
- 2023: ₱3.48 -0.6% · H 3.54 L 2.63 · ₱1.8M/d
- 2024: ₱2.50 -28.2% · H 3.40 L 2.50 · ₱313.9K/d
- 2025: ₱2.39 -4.4% · H 2.66 L 2.30 · ₱323.8K/d
- 2026*: ₱1.88 -21.3% · H 2.41 L 1.88 · ₱88.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
