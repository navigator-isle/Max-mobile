---
tags: [trading, pse, stock, ecvc]
---
**ECVC — East Coast Vulcan Mining Corporation**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Aug 31, 1970
- Data: 2015-01-05 → 2026-11-06 (2,646 trading days)
- Last close ₱0.3050 (2026-11-06) · all-time high ₱3.85 (2021-02-15) · low ₱0.2450 (2025-11-14) · now -92.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2018-11-07 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱1.08 start · H 1.76 L 1.00 · ₱764.1K/d
- 2016: ₱1.12 +3.7% · H 1.43 L 0.9800 · ₱796.9K/d
- 2017: ₱0.7800 -30.4% · H 1.17 L 0.6000 · ₱450.5K/d
- 2018: ₱1.60 +105.1% · H 2.88 L 0.6900 · ₱33.7M/d
- 2019: ₱0.8600 -46.2% · H 1.66 L 0.8600 · ₱7.6M/d
- 2020: ₱1.05 +22.1% · H 1.34 L 0.4800 · ₱1.7M/d
- 2021: ₱0.9600 -8.6% · H 3.85 L 0.9200 · ₱26.2M/d
- 2022: ₱0.8000 -16.7% · H 1.44 L 0.7700 · ₱2.5M/d
- 2023: ₱0.6000 -25.0% · H 1.24 L 0.6000 · ₱2.9M/d
- 2024: ₱0.3100 -48.3% · H 0.7500 L 0.2600 · ₱345.8K/d
- 2025: ₱0.2700 -12.9% · H 0.3900 L 0.2450 · ₱103.7K/d
- 2026*: ₱0.3050 +13.0% · H 0.4000 L 0.2500 · ₱205.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
