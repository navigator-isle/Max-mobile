---
tags: [trading, pse, stock, ar]
---
**AR — Abra Mining and Industrial Corporation**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Dec 24, 1969
- Data: 1994-10-10 → 2021-03-03 (5,444 trading days)
- Last close ₱0.0046 (2021-03-03) · all-time high ₱0.0500 (1996-03-04) · low ₱0.0007 (2020-07-15) · now -90.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2003-03-17 (÷5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱0.0100 start · H 0.0120 L 0.009 · ₱251.6K/d
- 1995: ₱0.0230 +130.0% · H 0.0230 L 0.009 · ₱853.3K/d
- 1996: ₱0.0130 -43.5% · H 0.0500 L 0.0130 · ₱2.1M/d
- 1997: ₱0.0055 -57.7% · H 0.0220 L 0.0055 · ₱2.7M/d
- 1998: ₱0.0065 +18.2% · H 0.0120 L 0.0036 · ₱235.4K/d
- 1999: ₱0.0095 +46.2% · H 0.0120 L 0.005 · ₱761.7K/d
- 2000: ₱0.0055 -42.1% · H 0.0130 L 0.0046 · ₱1.2M/d
- 2001: ₱0.0032 -41.8% · H 0.006 L 0.002 · ₱88.5K/d
- 2002: ₱0.0034 +6.2% · H 0.0046 L 0.0026 · ₱77.9K/d
- 2003: ₱0.0034 +0.0% · H 0.0140 L 0.0028 · ₱229.6K/d
- 2004: ₱0.0120 +252.9% · H 0.0140 L 0.0028 · ₱1.0M/d
- 2005: ₱0.0065 -45.8% · H 0.0150 L 0.0055 · ₱857.5K/d
- 2006: ₱0.0120 +84.6% · H 0.0140 L 0.0065 · ₱2.7M/d
- 2007: ₱0.0100 -16.7% · H 0.0170 L 0.0085 · ₱3.6M/d
- 2008: ₱0.003 -70.0% · H 0.0100 L 0.0028 · ₱510.2K/d
- 2009: ₱0.0044 +46.7% · H 0.006 L 0.003 · ₱562.2K/d
- 2010: ₱0.0039 -11.4% · H 0.0046 L 0.0036 · ₱296.1K/d
- 2011: ₱0.0058 +48.7% · H 0.0077 L 0.0035 · ₱3.9M/d
- 2012: ₱0.0055 -5.2% · H 0.0067 L 0.0039 · ₱979.8K/d
- 2013: ₱0.0032 -41.8% · H 0.0058 L 0.0029 · ₱238.4K/d
- 2014: ₱0.0063 +96.9% · H 0.0095 L 0.0031 · ₱11.8M/d
- 2015: ₱0.005 -20.6% · H 0.007 L 0.0046 · ₱5.2M/d
- 2016: ₱0.0032 -36.0% · H 0.0049 L 0.0032 · ₱2.0M/d
- 2017: ₱0.0022 -31.2% · H 0.0036 L 0.0022 · ₱1.3M/d
- 2018: ₱0.002 -9.1% · H 0.0037 L 0.0018 · ₱1.7M/d
- 2019: ₱0.0015 -25.0% · H 0.0023 L 0.0015 · ₱707.7K/d
- 2020: ₱0.0029 +93.3% · H 0.0035 L 0.0007 · ₱10.4M/d
- 2021*: ₱0.0046 +58.6% · H 0.0110 L 0.0029 · ₱259.7M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
