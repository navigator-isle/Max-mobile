---
tags: [trading, pse, stock, enex]
---
**ENEX — ENEX Energy Corp.**
- Status: listed on PSE · sector Mining and Oil › Oil · listed Aug 28, 2014
- Data: 2015-01-05 → 2026-11-06 (2,708 trading days)
- Last close ₱3.10 (2026-11-06) · all-time high ₱40.80 (2021-12-27) · low ₱1.71 (2016-01-26) · now -92.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-08-17 (÷2), 2015-08-18 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱2.28 start · H 12.26 L 2.09 · ₱4.4M/d
- 2016: ₱3.00 +31.6% · H 4.65 L 1.71 · ₱2.1M/d
- 2017: ₱2.02 -32.7% · H 3.08 L 2.00 · ₱160.3K/d
- 2018: ₱3.37 +66.8% · H 4.70 L 2.00 · ₱731.2K/d
- 2019: ₱7.32 +117.2% · H 13.14 L 2.99 · ₱10.7M/d
- 2020: ₱11.50 +57.1% · H 12.30 L 4.70 · ₱2.8M/d
- 2021: ₱39.00 +239.1% · H 40.80 L 12.22 · ₱11.4M/d
- 2022: ₱14.04 -64.0% · H 36.80 L 7.94 · ₱7.8M/d
- 2023: ₱4.90 -65.1% · H 14.52 L 4.20 · ₱482.0K/d
- 2024: ₱5.00 +2.0% · H 6.79 L 4.00 · ₱248.5K/d
- 2025: ₱3.34 -33.2% · H 5.49 L 3.24 · ₱132.8K/d
- 2026*: ₱3.10 -7.2% · H 4.10 L 2.85 · ₱106.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
