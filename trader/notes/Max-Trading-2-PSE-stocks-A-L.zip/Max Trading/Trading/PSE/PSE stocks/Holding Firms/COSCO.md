---
tags: [trading, pse, stock, cosco]
---
**COSCO — Cosco Capital, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Sep 26, 1988
- Data: 2000-01-03 → 2026-11-06 (5,863 trading days)
- Last close ₱7.22 (2026-11-06) · all-time high ₱18.60 (2013-04-22) · low ₱0.3400 (2003-01-21) · now -61.2% from high
- Cash dividends last 12 months ₱0.3980 = 5.5% yield
- Dividend events on record (2013 → 2026): 25

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱0.4000 start · H 1.70 L 0.4000 · ₱1.4M/d
- 2001: ₱0.6500 +62.5% · H 1.00 L 0.4000 · ₱573.3K/d
- 2002: ₱0.5500 -15.4% · H 0.9500 L 0.4800 · ₱346.1K/d
- 2003: ₱0.6000 +9.1% · H 0.9000 L 0.3400 · ₱178.6K/d
- 2004: ₱0.7500 +25.0% · H 0.8000 L 0.4800 · ₱448.8K/d
- 2005: ₱0.7000 -6.7% · H 0.9500 L 0.5500 · ₱560.1K/d
- 2006: ₱1.00 +42.9% · H 1.10 L 0.6500 · ₱816.3K/d
- 2007: ₱1.40 +40.0% · H 2.00 L 1.00 · ₱3.3M/d
- 2008: ₱0.5500 -60.7% · H 1.60 L 0.4800 · ₱435.4K/d
- 2009: ₱0.8000 +45.5% · H 0.9500 L 0.5500 · ₱317.0K/d
- 2010: ₱1.20 +50.0% · H 1.20 L 0.7000 · ₱654.4K/d
- 2011: ₱1.50 +25.0% · H 1.90 L 1.40 · ₱2.1M/d
- 2012: ₱14.50 +866.7% · H 15.40 L 1.40 · ₱61.6M/d
- 2013: ₱8.79 -39.4% · H 18.60 L 8.60 · ₱93.7M/d
- 2014: ₱8.65 -1.6% · H 11.02 L 7.40 · ₱69.1M/d · div ₱0.0600 (0.7%): 08Jul 0.06S
- 2015: ₱8.20 -5.2% · H 9.72 L 6.50 · ₱29.1M/d · div ₱0.0800 (1.0%): 07Jan 0.02S, 07Jan 0.06
- 2016: ₱8.50 +3.7% · H 9.30 L 7.04 · ₱20.3M/d · div ₱0.0800 (0.9%): 05Jan 0.02S, 05Jan 0.06
- 2017: ₱7.70 -9.4% · H 9.34 L 7.40 · ₱19.2M/d · div ₱0.1800 (2.3%): 09Jan 0.02S, 09Jan 0.06, 27Dec 0.04S, 27Dec 0.06
- 2018: ₱6.71 -12.9% · H 7.77 L 5.70 · ₱17.9M/d
- 2019: ₱6.84 +1.9% · H 7.87 L 6.39 · ₱10.5M/d · div ₱0.2200 (3.2%): 12Feb 0.04S, 12Feb 0.06, 20Dec 0.04S, 20Dec 0.08
- 2020: ₱5.65 -17.4% · H 6.80 L 4.29 · ₱11.8M/d
- 2021: ₱5.20 -8.0% · H 5.65 L 4.80 · ₱8.4M/d · div ₱0.1200 (2.3%): 05Jan 0.08, 12Jan 0.04S
- 2022: ₱4.67 -10.2% · H 5.24 L 3.80 · ₱5.3M/d · div ₱0.1200 (2.6%): 05Jan 0.04S, 05Jan 0.08
- 2023: ₱4.62 -1.1% · H 5.42 L 4.00 · ₱6.8M/d · div ₱0.3870 (8.4%): 13Jan 0.05S, 13Jan 0.14, 29Dec 0.197
- 2024: ₱5.38 +16.5% · H 5.62 L 4.52 · ₱4.8M/d · div ₱0.2100 (3.9%): 28May 0.21
- 2025: ₱6.99 +29.9% · H 7.83 L 5.12 · ₱5.1M/d · div ₱0.3960 (5.7%): 08May 0.264, 03Sep 0.132S
- 2026*: ₱7.22 +3.3% · H 8.84 L 6.61 · ₱7.2M/d · div ₱0.3980 (5.5%): 16Apr 0.265, 19Aug 0.133

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
