---
tags: [trading, pse, stock, apo]
---
**APO — Anglo Philippine Holdings Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Jul 31, 1959
- Data: 1986-07-16 → 2026-11-06 (6,927 trading days)
- Last close ₱1.00 (2026-11-06) · all-time high ₱2.80 (2011-07-20) · low ₱0.1100 (2004-08-31) · now -64.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 5
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-12-20 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1986: ₱0.9156 start · H 0.9156 L 0.9156 · ₱137.3K/d
- 1987: ₱1.12 +22.5% · H 1.38 L 1.03 · ₱406.3K/d
- 1988: ₱1.03 -8.4% · H 1.21 L 0.9672 · ₱250.3K/d
- 1989: ₱1.00 -2.7% · H 1.03 L 0.9906 · ₱157.2K/d
- 1990: ₱0.9625 -3.7% · H 1.02 L 0.9063 · ₱101.9K/d
- 1991: ₱0.9625 +0.0% · H 1.00 L 0.9025 · ₱113.7K/d
- 1992: ₱1.04 +7.8% · H 1.07 L 0.9344 · ₱181.9K/d
- 1993: ₱1.07 +3.6% · H 1.19 L 0.9906 · ₱321.4K/d
- 1994: ₱1.10 +2.3% · H 1.15 L 0.9375 · ₱297.6K/d
- 1995: ₱1.10 +0.0% · H 1.55 L 1.00 · ₱2.8M/d
- 1996: ₱1.04 -5.5% · H 1.40 L 0.7800 · ₱3.9M/d
- 1997: ₱0.3400 -67.3% · H 1.44 L 0.2300 · ₱5.9M/d
- 1998: ₱0.4800 +41.2% · H 0.7000 L 0.2200 · ₱605.2K/d
- 1999: ₱0.9000 +87.5% · H 1.12 L 0.4000 · ₱643.4K/d
- 2000: ₱0.4500 -50.0% · H 0.9800 L 0.4400 · ₱215.2K/d
- 2001: ₱0.3800 -15.6% · H 0.6000 L 0.3000 · ₱104.0K/d
- 2002: ₱0.1600 -57.9% · H 0.4700 L 0.1600 · ₱178.9K/d
- 2003: ₱0.1600 +0.0% · H 0.2100 L 0.1200 · ₱37.4K/d
- 2004: ₱0.3100 +93.8% · H 0.3400 L 0.1100 · ₱54.7K/d
- 2005: ₱0.8500 +174.2% · H 0.9200 L 0.2700 · ₱563.6K/d
- 2006: ₱1.12 +31.8% · H 1.26 L 0.8300 · ₱1.7M/d
- 2007: ₱2.24 +100.0% · H 2.75 L 1.04 · ₱10.2M/d
- 2008: ₱0.5800 -74.1% · H 2.40 L 0.5700 · ₱1.5M/d
- 2009: ₱1.20 +106.9% · H 1.42 L 0.5800 · ₱790.1K/d
- 2010: ₱2.11 +75.8% · H 2.40 L 1.06 · ₱1.4M/d
- 2011: ₱1.92 -9.0% · H 2.80 L 1.59 · ₱4.2M/d
- 2012: ₱2.16 +12.5% · H 2.24 L 1.88 · ₱1.2M/d
- 2013: ₱1.93 -10.6% · H 2.41 L 1.66 · ₱1.7M/d · div ₱0.0600 (3.1%): 02Apr 0.03, 05Nov 0.03
- 2014: ₱1.65 -14.5% · H 1.90 L 1.62 · ₱222.5K/d · div ₱0.0150 (0.9%): 07Nov 0.015
- 2015: ₱1.05 -36.4% · H 1.64 L 1.02 · ₱139.5K/d · div ₱0.0200 (1.9%): 10Jun 0.02
- 2016: ₱1.20 +14.3% · H 1.45 L 0.9000 · ₱886.1K/d · div ₱0.0150 (1.2%): 15Nov 0.015
- 2017: ₱1.00 -16.7% · H 1.31 L 0.9200 · ₱222.7K/d
- 2018: ₱0.8800 -12.0% · H 1.10 L 0.7400 · ₱206.8K/d
- 2019: ₱0.6900 -21.6% · H 1.11 L 0.6700 · ₱2.2M/d
- 2020: ₱0.7700 +11.6% · H 0.8300 L 0.4450 · ₱562.1K/d
- 2021: ₱0.9000 +16.9% · H 1.43 L 0.6100 · ₱6.0M/d
- 2022: ₱0.6600 -26.7% · H 1.07 L 0.5800 · ₱340.7K/d
- 2023: ₱0.4500 -31.8% · H 0.7900 L 0.4000 · ₱147.9K/d
- 2024: ₱0.4500 +0.0% · H 0.7300 L 0.3600 · ₱134.9K/d
- 2025: ₱0.7000 +55.6% · H 0.7000 L 0.3600 · ₱280.5K/d
- 2026*: ₱1.00 +42.9% · H 1.80 L 0.7100 · ₱1.8M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
