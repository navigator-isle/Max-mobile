---
tags: [trading, pse, stock, aaa]
---
**AAA — Asia Amalgamated Holdings Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Mar 22, 1973
- Data: 2006-09-01 → 2015-05-15 (891 trading days)
- Last close ₱1.61 (2015-05-15) · all-time high ₱6.71 (2012-03-08) · low ₱0.1500 (2008-10-27) · now -76.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2010-03-17 (÷1.5), 2010-12-22 (÷2), 2011-02-17 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.5000 start · H 0.7300 L 0.2000 · ₱98.4K/d
- 2007: ₱0.4200 -16.0% · H 1.30 L 0.4000 · ₱227.6K/d
- 2008: ₱0.1500 -64.3% · H 0.4600 L 0.1500 · ₱39.3K/d
- 2009: ₱0.4000 +166.7% · H 0.9400 L 0.1500 · ₱98.9K/d
- 2010: ₱0.2700 -32.5% · H 0.6500 L 0.2000 · ₱12.5K/d
- 2011: ₱3.06 +1033.3% · H 3.46 L 0.1800 · ₱2.2M/d
- 2012: ₱4.80 +56.9% · H 6.71 L 3.25 · ₱3.4M/d
- 2013: ₱2.00 -58.3% · H 5.25 L 1.50 · ₱234.9K/d
- 2014: ₱1.50 -25.0% · H 2.26 L 1.42 · ₱95.6K/d
- 2015*: ₱1.61 +7.3% · H 1.95 L 1.22 · ₱184.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
