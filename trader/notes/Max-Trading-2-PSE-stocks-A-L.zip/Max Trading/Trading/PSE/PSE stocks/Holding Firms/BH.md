---
tags: [trading, pse, stock, bh]
---
**BH — BHI Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Nov 02, 1966
- Data: 2007-08-07 → 2026-10-05 (195 trading days)
- Last close ₱687.0 (2026-10-05) · all-time high ₱2,900 (2018-03-14) · low ₱150.0 (2007-08-07) · now -76.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-12-01 (÷2), 2014-09-01 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱150.0 start · H 150.0 L 150.0 · ₱15.0K/d
- 2008: ₱150.0 +0.0% · H 150.0 L 150.0 · ₱9.0K/d
- 2009: ₱230.0 +53.3% · H 230.0 L 225.0 · ₱2.3K/d
- 2010: ₱340.0 +47.8% · H 340.0 L 250.0 · ₱37.8K/d
- 2011: ₱450.0 +32.4% · H 900.0 L 260.0 · ₱259.4K/d
- 2012: ₱430.0 -4.4% · H 630.0 L 400.0 · ₱9.0K/d
- 2013: ₱550.0 +27.9% · H 645.0 L 550.0 · ₱11.7K/d
- 2014: ₱700.0 +27.3% · H 1,390 L 700.0 · ₱34.1K/d
- 2015: ₱669.5 -4.4% · H 669.5 L 303.0 · ₱14.0K/d
- 2016: ₱1,140 +70.3% · H 1,480 L 700.0 · ₱63.1K/d
- 2017: ₱1,486 +30.4% · H 1,490 L 1,001 · ₱26.2K/d
- 2018: ₱1,251 -15.8% · H 2,900 L 1,000 · ₱281.3K/d
- 2019: ₱1,275 +1.9% · H 1,718 L 1,250 · ₱17.0K/d
- 2020: ₱901.0 -29.3% · H 1,250 L 901.0 · ₱121.4K/d
- 2021: ₱945.0 +4.9% · H 1,350 L 945.0 · ₱18.2K/d
- 2022: ₱662.0 -29.9% · H 662.0 L 662.0 · ₱3.4M/d
- 2023: ₱680.0 +2.7% · H 960.0 L 680.0 · ₱10.0K/d
- 2025: ₱680.0 start · H 680.0 L 680.0 · ₱88.4K/d
- 2026*: ₱687.0 +1.0% · H 980.0 L 680.0 · ₱2.7M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
