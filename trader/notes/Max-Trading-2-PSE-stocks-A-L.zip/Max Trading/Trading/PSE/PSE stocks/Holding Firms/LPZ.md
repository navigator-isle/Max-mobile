---
tags: [trading, pse, stock, lpz]
---
**LPZ — Lopez Holdings Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Nov 25, 1993
- Data: 1993-11-25 → 2026-11-06 (7,933 trading days)
- Last close ₱4.40 (2026-11-06) · all-time high ₱13.25 (1993-12-27) · low ₱0.0800 (2002-12-10) · now -66.8% from high
- Cash dividends last 12 months ₱0.1000 = 2.3% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱13.25 start · H 13.25 L 7.21 · ₱56.5M/d
- 1994: ₱8.21 -38.0% · H 12.92 L 6.75 · ₱59.4M/d
- 1995: ₱6.27 -23.6% · H 8.54 L 6.13 · ₱13.0M/d
- 1996: ₱8.13 +29.6% · H 8.27 L 6.27 · ₱12.5M/d
- 1997: ₱6.00 -26.2% · H 9.06 L 5.90 · ₱10.8M/d
- 1998: ₱6.30 +5.0% · H 8.00 L 2.38 · ₱16.8M/d
- 1999: ₱6.10 -3.2% · H 11.00 L 5.00 · ₱56.1M/d
- 2000: ₱2.90 -52.5% · H 8.70 L 2.40 · ₱27.1M/d
- 2001: ₱0.6000 -79.3% · H 3.45 L 0.4500 · ₱14.7M/d
- 2002: ₱0.1100 -81.7% · H 0.9600 L 0.0800 · ₱5.9M/d
- 2003: ₱0.4800 +336.4% · H 0.8500 L 0.1100 · ₱6.7M/d
- 2004: ₱0.6800 +41.7% · H 0.7600 L 0.4800 · ₱8.1M/d
- 2005: ₱1.08 +58.8% · H 1.42 L 0.6700 · ₱23.3M/d
- 2006: ₱2.16 +100.0% · H 2.26 L 0.9200 · ₱13.0M/d
- 2007: ₱4.60 +113.0% · H 5.70 L 2.20 · ₱72.7M/d
- 2008: ₱0.9700 -78.9% · H 4.55 L 0.9600 · ₱20.5M/d
- 2009: ₱3.50 +260.8% · H 4.10 L 1.02 · ₱45.3M/d
- 2010: ₱5.31 +51.7% · H 6.51 L 2.75 · ₱38.0M/d
- 2011: ₱5.10 -4.0% · H 6.92 L 4.00 · ₱27.6M/d
- 2012: ₱6.28 +23.1% · H 6.60 L 4.97 · ₱22.8M/d
- 2013: ₱4.00 -36.3% · H 7.59 L 3.95 · ₱26.7M/d · div ₱0.1250 (3.1%): 10Jun 0.125
- 2014: ₱6.70 +67.5% · H 6.99 L 4.12 · ₱20.9M/d · div ₱0.1000 (1.5%): 06Jun 0.1
- 2015: ₱6.60 -1.5% · H 9.18 L 5.14 · ₱31.9M/d · div ₱0.1000 (1.5%): 09Jun 0.1
- 2016: ₱7.80 +18.2% · H 8.28 L 5.04 · ₱22.5M/d · div ₱0.2000 (2.6%): 09Jun 0.2
- 2017: ₱5.60 -28.2% · H 8.05 L 5.50 · ₱10.3M/d · div ₱0.1000 (1.8%): 29May 0.1
- 2018: ₱4.00 -28.6% · H 5.83 L 3.55 · ₱11.0M/d · div ₱0.1000 (2.5%): 28May 0.1
- 2019: ₱3.71 -7.3% · H 5.74 L 3.70 · ₱9.3M/d · div ₱0.1000 (2.7%): 21Jun 0.1
- 2020: ₱3.72 +0.3% · H 4.00 L 2.26 · ₱6.4M/d · div ₱0.1000 (2.7%): 13Oct 0.1
- 2021: ₱2.91 -21.8% · H 3.80 L 2.90 · ₱2.7M/d
- 2022: ₱2.95 +1.4% · H 3.30 L 2.87 · ₱865.0K/d · div ₱0.0500 (1.7%): 20Jun 0.05
- 2023: ₱4.25 +44.1% · H 4.69 L 2.94 · ₱1.5M/d · div ₱0.1000 (2.4%): 28Sep 0.1
- 2024: ₱2.70 -36.5% · H 4.45 L 2.70 · ₱900.2K/d · div ₱0.1000 (3.7%): 13Jun 0.1
- 2025: ₱3.72 +37.8% · H 4.32 L 2.51 · ₱986.6K/d · div ₱0.1000 (2.7%): 03Jul 0.1
- 2026*: ₱4.40 +18.3% · H 6.48 L 3.56 · ₱4.2M/d · div ₱0.1000 (2.3%): 25Jun 0.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
