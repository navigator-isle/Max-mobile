---
tags: [trading, pse, stock, abg]
---
**ABG — Asiabest Group International Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Jul 10, 1979
- Data: 2011-06-22 → 2026-11-06 (3,085 trading days)
- Last close ₱21.45 (2026-11-06) · all-time high ₱72.75 (2026-09-28) · low ₱2.55 (2023-04-25) · now -70.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2025-08-08 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱27.30 start · H 50.50 L 11.20 · ₱11.2M/d
- 2012: ₱19.40 -28.9% · H 55.85 L 17.50 · ₱8.0M/d
- 2013: ₱10.00 -48.5% · H 23.00 L 9.90 · ₱198.6K/d
- 2014: ₱8.55 -14.5% · H 13.88 L 8.50 · ₱186.5K/d
- 2015: ₱10.28 +20.2% · H 12.90 L 8.05 · ₱286.1K/d
- 2016: ₱19.60 +90.7% · H 26.00 L 9.50 · ₱504.2K/d
- 2017: ₱17.36 -11.4% · H 33.30 L 15.80 · ₱2.3M/d
- 2018: ₱26.00 +49.8% · H 43.35 L 17.00 · ₱8.9M/d
- 2019: ₱10.46 -59.8% · H 31.10 L 10.46 · ₱5.3M/d
- 2020: ₱10.38 -0.8% · H 11.82 L 5.50 · ₱329.4K/d
- 2021: ₱5.90 -43.2% · H 9.96 L 5.22 · ₱201.4K/d
- 2022: ₱3.53 -40.2% · H 5.95 L 3.52 · ₱41.1K/d
- 2023: ₱3.01 -14.7% · H 4.05 L 2.55 · ₱84.1K/d
- 2024: ₱21.00 +597.7% · H 26.50 L 2.68 · ₱2.8M/d
- 2025: ₱18.78 -10.6% · H 39.30 L 18.78 · ₱4.7M/d
- 2026*: ₱21.45 +14.2% · H 72.75 L 14.50 · ₱14.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
