---
tags: [trading, pse, stock, gtcap]
---
**GTCAP — GT Capital Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Apr 20, 2012
- Data: 2012-04-20 → 2026-11-06 (3,541 trading days)
- Last close ₱456.0 (2026-11-06) · all-time high ₱1,620 (2016-08-10) · low ₱368.0 (2020-05-21) · now -71.9% from high
- Cash dividends last 12 months ₱14.16 = 3.1% yield
- Dividend events on record (2013 → 2026): 22

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱620.0 start · H 677.5 L 465.0 · ₱132.4M/d
- 2013: ₱772.0 +24.5% · H 884.5 L 645.0 · ₱184.6M/d · div ₱3.00 (0.4%): 05Sep 3
- 2014: ₱1,032 +33.7% · H 1,135 L 720.0 · ₱153.1M/d · div ₱3.00 (0.3%): 03Apr 3
- 2015: ₱1,320 +27.9% · H 1,446 L 1,081 · ₱324.0M/d · div ₱3.00 (0.2%): 14Apr 3
- 2016: ₱1,270 -3.8% · H 1,620 L 1,120 · ₱235.7M/d · div ₱3.00 (0.2%): 05Apr 3S
- 2017: ₱1,292 +1.7% · H 1,381 L 1,105 · ₱197.8M/d · div ₱5.00 (0.4%): 30Mar 2S, 30Mar 3
- 2018: ₱975.0 -24.5% · H 1,450 L 671.0 · ₱124.6M/d · div ₱3.00 (0.3%): 28Mar 3
- 2019: ₱847.0 -13.1% · H 1,129 L 797.0 · ₱102.0M/d · div ₱3.00 (0.4%): 04Apr 3
- 2020: ₱585.0 -30.9% · H 875.0 L 368.0 · ₱138.0M/d · div ₱3.00 (0.5%): 02Jun 3S
- 2021: ₱540.0 -7.7% · H 629.5 L 501.0 · ₱101.0M/d · div ₱3.00 (0.6%): 31Mar 3
- 2022: ₱435.0 -19.4% · H 596.0 L 380.0 · ₱115.8M/d · div ₱3.00 (0.7%): 05Apr 3
- 2023: ₱590.0 +35.6% · H 599.0 L 438.8 · ₱100.1M/d · div ₱3.00 (0.5%): 29Mar 3
- 2024: ₱658.0 +11.5% · H 740.0 L 554.0 · ₱101.0M/d · div ₱8.00 (1.2%): 26Mar 2S, 26Mar 3, 21Aug 3
- 2025: ₱595.0 -9.6% · H 717.5 L 465.0 · ₱78.8M/d · div ₱8.00 (1.3%): 31Mar 2S, 31Mar 3, 26Aug 3
- 2026*: ₱456.0 -23.4% · H 692.0 L 414.2 · ₱72.6M/d · div ₱14.16 (3.1%): 07Apr 3, 07Apr 4.08, 24Aug 3, 24Aug 4.08

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
