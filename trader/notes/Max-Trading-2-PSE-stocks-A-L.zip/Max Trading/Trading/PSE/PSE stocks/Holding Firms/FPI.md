---
tags: [trading, pse, stock, fpi]
---
**FPI — Forum Pacific, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Dec 19, 1994
- Data: 2006-12-22 → 2026-11-04 (2,134 trading days)
- Last close ₱0.2800 (2026-11-04) · all-time high ₱0.5500 (2014-11-03) · low ₱0.0800 (2009-04-03) · now -49.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-05-18 (÷0.333)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.2600 start · H 0.2600 L 0.1700 · ₱362.1K/d
- 2007: ₱0.2800 +7.7% · H 0.3600 L 0.2700 · ₱226.1K/d
- 2008: ₱0.2600 -7.1% · H 0.2800 L 0.2600 · ₱9.2K/d
- 2009: ₱0.1000 -61.5% · H 0.2700 L 0.0800 · ₱52.6K/d
- 2011: ₱0.2000 start · H 0.3400 L 0.1000 · ₱260.7K/d
- 2012: ₱0.2000 +0.0% · H 0.3450 L 0.2000 · ₱215.5K/d
- 2013: ₱0.2170 +8.5% · H 0.2500 L 0.1720 · ₱53.6K/d
- 2014: ₱0.3150 +45.2% · H 0.5500 L 0.1500 · ₱2.7M/d
- 2015: ₱0.2250 -28.6% · H 0.4200 L 0.1760 · ₱771.5K/d
- 2016: ₱0.1900 -15.6% · H 0.2900 L 0.1730 · ₱132.2K/d
- 2017: ₱0.1820 -4.2% · H 0.2550 L 0.1780 · ₱203.5K/d
- 2018: ₱0.2190 +20.3% · H 0.2650 L 0.1820 · ₱179.3K/d
- 2019: ₱0.2030 -7.3% · H 0.2800 L 0.2010 · ₱170.3K/d
- 2020: ₱0.2250 +10.8% · H 0.2360 L 0.1560 · ₱111.7K/d
- 2021: ₱0.2650 +17.8% · H 0.3400 L 0.2050 · ₱260.5K/d
- 2022: ₱0.2300 -13.2% · H 0.2900 L 0.2030 · ₱62.5K/d
- 2023: ₱0.2000 -13.0% · H 0.2500 L 0.1700 · ₱66.8K/d
- 2024: ₱0.2100 +5.0% · H 0.2950 L 0.2000 · ₱182.6K/d
- 2025: ₱0.2400 +14.3% · H 0.2850 L 0.2100 · ₱89.6K/d
- 2026*: ₱0.2800 +16.7% · H 0.3450 L 0.2400 · ₱187.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
