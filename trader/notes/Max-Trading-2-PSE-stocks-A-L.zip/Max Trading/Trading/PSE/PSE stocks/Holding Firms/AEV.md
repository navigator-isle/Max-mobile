---
tags: [trading, pse, stock, aev]
---
**AEV — Aboitiz Equity Ventures, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Nov 16, 1994
- Data: 1994-11-16 → 2026-11-06 (7,689 trading days)
- Last close ₱38.00 (2026-11-06) · all-time high ₱84.40 (2016-07-20) · low ₱1.00 (1997-12-03) · now -55.0% from high
- Cash dividends last 12 months ₱1.53 = 4.0% yield
- Dividend events on record (2013 → 2026): 17

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱3.65 start · H 4.17 L 3.27 · ₱48.3M/d
- 1995: ₱3.85 +5.3% · H 4.38 L 2.31 · ₱13.6M/d
- 1996: ₱2.65 -31.1% · H 4.38 L 2.60 · ₱12.5M/d
- 1997: ₱1.26 -52.5% · H 3.20 L 1.00 · ₱6.0M/d
- 1998: ₱1.40 +11.1% · H 2.44 L 1.00 · ₱4.5M/d
- 1999: ₱2.20 +57.1% · H 2.55 L 1.36 · ₱9.2M/d
- 2000: ₱1.40 -36.4% · H 2.32 L 1.18 · ₱2.8M/d
- 2001: ₱1.58 +12.9% · H 1.70 L 1.08 · ₱1.4M/d
- 2002: ₱2.26 +43.0% · H 2.55 L 1.40 · ₱3.6M/d
- 2003: ₱3.05 +35.0% · H 3.45 L 2.20 · ₱2.0M/d
- 2004: ₱3.20 +4.9% · H 3.70 L 2.70 · ₱3.6M/d
- 2005: ₱4.80 +50.0% · H 5.30 L 3.20 · ₱8.3M/d
- 2006: ₱7.00 +45.8% · H 7.00 L 4.75 · ₱7.1M/d
- 2007: ₱6.90 -1.4% · H 9.60 L 5.80 · ₱43.9M/d
- 2008: ₱5.60 -18.8% · H 7.70 L 5.00 · ₱14.0M/d
- 2009: ₱9.00 +60.7% · H 9.30 L 5.30 · ₱15.3M/d
- 2010: ₱37.10 +312.2% · H 40.50 L 9.00 · ₱70.2M/d
- 2011: ₱40.15 +8.2% · H 47.00 L 33.30 · ₱135.3M/d
- 2012: ₱52.95 +31.9% · H 54.80 L 40.20 · ₱81.4M/d
- 2013: ₱54.55 +3.0% · H 60.30 L 40.00 · ₱85.5M/d · div ₱2.00 (3.7%): 14Mar 0.56S, 14Mar 1.44
- 2014: ₱52.70 -3.4% · H 61.50 L 48.90 · ₱84.5M/d · div ₱1.80 (3.4%): 20Mar 0.53S, 20Mar 1.27
- 2015: ₱57.95 +10.0% · H 59.00 L 51.95 · ₱91.6M/d · div ₱1.11 (1.9%): 19Mar 1.11
- 2016: ₱70.80 +22.2% · H 84.40 L 54.40 · ₱136.6M/d · div ₱1.06 (1.5%): 17Mar 1.06
- 2017: ₱74.00 +4.5% · H 77.65 L 67.50 · ₱96.9M/d · div ₱1.33 (1.8%): 16Mar 1.33
- 2018: ₱55.00 -25.7% · H 79.00 L 44.10 · ₱98.6M/d · div ₱1.28 (2.3%): 19Mar 1.28
- 2019: ₱51.50 -6.4% · H 67.90 L 46.70 · ₱78.7M/d · div ₱1.32 (2.6%): 18Mar 1.32
- 2020: ₱47.25 -8.3% · H 54.00 L 29.10 · ₱54.3M/d · div ₱1.30 (2.8%): 17Mar 1.3
- 2021: ₱54.45 +15.2% · H 59.05 L 34.00 · ₱66.5M/d · div ₱0.9100 (1.7%): 16Mar 0.91
- 2022: ₱57.70 +6.0% · H 64.05 L 46.90 · ₱81.9M/d · div ₱1.62 (2.8%): 15Mar 1.62
- 2023: ₱44.60 -22.7% · H 60.00 L 44.60 · ₱57.2M/d · div ₱1.47 (3.3%): 14Mar 1.47
- 2024: ₱34.35 -23.0% · H 53.00 L 32.60 · ₱104.3M/d · div ₱1.40 (4.1%): 18Mar 1.4
- 2025: ₱28.00 -18.5% · H 37.25 L 24.20 · ₱40.3M/d · div ₱1.54 (5.5%): 20Mar 1.54
- 2026*: ₱38.00 +35.7% · H 40.80 L 27.70 · ₱59.7M/d · div ₱1.53 (4.0%): 18Mar 0.43, 18Mar 1.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
