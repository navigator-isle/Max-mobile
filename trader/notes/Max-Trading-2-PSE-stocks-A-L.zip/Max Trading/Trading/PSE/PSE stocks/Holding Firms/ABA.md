---
tags: [trading, pse, stock, aba]
---
**ABA — AbaCore Capital Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Oct 28, 1987
- Data: 1993-07-15 → 2026-11-06 (7,278 trading days)
- Last close ₱0.3200 (2026-11-06) · all-time high ₱6.50 (1993-11-08) · low ₱0.0075 (2006-10-16) · now -95.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 4

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱4.50 start · H 6.50 L 1.00 · ₱3.4M/d
- 1994: ₱1.80 -60.0% · H 4.80 L 1.40 · ₱4.4M/d
- 1995: ₱1.80 +0.0% · H 2.70 L 1.60 · ₱4.8M/d
- 1996: ₱1.90 +5.6% · H 2.40 L 1.60 · ₱3.0M/d
- 1997: ₱0.5100 -73.2% · H 3.10 L 0.4900 · ₱8.9M/d
- 1998: ₱0.3100 -39.2% · H 0.6700 L 0.2400 · ₱712.8K/d
- 1999: ₱1.68 +441.9% · H 3.15 L 0.1900 · ₱10.4M/d
- 2000: ₱0.4000 -76.2% · H 1.57 L 0.3750 · ₱1.4M/d
- 2001: ₱0.5583 +39.6% · H 0.7833 L 0.2500 · ₱116.5K/d
- 2002: ₱0.3000 -46.3% · H 0.6250 L 0.2583 · ₱38.9K/d
- 2003: ₱0.2667 -11.1% · H 0.4083 L 0.2583 · ₱45.1K/d
- 2004: ₱0.4000 +50.0% · H 0.5417 L 0.2333 · ₱2.0M/d
- 2005: ₱0.5833 +45.8% · H 1.25 L 0.3833 · ₱780.7K/d
- 2006: ₱0.6667 +14.3% · H 0.8333 L 0.0075 · ₱615.6K/d
- 2007: ₱0.9167 +37.5% · H 1.42 L 0.6667 · ₱3.5M/d
- 2008: ₱0.5250 -42.7% · H 0.9167 L 0.4167 · ₱292.2K/d
- 2009: ₱0.7417 +41.3% · H 0.8333 L 0.3333 · ₱1.7M/d
- 2010: ₱0.9700 +30.8% · H 1.00 L 0.4400 · ₱7.2M/d
- 2011: ₱0.9100 -6.2% · H 1.15 L 0.7900 · ₱2.7M/d
- 2012: ₱0.6700 -26.4% · H 1.00 L 0.6600 · ₱8.4M/d
- 2013: ₱0.5000 -25.4% · H 0.6900 L 0.4600 · ₱991.4K/d
- 2014: ₱0.4800 -4.0% · H 0.5800 L 0.4600 · ₱553.9K/d
- 2015: ₱0.3800 -20.8% · H 0.4900 L 0.3650 · ₱221.9K/d
- 2016: ₱0.4150 +9.2% · H 0.5400 L 0.2800 · ₱2.0M/d
- 2017: ₱0.3100 -25.3% · H 0.4450 L 0.3000 · ₱1.5M/d
- 2018: ₱0.6100 +96.8% · H 0.6400 L 0.2000 · ₱5.9M/d
- 2019: ₱0.8600 +41.0% · H 1.06 L 0.5400 · ₱22.6M/d · div ₱0.2000 (23.3%): 19Feb 0.1, 20Mar 0.1
- 2020: ₱0.6400 -25.6% · H 0.9300 L 0.4500 · ₱7.7M/d · div ₱0.1000 (15.6%): 26Feb 0.1
- 2021: ₱0.9200 +43.8% · H 1.38 L 0.6500 · ₱40.5M/d
- 2022: ₱2.08 +126.1% · H 2.92 L 0.8200 · ₱43.0M/d · div ₱0.0100 (0.5%): 23Jun 0.01
- 2023: ₱0.8500 -59.1% · H 2.71 L 0.7900 · ₱14.4M/d
- 2024: ₱0.5300 -37.6% · H 1.39 L 0.5200 · ₱6.8M/d
- 2025: ₱0.2600 -50.9% · H 0.8000 L 0.2600 · ₱4.8M/d
- 2026*: ₱0.3200 +23.1% · H 0.3900 L 0.2800 · ₱1.8M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
