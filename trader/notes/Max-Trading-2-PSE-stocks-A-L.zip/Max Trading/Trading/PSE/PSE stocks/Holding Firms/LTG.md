---
tags: [trading, pse, stock, ltg]
---
**LTG — LT Group, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Nov 07, 1947
- Data: 2004-09-09 → 2026-11-06 (4,156 trading days)
- Last close ₱15.42 (2026-11-06) · all-time high ₱27.00 (2013-05-06) · low ₱1.60 (2008-12-03) · now -42.9% from high
- Cash dividends last 12 months ₱1.10 = 7.1% yield
- Dividend events on record (2013 → 2026): 37
- Splits / stock dividends detected (prices before these dates are as traded then): 2008-10-27 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2004: ₱3.75 start · H 3.75 L 2.20 · ₱139.3K/d
- 2005: ₱3.25 -13.3% · H 4.45 L 2.70 · ₱154.0K/d
- 2006: ₱3.80 +16.9% · H 4.00 L 2.00 · ₱75.0K/d
- 2007: ₱5.80 +52.6% · H 6.50 L 3.10 · ₱302.1K/d
- 2008: ₱2.02 -65.2% · H 5.60 L 1.60 · ₱74.2K/d
- 2009: ₱2.70 +33.7% · H 3.50 L 1.64 · ₱75.9K/d
- 2010: ₱3.00 +11.1% · H 3.35 L 2.30 · ₱188.6K/d
- 2011: ₱4.40 +46.7% · H 5.40 L 2.80 · ₱878.1K/d
- 2012: ₱13.38 +204.1% · H 13.38 L 3.70 · ₱23.9M/d
- 2013: ₱15.44 +15.4% · H 27.00 L 12.88 · ₱179.2M/d · div ₱0.1500 (1.0%): 28Jun 0.15
- 2014: ₱12.14 -21.4% · H 19.52 L 12.10 · ₱100.6M/d · div ₱0.1600 (1.3%): 22Apr 0.01S, 22Apr 0.15
- 2015: ₱14.78 +21.7% · H 16.84 L 9.89 · ₱88.2M/d · div ₱0.1500 (1.0%): 22May 0.15
- 2016: ₱12.56 -15.0% · H 17.70 L 12.56 · ₱70.9M/d · div ₱0.1500 (1.2%): 25Apr 0.15
- 2017: ₱18.74 +49.2% · H 19.48 L 12.06 · ₱54.9M/d · div ₱0.1800 (1.0%): 24Mar 0.03S, 24Mar 0.15
- 2018: ₱16.60 -11.4% · H 24.50 L 12.86 · ₱68.1M/d · div ₱0.2000 (1.2%): 23Mar 0.05S, 23Mar 0.15
- 2019: ₱11.98 -27.8% · H 17.30 L 11.00 · ₱41.3M/d · div ₱0.1500 (1.3%): 24Apr 0.15S
- 2020: ₱13.10 +9.3% · H 14.02 L 5.50 · ₱30.6M/d · div ₱0.8100 (6.2%): 03Jun 0.15, 03Jun 0.28S, 27Aug 0.23, 03Dec 0.15S
- 2021: ₱9.90 -24.4% · H 15.00 L 8.51 · ₱67.0M/d · div ₱1.08 (10.9%): 26Mar 0.09S, 26Mar 0.15, 22Jun 0.24S, 01Dec 0.6S
- 2022: ₱9.20 -7.1% · H 10.16 L 7.70 · ₱27.0M/d · div ₱1.25 (13.6%): 25Mar 0.15S, 26May 0.3S, 30Aug 0.3S, 01Dec 0.5
- 2023: ₱8.98 -2.4% · H 10.52 L 8.50 · ₱23.9M/d · div ₱1.05 (11.7%): 01Mar 0.15S, 25May 0.3, 01Sep 0.3S, 04Dec 0.3S
- 2024: ₱10.50 +16.9% · H 10.50 L 8.90 · ₱26.4M/d · div ₱1.10 (10.5%): 08Mar 0.15S, 31May 0.3S, 03Sep 0.3S, 29Nov 0.35S
- 2025: ₱14.78 +40.8% · H 15.50 L 10.40 · ₱32.6M/d · div ₱1.10 (7.4%): 28Mar 0.15S, 30Jun 0.3, 08Sep 0.3S, 01Dec 0.35
- 2026*: ₱15.42 +4.3% · H 16.06 L 13.92 · ₱28.9M/d · div ₱0.7500 (4.9%): 05Mar 0.15, 04Jun 0.3, 07Sep 0.3

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
