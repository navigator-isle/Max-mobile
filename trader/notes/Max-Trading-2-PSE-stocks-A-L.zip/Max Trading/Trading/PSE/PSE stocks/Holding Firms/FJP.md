---
tags: [trading, pse, stock, fjp]
---
**FJP — F &amp; J Prince Holdings Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Dec 08, 1982
- Data: 2006-04-03 → 2026-11-04 (1,620 trading days)
- Last close ₱2.50 (2026-11-04) · all-time high ₱7.10 (2016-08-02) · low ₱0.7000 (2006-10-18) · now -64.8% from high
- Cash dividends last 12 months ₱0.2100 = 8.4% yield
- Dividend events on record (2013 → 2026): 25
- Splits / stock dividends detected (prices before these dates are as traded then): 2008-12-16 (÷1.5), 2010-08-11 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.00 start · H 1.00 L 0.7000 · ₱70.4K/d
- 2007: ₱1.46 +46.0% · H 2.02 L 0.9000 · ₱251.4K/d
- 2008: ₱1.22 -16.4% · H 1.60 L 1.02 · ₱13.7K/d
- 2009: ₱1.08 -11.5% · H 1.80 L 0.7600 · ₱92.4K/d
- 2010: ₱1.25 +15.7% · H 1.72 L 0.9300 · ₱137.0K/d
- 2011: ₱1.96 +56.8% · H 1.96 L 1.00 · ₱115.3K/d
- 2012: ₱2.99 +52.6% · H 3.56 L 1.96 · ₱424.6K/d
- 2013: ₱3.20 +7.0% · H 3.90 L 2.85 · ₱152.7K/d · div ₱0.2000 (6.2%): 10Jun 0.1, 06Aug 0.1
- 2014: ₱3.30 +3.1% · H 3.32 L 2.60 · ₱126.7K/d · div ₱0.2000 (6.1%): 17Jun 0.1, 16Jul 0.1
- 2015: ₱5.81 +76.1% · H 6.60 L 2.76 · ₱554.9K/d · div ₱0.2000 (3.4%): 29May 0.1, 29Jul 0.1
- 2016: ₱5.75 -1.0% · H 7.10 L 4.50 · ₱410.0K/d · div ₱0.2000 (3.5%): 17Aug 0.1, 16Sep 0.1
- 2017: ₱4.42 -23.1% · H 6.52 L 4.01 · ₱176.2K/d · div ₱0.2000 (4.5%): 16Aug 0.1, 18Sep 0.1
- 2018: ₱5.30 +19.9% · H 6.00 L 4.00 · ₱139.0K/d · div ₱0.2000 (3.8%): 10Aug 0.1, 11Sep 0.1
- 2019: ₱3.99 -24.7% · H 5.28 L 3.01 · ₱80.3K/d · div ₱0.2000 (5.0%): 18Sep 0.1, 18Oct 0.1
- 2020: ₱2.99 -25.1% · H 4.06 L 2.77 · ₱43.1K/d · div ₱0.1000 (3.3%): 28Aug 0.1
- 2021: ₱2.60 -13.0% · H 3.44 L 2.38 · ₱76.9K/d · div ₱0.1000 (3.8%): 28Sep 0.1
- 2022: ₱2.10 -19.2% · H 2.70 L 1.98 · ₱118.0K/d · div ₱0.1500 (7.1%): 07Jul 0.05, 16Aug 0.1
- 2023: ₱1.57 -25.2% · H 2.85 L 1.52 · ₱38.5K/d · div ₱0.1700 (10.8%): 05Jul 0.1, 08Sep 0.07
- 2024: ₱2.50 +59.2% · H 2.62 L 1.61 · ₱82.4K/d · div ₱0.1500 (6.0%): 22Aug 0.1, 04Oct 0.05
- 2025: ₱2.60 +4.0% · H 2.90 L 2.00 · ₱22.7K/d · div ₱0.2000 (7.7%): 19Sep 0.2S
- 2026*: ₱2.50 -3.8% · H 2.97 L 2.21 · ₱25.3K/d · div ₱0.2100 (8.4%): 08Apr 0.1, 25Aug 0.11

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
