---
tags: [trading, pse, stock, hi]
---
**HI — House of Investments, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Jul 02, 1962
- Data: 1993-01-22 → 2026-11-06 (5,332 trading days)
- Last close ₱4.88 (2026-11-06) · all-time high ₱9.10 (2013-05-17) · low ₱0.3000 (2004-02-20) · now -46.4% from high
- Cash dividends last 12 months ₱0.2500 = 5.1% yield
- Dividend events on record (2013 → 2026): 11

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱6.88 start · H 6.88 L 3.29 · ₱158.7K/d
- 1994: ₱3.20 -53.5% · H 7.38 L 3.15 · ₱245.7K/d
- 1995: ₱2.80 -12.5% · H 3.50 L 2.10 · ₱508.4K/d
- 1996: ₱3.50 +25.0% · H 4.70 L 2.70 · ₱2.1M/d
- 1997: ₱0.9600 -72.6% · H 4.10 L 0.9600 · ₱1.0M/d
- 1998: ₱1.08 +12.5% · H 1.40 L 0.3700 · ₱557.5K/d
- 1999: ₱1.20 +11.1% · H 2.50 L 1.06 · ₱1.1M/d
- 2000: ₱0.6800 -43.3% · H 1.40 L 0.5500 · ₱569.2K/d
- 2001: ₱0.3200 -52.9% · H 1.00 L 0.3200 · ₱144.0K/d
- 2002: ₱0.4800 +50.0% · H 0.6000 L 0.3200 · ₱116.8K/d
- 2003: ₱0.5000 +4.2% · H 0.5200 L 0.4800 · ₱368.4K/d
- 2004: ₱0.7000 +40.0% · H 0.7500 L 0.3000 · ₱104.0K/d
- 2005: ₱0.9200 +31.4% · H 2.08 L 0.7200 · ₱1.8M/d
- 2006: ₱1.90 +106.5% · H 1.98 L 0.9200 · ₱1.0M/d
- 2007: ₱2.00 +5.3% · H 3.50 L 1.76 · ₱1.3M/d
- 2008: ₱0.9400 -53.0% · H 2.18 L 0.9400 · ₱229.6K/d
- 2009: ₱2.16 +129.8% · H 2.36 L 0.9500 · ₱144.3K/d
- 2010: ₱3.35 +55.1% · H 3.38 L 2.10 · ₱429.6K/d
- 2011: ₱3.08 -8.1% · H 3.65 L 2.93 · ₱1.2M/d
- 2012: ₱6.29 +104.2% · H 6.68 L 3.07 · ₱1.3M/d
- 2013: ₱6.18 -1.7% · H 9.10 L 5.70 · ₱2.8M/d · div ₱0.0600 (1.0%): 13Aug 0.06
- 2014: ₱6.15 -0.5% · H 6.73 L 5.46 · ₱1.2M/d · div ₱0.0650 (1.1%): 11Aug 0.065
- 2015: ₱5.51 -10.4% · H 6.88 L 5.42 · ₱1.2M/d · div ₱0.0650 (1.2%): 11Aug 0.065
- 2016: ₱5.55 +0.7% · H 6.85 L 5.18 · ₱530.2K/d · div ₱0.0650 (1.2%): 09Aug 0.065
- 2017: ₱7.36 +32.6% · H 8.40 L 5.77 · ₱534.9K/d · div ₱0.0650 (0.9%): 15Aug 0.065
- 2018: ₱5.83 -20.8% · H 7.82 L 5.70 · ₱285.4K/d · div ₱0.0650 (1.1%): 13Aug 0.065
- 2019: ₱5.20 -10.8% · H 7.00 L 5.20 · ₱1.2M/d · div ₱0.0650 (1.2%): 12Aug 0.065
- 2020: ₱4.02 -22.7% · H 5.47 L 2.77 · ₱412.8K/d
- 2021: ₱3.55 -11.7% · H 4.42 L 3.30 · ₱538.5K/d
- 2022: ₱3.58 +0.8% · H 3.89 L 3.28 · ₱276.5K/d
- 2023: ₱3.27 -8.7% · H 5.02 L 3.15 · ₱359.1K/d · div ₱0.0500 (1.5%): 01Aug 0.05
- 2024: ₱3.38 +3.4% · H 4.09 L 3.22 · ₱255.7K/d · div ₱0.0500 (1.5%): 22Aug 0.05
- 2025: ₱4.60 +36.1% · H 4.60 L 3.24 · ₱437.7K/d · div ₱0.1800 (3.9%): 26Aug 0.18
- 2026*: ₱4.88 +6.1% · H 5.35 L 4.41 · ₱653.6K/d · div ₱0.2500 (5.1%): 28Aug 0.25

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
