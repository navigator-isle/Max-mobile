---
tags: [trading, pse, stock, fdc]
---
**FDC — Filinvest Development Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Dec 22, 1982
- Data: 1995-10-12 → 2026-11-06 (6,575 trading days)
- Last close ₱4.00 (2026-11-06) · all-time high ₱16.16 (2019-03-21) · low ₱0.4382 (2000-10-31) · now -75.2% from high
- Cash dividends last 12 months ₱0.1403 = 3.5% yield
- Dividend events on record (2013 → 2026): 14

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱7.10 start · H 10.96 L 6.19 · ₱20.1M/d
- 1996: ₱6.33 -10.9% · H 11.36 L 6.25 · ₱15.6M/d
- 1997: ₱2.76 -56.4% · H 6.98 L 2.76 · ₱6.4M/d
- 1998: ₱1.04 -62.4% · H 3.41 L 1.01 · ₱2.1M/d
- 1999: ₱2.11 +103.1% · H 3.33 L 1.12 · ₱5.5M/d
- 2000: ₱0.5356 -74.6% · H 2.23 L 0.4382 · ₱1.2M/d
- 2001: ₱0.6492 +21.2% · H 1.25 L 0.4950 · ₱1.2M/d
- 2002: ₱0.9089 +40.0% · H 1.23 L 0.6816 · ₱759.4K/d
- 2003: ₱0.9738 +7.1% · H 1.07 L 0.7953 · ₱277.4K/d
- 2004: ₱0.8277 -15.0% · H 0.9251 L 0.7303 · ₱329.9K/d
- 2005: ₱0.9738 +17.7% · H 1.41 L 0.8115 · ₱915.6K/d
- 2006: ₱3.65 +274.8% · H 3.65 L 0.9576 · ₱3.8M/d
- 2007: ₱4.90 +34.2% · H 7.90 L 3.75 · ₱8.1M/d
- 2008: ₱0.7700 -84.3% · H 5.30 L 0.7000 · ₱788.7K/d
- 2009: ₱2.08 +170.1% · H 2.32 L 0.7900 · ₱1.0M/d
- 2010: ₱5.05 +142.8% · H 5.47 L 1.78 · ₱3.1M/d
- 2011: ₱3.35 -33.7% · H 6.10 L 3.31 · ₱3.7M/d
- 2012: ₱4.94 +47.5% · H 5.06 L 3.30 · ₱3.4M/d
- 2013: ₱4.40 -10.9% · H 6.90 L 4.00 · ₱3.3M/d · div ₱0.0536 (1.2%): 24Jun 0.0536
- 2014: ₱4.32 -1.8% · H 5.32 L 4.25 · ₱711.3K/d · div ₱0.0549 (1.3%): 23Jun 0.0549
- 2015: ₱4.40 +1.9% · H 4.85 L 3.60 · ₱437.9K/d · div ₱0.0500 (1.1%): 05Jun 0.05
- 2016: ₱8.24 +87.3% · H 8.28 L 4.20 · ₱2.7M/d · div ₱0.0516 (0.6%): 24May 0.0516
- 2017: ₱7.75 -5.9% · H 8.18 L 7.47 · ₱547.1K/d · div ₱0.0590 (0.8%): 24May 0.059
- 2018: ₱11.80 +52.3% · H 12.92 L 6.92 · ₱5.5M/d · div ₱0.0765 (0.6%): 30May 0.0765
- 2019: ₱13.00 +10.2% · H 16.16 L 12.26 · ₱10.1M/d · div ₱0.1000 (0.8%): 22May 0.1
- 2020: ₱9.44 -27.4% · H 13.46 L 6.70 · ₱1.9M/d · div ₱0.1384 (1.5%): 17Jul 0.1384
- 2021: ₱7.97 -15.6% · H 9.47 L 7.41 · ₱358.8K/d · div ₱0.0980 (1.2%): 18May 0.098
- 2022: ₱6.42 -19.4% · H 7.90 L 6.40 · ₱292.0K/d · div ₱0.0701 (1.1%): 17May 0.07014
- 2023: ₱5.35 -16.7% · H 6.62 L 4.86 · ₱325.1K/d · div ₱0.0653 (1.2%): 17May 0.06534
- 2024: ₱4.94 -7.7% · H 6.00 L 4.90 · ₱236.5K/d · div ₱0.1035 (2.1%): 17May 0.10346
- 2025: ₱4.55 -7.9% · H 5.00 L 4.03 · ₱232.9K/d · div ₱0.1403 (3.1%): 16May 0.14027
- 2026*: ₱4.00 -12.1% · H 4.95 L 3.30 · ₱538.9K/d · div ₱0.1403 (3.5%): 11May 0.14027

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
