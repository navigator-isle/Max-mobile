---
tags: [trading, pse, stock, dmc]
---
**DMC — DMCI Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Dec 18, 1995
- Data: 1995-12-18 → 2026-11-06 (7,312 trading days)
- Last close ₱6.65 (2026-11-06) · all-time high ₱16.63 (2014-09-03) · low ₱0.0180 (2001-11-07) · now -60.0% from high
- Cash dividends last 12 months ₱0.3000 = 4.5% yield
- Dividend events on record (2013 → 2026): 30

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱0.9400 start · H 0.9400 L 0.9100 · ₱9.0M/d
- 1996: ₱1.73 +83.5% · H 2.02 L 0.9200 · ₱4.5M/d
- 1997: ₱0.2400 -86.1% · H 2.08 L 0.2400 · ₱3.0M/d
- 1998: ₱0.3280 +36.7% · H 0.6500 L 0.1020 · ₱3.7M/d
- 1999: ₱0.2160 -34.1% · H 0.5700 L 0.2000 · ₱2.6M/d
- 2000: ₱0.0540 -75.0% · H 0.2440 L 0.0500 · ₱198.4K/d
- 2001: ₱0.0360 -33.3% · H 0.1280 L 0.0180 · ₱111.0K/d
- 2002: ₱0.0280 -22.2% · H 0.0780 L 0.0200 · ₱88.0K/d
- 2003: ₱0.0500 +78.6% · H 0.0680 L 0.0260 · ₱115.7K/d
- 2004: ₱0.7600 +1420.0% · H 0.8100 L 0.0420 · ₱2.4M/d
- 2005: ₱0.6300 -17.1% · H 1.16 L 0.4400 · ₱2.4M/d
- 2006: ₱1.22 +93.7% · H 1.26 L 0.5700 · ₱1.8M/d
- 2007: ₱1.92 +57.4% · H 2.40 L 1.18 · ₱5.1M/d
- 2008: ₱0.5300 -72.4% · H 1.96 L 0.3760 · ₱1.8M/d
- 2009: ₱1.94 +266.0% · H 2.05 L 0.5200 · ₱2.4M/d
- 2010: ₱7.20 +271.1% · H 7.99 L 1.74 · ₱21.7M/d
- 2011: ₱8.26 +14.7% · H 9.63 L 6.12 · ₱26.0M/d
- 2012: ₱10.79 +30.6% · H 12.68 L 8.48 · ₱31.5M/d
- 2013: ₱11.20 +3.8% · H 12.18 L 9.02 · ₱19.0M/d · div ₱3.40 (30.4%): 23Apr 1S, 23Apr 1.2, 26Nov 1.2S
- 2014: ₱15.70 +40.2% · H 16.63 L 11.20 · ₱48.1M/d · div ₱1.20 (7.6%): 27May 1.2S
- 2015: ₱13.80 -12.1% · H 16.00 L 10.70 · ₱110.2M/d · div ₱0.2400 (1.7%): 26May 0.24S
- 2016: ₱13.26 -3.9% · H 13.80 L 10.78 · ₱85.4M/d · div ₱0.2400 (1.8%): 24May 0.24S
- 2017: ₱14.40 +8.6% · H 16.60 L 11.40 · ₱130.5M/d · div ₱0.2400 (1.7%): 18Apr 0.24S
- 2018: ₱12.78 -11.3% · H 14.98 L 9.87 · ₱62.6M/d · div ₱0.9600 (7.5%): 20Mar 0.2S, 20Mar 0.28, 29Nov 0.48S
- 2019: ₱6.61 -48.3% · H 13.00 L 5.05 · ₱85.2M/d · div ₱0.4800 (7.3%): 24Apr 0.2S, 24Apr 0.28
- 2020: ₱5.66 -14.4% · H 7.07 L 3.29 · ₱52.9M/d · div ₱0.4800 (8.5%): 18Mar 0.23, 18Mar 0.25S
- 2021: ₱7.71 +36.2% · H 9.32 L 5.00 · ₱72.7M/d · div ₱0.9600 (12.5%): 12Apr 0.13, 12Apr 0.35S, 21Oct 0.48S
- 2022: ₱12.00 +55.6% · H 12.00 L 7.89 · ₱70.4M/d · div ₱1.20 (10.0%): 12Apr 0.14S, 12Apr 0.34, 27Oct 0.72
- 2023: ₱9.77 -18.6% · H 13.00 L 9.05 · ₱52.0M/d · div ₱1.44 (14.7%): 12Apr 0.11S, 12Apr 0.61, 23Oct 0.72S
- 2024: ₱10.82 +10.7% · H 12.60 L 9.85 · ₱37.0M/d · div ₱1.20 (11.1%): 19Apr 0.26S, 19Apr 0.46, 29Oct 0.48S
- 2025: ₱10.54 -2.6% · H 11.82 L 9.90 · ₱35.3M/d · div ₱1.08 (10.2%): 08Apr 0.25S, 08Apr 0.35, 04Nov 0.48
- 2026*: ₱6.65 -36.9% · H 11.04 L 6.34 · ₱38.9M/d · div ₱0.3000 (4.5%): 20May 0.3

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
