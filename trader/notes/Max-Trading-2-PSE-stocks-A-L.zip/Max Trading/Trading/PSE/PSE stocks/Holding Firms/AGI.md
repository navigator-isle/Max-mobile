---
tags: [trading, pse, stock, agi]
---
**AGI — Alliance Global Group, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Apr 19, 1999
- Data: 1999-04-19 → 2026-11-06 (5,477 trading days)
- Last close ₱8.89 (2026-11-06) · all-time high ₱31.15 (2014-04-30) · low ₱1.26 (2009-03-18) · now -71.5% from high
- Cash dividends last 12 months ₱0.1000 = 1.1% yield
- Dividend events on record (2013 → 2026): 11
- Splits / stock dividends detected (prices before these dates are as traded then): 2007-02-12 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1999: ₱7.25 start · H 7.25 L 1.38 · ₱16.1M/d
- 2000: ₱7.38 +1.7% · H 8.00 L 5.70 · ₱6.3M/d
- 2001: ₱6.62 -10.2% · H 7.25 L 6.00 · ₱1.6M/d
- 2002: ₱6.25 -5.7% · H 7.00 L 6.25 · ₱8.6K/d
- 2003: ₱6.62 +6.0% · H 6.62 L 6.25 · ₱8.2K/d
- 2004: ₱6.75 +1.9% · H 6.75 L 6.00 · ₱31.5K/d
- 2005: ₱6.25 -7.4% · H 6.75 L 5.70 · ₱1.4M/d
- 2006: ₱8.50 +36.0% · H 11.50 L 5.75 · ₱59.8K/d
- 2007: ₱5.60 -34.1% · H 9.90 L 3.90 · ₱96.1M/d
- 2008: ₱1.74 -68.9% · H 5.60 L 1.48 · ₱47.1M/d
- 2009: ₱4.15 +138.5% · H 5.10 L 1.26 · ₱56.8M/d
- 2010: ₱12.50 +201.2% · H 12.96 L 4.10 · ₱166.9M/d
- 2011: ₱10.34 -17.3% · H 12.40 L 8.42 · ₱219.1M/d
- 2012: ₱16.76 +62.1% · H 16.76 L 10.28 · ₱248.2M/d
- 2013: ₱25.80 +53.9% · H 28.20 L 16.80 · ₱403.9M/d · div ₱0.3800 (1.5%): 04Sep 0.38
- 2014: ₱22.55 -12.6% · H 31.15 L 21.95 · ₱312.3M/d · div ₱0.3800 (1.7%): 03Sep 0.38S
- 2015: ₱16.10 -28.6% · H 27.30 L 15.30 · ₱196.6M/d · div ₱0.3100 (1.9%): 26Aug 0.31
- 2016: ₱12.78 -20.6% · H 17.22 L 12.30 · ₱86.6M/d · div ₱0.3100 (2.4%): 31Aug 0.31
- 2017: ₱16.00 +25.2% · H 17.18 L 12.32 · ₱130.3M/d
- 2018: ₱11.90 -25.6% · H 16.46 L 10.28 · ₱100.3M/d · div ₱0.1000 (0.8%): 06Dec 0.1
- 2019: ₱11.66 -2.0% · H 16.40 L 10.46 · ₱145.6M/d
- 2020: ₱10.60 -9.1% · H 11.30 L 5.53 · ₱90.3M/d · div ₱0.0500 (0.5%): 10Dec 0.05
- 2021: ₱11.80 +11.3% · H 12.32 L 9.00 · ₱56.6M/d · div ₱0.0700 (0.6%): 14Dec 0.07
- 2022: ₱11.90 +0.8% · H 13.30 L 7.70 · ₱47.6M/d · div ₱0.1200 (1.0%): 25Nov 0.12
- 2023: ₱11.28 -5.2% · H 14.00 L 9.61 · ₱24.3M/d · div ₱0.1500 (1.3%): 15Dec 0.15
- 2024: ₱9.00 -20.2% · H 11.74 L 8.41 · ₱23.6M/d · div ₱0.1000 (1.1%): 26Dec 0.1
- 2025: ₱8.19 -9.0% · H 9.61 L 5.93 · ₱25.8M/d · div ₱0.1000 (1.2%): 19Dec 0.1
- 2026*: ₱8.89 +8.5% · H 10.00 L 7.18 · ₱24.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
