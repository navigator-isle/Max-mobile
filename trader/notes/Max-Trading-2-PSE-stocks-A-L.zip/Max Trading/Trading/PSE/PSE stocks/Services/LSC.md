---
tags: [trading, pse, stock, lsc]
---
**LSC — Lorenzo Shipping Corporation**
- Status: listed on PSE · sector Services › Transportation Services · listed Jul 22, 1996
- Data: 1996-07-22 → 2026-11-06 (3,294 trading days)
- Last close ₱0.6500 (2026-11-06) · all-time high ₱5.90 (1996-07-22) · low ₱0.1400 (2003-07-31) · now -89.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱4.60 start · H 5.90 L 4.20 · ₱5.0M/d
- 1997: ₱1.20 -73.9% · H 4.60 L 1.00 · ₱844.8K/d
- 1998: ₱0.6000 -50.0% · H 1.46 L 0.3200 · ₱67.1K/d
- 1999: ₱0.4200 -30.0% · H 0.7000 L 0.2900 · ₱55.2K/d
- 2000: ₱0.3000 -28.6% · H 0.4800 L 0.2000 · ₱127.4K/d
- 2001: ₱0.2700 -10.0% · H 0.4000 L 0.2000 · ₱278.1K/d
- 2002: ₱0.2000 -25.9% · H 0.4800 L 0.2000 · ₱61.6K/d
- 2003: ₱0.3200 +60.0% · H 0.3300 L 0.1400 · ₱11.5K/d
- 2004: ₱1.18 +268.7% · H 1.38 L 0.1500 · ₱456.9K/d
- 2005: ₱1.36 +15.3% · H 1.36 L 0.9600 · ₱896.1K/d
- 2006: ₱1.26 -7.4% · H 1.74 L 1.00 · ₱264.3K/d
- 2007: ₱1.68 +33.3% · H 2.14 L 1.14 · ₱1.4M/d
- 2008: ₱1.06 -36.9% · H 1.68 L 1.00 · ₱34.3K/d
- 2009: ₱1.00 -5.7% · H 1.20 L 1.00 · ₱30.7K/d
- 2010: ₱1.02 +2.0% · H 1.15 L 1.00 · ₱32.9K/d
- 2011: ₱1.03 +1.0% · H 1.90 L 0.9000 · ₱376.3K/d
- 2012: ₱1.45 +40.8% · H 2.40 L 1.03 · ₱255.5K/d
- 2013: ₱1.32 -9.0% · H 2.20 L 1.10 · ₱406.9K/d · div ₱0.0250 (1.9%): 09Jul 0.025
- 2014: ₱1.21 -8.3% · H 2.08 L 1.20 · ₱841.0K/d
- 2015: ₱1.08 -10.7% · H 1.69 L 0.7700 · ₱107.0K/d · div ₱0.0200 (1.9%): 20May 0.02
- 2016: ₱1.03 -4.6% · H 1.34 L 0.8700 · ₱66.5K/d
- 2017: ₱1.21 +17.5% · H 2.50 L 0.9000 · ₱4.4M/d
- 2018: ₱0.8000 -33.9% · H 1.19 L 0.6500 · ₱767.3K/d
- 2019: ₱0.8500 +6.2% · H 1.04 L 0.7400 · ₱1.2M/d
- 2020: ₱1.01 +18.8% · H 1.05 L 0.6100 · ₱125.8K/d
- 2021: ₱0.9000 -10.9% · H 1.23 L 0.9000 · ₱289.8K/d
- 2022: ₱0.5800 -35.6% · H 0.9200 L 0.3900 · ₱43.2K/d
- 2023: ₱0.5500 -5.2% · H 0.8700 L 0.4900 · ₱29.7K/d
- 2024: ₱0.9600 +74.5% · H 1.05 L 0.4550 · ₱70.6K/d
- 2025: ₱0.6100 -36.5% · H 0.9600 L 0.4800 · ₱20.0K/d
- 2026*: ₱0.6500 +6.6% · H 0.7200 L 0.5100 · ₱26.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
