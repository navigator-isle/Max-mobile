---
tags: [trading, pse, stock, ace]
---
**ACE — Acesite (Phils.) Hotel Corporation**
- Status: listed on PSE · sector Services › Hotel &amp; Leisure · listed Dec 05, 1986
- Data: 2011-08-17 → 2026-11-03 (2,477 trading days)
- Last close ₱1.29 (2026-11-03) · all-time high ₱5.69 (2012-06-20) · low ₱0.5029 (2011-10-04) · now -77.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱0.8343 start · H 1.19 L 0.5029 · ₱372.3K/d
- 2012: ₱1.20 +43.8% · H 5.69 L 0.8743 · ₱2.3M/d
- 2013: ₱1.04 -13.3% · H 1.43 L 0.9900 · ₱133.2K/d
- 2014: ₱1.10 +5.8% · H 1.35 L 1.01 · ₱92.7K/d
- 2015: ₱1.26 +14.5% · H 1.26 L 1.02 · ₱140.9K/d
- 2016: ₱1.36 +7.9% · H 1.59 L 1.12 · ₱170.1K/d
- 2017: ₱1.39 +2.2% · H 2.29 L 1.34 · ₱953.0K/d
- 2018: ₱1.40 +0.7% · H 1.75 L 1.23 · ₱494.5K/d
- 2019: ₱1.40 +0.0% · H 1.86 L 1.23 · ₱165.7K/d
- 2020: ₱1.48 +5.7% · H 1.58 L 1.03 · ₱116.7K/d
- 2021: ₱1.66 +12.2% · H 2.95 L 1.40 · ₱576.3K/d
- 2022: ₱1.32 -20.5% · H 1.75 L 1.32 · ₱44.4K/d
- 2023: ₱1.73 +31.1% · H 1.90 L 1.32 · ₱136.2K/d
- 2024: ₱1.78 +2.9% · H 1.99 L 1.58 · ₱110.6K/d
- 2025: ₱1.20 -32.6% · H 1.78 L 1.20 · ₱80.2K/d
- 2026*: ₱1.29 +7.5% · H 1.54 L 1.20 · ₱67.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
