---
tags: [trading, pse, stock, gph]
---
**GPH — Grand Plaza Hotel Corporation**
- Status: listed on PSE · sector Services › Hotel &amp; Leisure · listed Dec 10, 1992
- Data: 2006-10-19 → 2026-11-06 (774 trading days)
- Last close ₱5.03 (2026-11-06) · all-time high ₱51.95 (2014-07-17) · low ₱4.52 (2025-03-11) · now -90.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱18.75 start · H 34.00 L 18.75 · ₱37.8K/d
- 2007: ₱27.50 +46.7% · H 27.50 L 27.50 · ₱7.5M/d
- 2008: ₱37.50 +36.4% · H 41.00 L 25.00 · ₱6.7K/d
- 2009: ₱37.50 +0.0% · H 37.50 L 37.50 · ₱189.4K/d
- 2011: ₱33.00 start · H 33.00 L 30.00 · ₱42.0K/d
- 2012: ₱45.00 +36.4% · H 48.00 L 26.80 · ₱1.1M/d
- 2014: ₱25.00 start · H 51.95 L 25.00 · ₱29.8K/d
- 2015: ₱17.80 -28.8% · H 45.90 L 16.90 · ₱353.5K/d
- 2016: ₱15.02 -15.6% · H 35.25 L 15.02 · ₱382.6K/d
- 2017: ₱12.00 -20.1% · H 18.00 L 10.14 · ₱120.3K/d
- 2018: ₱10.04 -16.3% · H 16.00 L 8.00 · ₱49.3K/d
- 2019: ₱10.66 +6.2% · H 14.00 L 9.52 · ₱24.2K/d
- 2020: ₱10.96 +2.8% · H 18.88 L 10.08 · ₱77.5K/d
- 2021: ₱14.38 +31.2% · H 17.50 L 7.79 · ₱22.7K/d
- 2022: ₱11.98 -16.7% · H 19.00 L 10.00 · ₱19.2K/d
- 2023: ₱9.75 -18.6% · H 12.84 L 8.46 · ₱43.0K/d
- 2024: ₱5.91 -39.4% · H 11.96 L 5.91 · ₱23.8K/d
- 2025: ₱5.80 -1.9% · H 8.24 L 4.52 · ₱66.2K/d
- 2026*: ₱5.03 -13.3% · H 7.01 L 4.98 · ₱13.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
