---
tags: [trading, pse, stock, c]
---
**C — Chelsea Logistics and Infrastructure Holdings Corp.**
- Status: listed on PSE · sector Services › Transportation Services · listed Aug 08, 2017
- Data: 2017-08-08 → 2026-11-06 (2,192 trading days)
- Last close ₱1.10 (2026-11-06) · all-time high ₱10.78 (2017-09-11) · low ₱0.6000 (2026-06-10) · now -89.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱8.78 start · H 10.78 L 8.34 · ₱52.6M/d
- 2018: ₱6.46 -26.4% · H 9.43 L 4.64 · ₱21.6M/d
- 2019: ₱5.50 -14.9% · H 9.02 L 4.85 · ₱12.6M/d
- 2020: ₱5.21 -5.3% · H 6.30 L 2.00 · ₱19.5M/d
- 2021: ₱1.66 -68.1% · H 5.60 L 1.61 · ₱4.9M/d
- 2022: ₱1.20 -27.7% · H 1.87 L 1.08 · ₱583.0K/d
- 2023: ₱1.50 +25.0% · H 1.54 L 0.9500 · ₱314.4K/d
- 2024: ₱1.31 -12.7% · H 1.55 L 1.00 · ₱321.3K/d
- 2025: ₱0.9500 -27.5% · H 1.36 L 0.9000 · ₱231.2K/d
- 2026*: ₱1.10 +15.8% · H 1.13 L 0.6000 · ₱238.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
