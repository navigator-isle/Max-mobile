---
tags: [trading, pse, stock, ipm]
---
**IPM — IPM Holdings, Inc.**
- Status: listed on PSE · sector Services › Other Services · listed Jun 17, 1998
- Data: 1998-06-17 → 2026-11-04 (4,466 trading days)
- Last close ₱1.92 (2026-11-04) · all-time high ₱43.00 (1999-10-06) · low ₱0.1700 (2004-08-17) · now -95.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1998: ₱1.04 start · H 1.08 L 1.04 · ₱205.5K/d
- 1999: ₱9.50 +813.5% · H 43.00 L 1.06 · ₱56.5M/d
- 2000: ₱0.5100 -94.6% · H 9.90 L 0.4800 · ₱2.5M/d
- 2001: ₱0.2500 -51.0% · H 0.5300 L 0.2000 · ₱236.7K/d
- 2002: ₱0.3000 +20.0% · H 0.7500 L 0.2100 · ₱93.1K/d
- 2003: ₱0.2900 -3.3% · H 0.3400 L 0.2200 · ₱47.7K/d
- 2004: ₱0.2800 -3.4% · H 0.5200 L 0.1700 · ₱83.7K/d
- 2005: ₱0.2200 -21.4% · H 0.5600 L 0.2200 · ₱218.6K/d
- 2006: ₱1.54 +600.0% · H 3.15 L 0.1900 · ₱7.8M/d
- 2007: ₱6.10 +296.1% · H 11.25 L 1.54 · ₱36.5M/d
- 2008: ₱1.70 -72.1% · H 6.20 L 1.70 · ₱1.8M/d
- 2009: ₱3.85 +126.5% · H 5.20 L 1.72 · ₱3.2M/d
- 2010: ₱2.99 -22.3% · H 3.85 L 2.55 · ₱1.1M/d
- 2011: ₱4.50 +50.5% · H 5.86 L 2.52 · ₱4.4M/d
- 2012: ₱5.97 +32.7% · H 6.40 L 4.49 · ₱2.2M/d
- 2013: ₱5.15 -13.7% · H 7.60 L 5.05 · ₱1.2M/d
- 2014: ₱5.57 +8.2% · H 6.11 L 4.50 · ₱2.4M/d
- 2015: ₱9.94 +78.5% · H 9.96 L 4.90 · ₱5.9M/d
- 2016: ₱9.05 -9.0% · H 9.90 L 9.03 · ₱9.8M/d
- 2017: ₱8.35 -7.7% · H 9.08 L 8.30 · ₱3.1M/d
- 2018: ₱8.20 -1.8% · H 8.35 L 7.05 · ₱201.1K/d
- 2019: ₱7.00 -14.6% · H 8.20 L 2.40 · ₱63.7K/d
- 2020: ₱7.95 +13.6% · H 8.00 L 3.00 · ₱74.2K/d
- 2021: ₱7.05 -11.3% · H 7.10 L 4.53 · ₱50.0K/d
- 2022: ₱6.70 -5.0% · H 7.05 L 6.15 · ₱553.1K/d
- 2023: ₱3.50 -47.8% · H 6.65 L 3.40 · ₱26.8K/d
- 2024: ₱3.00 -14.3% · H 3.50 L 1.95 · ₱49.3K/d
- 2025: ₱1.57 -47.7% · H 3.00 L 1.24 · ₱117.1K/d
- 2026*: ₱1.92 +22.3% · H 2.79 L 1.42 · ₱17.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
