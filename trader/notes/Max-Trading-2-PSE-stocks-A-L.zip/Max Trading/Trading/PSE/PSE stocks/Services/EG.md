---
tags: [trading, pse, stock, eg]
---
**EG — IP E-Game Ventures, Inc.**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Feb 17, 2010
- Data: 2010-02-17 → 2017-05-02 (1,573 trading days)
- Last close ₱0.0094 (2017-05-02) · all-time high ₱123.0 (2010-03-08) · low ₱0.0053 (2015-12-29) · now -100.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2010-12-28 (÷3)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱30.80 start · H 123.0 L 24.25 · ₱1.6M/d
- 2011: ₱23.30 -24.4% · H 32.50 L 12.30 · ₱4.2M/d
- 2012: ₱0.0250 -99.9% · H 23.30 L 0.0200 · ₱10.1M/d
- 2013: ₱0.0130 -48.0% · H 0.0270 L 0.0120 · ₱2.0M/d
- 2014: ₱0.0140 +7.7% · H 0.0160 L 0.0100 · ₱811.4K/d
- 2015: ₱0.0053 -62.1% · H 0.0160 L 0.0053 · ₱512.4K/d
- 2016: ₱0.009 +69.8% · H 0.0130 L 0.0075 · ₱534.8K/d
- 2017*: ₱0.0094 +4.4% · H 0.0110 L 0.0089 · ₱533.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
