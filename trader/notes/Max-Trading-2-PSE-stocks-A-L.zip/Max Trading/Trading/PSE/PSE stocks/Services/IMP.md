---
tags: [trading, pse, stock, imp]
---
**IMP — Imperial Resources, Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed Aug 31, 1970
- Data: 1995-07-07 → 2026-11-06 (3,676 trading days)
- Last close ₱0.9000 (2026-11-06) · all-time high ₱33.75 (2016-03-29) · low ₱0.4000 (1998-09-24) · now -97.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2012-09-11 (÷1.5), 2017-02-22 (÷4)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱1.50 start · H 3.10 L 0.8000 · ₱1.1M/d
- 1996: ₱3.10 +106.7% · H 3.10 L 1.40 · ₱404.1K/d
- 1997: ₱0.8000 -74.2% · H 9.75 L 0.6500 · ₱1.6M/d
- 1998: ₱0.7000 -12.5% · H 2.10 L 0.4000 · ₱242.9K/d
- 1999: ₱1.60 +128.6% · H 2.50 L 0.4000 · ₱485.2K/d
- 2000: ₱2.30 +43.7% · H 15.50 L 1.20 · ₱11.1M/d
- 2001: ₱1.40 -39.1% · H 3.60 L 1.00 · ₱221.4K/d
- 2002: ₱1.10 -21.4% · H 2.40 L 0.9000 · ₱126.1K/d
- 2003: ₱1.10 +0.0% · H 1.50 L 0.9000 · ₱64.6K/d
- 2004: ₱1.00 -9.1% · H 1.40 L 0.8500 · ₱119.1K/d
- 2005: ₱1.10 +10.0% · H 1.70 L 0.9500 · ₱181.7K/d
- 2006: ₱1.90 +72.7% · H 2.10 L 1.00 · ₱385.5K/d
- 2007: ₱3.40 +78.9% · H 5.60 L 1.90 · ₱764.7K/d
- 2008: ₱2.30 -32.4% · H 3.40 L 1.86 · ₱146.0K/d
- 2009: ₱1.80 -21.7% · H 2.50 L 1.32 · ₱256.5K/d
- 2010: ₱1.40 -22.2% · H 2.50 L 0.9600 · ₱19.9K/d
- 2011: ₱1.60 +14.3% · H 2.50 L 1.00 · ₱32.9K/d
- 2012: ₱1.52 -5.0% · H 2.80 L 0.9000 · ₱90.4K/d
- 2013: ₱0.9000 -40.8% · H 1.52 L 0.6040 · ₱60.9K/d
- 2014: ₱0.8920 -0.9% · H 1.33 L 0.8420 · ₱280.0K/d
- 2015: ₱4.20 +370.9% · H 9.90 L 3.01 · ₱41.9K/d
- 2016: ₱15.48 +268.6% · H 33.75 L 5.20 · ₱3.5M/d
- 2017: ₱2.64 -82.9% · H 19.52 L 2.30 · ₱669.5K/d
- 2018: ₱1.87 -29.2% · H 3.10 L 1.70 · ₱156.6K/d
- 2019: ₱1.66 -11.2% · H 2.13 L 1.65 · ₱82.6K/d
- 2020: ₱1.67 +0.6% · H 1.86 L 1.00 · ₱49.6K/d
- 2021: ₱1.41 -15.6% · H 2.15 L 1.40 · ₱139.4K/d
- 2022: ₱1.32 -6.4% · H 1.48 L 1.06 · ₱25.5K/d
- 2023: ₱0.5500 -58.3% · H 1.32 L 0.5200 · ₱26.0K/d
- 2024: ₱0.6300 +14.5% · H 0.8300 L 0.5200 · ₱18.1K/d
- 2025: ₱0.7200 +14.3% · H 0.7800 L 0.4200 · ₱28.4K/d
- 2026*: ₱0.9000 +25.0% · H 1.10 L 0.7000 · ₱24.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
