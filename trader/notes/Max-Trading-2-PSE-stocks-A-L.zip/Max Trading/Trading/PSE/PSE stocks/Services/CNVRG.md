---
tags: [trading, pse, stock, cnvrg]
---
**CNVRG — Converge Information and Communications Technology Solutions, Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed Oct 26, 2020
- Data: 2020-10-26 → 2026-11-06 (1,473 trading days)
- Last close ₱9.13 (2026-11-06) · all-time high ₱44.00 (2021-10-06) · low ₱7.73 (2023-12-11) · now -79.2% from high
- Cash dividends last 12 months ₱0.4900 = 5.4% yield
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2020: ₱14.90 start · H 16.62 L 13.92 · ₱302.9M/d
- 2021: ₱31.90 +114.1% · H 44.00 L 14.84 · ₱277.4M/d
- 2022: ₱15.88 -50.2% · H 32.00 L 11.10 · ₱274.4M/d
- 2023: ₱8.38 -47.2% · H 19.38 L 7.73 · ₱59.4M/d
- 2024: ₱16.14 +92.6% · H 17.38 L 8.31 · ₱63.8M/d · div ₱0.1800 (1.1%): 23Sep 0.18S
- 2025: ₱15.32 -5.1% · H 21.40 L 11.20 · ₱106.0M/d · div ₱0.4300 (2.8%): 31Mar 0.43
- 2026*: ₱9.13 -40.4% · H 16.08 L 8.67 · ₱63.4M/d · div ₱0.4900 (5.4%): 19Mar 0.49

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
