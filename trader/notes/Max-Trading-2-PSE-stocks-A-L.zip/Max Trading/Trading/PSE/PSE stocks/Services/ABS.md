---
tags: [trading, pse, stock, abs]
---
**ABS — ABS-CBN Corporation**
- Status: listed on PSE · sector Services › Media · listed Jul 08, 1992
- Data: 1992-07-08 → 2026-11-06 (8,264 trading days)
- Last close ₱2.45 (2026-11-06) · all-time high ₱67.80 (2015-11-05) · low ₱1.78 (2026-06-25) · now -96.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 7

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1992: ₱5.24 start · H 6.27 L 3.33 · ₱1.4M/d
- 1993: ₱21.22 +305.2% · H 21.44 L 5.32 · ₱2.1M/d
- 1994: ₱24.33 +14.7% · H 27.50 L 18.44 · ₱5.2M/d
- 1995: ₱27.33 +12.3% · H 32.00 L 20.33 · ₱7.5M/d
- 1996: ₱28.50 +4.3% · H 35.00 L 25.50 · ₱10.1M/d
- 1997: ₱18.00 -36.8% · H 33.00 L 17.25 · ₱6.6M/d
- 1998: ₱20.00 +11.1% · H 21.00 L 12.75 · ₱3.3M/d
- 1999: ₱50.00 +150.0% · H 52.00 L 20.25 · ₱15.2M/d
- 2000: ₱49.50 -1.0% · H 66.50 L 35.00 · ₱17.2M/d
- 2001: ₱24.00 -51.5% · H 51.00 L 22.50 · ₱1.1M/d
- 2002: ₱16.00 -33.3% · H 38.00 L 14.00 · ₱792.1K/d
- 2003: ₱25.00 +56.2% · H 29.50 L 10.50 · ₱718.5K/d
- 2004: ₱18.50 -26.0% · H 27.00 L 18.00 · ₱643.5K/d
- 2005: ₱12.75 -31.1% · H 18.75 L 10.25 · ₱798.2K/d
- 2006: ₱20.25 +58.8% · H 22.75 L 10.50 · ₱1.4M/d
- 2007: ₱32.50 +60.5% · H 37.50 L 18.75 · ₱3.8M/d
- 2008: ₱12.25 -62.3% · H 33.00 L 12.25 · ₱751.8K/d
- 2009: ₱28.50 +132.7% · H 32.00 L 12.00 · ₱1.3M/d
- 2010: ₱45.00 +57.9% · H 56.00 L 25.50 · ₱3.5M/d
- 2011: ₱29.70 -34.0% · H 47.50 L 28.60 · ₱543.5K/d
- 2012: ₱33.85 +14.0% · H 41.80 L 24.45 · ₱3.8M/d
- 2013: ₱32.45 -4.1% · H 46.00 L 30.30 · ₱3.1M/d · div ₱0.4000 (1.2%): 07May 0.4
- 2014: ₱46.50 +43.3% · H 48.00 L 27.40 · ₱2.8M/d · div ₱0.6000 (1.3%): 11Apr 0.6
- 2015: ₱61.90 +33.1% · H 67.80 L 46.30 · ₱2.5M/d · div ₱0.6000 (1.0%): 17Mar 0.6
- 2016: ₱43.80 -29.2% · H 62.40 L 43.30 · ₱4.0M/d · div ₱0.7500 (1.7%): 06Apr 0.75
- 2017: ₱34.60 -21.0% · H 48.35 L 34.50 · ₱1.6M/d · div ₱1.04 (3.0%): 03Mar 1.04
- 2018: ₱20.00 -42.2% · H 35.15 L 19.30 · ₱1.9M/d · div ₱0.9200 (4.6%): 05Mar 0.92
- 2019: ₱15.80 -21.0% · H 24.95 L 15.40 · ₱3.6M/d · div ₱0.5500 (3.5%): 11Mar 0.55
- 2020: ₱11.68 -26.1% · H 23.50 L 6.76 · ₱12.9M/d
- 2021: ₱12.60 +7.9% · H 16.24 L 10.80 · ₱4.2M/d
- 2022: ₱7.39 -41.3% · H 14.26 L 7.03 · ₱2.2M/d
- 2023: ₱4.62 -37.5% · H 8.10 L 3.14 · ₱1.3M/d
- 2024: ₱4.20 -9.1% · H 7.80 L 3.06 · ₱5.8M/d
- 2025: ₱4.21 +0.2% · H 6.45 L 3.16 · ₱2.2M/d
- 2026*: ₱2.45 -41.8% · H 4.60 L 1.78 · ₱1.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
