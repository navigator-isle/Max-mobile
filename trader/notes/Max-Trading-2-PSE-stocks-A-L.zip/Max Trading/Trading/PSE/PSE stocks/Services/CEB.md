---
tags: [trading, pse, stock, ceb]
---
**CEB — Cebu Air, Inc.**
- Status: listed on PSE · sector Services › Transportation Services · listed Oct 26, 2010
- Data: 2010-10-26 → 2026-11-06 (3,905 trading days)
- Last close ₱25.55 (2026-11-06) · all-time high ₱133.0 (2010-10-26) · low ₱18.34 (2026-10-01) · now -80.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 11

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱113.4 start · H 133.0 L 106.0 · ₱332.8M/d
- 2011: ₱64.80 -42.9% · H 114.0 L 62.85 · ₱79.2M/d
- 2012: ₱61.85 -4.6% · H 75.65 L 52.45 · ₱39.1M/d
- 2013: ₱46.85 -24.3% · H 83.85 L 46.10 · ₱26.0M/d · div ₱1.00 (2.1%): 12Jul 1S
- 2014: ₱85.85 +83.2% · H 88.00 L 46.05 · ₱37.7M/d · div ₱1.00 (1.2%): 11Jul 1
- 2015: ₱82.35 -4.1% · H 98.40 L 79.10 · ₱63.5M/d · div ₱1.50 (1.8%): 13Jul 0.5S, 13Jul 1
- 2016: ₱93.00 +12.9% · H 125.0 L 74.50 · ₱61.3M/d · div ₱1.00 (1.1%): 06Jun 1S
- 2017: ₱100.0 +7.5% · H 112.6 L 90.00 · ₱38.4M/d · div ₱2.75 (2.8%): 06Jun 1, 06Jun 1.75S
- 2018: ₱73.20 -26.8% · H 103.0 L 61.40 · ₱18.2M/d · div ₱4.50 (6.1%): 08Jun 1.62S, 08Jun 2.88
- 2019: ₱89.50 +22.3% · H 98.00 L 58.00 · ₱17.5M/d · div ₱7.00 (7.8%): 10Jun 2, 10Jun 5S
- 2020: ₱50.50 -43.6% · H 88.85 L 31.20 · ₱24.0M/d
- 2021: ₱42.15 -16.5% · H 54.20 L 38.90 · ₱21.3M/d
- 2022: ₱38.30 -9.1% · H 49.30 L 35.50 · ₱10.1M/d
- 2023: ₱32.50 -15.1% · H 44.30 L 30.90 · ₱6.8M/d
- 2024: ₱28.25 -13.1% · H 36.10 L 26.10 · ₱8.5M/d
- 2025: ₱32.00 +13.3% · H 38.30 L 27.65 · ₱7.3M/d
- 2026*: ₱25.55 -20.2% · H 38.00 L 18.34 · ₱8.7M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
