---
tags: [trading, pse, stock, apl]
---
**APL — Apollo Global Capital, Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed Oct 18, 2012
- Data: 2012-10-18 → 2026-11-06 (3,207 trading days)
- Last close ₱0.0048 (2026-11-06) · all-time high ₱7.35 (2016-05-18) · low ₱0.0034 (2024-12-17) · now -99.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱0.0125 start · H 0.0270 L 0.0114 · ₱2.0M/d
- 2013: ₱0.0118 -5.6% · H 0.0152 L 0.0115 · ₱110.8K/d
- 2014: ₱0.0121 +2.5% · H 0.0152 L 0.0104 · ₱271.2K/d
- 2015: ₱4.11 +33866.9% · H 4.80 L 1.20 · ₱2.9M/d
- 2016: ₱0.0420 -99.0% · H 7.35 L 0.0400 · ₱2.7M/d
- 2017: ₱0.0420 +0.0% · H 0.0690 L 0.0390 · ₱6.2M/d
- 2018: ₱0.0390 -7.1% · H 0.0690 L 0.0370 · ₱2.4M/d
- 2019: ₱0.0430 +10.3% · H 0.0520 L 0.0390 · ₱707.7K/d
- 2020: ₱0.1280 +197.7% · H 0.1280 L 0.0360 · ₱10.9M/d
- 2021: ₱0.0800 -37.5% · H 0.4300 L 0.0700 · ₱174.6M/d
- 2022: ₱0.0330 -58.7% · H 0.0780 L 0.0260 · ₱13.0M/d
- 2023: ₱0.0130 -60.6% · H 0.0390 L 0.0130 · ₱11.3M/d
- 2024: ₱0.004 -69.2% · H 0.0150 L 0.0034 · ₱2.4M/d
- 2025: ₱0.005 +25.0% · H 0.0100 L 0.004 · ₱3.4M/d
- 2026*: ₱0.0048 -4.0% · H 0.0091 L 0.0047 · ₱2.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
