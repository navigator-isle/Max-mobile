---
tags: [trading, pse, stock, gmap]
---
**GMAP — GMA Holdings, Inc.**
- Status: listed on PSE · sector Services › Media · listed Jul 30, 2007
- Data: 2007-07-30 → 2026-11-06 (4,166 trading days)
- Last close ₱3.09 (2026-11-06) · all-time high ₱15.04 (2021-09-29) · low ₱3.04 (2026-10-12) · now -79.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱7.40 start · H 11.00 L 7.40 · ₱93.4M/d
- 2008: ₱3.30 -55.4% · H 8.00 L 3.30 · ₱15.3M/d
- 2009: ₱8.10 +145.5% · H 8.60 L 3.20 · ₱11.2M/d
- 2010: ₱7.20 -11.1% · H 7.80 L 5.62 · ₱12.2M/d
- 2011: ₱6.50 -9.7% · H 7.10 L 6.03 · ₱4.2M/d
- 2012: ₱9.32 +43.4% · H 10.94 L 6.41 · ₱32.2M/d
- 2013: ₱8.05 -13.6% · H 10.20 L 7.10 · ₱18.3M/d
- 2014: ₱6.75 -16.1% · H 9.00 L 5.99 · ₱2.6M/d
- 2015: ₱7.22 +7.0% · H 7.40 L 5.92 · ₱1.8M/d
- 2016: ₱5.85 -19.0% · H 7.20 L 5.85 · ₱1.2M/d
- 2017: ₱5.68 -2.9% · H 6.34 L 5.39 · ₱6.3M/d
- 2018: ₱5.36 -5.6% · H 6.32 L 4.91 · ₱1.4M/d
- 2019: ₱5.30 -1.1% · H 5.83 L 4.97 · ₱2.8M/d
- 2020: ₱5.95 +12.3% · H 5.95 L 4.42 · ₱2.0M/d
- 2021: ₱13.14 +120.8% · H 15.04 L 5.76 · ₱3.4M/d
- 2022: ₱10.60 -19.3% · H 15.00 L 9.90 · ₱1.3M/d
- 2023: ₱8.30 -21.7% · H 12.70 L 7.34 · ₱392.6K/d
- 2024: ₱6.26 -24.6% · H 9.00 L 5.40 · ₱1.4M/d
- 2025: ₱5.29 -15.5% · H 6.24 L 4.50 · ₱526.2K/d
- 2026*: ₱3.09 -41.6% · H 6.24 L 3.04 · ₱91.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
