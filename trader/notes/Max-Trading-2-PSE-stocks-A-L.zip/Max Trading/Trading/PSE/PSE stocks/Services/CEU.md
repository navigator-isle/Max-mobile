---
tags: [trading, pse, stock, ceu]
---
**CEU — Centro Escolar University**
- Status: listed on PSE · sector Services › Education · listed Nov 10, 1986
- Data: 2006-04-12 → 2026-11-06 (2,768 trading days)
- Last close ₱11.98 (2026-11-06) · all-time high ₱18.98 (2025-07-07) · low ₱5.50 (2007-12-28) · now -36.9% from high
- Cash dividends last 12 months ₱1.00 = 8.3% yield
- Dividend events on record (2013 → 2026): 16
- Splits / stock dividends detected (prices before these dates are as traded then): 2007-12-28 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱9.30 start · H 9.80 L 8.40 · ₱571.8K/d
- 2007: ₱5.50 -40.9% · H 9.00 L 5.50 · ₱98.9K/d
- 2008: ₱6.00 +9.1% · H 10.00 L 5.70 · ₱138.2K/d
- 2009: ₱8.60 +43.3% · H 9.50 L 5.50 · ₱148.6K/d
- 2010: ₱9.29 +8.0% · H 10.25 L 8.10 · ₱114.7K/d
- 2011: ₱9.10 -2.0% · H 10.00 L 8.20 · ₱108.8K/d
- 2012: ₱11.92 +31.0% · H 12.50 L 9.30 · ₱90.3K/d
- 2013: ₱10.82 -9.2% · H 12.00 L 10.20 · ₱172.1K/d · div ₱0.6000 (5.5%): 12Jul 0.35, 14Nov 0.25
- 2014: ₱10.50 -3.0% · H 11.38 L 10.14 · ₱136.8K/d · div ₱0.5000 (4.8%): 11Aug 0.5S
- 2015: ₱9.89 -5.8% · H 12.00 L 9.50 · ₱109.6K/d · div ₱0.6000 (6.1%): 17Mar 0.2, 13Aug 0.2S, 16Dec 0.2
- 2016: ₱9.90 +0.1% · H 10.16 L 9.13 · ₱48.1K/d · div ₱0.2000 (2.0%): 11Aug 0.2S
- 2017: ₱8.64 -12.7% · H 10.96 L 8.20 · ₱82.5K/d · div ₱0.2000 (2.3%): 17Oct 0.2
- 2018: ₱7.80 -9.7% · H 9.06 L 6.14 · ₱149.5K/d · div ₱0.2000 (2.6%): 09Jul 0.2
- 2019: ₱7.09 -9.1% · H 8.39 L 6.56 · ₱50.4K/d · div ₱0.2000 (2.8%): 31Jul 0.2
- 2020: ₱6.90 -2.7% · H 7.08 L 5.50 · ₱18.6K/d
- 2021: ₱6.98 +1.2% · H 7.96 L 6.49 · ₱639.5K/d · div ₱0.4000 (5.7%): 24Aug 0.4
- 2022: ₱6.50 -6.9% · H 7.70 L 6.01 · ₱32.9K/d · div ₱0.6000 (9.2%): 08Nov 0.6
- 2023: ₱8.50 +30.8% · H 9.05 L 6.29 · ₱75.5K/d · div ₱0.6000 (7.1%): 27Jun 0.6
- 2024: ₱13.80 +62.4% · H 15.98 L 8.00 · ₱219.7K/d · div ₱1.20 (8.7%): 10Jul 1.2S
- 2025: ₱15.70 +13.8% · H 18.98 L 13.00 · ₱322.7K/d · div ₱1.40 (8.9%): 09Jul 1.4
- 2026*: ₱11.98 -23.7% · H 17.00 L 11.98 · ₱194.0K/d · div ₱1.00 (8.3%): 29Jun 1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
