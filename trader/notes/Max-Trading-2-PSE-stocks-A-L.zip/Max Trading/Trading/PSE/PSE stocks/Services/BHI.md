---
tags: [trading, pse, stock, bhi]
---
**BHI — Boulevard Holdings, Inc.**
- Status: listed on PSE · sector Services › Hotel &amp; Leisure · listed Apr 28, 1997
- Data: 1997-04-28 → 2026-11-06 (5,408 trading days)
- Last close ₱0.0290 (2026-11-06) · all-time high ₱0.8200 (1997-06-05) · low ₱0.0240 (2020-05-18) · now -96.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-10-11 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1997: ₱0.1550 start · H 0.8200 L 0.1550 · ₱3.1M/d
- 1998: ₱0.3000 +93.5% · H 0.4000 L 0.1200 · ₱593.4K/d
- 1999: ₱0.2900 -3.3% · H 0.5500 L 0.2500 · ₱642.3K/d
- 2000: ₱0.1550 -46.6% · H 0.3500 L 0.1550 · ₱242.7K/d
- 2001: ₱0.1800 +16.1% · H 0.2800 L 0.1300 · ₱169.2K/d
- 2002: ₱0.1400 -22.2% · H 0.2400 L 0.0700 · ₱45.8K/d
- 2003: ₱0.0700 -50.0% · H 0.1900 L 0.0700 · ₱36.9K/d
- 2004: ₱0.1050 +50.0% · H 0.1650 L 0.0500 · ₱78.6K/d
- 2005: ₱0.1400 +33.3% · H 0.2350 L 0.1000 · ₱373.5K/d
- 2006: ₱0.1900 +35.7% · H 0.2500 L 0.1400 · ₱1.2M/d
- 2007: ₱0.1900 +0.0% · H 0.3600 L 0.1700 · ₱4.2M/d
- 2008: ₱0.0875 -53.9% · H 0.1900 L 0.0800 · ₱311.8K/d
- 2009: ₱0.0900 +2.9% · H 0.1400 L 0.0825 · ₱480.4K/d
- 2010: ₱0.0700 -22.2% · H 0.0925 L 0.0560 · ₱278.2K/d
- 2011: ₱0.1670 +138.6% · H 0.4900 L 0.0660 · ₱30.6M/d
- 2012: ₱0.1320 -21.0% · H 0.2300 L 0.1040 · ₱9.6M/d
- 2013: ₱0.1430 +8.3% · H 0.2000 L 0.1120 · ₱17.7M/d
- 2014: ₱0.1050 -26.6% · H 0.1590 L 0.0780 · ₱8.6M/d
- 2015: ₱0.0410 -61.0% · H 0.1200 L 0.0400 · ₱2.5M/d
- 2016: ₱0.0630 +53.7% · H 0.1180 L 0.0370 · ₱8.1M/d
- 2017: ₱0.0710 +12.7% · H 0.0960 L 0.0640 · ₱3.8M/d
- 2018: ₱0.0560 -21.1% · H 0.0710 L 0.0520 · ₱1.4M/d
- 2019: ₱0.0530 -5.4% · H 0.0790 L 0.0490 · ₱3.3M/d
- 2020: ₱0.0390 -26.4% · H 0.0540 L 0.0240 · ₱2.0M/d
- 2021: ₱0.0630 +61.5% · H 0.1490 L 0.0340 · ₱37.7M/d
- 2022: ₱0.0510 -19.0% · H 0.1130 L 0.0500 · ₱6.9M/d
- 2023: ₱0.0610 +19.6% · H 0.0820 L 0.0500 · ₱1.3M/d
- 2024: ₱0.0740 +21.3% · H 0.1050 L 0.0470 · ₱2.4M/d
- 2025: ₱0.0390 -47.3% · H 0.0880 L 0.0340 · ₱1.2M/d
- 2026*: ₱0.0290 -25.6% · H 0.0420 L 0.0270 · ₱767.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
