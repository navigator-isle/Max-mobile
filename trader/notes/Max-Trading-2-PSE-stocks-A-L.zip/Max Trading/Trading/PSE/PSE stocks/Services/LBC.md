---
tags: [trading, pse, stock, lbc]
---
**LBC — LBC Express Holdings, Inc.**
- Status: listed on PSE · sector Services › Transportation Services · listed Dec 21, 2001
- Data: 2007-07-12 → 2026-11-06 (2,830 trading days)
- Last close ₱9.98 (2026-11-06) · all-time high ₱26.00 (2022-06-01) · low ₱2.50 (2008-11-28) · now -61.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 5
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-08-22 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱10.50 start · H 21.00 L 6.00 · ₱4.8M/d
- 2008: ₱2.50 -76.2% · H 9.00 L 2.50 · ₱74.3K/d
- 2009: ₱11.00 +340.0% · H 14.75 L 3.00 · ₱1.1M/d
- 2010: ₱7.00 -36.4% · H 12.25 L 5.00 · ₱56.6K/d
- 2011: ₱8.90 +27.1% · H 18.00 L 5.80 · ₱825.1K/d
- 2012: ₱10.20 +14.6% · H 16.30 L 8.61 · ₱259.0K/d
- 2013: ₱8.00 -21.6% · H 15.00 L 5.30 · ₱236.4K/d
- 2014: ₱16.60 +107.5% · H 17.06 L 8.09 · ₱1.1M/d
- 2015: ₱12.00 -27.7% · H 25.60 L 11.48 · ₱4.5M/d
- 2016: ₱15.88 +32.3% · H 15.88 L 6.01 · ₱508.8K/d · div ₱0.2200 (1.4%): 07Nov 0.22
- 2017: ₱17.00 +7.1% · H 17.94 L 14.00 · ₱189.8K/d · div ₱0.5800 (3.4%): 16May 0.58
- 2018: ₱14.10 -17.1% · H 16.48 L 13.70 · ₱274.8K/d
- 2019: ₱13.50 -4.3% · H 15.94 L 12.74 · ₱202.1K/d · div ₱0.4500 (3.3%): 16Jan 0.2S, 09Oct 0.25S
- 2020: ₱15.48 +14.7% · H 16.80 L 10.50 · ₱359.1K/d · div ₱0.2000 (1.3%): 18Nov 0.2S
- 2021: ₱24.95 +61.2% · H 24.95 L 15.38 · ₱337.7K/d
- 2022: ₱18.96 -24.0% · H 26.00 L 16.02 · ₱85.9K/d
- 2023: ₱18.24 -3.8% · H 20.45 L 13.96 · ₱20.5K/d
- 2024: ₱11.82 -35.2% · H 18.12 L 11.10 · ₱43.3K/d
- 2025: ₱8.80 -25.5% · H 11.90 L 6.78 · ₱29.7K/d
- 2026*: ₱9.98 +13.4% · H 12.62 L 6.00 · ₱245.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
