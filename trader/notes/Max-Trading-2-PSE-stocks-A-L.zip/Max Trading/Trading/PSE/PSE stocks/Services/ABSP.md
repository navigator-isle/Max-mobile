---
tags: [trading, pse, stock, absp]
---
**ABSP — ABS-CBN Holdings Corporation**
- Status: listed on PSE · sector Services › Media · listed Oct 07, 1999
- Data: 2006-04-03 → 2026-11-06 (3,992 trading days)
- Last close ₱2.29 (2026-11-06) · all-time high ₱68.00 (2015-03-02) · low ₱1.38 (2026-06-25) · now -96.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱20.25 start · H 23.75 L 11.50 · ₱8.2M/d
- 2007: ₱33.00 +63.0% · H 38.00 L 18.75 · ₱21.2M/d
- 2008: ₱12.50 -62.1% · H 35.00 L 12.00 · ₱10.0M/d
- 2009: ₱29.00 +132.0% · H 32.00 L 12.50 · ₱6.3M/d
- 2010: ₱45.00 +55.2% · H 56.00 L 26.00 · ₱15.5M/d
- 2011: ₱29.90 -33.6% · H 47.90 L 29.50 · ₱5.5M/d
- 2012: ₱34.00 +13.7% · H 50.00 L 23.30 · ₱28.8M/d
- 2013: ₱32.00 -5.9% · H 48.10 L 30.80 · ₱36.8M/d
- 2014: ₱46.50 +45.3% · H 49.00 L 26.40 · ₱20.2M/d
- 2015: ₱62.70 +34.8% · H 68.00 L 46.50 · ₱17.4M/d
- 2016: ₱44.00 -29.8% · H 64.00 L 43.50 · ₱12.4M/d
- 2017: ₱34.50 -21.6% · H 48.55 L 34.10 · ₱8.8M/d
- 2018: ₱18.70 -45.8% · H 35.40 L 18.50 · ₱4.1M/d
- 2019: ₱15.40 -17.6% · H 21.10 L 14.70 · ₱3.2M/d
- 2020: ₱12.60 -18.2% · H 19.38 L 6.64 · ₱4.2M/d
- 2021: ₱11.92 -5.4% · H 15.44 L 10.10 · ₱1.3M/d
- 2022: ₱7.53 -36.8% · H 13.48 L 7.50 · ₱1.4M/d
- 2023: ₱4.60 -38.9% · H 7.80 L 2.00 · ₱1.8M/d
- 2024: ₱3.80 -17.4% · H 7.79 L 2.70 · ₱580.6K/d
- 2025: ₱4.10 +7.9% · H 6.00 L 3.00 · ₱408.8K/d
- 2026*: ₱2.29 -44.1% · H 4.48 L 1.38 · ₱246.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
