---
tags: [trading, pse, stock, bloom]
---
**BLOOM — Bloomberry Resorts Corporation**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Oct 17, 2000
- Data: 2000-10-17 → 2026-11-06 (3,948 trading days)
- Last close ₱1.92 (2026-11-06) · all-time high ₱76.00 (2011-11-21) · low ₱0.1200 (2004-07-16) · now -97.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 5
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-03-14 (÷1.5), 2004-06-30 (÷1.5), 2011-11-25 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱0.6800 start · H 1.00 L 0.6800 · ₱84.8K/d
- 2001: ₱0.4000 -41.2% · H 0.9000 L 0.3300 · ₱18.6K/d
- 2002: ₱0.3900 -2.5% · H 0.6000 L 0.3000 · ₱9.6K/d
- 2003: ₱0.3200 -17.9% · H 0.3800 L 0.3200 · ₱379.9K/d
- 2004: ₱0.4200 +31.2% · H 0.4800 L 0.1200 · ₱6.7K/d
- 2005: ₱1.70 +304.8% · H 1.82 L 0.5000 · ₱173.3K/d
- 2006: ₱2.00 +17.6% · H 2.00 L 1.40 · ₱166.4K/d
- 2007: ₱2.50 +25.0% · H 4.00 L 2.50 · ₱61.0K/d
- 2008: ₱3.00 +20.0% · H 3.00 L 2.50 · ₱312.5K/d
- 2009: ₱12.00 +300.0% · H 19.25 L 2.80 · ₱268.9K/d
- 2010: ₱8.58 -28.5% · H 15.50 L 5.00 · ₱100.5K/d
- 2011: ₱28.70 +234.5% · H 76.00 L 3.02 · ₱3.2M/d
- 2012: ₱13.20 -54.0% · H 63.00 L 8.21 · ₱97.5M/d
- 2013: ₱8.61 -34.8% · H 16.58 L 8.30 · ₱124.2M/d
- 2014: ₱12.40 +44.0% · H 15.58 L 8.35 · ₱118.7M/d
- 2015: ₱4.54 -63.4% · H 13.00 L 4.20 · ₱113.2M/d · div ₱0.0500 (1.1%): 31Mar 0.05S
- 2016: ₱6.15 +35.5% · H 6.92 L 3.08 · ₱63.6M/d
- 2017: ₱10.90 +77.2% · H 11.90 L 5.88 · ₱118.6M/d
- 2018: ₱9.41 -13.7% · H 14.86 L 7.33 · ₱120.0M/d · div ₱0.1000 (1.1%): 19Apr 0.1S
- 2019: ₱11.30 +20.1% · H 13.00 L 9.64 · ₱80.4M/d · div ₱0.1500 (1.3%): 02Apr 0.15S
- 2020: ₱8.11 -28.2% · H 10.98 L 4.30 · ₱46.8M/d · div ₱0.2500 (3.1%): 18Mar 0.25S
- 2021: ₱6.30 -22.3% · H 8.34 L 5.29 · ₱32.0M/d
- 2022: ₱7.65 +21.4% · H 7.80 L 5.59 · ₱44.2M/d
- 2023: ₱9.84 +28.6% · H 11.98 L 8.05 · ₱84.3M/d
- 2024: ₱4.58 -53.5% · H 11.78 L 4.48 · ₱64.7M/d
- 2025: ₱2.54 -44.5% · H 6.18 L 2.53 · ₱125.3M/d · div ₱0.0847 (3.3%): 24Mar 0.0847S
- 2026*: ₱1.92 -24.4% · H 3.01 L 1.65 · ₱36.1M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
