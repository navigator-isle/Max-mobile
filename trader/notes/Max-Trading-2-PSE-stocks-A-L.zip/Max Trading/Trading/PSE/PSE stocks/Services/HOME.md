---
tags: [trading, pse, stock, home]
---
**HOME — AllHome Corp.**
- Status: listed on PSE · sector Services › Retail · listed Oct 10, 2019
- Data: 2019-10-10 → 2026-06-01 (1,616 trading days)
- Last close ₱0.2400 (2026-06-01) · all-time high ₱11.66 (2019-11-20) · low ₱0.2300 (2026-05-19) · now -97.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱11.64 start · H 11.66 L 11.30 · ₱147.7M/d
- 2020: ₱9.15 -21.4% · H 11.64 L 4.49 · ₱19.7M/d · div ₱0.0140 (0.2%): 09Dec 0.014
- 2021: ₱8.39 -8.3% · H 10.98 L 6.90 · ₱10.4M/d · div ₱0.0527 (0.6%): 24Nov 0.0527
- 2022: ₱1.65 -80.3% · H 9.00 L 1.37 · ₱8.1M/d · div ₱0.0770 (4.7%): 12Dec 0.077
- 2023: ₱1.12 -32.1% · H 3.34 L 1.06 · ₱12.7M/d · div ₱0.0374 (3.3%): 29Nov 0.0374
- 2024: ₱0.6400 -42.9% · H 1.27 L 0.6000 · ₱1.9M/d · div ₱0.0309 (4.8%): 26Nov 0.0309
- 2025: ₱0.2370 -63.0% · H 0.6400 L 0.2370 · ₱512.3K/d
- 2026*: ₱0.2400 +1.3% · H 0.3950 L 0.2300 · ₱665.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
