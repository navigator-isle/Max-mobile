---
tags: [trading, pse, stock, gma7]
---
**GMA7 — GMA Network, Inc.**
- Status: listed on PSE · sector Services › Media · listed Jul 30, 2007
- Data: 2007-07-30 → 2026-11-06 (4,687 trading days)
- Last close ₱3.31 (2026-11-06) · all-time high ₱16.08 (2022-04-06) · low ₱3.20 (2026-10-05) · now -79.4% from high
- Cash dividends last 12 months ₱0.4000 = 12.1% yield
- Dividend events on record (2013 → 2026): 14

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱7.70 start · H 11.00 L 7.60 · ₱17.4M/d
- 2008: ₱3.45 -55.2% · H 7.70 L 3.45 · ₱2.9M/d
- 2009: ₱7.80 +126.1% · H 8.70 L 3.35 · ₱2.9M/d
- 2010: ₱7.20 -7.7% · H 7.80 L 5.70 · ₱3.3M/d
- 2011: ₱6.60 -8.3% · H 7.18 L 6.20 · ₱964.2K/d
- 2012: ₱9.18 +39.1% · H 10.90 L 6.60 · ₱13.3M/d
- 2013: ₱8.20 -10.7% · H 9.99 L 7.20 · ₱2.4M/d · div ₱0.2500 (3.0%): 12Apr 0.25
- 2014: ₱6.30 -23.2% · H 8.85 L 6.30 · ₱4.0M/d · div ₱0.2700 (4.3%): 21Apr 0.27
- 2015: ₱6.90 +9.5% · H 7.57 L 5.95 · ₱1.4M/d · div ₱0.2500 (3.6%): 21Apr 0.25
- 2016: ₱6.27 -9.1% · H 7.33 L 6.10 · ₱1.1M/d · div ₱0.4000 (6.4%): 20Apr 0.4
- 2017: ₱5.84 -6.9% · H 7.05 L 5.70 · ₱2.5M/d · div ₱0.7300 (12.5%): 17Apr 0.73
- 2018: ₱5.44 -6.8% · H 6.47 L 5.03 · ₱1.6M/d · div ₱0.5000 (9.2%): 18Apr 0.5
- 2019: ₱5.33 -2.0% · H 5.90 L 5.13 · ₱1.3M/d · div ₱0.4500 (8.4%): 15Apr 0.45
- 2020: ₱6.00 +12.6% · H 6.65 L 4.50 · ₱8.2M/d · div ₱0.3000 (5.0%): 19Jun 0.3
- 2021: ₱13.84 +130.7% · H 16.06 L 5.82 · ₱34.0M/d · div ₱1.35 (9.8%): 19Apr 1.35
- 2022: ₱11.22 -18.9% · H 16.08 L 9.76 · ₱13.8M/d · div ₱1.45 (12.9%): 20Apr 1.45
- 2023: ₱8.40 -25.1% · H 13.12 L 8.02 · ₱4.5M/d · div ₱1.10 (13.1%): 18Apr 1.1
- 2024: ₱6.11 -27.3% · H 9.27 L 6.11 · ₱3.4M/d · div ₱0.6000 (9.8%): 23Apr 0.6
- 2025: ₱5.41 -11.5% · H 6.70 L 5.08 · ₱2.1M/d · div ₱0.5000 (9.2%): 28Apr 0.5
- 2026*: ₱3.31 -38.8% · H 6.23 L 3.20 · ₱1.6M/d · div ₱0.4000 (12.1%): 17Apr 0.4

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
