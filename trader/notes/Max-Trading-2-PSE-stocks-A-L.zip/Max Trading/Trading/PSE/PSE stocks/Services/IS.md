---
tags: [trading, pse, stock, is]
---
**IS — Island Information &amp; Technology, Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed Dec 06, 1988
- Data: 1995-03-01 → 2026-11-06 (4,861 trading days)
- Last close ₱0.1350 (2026-11-06) · all-time high ₱0.8000 (2014-11-19) · low ₱0.0095 (1998-10-12) · now -83.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱0.0190 start · H 0.0310 L 0.0140 · ₱311.8K/d
- 1996: ₱0.0240 +26.3% · H 0.0480 L 0.0170 · ₱440.7K/d
- 1997: ₱0.0130 -45.8% · H 0.0850 L 0.0130 · ₱1.1M/d
- 1998: ₱0.0180 +38.5% · H 0.0250 L 0.0095 · ₱40.5K/d
- 1999: ₱0.0390 +116.7% · H 0.0470 L 0.0140 · ₱174.9K/d
- 2000: ₱0.0470 +20.5% · H 0.3200 L 0.0240 · ₱21.5M/d
- 2001: ₱0.0260 -44.7% · H 0.0725 L 0.0200 · ₱236.3K/d
- 2002: ₱0.0220 -15.4% · H 0.0925 L 0.0220 · ₱774.5K/d
- 2003: ₱0.0430 +95.5% · H 0.0600 L 0.0220 · ₱268.3K/d
- 2004: ₱0.0430 +0.0% · H 0.0575 L 0.0370 · ₱153.8K/d
- 2005: ₱0.0450 +4.7% · H 0.0600 L 0.0400 · ₱223.9K/d
- 2006: ₱0.0550 +22.2% · H 0.0575 L 0.0400 · ₱209.9K/d
- 2007: ₱0.1700 +209.1% · H 0.2700 L 0.0525 · ₱8.3M/d
- 2008: ₱0.0410 -75.9% · H 0.1600 L 0.0370 · ₱359.2K/d
- 2009: ₱0.0725 +76.8% · H 0.0900 L 0.0310 · ₱310.4K/d
- 2010: ₱0.0470 -35.2% · H 0.0800 L 0.0470 · ₱208.2K/d
- 2011: ₱0.0560 +19.1% · H 0.0690 L 0.0420 · ₱629.8K/d
- 2012: ₱0.0480 -14.3% · H 0.0740 L 0.0440 · ₱475.7K/d
- 2013: ₱0.0290 -39.6% · H 0.0590 L 0.0260 · ₱148.0K/d
- 2014: ₱0.3050 +951.7% · H 0.8000 L 0.0340 · ₱37.9M/d
- 2015: ₱0.1550 -49.2% · H 0.4550 L 0.1480 · ₱10.7M/d
- 2016: ₱0.2060 +32.9% · H 0.4250 L 0.1120 · ₱13.3M/d
- 2017: ₱0.1410 -31.6% · H 0.2400 L 0.1380 · ₱1.7M/d
- 2018: ₱0.1290 -8.5% · H 0.1600 L 0.0910 · ₱1.7M/d
- 2019: ₱0.1040 -19.4% · H 0.1500 L 0.0950 · ₱655.5K/d
- 2020: ₱0.1230 +18.3% · H 0.1370 L 0.0560 · ₱307.8K/d
- 2021: ₱0.1440 +17.1% · H 0.2650 L 0.1170 · ₱12.5M/d
- 2025: ₱0.1230 start · H 0.1410 L 0.0690 · ₱792.8K/d
- 2026*: ₱0.1350 +9.8% · H 0.1830 L 0.0930 · ₱586.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
