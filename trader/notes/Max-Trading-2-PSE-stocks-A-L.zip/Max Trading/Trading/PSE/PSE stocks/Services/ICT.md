---
tags: [trading, pse, stock, ict]
---
**ICT — International Container Terminal Services, Inc.**
- Status: listed on PSE · sector Services › Transportation Services · listed Mar 23, 1992
- Data: 1992-03-23 → 2026-11-06 (8,436 trading days)
- Last close ₱817.0 (2026-11-06) · all-time high ₱1,027 (2026-07-20) · low ₱0.6000 (2000-10-31) · now -20.4% from high
- Cash dividends last 12 months ₱17.85 = 2.2% yield
- Dividend events on record (2013 → 2026): 20

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1992: ₱3.08 start · H 3.49 L 0.8864 · ₱2.8M/d
- 1993: ₱8.11 +163.7% · H 8.11 L 3.11 · ₱5.0M/d
- 1994: ₱4.62 -43.0% · H 8.18 L 3.97 · ₱6.9M/d
- 1995: ₱4.07 -11.9% · H 5.63 L 3.11 · ₱7.7M/d
- 1996: ₱6.11 +50.0% · H 6.44 L 4.07 · ₱7.8M/d
- 1997: ₱3.33 -45.5% · H 8.11 L 3.33 · ₱15.6M/d
- 1998: ₱3.25 -2.5% · H 3.93 L 1.40 · ₱7.5M/d
- 1999: ₱3.65 +12.3% · H 5.10 L 1.88 · ₱11.4M/d
- 2000: ₱0.7800 -78.6% · H 3.55 L 0.6000 · ₱6.5M/d
- 2001: ₱2.10 +169.2% · H 3.25 L 0.7000 · ₱9.3M/d
- 2002: ₱2.40 +14.3% · H 3.20 L 2.14 · ₱5.5M/d
- 2003: ₱3.30 +37.5% · H 3.30 L 2.30 · ₱3.2M/d
- 2004: ₱5.90 +78.8% · H 5.90 L 2.75 · ₱4.3M/d
- 2005: ₱9.30 +57.6% · H 9.90 L 5.90 · ₱7.0M/d
- 2006: ₱20.75 +123.1% · H 20.75 L 9.20 · ₱47.3M/d
- 2007: ₱45.50 +119.3% · H 47.50 L 20.25 · ₱60.2M/d
- 2008: ₱12.75 -72.0% · H 45.50 L 12.00 · ₱33.0M/d
- 2009: ₱22.50 +76.5% · H 23.75 L 10.00 · ₱34.5M/d
- 2010: ₱45.00 +100.0% · H 45.85 L 19.75 · ₱76.1M/d
- 2011: ₱53.00 +17.8% · H 59.45 L 36.40 · ₱125.3M/d
- 2012: ₱74.00 +39.6% · H 77.00 L 53.10 · ₱95.9M/d
- 2013: ₱102.0 +37.8% · H 106.6 L 74.50 · ₱154.9M/d · div ₱0.7000 (0.7%): 30Apr 0.7
- 2014: ₱115.0 +12.7% · H 118.0 L 95.00 · ₱150.3M/d · div ₱0.8500 (0.7%): 23Apr 0.85
- 2015: ₱70.30 -38.9% · H 117.8 L 66.95 · ₱125.1M/d · div ₱0.9000 (1.3%): 28Apr 0.9
- 2016: ₱71.95 +2.3% · H 85.10 L 55.00 · ₱114.1M/d · div ₱0.9100 (1.3%): 02May 0.91
- 2017: ₱105.5 +46.6% · H 108.9 L 71.00 · ₱176.2M/d · div ₱2.47 (2.3%): 02May 2.47
- 2018: ₱100.0 -5.2% · H 113.5 L 77.20 · ₱143.5M/d · div ₱2.50 (2.5%): 30Apr 2.5
- 2019: ₱128.6 +28.6% · H 148.5 L 98.90 · ₱276.4M/d · div ₱5.00 (3.9%): 24Apr 2.08S, 24Apr 2.92
- 2020: ₱123.5 -4.0% · H 135.5 L 66.05 · ₱180.6M/d · div ₱3.31 (2.7%): 31Mar 3.31
- 2021: ₱200.0 +61.9% · H 205.0 L 118.5 · ₱231.7M/d · div ₱5.00 (2.5%): 25Mar 2.37, 17Aug 1.01, 17Aug 1.62S
- 2022: ₱200.0 +0.0% · H 233.0 L 156.6 · ₱314.4M/d · div ₱6.00 (3.0%): 15Mar 0.44S, 15Mar 5.56
- 2023: ₱246.8 +23.4% · H 246.8 L 194.5 · ₱239.3M/d · div ₱10.00 (4.1%): 15Mar 1.44S, 15Mar 8.56
- 2024: ₱386.0 +56.4% · H 438.0 L 236.0 · ₱495.8M/d · div ₱11.00 (2.8%): 14Mar 1.65S, 14Mar 9.35
- 2025: ₱567.0 +46.9% · H 610.0 L 320.0 · ₱676.8M/d · div ₱14.16 (2.5%): 19Mar 14.16
- 2026*: ₱817.0 +44.1% · H 1,027 L 555.5 · ₱1.3B/d · div ₱17.85 (2.2%): 18Mar 17.85

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
