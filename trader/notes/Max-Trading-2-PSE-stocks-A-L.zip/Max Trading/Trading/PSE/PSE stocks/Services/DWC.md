---
tags: [trading, pse, stock, dwc]
---
**DWC — Discovery World Corporation**
- Status: listed on PSE · sector Services › Hotel &amp; Leisure · listed Nov 21, 2013
- Data: 2013-11-21 → 2026-11-06 (1,891 trading days)
- Last close ₱0.9900 (2026-11-06) · all-time high ₱6.81 (2021-02-11) · low ₱0.8500 (2026-05-18) · now -85.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱2.48 start · H 3.00 L 2.48 · ₱492.3K/d
- 2014: ₱1.80 -27.4% · H 2.46 L 1.60 · ₱226.7K/d
- 2015: ₱1.70 -5.6% · H 2.00 L 1.60 · ₱134.8K/d · div ₱0.0250 (1.5%): 08Jul 0.025
- 2016: ₱2.39 +40.6% · H 3.00 L 1.44 · ₱104.1K/d · div ₱0.0250 (1.0%): 15Apr 0.025
- 2017: ₱2.49 +4.2% · H 4.18 L 2.00 · ₱479.8K/d
- 2018: ₱2.15 -13.7% · H 2.95 L 2.00 · ₱193.5K/d
- 2019: ₱2.03 -5.6% · H 2.34 L 1.90 · ₱40.1K/d
- 2020: ₱2.60 +28.1% · H 2.60 L 1.36 · ₱388.7K/d
- 2021: ₱1.80 -30.8% · H 6.81 L 1.80 · ₱3.2M/d
- 2022: ₱1.37 -23.9% · H 1.97 L 1.29 · ₱171.9K/d
- 2023: ₱1.41 +2.9% · H 1.74 L 1.05 · ₱251.8K/d
- 2024: ₱1.11 -21.3% · H 1.40 L 1.05 · ₱361.8K/d
- 2025: ₱1.13 +1.8% · H 1.19 L 1.03 · ₱106.0K/d
- 2026*: ₱0.9900 -12.4% · H 1.15 L 0.8500 · ₱598.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
