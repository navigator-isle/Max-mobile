---
tags: [trading, pse, stock, loto]
---
**LOTO — Pacific Online Systems Corporation**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Apr 12, 2007
- Data: 2007-04-12 → 2026-11-06 (4,161 trading days)
- Last close ₱1.68 (2026-11-06) · all-time high ₱21.00 (2015-08-11) · low ₱1.30 (2022-05-04) · now -92.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 13
- Splits / stock dividends detected (prices before these dates are as traded then): 2019-03-26 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱7.00 start · H 11.17 L 6.53 · ₱9.6M/d
- 2008: ₱5.00 -28.6% · H 7.17 L 4.87 · ₱880.3K/d
- 2009: ₱10.83 +116.7% · H 11.83 L 5.20 · ₱1.1M/d
- 2010: ₱10.69 -1.3% · H 11.17 L 9.50 · ₱975.2K/d
- 2011: ₱12.39 +15.8% · H 14.00 L 10.69 · ₱1.8M/d
- 2012: ₱9.39 -24.2% · H 15.13 L 9.19 · ₱925.3K/d
- 2013: ₱10.32 +9.9% · H 11.55 L 9.32 · ₱1.2M/d · div ₱0.7000 (6.8%): 12Nov 0.7
- 2014: ₱11.85 +14.9% · H 12.53 L 9.81 · ₱3.4M/d · div ₱0.5000 (4.2%): 16Jun 0.5
- 2015: ₱18.48 +55.9% · H 21.00 L 17.12 · ₱8.7M/d · div ₱0.6000 (3.2%): 16Jun 0.3, 16Sep 0.3
- 2016: ₱11.24 -39.2% · H 18.88 L 11.06 · ₱3.3M/d · div ₱0.9800 (8.7%): 04Feb 0.6, 03Nov 0.38S
- 2017: ₱11.10 -1.2% · H 11.92 L 10.92 · ₱1.4M/d · div ₱0.6000 (5.4%): 12May 0.3, 08Aug 0.3
- 2018: ₱9.99 -10.0% · H 11.92 L 9.56 · ₱2.7M/d · div ₱0.8000 (8.0%): 02Jan 0.2S, 09May 0.3, 31Jul 0.3
- 2019: ₱2.50 -75.0% · H 10.32 L 2.45 · ₱541.0K/d
- 2020: ₱2.11 -15.6% · H 2.72 L 1.50 · ₱340.9K/d
- 2021: ₱1.82 -13.7% · H 2.33 L 1.70 · ₱238.5K/d
- 2022: ₱1.65 -9.3% · H 1.84 L 1.30 · ₱53.5K/d
- 2023: ₱4.95 +200.0% · H 4.95 L 1.56 · ₱1.2M/d · div ₱0.1000 (2.0%): 10Mar 0.1
- 2024: ₱2.65 -46.5% · H 5.24 L 2.50 · ₱2.6M/d · div ₱0.1000 (3.8%): 13Mar 0.1
- 2025: ₱1.70 -35.8% · H 4.87 L 1.64 · ₱450.6K/d
- 2026*: ₱1.68 -1.2% · H 1.97 L 1.45 · ₱86.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
