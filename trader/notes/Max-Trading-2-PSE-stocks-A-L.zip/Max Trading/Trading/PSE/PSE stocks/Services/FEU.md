---
tags: [trading, pse, stock, feu]
---
**FEU — Far Eastern University, Incorporated**
- Status: listed on PSE · sector Services › Education · listed Jul 11, 1986
- Data: 2006-04-03 → 2026-11-06 (2,565 trading days)
- Last close ₱790.0 (2026-11-06) · all-time high ₱1,700 (2014-09-03) · low ₱488.2 (2020-10-08) · now -53.5% from high
- Cash dividends last 12 months ₱29.00 = 3.7% yield
- Dividend events on record (2013 → 2026): 28

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱810.0 start · H 1,450 L 645.0 · ₱509.4K/d
- 2007: ₱805.0 -0.6% · H 950.0 L 650.0 · ₱2.1M/d
- 2008: ₱620.0 -23.0% · H 1,300 L 575.0 · ₱2.7M/d
- 2009: ₱775.0 +25.0% · H 800.0 L 620.0 · ₱693.8K/d
- 2010: ₱778.0 +0.4% · H 800.0 L 740.0 · ₱756.3K/d
- 2011: ₱1,000 +28.5% · H 1,500 L 760.0 · ₱1.4M/d
- 2012: ₱1,080 +8.0% · H 1,080 L 900.0 · ₱1.3M/d
- 2013: ₱1,104 +2.2% · H 1,300 L 1,052 · ₱775.3K/d · div ₱39.00 (3.5%): 03Jan 12, 27Jun 15, 19Dec 12
- 2014: ₱1,020 -7.6% · H 1,700 L 1,000 · ₱689.0K/d · div ₱12.00 (1.2%): 26Jun 12
- 2015: ₱955.0 -6.4% · H 1,095 L 886.0 · ₱932.0K/d · div ₱36.00 (3.8%): 29Jan 12, 25Jun 12, 22Dec 12
- 2016: ₱950.0 -0.5% · H 1,046 L 910.5 · ₱1.7M/d · div ₱12.00 (1.3%): 30Jun 12
- 2017: ₱960.0 +1.1% · H 1,050 L 950.0 · ₱1.1M/d · div ₱18.00 (1.9%): 02Mar 10, 29Sep 8
- 2018: ₱890.0 -7.3% · H 1,000 L 890.0 · ₱754.0K/d · div ₱16.00 (1.8%): 01Mar 8, 27Sep 8
- 2019: ₱890.0 +0.0% · H 950.0 L 890.0 · ₱836.1K/d · div ₱18.00 (2.0%): 01Mar 8, 19Sep 10
- 2020: ₱630.0 -29.2% · H 998.5 L 488.2 · ₱415.0K/d · div ₱13.00 (2.1%): 28Feb 10, 27Nov 3
- 2021: ₱550.0 -12.7% · H 660.0 L 530.0 · ₱419.3K/d · div ₱13.00 (2.4%): 26Feb 5, 30Sep 8
- 2022: ₱540.0 -1.8% · H 597.0 L 530.0 · ₱785.5K/d · div ₱24.00 (4.4%): 24Feb 10, 29Sep 14
- 2023: ₱590.0 +9.3% · H 650.0 L 530.0 · ₱338.0K/d · div ₱30.00 (5.1%): 02Mar 14, 02Oct 16
- 2024: ₱735.0 +24.6% · H 800.0 L 551.5 · ₱423.6K/d · div ₱32.00 (4.4%): 04Mar 16, 30Sep 16
- 2025: ₱800.0 +8.8% · H 947.0 L 700.0 · ₱485.7K/d · div ₱32.00 (4.0%): 03Mar 16, 29Sep 16
- 2026*: ₱790.0 -1.2% · H 859.5 L 750.5 · ₱325.1K/d · div ₱29.00 (3.7%): 09Mar 14, 28Sep 15

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
