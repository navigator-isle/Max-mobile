---
tags: [trading, pse, stock, dfnn]
---
**DFNN — DFNN, Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed Oct 30, 2000
- Data: 2000-10-30 → 2026-11-06 (4,335 trading days)
- Last close ₱0.6400 (2026-11-06) · all-time high ₱15.50 (2007-12-12) · low ₱0.6000 (2026-10-06) · now -95.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱10.25 start · H 10.25 L 8.80 · ₱124.1K/d
- 2001: ₱6.10 -40.5% · H 11.00 L 4.80 · ₱699.0K/d
- 2002: ₱3.95 -35.2% · H 5.30 L 2.10 · ₱313.9K/d
- 2003: ₱2.00 -49.4% · H 4.05 L 1.80 · ₱109.6K/d
- 2004: ₱5.00 +150.0% · H 5.00 L 1.98 · ₱32.0K/d
- 2005: ₱4.00 -20.0% · H 5.00 L 3.00 · ₱20.2K/d
- 2006: ₱2.30 -42.5% · H 3.80 L 2.00 · ₱17.4K/d
- 2007: ₱14.50 +530.4% · H 15.50 L 2.50 · ₱4.9M/d
- 2008: ₱4.80 -66.9% · H 14.25 L 3.90 · ₱546.0K/d
- 2009: ₱8.30 +72.9% · H 9.80 L 3.25 · ₱1.2M/d
- 2010: ₱5.80 -30.1% · H 11.25 L 5.71 · ₱2.2M/d
- 2011: ₱5.90 +1.7% · H 9.86 L 5.50 · ₱2.4M/d
- 2012: ₱4.52 -23.4% · H 9.10 L 4.10 · ₱3.1M/d
- 2013: ₱5.50 +21.7% · H 6.40 L 3.72 · ₱1.4M/d
- 2014: ₱7.10 +29.1% · H 8.88 L 4.90 · ₱1.1M/d
- 2015: ₱5.30 -25.4% · H 7.33 L 4.00 · ₱1.2M/d
- 2016: ₱8.34 +57.4% · H 8.62 L 4.70 · ₱2.5M/d
- 2017: ₱7.01 -15.9% · H 11.00 L 6.65 · ₱2.9M/d
- 2018: ₱7.69 +9.7% · H 9.70 L 6.68 · ₱1.4M/d
- 2019: ₱4.88 -36.5% · H 7.60 L 4.83 · ₱1.3M/d
- 2020: ₱5.15 +5.5% · H 6.35 L 2.53 · ₱954.5K/d
- 2021: ₱2.45 -52.4% · H 5.64 L 2.38 · ₱6.5M/d
- 2022: ₱3.59 +46.5% · H 3.70 L 2.25 · ₱1.1M/d
- 2023: ₱3.09 -13.9% · H 3.99 L 2.90 · ₱885.2K/d
- 2024: ₱2.85 -7.8% · H 3.98 L 2.50 · ₱1.1M/d
- 2025: ₱0.8000 -71.9% · H 3.20 L 0.6600 · ₱274.5K/d
- 2026*: ₱0.6400 -20.0% · H 0.8300 L 0.6000 · ₱98.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
