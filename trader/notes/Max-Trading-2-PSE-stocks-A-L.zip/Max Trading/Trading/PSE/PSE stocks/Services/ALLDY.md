---
tags: [trading, pse, stock, alldy]
---
**ALLDY — AllDay Marts, Inc.**
- Status: listed on PSE · sector Services › Retail · listed Nov 03, 2021
- Data: 2021-11-03 → 2026-06-01 (1,114 trading days)
- Last close ₱0.0350 (2026-06-01) · all-time high ₱0.9000 (2021-11-03) · low ₱0.0300 (2025-11-07) · now -96.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱0.6100 start · H 0.9000 L 0.5700 · ₱189.0M/d
- 2022: ₱0.2250 -63.1% · H 0.6300 L 0.2190 · ₱7.3M/d · div ₱0.0032 (1.4%): 07Sep 0.0032
- 2023: ₱0.1570 -30.2% · H 0.3150 L 0.1550 · ₱2.4M/d · div ₱0.0026 (1.7%): 11Sep 0.0026
- 2024: ₱0.1330 -15.3% · H 0.1620 L 0.1250 · ₱505.8K/d · div ₱0.0032 (2.4%): 26Nov 0.0032
- 2025: ₱0.0310 -76.7% · H 0.1340 L 0.0300 · ₱548.6K/d
- 2026*: ₱0.0350 +12.9% · H 0.0590 L 0.0320 · ₱1.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
