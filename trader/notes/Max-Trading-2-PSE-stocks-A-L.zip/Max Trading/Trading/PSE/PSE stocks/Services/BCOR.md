---
tags: [trading, pse, stock, bcor]
---
**BCOR — Berjaya Philippines Inc.**
- Status: listed on PSE · sector Services › Retail · listed Nov 29, 1948
- Data: 2010-08-25 → 2026-11-06 (2,011 trading days)
- Last close ₱7.70 (2026-11-06) · all-time high ₱34.00 (2016-06-20) · low ₱1.43 (2018-11-08) · now -77.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-05 (÷0.2), 2016-06-21 (÷4), 2018-08-20 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱5.80 start · H 5.80 L 2.40 · ₱346.5K/d
- 2011: ₱5.00 -13.8% · H 5.76 L 3.00 · ₱1.8M/d
- 2012: ₱5.60 +12.0% · H 5.60 L 3.50 · ₱591.4K/d
- 2013: ₱5.70 +1.8% · H 6.39 L 3.60 · ₱289.8K/d
- 2014: ₱5.70 +0.0% · H 5.70 L 4.00 · ₱1.3M/d
- 2015: ₱28.50 +400.0% · H 29.00 L 22.60 · ₱5.2M/d
- 2016: ₱6.30 -77.9% · H 34.00 L 5.00 · ₱640.7K/d
- 2017: ₱4.87 -22.7% · H 6.05 L 4.51 · ₱2.8M/d
- 2018: ₱4.50 -7.6% · H 8.55 L 1.43 · ₱10.7M/d
- 2019: ₱5.20 +15.6% · H 5.20 L 2.22 · ₱3.6M/d
- 2020: ₱6.00 +15.4% · H 6.00 L 2.00 · ₱2.5M/d
- 2021: ₱7.00 +16.7% · H 7.85 L 4.02 · ₱1.1M/d
- 2022: ₱7.92 +13.1% · H 8.89 L 5.32 · ₱140.6K/d
- 2023: ₱7.51 -5.2% · H 8.50 L 6.10 · ₱56.4K/d
- 2024: ₱9.80 +30.5% · H 9.80 L 6.10 · ₱2.2M/d
- 2025: ₱9.00 -8.2% · H 9.49 L 5.00 · ₱107.2K/d
- 2026*: ₱7.70 -14.4% · H 9.71 L 6.01 · ₱1.0M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
