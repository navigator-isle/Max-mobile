---
tags: [trading, pse, stock, ecp]
---
**ECP — EasyCall Communications Philippines, Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed May 05, 1992
- Data: 2006-08-04 → 2026-09-30 (2,001 trading days)
- Last close ₱2.50 (2026-09-30) · all-time high ₱67.50 (2018-02-05) · low ₱1.55 (2024-08-22) · now -96.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2007-08-14 (÷1.5), 2011-11-28 (÷2), 2017-12-20 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱3.00 start · H 4.00 L 3.00 · ₱28.5K/d
- 2007: ₱4.00 +33.3% · H 7.50 L 3.00 · ₱45.8K/d
- 2008: ₱3.50 -12.5% · H 4.00 L 3.50 · ₱13.6K/d
- 2009: ₱2.20 -37.1% · H 3.50 L 1.60 · ₱36.2K/d
- 2010: ₱1.72 -21.8% · H 2.38 L 1.72 · ₱11.0K/d
- 2011: ₱2.76 +60.5% · H 4.10 L 1.60 · ₱333.3K/d
- 2012: ₱2.60 -5.8% · H 5.09 L 1.90 · ₱164.3K/d
- 2013: ₱2.62 +0.8% · H 3.20 L 2.54 · ₱41.3K/d
- 2014: ₱2.83 +8.0% · H 3.50 L 2.74 · ₱85.7K/d
- 2015: ₱3.78 +33.6% · H 3.86 L 2.72 · ₱80.8K/d
- 2016: ₱3.06 -19.0% · H 4.45 L 2.35 · ₱264.9K/d
- 2017: ₱18.50 +504.6% · H 41.15 L 2.91 · ₱2.4M/d
- 2018: ₱14.92 -19.4% · H 67.50 L 4.88 · ₱11.8M/d
- 2019: ₱7.79 -47.8% · H 18.88 L 7.78 · ₱3.1M/d
- 2020: ₱6.86 -11.9% · H 9.00 L 4.25 · ₱999.9K/d
- 2021: ₱4.20 -38.8% · H 8.68 L 4.10 · ₱306.1K/d
- 2022: ₱4.40 +4.8% · H 5.00 L 2.88 · ₱40.1K/d
- 2023: ₱2.52 -42.7% · H 4.37 L 1.97 · ₱29.2K/d
- 2024: ₱2.21 -12.3% · H 3.54 L 1.55 · ₱65.1K/d
- 2025: ₱3.14 +42.1% · H 4.50 L 2.05 · ₱142.0K/d
- 2026*: ₱2.50 -20.4% · H 3.30 L 2.28 · ₱35.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
