---
tags: [trading, pse, stock, dito]
---
**DITO — DITO CME Holdings Corp.**
- Status: listed on PSE · sector Services › Telecommunications · listed Oct 01, 1975
- Data: 1995-08-23 → 2026-11-06 (6,687 trading days)
- Last close ₱0.5500 (2026-11-06) · all-time high ₱18.12 (2021-02-22) · low ₱0.5400 (2026-10-08) · now -97.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱1.23 start · H 1.89 L 1.20 · ₱114.6K/d
- 1996: ₱1.69 +37.4% · H 1.69 L 0.9671 · ₱63.1K/d
- 1997: ₱1.03 -38.9% · H 15.47 L 1.03 · ₱4.9M/d
- 1998: ₱1.39 +35.0% · H 2.28 L 0.9342 · ₱90.8K/d
- 1999: ₱1.92 +37.7% · H 2.56 L 1.07 · ₱198.8K/d
- 2000: ₱1.20 -37.7% · H 3.14 L 1.07 · ₱612.6K/d
- 2001: ₱1.33 +11.0% · H 2.89 L 1.07 · ₱829.6K/d
- 2002: ₱1.16 -12.4% · H 2.32 L 1.03 · ₱321.3K/d
- 2003: ₱1.99 +70.6% · H 2.40 L 1.07 · ₱322.0K/d
- 2004: ₱1.79 -9.9% · H 2.12 L 1.72 · ₱478.4K/d
- 2005: ₱2.22 +23.9% · H 2.97 L 1.79 · ₱305.3K/d
- 2006: ₱2.56 +15.6% · H 15.47 L 2.25 · ₱754.9K/d
- 2007: ₱2.78 +8.3% · H 3.96 L 2.12 · ₱2.6M/d
- 2008: ₱2.64 -4.7% · H 3.56 L 1.92 · ₱947.7K/d
- 2009: ₱6.50 +145.9% · H 7.25 L 1.70 · ₱13.0M/d
- 2010: ₱3.90 -40.0% · H 6.75 L 3.42 · ₱5.4M/d
- 2011: ₱3.34 -14.4% · H 4.94 L 2.92 · ₱6.1M/d
- 2012: ₱2.59 -22.5% · H 3.42 L 2.17 · ₱489.1K/d
- 2013: ₱1.82 -29.7% · H 2.56 L 1.80 · ₱947.8K/d
- 2014: ₱1.51 -17.0% · H 2.00 L 1.47 · ₱482.3K/d
- 2015: ₱1.40 -7.3% · H 1.90 L 1.20 · ₱3.1M/d
- 2016: ₱1.31 -6.4% · H 2.42 L 1.12 · ₱7.2M/d
- 2017: ₱1.40 +6.9% · H 1.80 L 1.28 · ₱1.2M/d
- 2018: ₱6.03 +330.7% · H 8.30 L 1.35 · ₱70.5M/d
- 2019: ₱3.44 -43.0% · H 7.08 L 2.90 · ₱36.5M/d
- 2020: ₱10.90 +216.9% · H 10.90 L 1.06 · ₱225.7M/d
- 2021: ₱5.05 -53.7% · H 18.12 L 5.01 · ₱319.6M/d
- 2022: ₱2.79 -44.8% · H 6.90 L 2.43 · ₱35.7M/d
- 2023: ₱2.35 -15.8% · H 3.69 L 1.98 · ₱19.9M/d
- 2024: ₱1.64 -30.2% · H 2.60 L 1.17 · ₱18.3M/d
- 2025: ₱0.6800 -58.5% · H 2.23 L 0.6200 · ₱29.2M/d
- 2026*: ₱0.5500 -19.1% · H 1.05 L 0.5400 · ₱13.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
