---
tags: [trading, pse, stock, ew]
---
**EW — East West Banking Corporation**
- Status: listed on PSE · sector Financials › Banks · listed May 07, 2012
- Data: 2012-05-07 → 2026-11-06 (3,532 trading days)
- Last close ₱9.94 (2026-11-06) · all-time high ₱37.59 (2013-05-06) · low ₱5.73 (2022-10-26) · now -73.6% from high
- Cash dividends last 12 months ₱0.8200 = 8.2% yield
- Dividend events on record (2013 → 2026): 7
- Splits / stock dividends detected (prices before these dates are as traded then): 2018-03-26 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱28.99 start · H 29.14 L 18.51 · ₱37.2M/d
- 2013: ₱24.30 -16.2% · H 37.59 L 23.25 · ₱33.5M/d
- 2014: ₱23.94 -1.5% · H 31.50 L 23.55 · ₱12.3M/d
- 2015: ₱18.94 -20.9% · H 26.90 L 18.04 · ₱10.2M/d
- 2016: ₱18.54 -2.1% · H 21.90 L 14.34 · ₱9.1M/d · div ₱0.2667 (1.4%): 26Apr 0.26667
- 2017: ₱31.95 +72.3% · H 35.60 L 18.38 · ₱41.8M/d · div ₱0.3333 (1.0%): 04May 0.33334
- 2018: ₱11.90 -62.8% · H 33.00 L 10.30 · ₱19.4M/d
- 2019: ₱12.06 +1.3% · H 13.58 L 10.90 · ₱8.6M/d
- 2020: ₱10.80 -10.4% · H 12.48 L 6.08 · ₱6.5M/d
- 2021: ₱9.60 -11.1% · H 11.10 L 8.92 · ₱3.3M/d
- 2022: ₱6.67 -30.5% · H 9.68 L 5.73 · ₱2.0M/d · div ₱0.4000 (6.0%): 05May 0.4
- 2023: ₱8.52 +27.7% · H 9.54 L 6.76 · ₱2.3M/d · div ₱0.4100 (4.8%): 09May 0.41
- 2024: ₱9.85 +15.6% · H 10.24 L 8.42 · ₱2.8M/d · div ₱0.5400 (5.5%): 16May 0.54
- 2025: ₱11.60 +17.8% · H 13.00 L 9.65 · ₱3.8M/d · div ₱0.6800 (5.9%): 09May 0.68
- 2026*: ₱9.94 -14.3% · H 14.08 L 9.40 · ₱4.5M/d · div ₱0.8200 (8.2%): 08May 0.82

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
