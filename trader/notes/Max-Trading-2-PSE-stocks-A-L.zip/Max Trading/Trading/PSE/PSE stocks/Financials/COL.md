---
tags: [trading, pse, stock, col]
---
**COL — COL Financial Group, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Jul 12, 2006
- Data: 2006-07-12 → 2026-11-06 (4,785 trading days)
- Last close ₱1.18 (2026-11-06) · all-time high ₱46.50 (2021-01-11) · low ₱1.17 (2026-11-05) · now -97.5% from high
- Cash dividends last 12 months ₱0.0841 = 7.1% yield
- Dividend events on record (2013 → 2026): 29
- Splits / stock dividends detected (prices before these dates are as traded then): 2021-01-12 (÷10)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱5.60 start · H 5.70 L 1.66 · ₱4.6M/d
- 2007: ₱11.00 +96.4% · H 16.00 L 4.70 · ₱9.2M/d
- 2008: ₱4.50 -59.1% · H 11.00 L 2.90 · ₱1.8M/d
- 2009: ₱11.00 +144.4% · H 12.00 L 3.40 · ₱1.9M/d
- 2010: ₱13.18 +19.8% · H 13.40 L 10.00 · ₱1.9M/d
- 2011: ₱19.10 +44.9% · H 21.20 L 12.50 · ₱3.3M/d
- 2012: ₱19.48 +2.0% · H 23.90 L 18.00 · ₱6.2M/d
- 2013: ₱16.80 -13.8% · H 21.00 L 16.00 · ₱3.1M/d · div ₱0.6300 (3.8%): 01Apr 0.12, 01Apr 0.51S
- 2014: ₱15.24 -9.3% · H 18.70 L 12.76 · ₱3.1M/d · div ₱0.6000 (3.9%): 10Apr 0.12, 10Apr 0.48S
- 2015: ₱15.00 -1.6% · H 16.98 L 14.30 · ₱2.3M/d · div ₱0.5000 (3.3%): 13Apr 0.1, 13Apr 0.4S
- 2016: ₱16.10 +7.3% · H 17.04 L 13.90 · ₱1.6M/d · div ₱0.5000 (3.1%): 12Apr 0.11, 12Apr 0.39S
- 2017: ₱15.50 -3.7% · H 16.76 L 15.00 · ₱2.7M/d · div ₱0.6000 (3.9%): 25Apr 0.14, 25Apr 0.46S
- 2018: ₱16.24 +4.8% · H 16.78 L 15.10 · ₱697.8K/d · div ₱0.7000 (4.3%): 24Apr 0.15, 24Apr 0.55S
- 2019: ₱18.42 +13.4% · H 19.20 L 16.00 · ₱1.3M/d · div ₱0.8500 (4.6%): 11Apr 0.21, 11Apr 0.64S
- 2020: ₱34.00 +84.6% · H 34.00 L 14.90 · ₱2.0M/d · div ₱0.7000 (2.1%): 27Apr 0.18, 27Apr 0.52S
- 2021: ₱4.15 -87.8% · H 46.50 L 3.71 · ₱6.7M/d · div ₱0.0650 (1.6%): 25May 0.02, 25May 0.045S
- 2022: ₱3.21 -22.7% · H 4.15 L 2.95 · ₱239.3K/d · div ₱0.0850 (2.6%): 11May 0.024, 11May 0.061S
- 2023: ₱2.66 -17.1% · H 3.21 L 2.47 · ₱668.7K/d · div ₱0.0420 (1.6%): 11May 0.0114, 11May 0.0306S
- 2024: ₱1.65 -38.0% · H 2.65 L 1.59 · ₱556.7K/d · div ₱0.0651 (3.9%): 16May 0.0186, 16May 0.0465S
- 2025: ₱1.42 -13.9% · H 1.74 L 1.35 · ₱545.3K/d · div ₱0.0550 (3.9%): 15May 0.0157, 15May 0.0393S
- 2026*: ₱1.18 -16.9% · H 1.58 L 1.17 · ₱540.5K/d · div ₱0.0841 (7.1%): 14May 0.0194, 14May 0.0387, 28Aug 0.026

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
