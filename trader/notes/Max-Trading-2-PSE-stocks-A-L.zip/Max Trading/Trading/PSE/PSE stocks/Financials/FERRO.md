---
tags: [trading, pse, stock, ferro]
---
**FERRO — Ferronoux Holdings, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Aug 13, 2013
- Data: 2013-08-13 → 2026-11-06 (2,559 trading days)
- Last close ₱3.50 (2026-11-06) · all-time high ₱9.30 (2025-06-19) · low ₱1.70 (2022-10-05) · now -62.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱3.10 start · H 3.69 L 2.20 · ₱1.5M/d
- 2014: ₱4.00 +29.0% · H 4.75 L 2.65 · ₱304.5K/d
- 2015: ₱2.86 -28.5% · H 8.70 L 2.33 · ₱1.2M/d
- 2016: ₱3.49 +22.0% · H 4.06 L 2.00 · ₱740.4K/d
- 2017: ₱3.40 -2.6% · H 5.47 L 3.01 · ₱813.6K/d
- 2018: ₱4.47 +31.5% · H 5.10 L 3.10 · ₱1.1M/d
- 2019: ₱3.83 -14.3% · H 5.90 L 3.83 · ₱1.4M/d
- 2020: ₱4.08 +6.5% · H 5.11 L 2.30 · ₱936.4K/d
- 2021: ₱3.32 -18.6% · H 5.09 L 2.88 · ₱701.7K/d
- 2022: ₱2.44 -26.5% · H 3.32 L 1.70 · ₱74.4K/d
- 2023: ₱2.90 +18.9% · H 3.26 L 2.23 · ₱824.4K/d
- 2024: ₱5.20 +79.3% · H 5.20 L 1.73 · ₱1.8M/d
- 2025: ₱5.00 -3.8% · H 9.30 L 4.26 · ₱2.5M/d
- 2026*: ₱3.50 -30.0% · H 5.60 L 2.30 · ₱398.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
