---
tags: [trading, pse, stock, cbc]
---
**CBC — China Banking Corporation**
- Status: listed on PSE · sector Financials › Banks · listed Sep 01, 1927
- Data: 2015-01-05 → 2026-11-06 (2,844 trading days)
- Last close ₱48.60 (2026-11-06) · all-time high ₱94.50 (2025-03-20) · low ₱18.40 (2020-03-19) · now -48.6% from high
- Cash dividends last 12 months ₱2.80 = 5.8% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱37.20 start · H 48.15 L 37.00 · ₱3.4M/d
- 2016: ₱38.00 +2.2% · H 40.20 L 33.50 · ₱4.6M/d
- 2017: ₱33.30 -12.4% · H 41.50 L 33.00 · ₱12.3M/d
- 2018: ₱27.10 -18.6% · H 37.15 L 26.85 · ₱7.0M/d
- 2019: ₱25.05 -7.6% · H 29.00 L 24.80 · ₱4.0M/d
- 2020: ₱24.95 -0.4% · H 26.00 L 18.40 · ₱4.0M/d
- 2021: ₱26.00 +4.2% · H 26.05 L 22.85 · ₱3.0M/d
- 2022: ₱27.45 +5.6% · H 31.00 L 24.90 · ₱3.2M/d
- 2023: ₱30.85 +12.4% · H 33.75 L 27.20 · ₱5.4M/d
- 2024: ₱63.50 +105.8% · H 63.50 L 30.95 · ₱24.2M/d · div ₱2.20 (3.5%): 02May 1S, 02May 1.2
- 2025: ₱57.00 -10.2% · H 94.50 L 47.50 · ₱84.8M/d · div ₱2.50 (4.4%): 08May 1S, 08May 1.5
- 2026*: ₱48.60 -14.7% · H 70.30 L 47.20 · ₱21.0M/d · div ₱2.80 (5.8%): 29Apr 1, 29Apr 1.8

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
