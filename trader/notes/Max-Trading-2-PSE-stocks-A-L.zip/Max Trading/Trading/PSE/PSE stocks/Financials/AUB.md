---
tags: [trading, pse, stock, aub]
---
**AUB — Asia United Bank Corporation**
- Status: listed on PSE · sector Financials › Banks · listed May 17, 2013
- Data: 2000-01-03 → 2026-11-06 (5,322 trading days)
- Last close ₱43.00 (2026-11-06) · all-time high ₱91.50 (2025-07-23) · low ₱19.75 (2008-10-27) · now -53.0% from high
- Cash dividends last 12 months ₱2.00 = 4.7% yield
- Dividend events on record (2013 → 2026): 24
- Splits / stock dividends detected (prices before these dates are as traded then): 2013-05-17 (÷0.333), 2025-07-24 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱36.60 start · H 55.64 L 32.40 · ₱50.1M/d
- 2001: ₱41.00 +12.0% · H 48.20 L 31.20 · ₱21.9M/d
- 2002: ₱31.50 -23.2% · H 45.50 L 29.50 · ₱12.3M/d
- 2003: ₱27.50 -12.7% · H 32.00 L 25.00 · ₱9.3M/d
- 2004: ₱26.50 -3.6% · H 29.50 L 23.50 · ₱10.9M/d
- 2005: ₱32.00 +20.8% · H 39.50 L 25.00 · ₱33.3M/d
- 2006: ₱51.50 +60.9% · H 53.00 L 29.00 · ₱67.7M/d
- 2007: ₱54.50 +5.8% · H 75.50 L 49.00 · ₱251.8M/d
- 2008: ₱23.00 -57.8% · H 55.50 L 19.75 · ₱94.2M/d
- 2013: ₱45.40 start · H 69.33 L 37.53 · ₱30.8M/d
- 2014: ₱46.00 +1.3% · H 50.10 L 44.00 · ₱4.7M/d
- 2015: ₱46.15 +0.3% · H 74.80 L 44.65 · ₱3.2M/d
- 2016: ₱47.95 +3.9% · H 48.50 L 44.35 · ₱1.1M/d · div ₱1.00 (2.1%): 02Aug 0.67S, 07Sep 0.33S
- 2017: ₱59.80 +24.7% · H 60.00 L 47.15 · ₱1.8M/d · div ₱1.50 (2.5%): 04Jul 1, 03Oct 0.5
- 2018: ₱59.30 -0.8% · H 60.10 L 57.25 · ₱1.1M/d · div ₱1.60 (2.7%): 10May 1, 31Jul 0.6
- 2019: ₱53.10 -10.5% · H 59.90 L 53.00 · ₱464.4K/d · div ₱1.80 (3.4%): 11Jun 1, 17Sep 0.8
- 2020: ₱44.90 -15.4% · H 54.00 L 40.00 · ₱750.2K/d · div ₱2.00 (4.5%): 10Jul 1, 25Sep 1
- 2021: ₱43.25 -3.7% · H 47.60 L 41.55 · ₱331.0K/d · div ₱2.00 (4.6%): 12Jul 1, 12Oct 1
- 2022: ₱41.45 -4.2% · H 45.10 L 39.15 · ₱164.0K/d · div ₱2.00 (4.8%): 12Jul 1, 11Oct 1
- 2023: ₱32.70 -21.1% · H 51.50 L 32.70 · ₱710.6K/d · div ₱2.33 (7.1%): 06Jun 1, 07Sep 1, 18Dec 0.33S
- 2024: ₱61.50 +88.1% · H 64.00 L 32.50 · ₱2.2M/d · div ₱2.33 (3.8%): 11Jul 1.33, 05Sep 1
- 2025: ₱39.20 -36.3% · H 91.50 L 36.40 · ₱3.5M/d · div ₱2.00 (5.1%): 14Aug 1, 19Sep 1
- 2026*: ₱43.00 +9.7% · H 57.50 L 38.50 · ₱2.1M/d · div ₱2.50 (5.8%): 09Jul 1, 11Sep 1, 01Dec 0.5 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
