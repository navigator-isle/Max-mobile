---
tags: [trading, pse, stock, lmg]
---
**LMG — LMG Corp.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Jan 07, 1986
- Data: 2010-07-02 → 2026-11-05 (2,008 trading days)
- Last close ₱0.3150 (2026-11-05) · all-time high ₱8.30 (2017-03-13) · low ₱0.1200 (2024-11-26) · now -96.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱1.84 start · H 1.84 L 1.84 · ₱287.0K/d
- 2011: ₱1.21 -34.2% · H 1.84 L 1.21 · ₱9.3M/d
- 2012: ₱1.83 +51.2% · H 8.00 L 1.21 · ₱3.8M/d
- 2013: ₱3.01 +64.5% · H 4.85 L 1.88 · ₱2.7M/d
- 2014: ₱2.85 -5.3% · H 4.22 L 2.80 · ₱815.9K/d
- 2015: ₱1.77 -37.9% · H 3.18 L 1.77 · ₱180.7K/d
- 2016: ₱2.58 +45.8% · H 2.84 L 1.70 · ₱117.0K/d
- 2017: ₱4.10 +58.9% · H 8.30 L 2.55 · ₱8.6M/d
- 2018: ₱4.30 +4.9% · H 5.43 L 4.03 · ₱1.0M/d
- 2019: ₱4.86 +13.0% · H 5.48 L 3.83 · ₱411.5K/d
- 2020: ₱4.45 -8.4% · H 5.00 L 3.80 · ₱1.4M/d
- 2021: ₱4.00 -10.1% · H 5.05 L 3.90 · ₱2.1M/d
- 2022: ₱3.48 -13.0% · H 4.00 L 3.00 · ₱33.6K/d
- 2023: ₱3.34 -4.0% · H 4.14 L 2.45 · ₱30.1K/d
- 2024: ₱0.2180 -93.5% · H 3.38 L 0.1200 · ₱18.9K/d
- 2025: ₱0.2500 +14.7% · H 0.3700 L 0.1700 · ₱1.1M/d
- 2026*: ₱0.3150 +26.0% · H 0.4250 L 0.2500 · ₱99.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
