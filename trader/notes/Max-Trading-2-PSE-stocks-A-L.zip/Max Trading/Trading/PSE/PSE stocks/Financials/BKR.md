---
tags: [trading, pse, stock, bkr]
---
**BKR — Bright Kindle Resources &amp; Investments Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Mar 21, 1995
- Data: 1995-03-21 → 2026-11-06 (5,886 trading days)
- Last close ₱0.4850 (2026-11-06) · all-time high ₱17.75 (1996-04-17) · low ₱0.4700 (2026-09-24) · now -97.3% from high
- Cash dividends last 12 months ₱0.004 = 0.8% yield
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱9.60 start · H 11.25 L 4.65 · ₱12.4M/d
- 1996: ₱9.40 -2.1% · H 17.75 L 6.90 · ₱8.4M/d
- 1997: ₱1.52 -83.8% · H 10.25 L 1.32 · ₱2.1M/d
- 1998: ₱1.38 -9.2% · H 2.90 L 0.5400 · ₱654.5K/d
- 1999: ₱3.25 +135.5% · H 6.00 L 1.36 · ₱1.4M/d
- 2000: ₱1.54 -52.6% · H 5.80 L 1.16 · ₱1.6M/d
- 2001: ₱1.04 -32.5% · H 1.74 L 0.9000 · ₱183.8K/d
- 2002: ₱0.8000 -23.1% · H 1.54 L 0.6100 · ₱218.3K/d
- 2003: ₱1.20 +50.0% · H 1.56 L 0.7300 · ₱603.2K/d
- 2004: ₱0.9500 -20.8% · H 1.20 L 0.8000 · ₱87.5K/d
- 2005: ₱0.7700 -18.9% · H 1.10 L 0.7000 · ₱120.8K/d
- 2006: ₱0.8000 +3.9% · H 0.9300 L 0.6000 · ₱113.2K/d
- 2007: ₱1.80 +125.0% · H 2.20 L 0.6000 · ₱5.8M/d
- 2008: ₱1.28 -28.9% · H 1.86 L 1.06 · ₱171.1K/d
- 2009: ₱1.20 -6.2% · H 1.32 L 0.9600 · ₱147.5K/d
- 2010: ₱1.10 -8.3% · H 1.24 L 1.00 · ₱46.0K/d
- 2011: ₱0.8500 -22.7% · H 1.45 L 0.6900 · ₱347.6K/d
- 2012: ₱0.7000 -17.6% · H 0.9500 L 0.6800 · ₱271.9K/d
- 2013: ₱1.95 +178.6% · H 2.54 L 0.7000 · ₱3.5M/d
- 2014: ₱3.34 +71.3% · H 4.02 L 1.91 · ₱5.9M/d
- 2015: ₱1.32 -60.5% · H 3.34 L 1.24 · ₱535.8K/d
- 2016: ₱1.35 +2.3% · H 1.85 L 1.12 · ₱572.8K/d
- 2017: ₱1.97 +45.9% · H 2.90 L 1.15 · ₱3.2M/d
- 2018: ₱1.50 -23.9% · H 2.00 L 1.30 · ₱835.3K/d
- 2019: ₱1.11 -26.0% · H 1.63 L 0.8500 · ₱174.2K/d
- 2020: ₱0.9100 -18.0% · H 1.10 L 0.5200 · ₱381.6K/d
- 2021: ₱1.68 +84.6% · H 2.04 L 0.8900 · ₱2.1M/d
- 2022: ₱1.50 -10.7% · H 2.60 L 1.27 · ₱1.3M/d
- 2023: ₱1.40 -6.7% · H 1.58 L 1.10 · ₱1.6M/d · div ₱0.0037 (0.3%): 13Oct 0.0037S
- 2024: ₱0.9900 -29.3% · H 1.50 L 0.6800 · ₱563.1K/d
- 2025: ₱0.6500 -34.3% · H 1.58 L 0.5300 · ₱242.1K/d · div ₱0.004 (0.6%): 23Dec 0.004
- 2026*: ₱0.4850 -25.4% · H 0.7800 L 0.4700 · ₱55.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
