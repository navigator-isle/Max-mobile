---
tags: [trading, pse, stock, bdo]
---
**BDO — BDO Unibank, Inc.**
- Status: listed on PSE · sector Financials › Banks · listed May 21, 2002
- Data: 2002-05-21 → 2026-11-06 (5,948 trading days)
- Last close ₱125.0 (2026-11-06) · all-time high ₱168.0 (2025-05-13) · low ₱20.00 (2009-03-13) · now -25.6% from high
- Cash dividends last 12 months ₱4.40 = 3.5% yield
- Dividend events on record (2013 → 2026): 58

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2002: ₱25.62 start · H 27.26 L 23.25 · ₱11.6M/d
- 2003: ₱25.07 -2.1% · H 26.71 L 23.07 · ₱2.5M/d
- 2004: ₱31.45 +25.4% · H 32.54 L 24.16 · ₱17.4M/d
- 2005: ₱36.91 +17.4% · H 37.64 L 30.72 · ₱27.9M/d
- 2006: ₱45.65 +23.7% · H 47.10 L 34.72 · ₱55.3M/d
- 2007: ₱56.20 +23.1% · H 65.31 L 44.55 · ₱86.3M/d
- 2008: ₱29.63 -47.3% · H 56.57 L 27.99 · ₱63.7M/d
- 2009: ₱39.00 +31.6% · H 41.00 L 20.00 · ₱55.2M/d
- 2010: ₱58.50 +50.0% · H 63.40 L 34.50 · ₱130.8M/d
- 2011: ₱59.00 +0.9% · H 64.35 L 46.25 · ₱146.2M/d
- 2012: ₱72.80 +23.4% · H 76.75 L 58.10 · ₱219.9M/d
- 2013: ₱68.60 -5.8% · H 99.00 L 68.20 · ₱336.7M/d · div ₱2.10 (3.1%): 19Jun 0.3, 19Jun 1.2, 10Sep 0.3, 09Dec 0.3
- 2014: ₱109.8 +60.1% · H 111.6 L 70.00 · ₱351.3M/d · div ₱2.10 (1.9%): 21Feb 0.3, 06Jun 0.3, 26Jun 0.9S, 08Sep 0.3, 04Dec 0.3
- 2015: ₱105.0 -4.4% · H 123.7 L 93.00 · ₱362.5M/d · div ₱2.10 (2.0%): 13Apr 0.3, 08Jun 0.3, 09Jul 0.9S, 07Sep 0.3, 07Dec 0.3
- 2016: ₱112.1 +6.8% · H 119.5 L 94.40 · ₱250.8M/d · div ₱1.20 (1.1%): 09Mar 0.3, 10Jun 0.3, 12Sep 0.3, 14Dec 0.3
- 2017: ₱164.0 +46.3% · H 164.0 L 110.5 · ₱310.8M/d · div ₱1.20 (0.7%): 09Mar 0.3, 09Jun 0.3, 08Sep 0.3, 14Dec 0.3
- 2018: ₱130.8 -20.2% · H 165.0 L 108.9 · ₱319.3M/d · div ₱1.20 (0.9%): 08Mar 0.3, 07Jun 0.3, 11Sep 0.3, 18Dec 0.3
- 2019: ₱158.0 +20.8% · H 161.0 L 123.7 · ₱315.2M/d · div ₱1.20 (0.8%): 07Mar 0.3, 06Jun 0.3, 12Sep 0.3, 18Dec 0.3
- 2020: ₱106.8 -32.4% · H 157.5 L 85.00 · ₱381.3M/d · div ₱1.20 (1.1%): 10Mar 0.3, 11Jun 0.3, 10Sep 0.3, 17Dec 0.3
- 2021: ₱120.7 +13.0% · H 133.5 L 98.50 · ₱310.1M/d · div ₱1.20 (1.0%): 10Mar 0.3, 11Jun 0.3, 10Sep 0.3, 17Dec 0.3
- 2022: ₱105.7 -12.4% · H 139.7 L 105.7 · ₱337.0M/d · div ₱2.20 (2.1%): 09Mar 0.3, 03May 1S, 09Jun 0.3, 08Sep 0.3, 15Dec 0.3
- 2023: ₱130.5 +23.5% · H 150.0 L 107.9 · ₱402.3M/d · div ₱3.00 (2.3%): 08Mar 0.75, 08Jun 0.75, 11Sep 0.75, 21Dec 0.75
- 2024: ₱144.0 +10.3% · H 167.1 L 126.2 · ₱505.5M/d · div ₱3.75 (2.6%): 11Mar 0.75, 10Jun 1, 16Sep 1, 12Dec 1
- 2025: ₱134.6 -6.5% · H 168.0 L 119.0 · ₱551.1M/d · div ₱4.30 (3.2%): 10Mar 1, 17Jun 1.1, 15Sep 1.1, 22Dec 1.1
- 2026*: ₱125.0 -7.1% · H 143.6 L 110.3 · ₱465.2M/d · div ₱3.30 (2.6%): 12Mar 1.1, 08Jun 1.1, 11Sep 1.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
