---
tags: [trading, pse, stock, dhi]
---
**DHI — Dominion Holdings, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Jan 06, 1997
- Data: 2015-01-05 → 2026-08-19 (1,437 trading days)
- Last close ₱15.60 (2026-08-19) · all-time high ₱15.60 (2026-08-19) · low ₱1.15 (2025-07-17) · now +0.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱2.45 start · H 2.55 L 2.11 · ₱169.0K/d
- 2016: ₱3.79 +54.7% · H 4.20 L 2.40 · ₱797.3K/d
- 2017: ₱3.82 +0.8% · H 4.45 L 3.70 · ₱181.3K/d
- 2018: ₱2.19 -42.7% · H 3.91 L 2.14 · ₱200.7K/d
- 2019: ₱1.87 -14.6% · H 2.44 L 1.76 · ₱346.6K/d
- 2020: ₱3.16 +69.0% · H 3.16 L 1.85 · ₱2.2M/d
- 2024: ₱1.60 start · H 2.74 L 1.41 · ₱1.3M/d · div ₱1.50 (93.8%): 29Apr 1.5S
- 2025: ₱1.39 -13.1% · H 1.61 L 1.15 · ₱93.0K/d
- 2026*: ₱15.60 +1022.3% · H 15.60 L 1.25 · ₱26.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
