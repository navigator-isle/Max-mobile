---
tags: [trading, pse, stock, i]
---
**I — I-Remit, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Oct 17, 2007
- Data: 2007-10-17 → 2025-05-15 (3,092 trading days)
- Last close ₱0.1990 (2025-05-15) · all-time high ₱6.60 (2009-12-01) · low ₱0.1990 (2025-05-15) · now -97.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱4.70 start · H 5.50 L 4.65 · ₱21.4M/d
- 2008: ₱4.95 +5.3% · H 5.00 L 2.70 · ₱1.6M/d
- 2009: ₱6.10 +23.2% · H 6.60 L 3.70 · ₱4.5M/d
- 2010: ₱3.34 -45.2% · H 6.00 L 3.30 · ₱647.9K/d
- 2011: ₱2.45 -26.6% · H 3.53 L 2.00 · ₱279.9K/d
- 2012: ₱2.79 +13.9% · H 3.20 L 2.10 · ₱579.1K/d
- 2013: ₱2.86 +2.5% · H 2.98 L 2.50 · ₱170.1K/d
- 2014: ₱1.82 -36.4% · H 2.85 L 1.74 · ₱142.5K/d
- 2015: ₱1.85 +1.6% · H 2.34 L 1.15 · ₱165.7K/d
- 2016: ₱1.74 -5.9% · H 2.33 L 1.60 · ₱306.1K/d
- 2017: ₱1.74 +0.0% · H 1.89 L 1.60 · ₱227.5K/d
- 2018: ₱1.53 -12.1% · H 1.80 L 1.36 · ₱91.2K/d
- 2019: ₱1.16 -24.2% · H 1.67 L 1.15 · ₱61.5K/d
- 2020: ₱1.68 +44.8% · H 2.40 L 0.8500 · ₱525.6K/d
- 2021: ₱0.9400 -44.0% · H 1.85 L 0.8400 · ₱392.6K/d
- 2022: ₱0.7400 -21.3% · H 0.9500 L 0.6500 · ₱26.8K/d
- 2023: ₱0.4850 -34.5% · H 0.9500 L 0.4850 · ₱594.0K/d
- 2024: ₱0.2400 -50.5% · H 0.4900 L 0.2000 · ₱449.9K/d
- 2025*: ₱0.1990 -17.1% · H 0.2700 L 0.1990 · ₱15.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
