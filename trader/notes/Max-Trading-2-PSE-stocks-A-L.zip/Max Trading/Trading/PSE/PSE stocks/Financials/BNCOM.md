---
tags: [trading, pse, stock, bncom]
---
**BNCOM — Bank of Commerce**
- Status: listed on PSE · sector Financials › Banks · listed Mar 31, 2022
- Data: 2022-03-31 → 2026-11-06 (1,105 trading days)
- Last close ₱9.90 (2026-11-06) · all-time high ₱12.22 (2022-03-31) · low ₱5.80 (2023-09-12) · now -19.0% from high
- Cash dividends last 12 months ₱0.4500 = 4.5% yield
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱7.89 start · H 12.22 L 7.80 · ₱3.4M/d
- 2023: ₱7.27 -7.9% · H 8.90 L 5.80 · ₱159.2K/d
- 2024: ₱6.75 -7.2% · H 8.80 L 6.13 · ₱173.9K/d · div ₱0.2512 (3.7%): 18Jun 0.2512
- 2025: ₱9.20 +36.3% · H 9.20 L 6.50 · ₱503.4K/d · div ₱0.4500 (4.9%): 18Jun 0.2S, 18Jun 0.25
- 2026*: ₱9.90 +7.6% · H 11.86 L 8.59 · ₱990.1K/d · div ₱0.4500 (4.5%): 18Jun 0.2, 18Jun 0.25

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
