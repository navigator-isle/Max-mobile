---
tags: [trading, pse, stock, csb]
---
**CSB — Citystate Savings Bank, Inc.**
- Status: listed on PSE · sector Financials › Banks · listed Jan 03, 2002
- Data: 2002-01-03 → 2026-10-28 (2,226 trading days)
- Last close ₱12.96 (2026-10-28) · all-time high ₱31.00 (2012-06-05) · low ₱5.96 (2021-01-05) · now -58.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2002: ₱15.00 start · H 15.00 L 12.50 · ₱73.1K/d
- 2003: ₱16.00 +6.7% · H 16.00 L 14.25 · ₱38.6K/d
- 2004: ₱17.50 +9.4% · H 17.50 L 16.00 · ₱30.4K/d
- 2005: ₱19.00 +8.6% · H 19.00 L 17.00 · ₱396.7K/d
- 2006: ₱19.00 +0.0% · H 20.50 L 18.50 · ₱11.0K/d
- 2007: ₱25.00 +31.6% · H 25.00 L 14.00 · ₱62.1K/d
- 2008: ₱27.00 +8.0% · H 27.00 L 22.50 · ₱11.8K/d
- 2009: ₱28.00 +3.7% · H 28.00 L 26.00 · ₱2.6M/d
- 2010: ₱28.00 +0.0% · H 28.00 L 28.00 · ₱5.7M/d
- 2011: ₱28.50 +1.8% · H 28.50 L 27.80 · ₱21.6K/d
- 2012: ₱28.00 -1.8% · H 31.00 L 18.00 · ₱2.9M/d
- 2013: ₱15.98 -42.9% · H 27.50 L 9.00 · ₱226.7K/d
- 2014: ₱13.98 -12.5% · H 14.78 L 9.22 · ₱73.8K/d
- 2015: ₱10.00 -28.5% · H 11.00 L 9.03 · ₱24.8K/d
- 2016: ₱9.99 -0.1% · H 10.16 L 8.20 · ₱14.0K/d
- 2017: ₱10.00 +0.1% · H 10.00 L 8.52 · ₱12.9K/d
- 2018: ₱7.59 -24.1% · H 10.00 L 6.42 · ₱23.1K/d
- 2019: ₱8.49 +11.9% · H 8.49 L 7.57 · ₱6.6K/d
- 2020: ₱8.48 -0.1% · H 8.50 L 7.80 · ₱876.7K/d
- 2021: ₱8.48 +0.0% · H 8.50 L 5.96 · ₱37.2K/d
- 2022: ₱8.49 +0.1% · H 8.49 L 6.76 · ₱8.2K/d
- 2023: ₱8.11 -4.5% · H 8.49 L 6.50 · ₱11.2K/d
- 2024: ₱12.52 +54.4% · H 13.40 L 5.96 · ₱327.0K/d
- 2025: ₱17.06 +36.3% · H 19.48 L 9.03 · ₱7.0M/d
- 2026*: ₱12.96 -24.0% · H 17.06 L 12.42 · ₱40.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
