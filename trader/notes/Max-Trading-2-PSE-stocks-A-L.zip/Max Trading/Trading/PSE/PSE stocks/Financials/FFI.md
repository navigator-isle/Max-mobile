---
tags: [trading, pse, stock, ffi]
---
**FFI — Filipino Fund, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Sep 27, 1995
- Data: 1995-09-27 → 2026-11-04 (3,303 trading days)
- Last close ₱7.70 (2026-11-04) · all-time high ₱23.45 (2013-03-22) · low ₱0.2000 (2002-07-09) · now -67.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2
- Splits / stock dividends detected (prices before these dates are as traded then): 2014-01-23 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱0.7500 start · H 1.06 L 0.6800 · ₱3.6M/d
- 1996: ₱0.8500 +13.3% · H 1.08 L 0.7200 · ₱1.8M/d
- 1997: ₱0.7900 -7.1% · H 0.9800 L 0.6200 · ₱1.4M/d
- 1998: ₱0.6800 -13.9% · H 0.8000 L 0.4400 · ₱360.7K/d
- 1999: ₱0.5700 -16.2% · H 0.8000 L 0.4800 · ₱132.6K/d
- 2000: ₱0.3500 -38.6% · H 0.6400 L 0.3400 · ₱57.7K/d
- 2001: ₱0.3200 -8.6% · H 0.5500 L 0.2600 · ₱46.2K/d
- 2002: ₱0.3200 +0.0% · H 0.4800 L 0.2000 · ₱79.6K/d
- 2003: ₱3.50 +993.8% · H 5.70 L 0.2900 · ₱453.0K/d
- 2004: ₱3.40 -2.9% · H 3.70 L 3.00 · ₱27.3K/d
- 2005: ₱3.70 +8.8% · H 3.80 L 3.05 · ₱35.9K/d
- 2006: ₱4.90 +32.4% · H 5.30 L 3.50 · ₱34.4K/d
- 2007: ₱7.80 +59.2% · H 8.80 L 4.80 · ₱82.5K/d
- 2008: ₱5.00 -35.9% · H 7.50 L 5.00 · ₱64.5K/d
- 2009: ₱5.90 +18.0% · H 6.20 L 5.10 · ₱31.6K/d
- 2010: ₱6.95 +17.8% · H 6.95 L 5.20 · ₱27.5K/d
- 2011: ₱8.30 +19.4% · H 12.12 L 6.76 · ₱22.7K/d
- 2012: ₱11.20 +34.9% · H 17.78 L 8.35 · ₱102.0K/d
- 2013: ₱15.00 +33.9% · H 23.45 L 10.26 · ₱168.6K/d · div ₱0.2000 (1.3%): 01Apr 0.2
- 2014: ₱7.05 -53.0% · H 18.00 L 6.35 · ₱80.7K/d
- 2015: ₱7.00 -0.7% · H 9.80 L 6.12 · ₱115.4K/d
- 2016: ₱6.60 -5.7% · H 7.70 L 6.15 · ₱49.1K/d
- 2017: ₱7.67 +16.2% · H 9.30 L 6.55 · ₱75.7K/d
- 2018: ₱7.32 -4.6% · H 12.10 L 7.24 · ₱74.9K/d · div ₱0.0800 (1.1%): 18Apr 0.08
- 2019: ₱7.00 -4.4% · H 8.98 L 7.00 · ₱42.6K/d
- 2020: ₱7.00 +0.0% · H 8.88 L 5.25 · ₱76.4K/d
- 2021: ₱6.52 -6.9% · H 8.50 L 6.30 · ₱27.8K/d
- 2022: ₱3.66 -43.9% · H 7.00 L 3.66 · ₱14.0K/d
- 2023: ₱4.20 +14.8% · H 4.20 L 3.30 · ₱22.4K/d
- 2024: ₱6.42 +52.9% · H 7.53 L 3.60 · ₱131.3K/d
- 2025: ₱7.50 +16.8% · H 8.20 L 6.31 · ₱29.7K/d
- 2026*: ₱7.70 +2.7% · H 7.90 L 7.50 · ₱72.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
