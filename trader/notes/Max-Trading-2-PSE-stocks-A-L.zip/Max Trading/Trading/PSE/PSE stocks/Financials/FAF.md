---
tags: [trading, pse, stock, faf]
---
**FAF — First Abacus Financial Holdings Corporation**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Nov 17, 1994
- Data: 1994-11-17 → 2026-11-04 (2,478 trading days)
- Last close ₱0.4600 (2026-11-04) · all-time high ₱2.80 (1997-02-06) · low ₱0.1900 (1998-07-29) · now -83.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2003-05-08 (÷1.5), 2003-09-25 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱0.9500 start · H 1.00 L 0.8000 · ₱607.0K/d
- 1995: ₱1.10 +15.8% · H 1.40 L 0.7000 · ₱3.4M/d
- 1996: ₱2.44 +121.8% · H 2.55 L 1.00 · ₱14.5M/d
- 1997: ₱1.08 -55.7% · H 2.80 L 1.08 · ₱3.3M/d
- 1998: ₱0.2600 -75.9% · H 0.9600 L 0.1900 · ₱401.1K/d
- 1999: ₱0.7000 +169.2% · H 0.9200 L 0.2700 · ₱1.1M/d
- 2000: ₱0.7000 +0.0% · H 0.8000 L 0.3900 · ₱238.7K/d
- 2001: ₱0.6000 -14.3% · H 0.6500 L 0.5000 · ₱46.4K/d
- 2002: ₱0.6000 +0.0% · H 0.6000 L 0.3600 · ₱336.1K/d
- 2003: ₱0.5100 -15.0% · H 1.00 L 0.2800 · ₱362.1K/d
- 2004: ₱0.7500 +47.1% · H 0.9000 L 0.5000 · ₱158.7K/d
- 2005: ₱0.7500 +0.0% · H 0.7500 L 0.4000 · ₱133.4K/d
- 2006: ₱0.7900 +5.3% · H 0.7900 L 0.4400 · ₱154.4K/d
- 2007: ₱1.00 +26.6% · H 1.46 L 0.5500 · ₱1.0M/d
- 2008: ₱0.5700 -43.0% · H 1.00 L 0.3000 · ₱200.2K/d
- 2009: ₱0.8500 +49.1% · H 0.9900 L 0.4400 · ₱1.9M/d
- 2010: ₱0.8700 +2.4% · H 0.8700 L 0.5400 · ₱245.3K/d
- 2011: ₱0.8000 -8.0% · H 0.8600 L 0.6200 · ₱640.8K/d
- 2012: ₱0.8100 +1.2% · H 0.9100 L 0.6900 · ₱231.6K/d
- 2013: ₱0.7800 -3.7% · H 0.8700 L 0.7500 · ₱138.5K/d
- 2014: ₱0.8500 +9.0% · H 0.8700 L 0.7800 · ₱185.1K/d
- 2015: ₱0.7400 -12.9% · H 0.8400 L 0.4400 · ₱138.3K/d
- 2016: ₱0.7300 -1.4% · H 0.7800 L 0.6300 · ₱879.0K/d
- 2017: ₱0.7200 -1.4% · H 0.7300 L 0.6500 · ₱110.8K/d
- 2018: ₱0.7200 +0.0% · H 0.7200 L 0.5400 · ₱379.1K/d
- 2019: ₱0.7200 +0.0% · H 0.7200 L 0.5200 · ₱336.7K/d
- 2020: ₱0.7200 +0.0% · H 0.7200 L 0.4600 · ₱57.2K/d
- 2021: ₱0.7200 +0.0% · H 0.7200 L 0.5600 · ₱92.7K/d
- 2022: ₱0.7200 +0.0% · H 0.7200 L 0.5900 · ₱65.6K/d
- 2023: ₱0.6000 -16.7% · H 0.7100 L 0.5400 · ₱48.1K/d
- 2024: ₱0.6500 +8.3% · H 0.7000 L 0.5900 · ₱71.5K/d
- 2025: ₱0.6600 +1.5% · H 0.6900 L 0.5600 · ₱45.9K/d
- 2026*: ₱0.4600 -30.3% · H 0.6600 L 0.4600 · ₱25.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
