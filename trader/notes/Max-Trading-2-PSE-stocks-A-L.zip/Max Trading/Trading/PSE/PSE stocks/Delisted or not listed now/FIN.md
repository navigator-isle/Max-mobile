---
tags: [trading, pse, stock, fin]
---
**FIN**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1996-11-15 → 2020-09-25 (5,839 trading days)
- Last close ₱1,139 (2020-09-25) · all-time high ₱2,326 (2018-01-12) · low ₱317.3 (1998-09-14) · now -51.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱1,067 start · H 1,067 L 1,001 · ₱8,150.3B/d
- 1997: ₱517.5 -51.5% · H 1,207 L 493.9 · ₱15,003.8B/d
- 1998: ₱577.0 +11.5% · H 649.9 L 317.3 · ₱28,128.0B/d
- 1999: ₱864.7 +49.9% · H 936.4 L 584.0 · ₱2,875.2B/d
- 2000: ₱554.1 -35.9% · H 867.2 L 490.6 · ₱15.6K/d
- 2001: ₱505.0 -8.9% · H 643.3 L 386.3 · ₱225.0M/d
- 2002: ₱371.4 -26.5% · H 589.9 L 366.0
- 2003: ₱439.1 +18.2% · H 467.7 L 331.3 · ₱272.5M/d
- 2004: ₱538.4 +22.6% · H 544.5 L 412.4 · ₱78.3M/d
- 2005: ₱613.6 +14.0% · H 649.6 L 515.2 · ₱157.6M/d
- 2006: ₱822.9 +34.1% · H 830.4 L 615.1 · ₱8.6B/d
- 2007: ₱864.4 +5.0% · H 1,017 L 791.8 · ₱697.2B/d
- 2008: ₱456.9 -47.1% · H 864.6 L 446.1 · ₱257.9B/d
- 2009: ₱670.0 +46.6% · H 689.5 L 382.9 · ₱188.2B/d
- 2010: ₱961.5 +43.5% · H 1,033 L 577.5 · ₱532.6B/d
- 2011: ₱968.9 +0.8% · H 1,044 L 818.8 · ₱648.4B/d
- 2012: ₱1,526 +57.5% · H 1,554 L 972.4 · ₱1,325.5B/d
- 2013: ₱1,428 -6.4% · H 1,918 L 1,383 · ₱2,063.9B/d
- 2014: ₱1,696 +18.8% · H 1,730 L 1,412 · ₱1,857.0B/d
- 2015: ₱1,551 -8.6% · H 1,889 L 1,501 · ₱1,948.1B/d
- 2016: ₱1,656 +6.8% · H 1,884 L 1,436 · ₱1,894.3B/d
- 2017: ₱2,230 +34.7% · H 2,230 L 1,657 · ₱2,333.0B/d
- 2018: ₱1,780 -20.2% · H 2,326 L 1,534 · ₱2,148.9B/d
- 2019: ₱1,864 +4.7% · H 1,965 L 1,663 · ₱1,999.2B/d
- 2020*: ₱1,139 -38.9% · H 1,847 L 1,077 · ₱1,198.7B/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
