---
tags: [trading, pse, stock, hvn]
---
**HVN**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-06-29 → 2021-03-12 (1,081 trading days)
- Last close ₱450.0 (2021-03-12) · all-time high ₱455.0 (2020-12-18) · low ₱12.52 (2016-11-15) · now -1.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱17.00 start · H 20.30 L 12.52 · ₱15.6M/d
- 2017: ₱22.00 +29.4% · H 22.00 L 15.22 · ₱1.6M/d
- 2018: ₱325.0 +1377.3% · H 330.0 L 21.00 · ₱11.3M/d
- 2019: ₱436.0 +34.2% · H 449.8 L 325.0 · ₱1.7M/d
- 2020: ₱441.0 +1.1% · H 455.0 L 280.0 · ₱7.1M/d
- 2021*: ₱450.0 +2.0% · H 450.0 L 440.0 · ₱290.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
