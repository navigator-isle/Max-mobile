---
tags: [trading, pse, stock, ati]
---
**ATI**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1996-01-25 → 2021-03-12 (4,193 trading days)
- Last close ₱15.50 (2021-03-12) · all-time high ₱21.60 (2019-07-12) · low ₱0.5000 (1998-09-14) · now -28.2% from high
- Cash dividends last 12 months ₱0.7030 = 4.5% yield
- Dividend events on record (2013 → 2026): 16

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱4.75 start · H 5.63 L 4.20 · ₱13.3M/d
- 1997: ₱2.50 -47.4% · H 6.10 L 2.00 · ₱6.6M/d
- 1998: ₱1.10 -56.0% · H 2.60 L 0.5000 · ₱848.5K/d
- 1999: ₱1.20 +9.1% · H 1.62 L 0.8500 · ₱683.6K/d
- 2000: ₱1.12 -6.7% · H 1.16 L 0.7200 · ₱647.1K/d
- 2001: ₱1.10 -1.8% · H 1.32 L 0.8800 · ₱2.6M/d
- 2002: ₱1.36 +23.6% · H 1.44 L 1.00 · ₱507.2K/d
- 2003: ₱1.34 -1.5% · H 1.76 L 1.10 · ₱742.6K/d
- 2004: ₱1.44 +7.5% · H 1.50 L 1.14 · ₱575.8K/d
- 2005: ₱1.72 +19.4% · H 2.00 L 1.40 · ₱841.1K/d
- 2006: ₱4.10 +138.4% · H 4.30 L 1.72 · ₱1.1M/d
- 2007: ₱4.00 -2.4% · H 6.70 L 3.60 · ₱2.7M/d
- 2008: ₱2.90 -27.5% · H 4.05 L 2.70 · ₱800.4K/d
- 2009: ₱4.00 +37.9% · H 4.25 L 2.60 · ₱326.2K/d
- 2010: ₱7.27 +81.7% · H 7.48 L 3.85 · ₱1.3M/d
- 2011: ₱8.25 +13.5% · H 8.30 L 7.00 · ₱503.7K/d
- 2012: ₱9.65 +17.0% · H 10.68 L 7.60 · ₱501.6K/d
- 2013: ₱11.00 +14.0% · H 15.80 L 9.64 · ₱953.0K/d · div ₱0.3500 (3.2%): 14May 0.35
- 2014: ₱11.80 +7.3% · H 12.54 L 10.00 · ₱644.1K/d · div ₱0.3500 (3.0%): 08May 0.35
- 2015: ₱11.70 -0.8% · H 14.48 L 10.90 · ₱2.1M/d · div ₱0.4100 (3.5%): 12May 0.41
- 2016: ₱10.56 -9.7% · H 11.96 L 10.00 · ₱294.3K/d · div ₱0.4100 (3.9%): 17May 0.41
- 2017: ₱11.82 +11.9% · H 12.40 L 10.26 · ₱381.4K/d · div ₱0.4300 (3.6%): 16May 0.43
- 2018: ₱13.88 +17.4% · H 16.94 L 11.00 · ₱1.6M/d · div ₱0.4500 (3.2%): 17May 0.45
- 2019: ₱18.50 +33.3% · H 21.60 L 14.02 · ₱1.5M/d · div ₱0.5625 (3.0%): 21May 0.5625
- 2020: ₱15.58 -15.8% · H 18.60 L 15.24 · ₱843.7K/d · div ₱0.7030 (4.5%): 24Apr 0.703
- 2021*: ₱15.50 -0.5% · H 15.80 L 14.52 · ₱3.7M/d · div ₱0.7030 (4.5%): 12May 0.703 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
