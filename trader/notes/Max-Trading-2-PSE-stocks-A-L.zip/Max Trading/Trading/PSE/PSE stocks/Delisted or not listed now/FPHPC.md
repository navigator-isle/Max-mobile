---
tags: [trading, pse, stock, fphpc]
---
**FPHPC**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-01-21 → 2020-09-30 (169 trading days)
- Last close ₱490.2 (2020-09-30) · all-time high ₱530.0 (2020-07-06) · low ₱430.0 (2019-02-12) · now -7.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱500.0 start · H 505.0 L 500.0 · ₱1.4M/d
- 2016: ₱505.0 +1.0% · H 515.0 L 500.0 · ₱6.1M/d
- 2017: ₱507.0 +0.4% · H 517.0 L 500.0 · ₱2.8M/d
- 2018: ₱465.0 -8.3% · H 517.0 L 451.0 · ₱2.7M/d
- 2019: ₱490.0 +5.4% · H 500.0 L 430.0 · ₱196.4K/d
- 2020*: ₱490.2 +0.0% · H 530.0 L 460.0 · ₱293.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
