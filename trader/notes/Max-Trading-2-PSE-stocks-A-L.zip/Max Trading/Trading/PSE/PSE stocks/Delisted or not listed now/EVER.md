---
tags: [trading, pse, stock, ever]
---
**EVER**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1996-09-16 → 2021-03-11 (4,009 trading days)
- Last close ₱0.0910 (2021-03-11) · all-time high ₱1.32 (1997-01-13) · low ₱0.0120 (2002-10-21) · now -93.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-10-21 (÷1.5), 2005-06-23 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱1.26 start · H 1.26 L 1.12 · ₱42.5M/d
- 1997: ₱0.4100 -67.5% · H 1.32 L 0.4100 · ₱9.9M/d
- 1998: ₱0.1100 -73.2% · H 0.5000 L 0.0700 · ₱2.5M/d
- 1999: ₱0.1800 +63.6% · H 0.4200 L 0.1000 · ₱2.3M/d
- 2000: ₱0.0500 -72.2% · H 0.2100 L 0.0400 · ₱313.9K/d
- 2001: ₱0.0250 -50.0% · H 0.0700 L 0.0200 · ₱59.9K/d
- 2002: ₱0.0150 -40.0% · H 0.0480 L 0.0120 · ₱21.1K/d
- 2003: ₱0.0180 +20.0% · H 0.0500 L 0.0130 · ₱46.7K/d
- 2004: ₱0.0290 +61.1% · H 0.0400 L 0.0160 · ₱149.2K/d
- 2005: ₱0.0240 -17.2% · H 0.0680 L 0.0230 · ₱411.4K/d
- 2006: ₱0.0625 +160.4% · H 0.0750 L 0.0230 · ₱510.4K/d
- 2007: ₱0.2200 +252.0% · H 0.3900 L 0.0575 · ₱5.2M/d
- 2008: ₱0.0800 -63.6% · H 0.2150 L 0.0700 · ₱279.9K/d
- 2009: ₱0.1000 +25.0% · H 0.1500 L 0.0700 · ₱298.3K/d
- 2010: ₱0.1000 +0.0% · H 0.1350 L 0.0900 · ₱218.6K/d
- 2011: ₱0.1500 +50.0% · H 0.2850 L 0.1000 · ₱1.2M/d
- 2012: ₱0.4000 +166.7% · H 0.4150 L 0.1520 · ₱3.4M/d
- 2013: ₱0.2100 -47.5% · H 0.4100 L 0.1770 · ₱1.8M/d
- 2014: ₱0.2030 -3.3% · H 0.3350 L 0.1800 · ₱1.8M/d
- 2015: ₱0.1600 -21.2% · H 0.2340 L 0.1560 · ₱270.8K/d
- 2016: ₱0.1250 -21.9% · H 0.1680 L 0.1230 · ₱108.2K/d
- 2017: ₱0.1480 +18.4% · H 0.1930 L 0.1250 · ₱434.3K/d
- 2018: ₱0.1210 -18.2% · H 0.1470 L 0.1030 · ₱43.0K/d
- 2019: ₱0.1000 -17.4% · H 0.1450 L 0.1000 · ₱161.6K/d
- 2020: ₱0.0850 -15.0% · H 0.1330 L 0.0510 · ₱278.4K/d
- 2021*: ₱0.0910 +7.1% · H 0.1170 L 0.0820 · ₱333.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
