---
tags: [trading, pse, stock, fjpb]
---
**FJPB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-03 → 2021-03-11 (293 trading days)
- Last close ₱3.30 (2021-03-11) · all-time high ₱7.60 (2016-08-02) · low ₱0.8000 (2008-11-19) · now -56.6% from high
- Cash dividends last 12 months ₱0.1000 = 3.0% yield
- Dividend events on record (2013 → 2026): 21

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.02 start · H 1.02 L 0.9200 · ₱14.3K/d
- 2007: ₱1.60 +56.9% · H 1.84 L 1.00 · ₱30.2K/d
- 2008: ₱0.8000 -50.0% · H 1.20 L 0.8000 · ₱13.9K/d
- 2009: ₱1.40 +75.0% · H 2.00 L 0.8500 · ₱49.2K/d
- 2010: ₱1.56 +11.4% · H 2.70 L 1.02 · ₱12.4K/d
- 2011: ₱2.34 +50.0% · H 2.48 L 1.15 · ₱72.0K/d
- 2012: ₱3.88 +65.8% · H 3.88 L 1.98 · ₱130.0K/d
- 2013: ₱3.97 +2.3% · H 3.99 L 2.34 · ₱64.9K/d
- 2014: ₱3.39 -14.6% · H 3.77 L 2.56 · ₱90.5K/d · div ₱0.2000 (5.9%): 17Jun 0.1, 16Jul 0.1
- 2015: ₱6.20 +82.9% · H 6.95 L 2.85 · ₱235.2K/d · div ₱0.2000 (3.2%): 29May 0.1, 29Jul 0.1
- 2016: ₱7.50 +21.0% · H 7.60 L 4.36 · ₱73.4K/d · div ₱0.2000 (2.7%): 17Aug 0.1, 16Sep 0.1
- 2017: ₱5.60 -25.3% · H 7.48 L 5.00 · ₱30.4K/d · div ₱0.2000 (3.6%): 16Aug 0.1, 18Sep 0.1
- 2018: ₱5.19 -7.3% · H 6.10 L 4.50 · ₱70.5K/d · div ₱0.2000 (3.9%): 10Aug 0.1, 11Sep 0.1
- 2019: ₱3.61 -30.4% · H 5.20 L 3.43 · ₱12.9K/d · div ₱0.2000 (5.5%): 18Sep 0.1, 18Oct 0.1
- 2020: ₱3.70 +2.5% · H 3.83 L 3.40 · ₱11.2K/d · div ₱0.1000 (2.7%): 28Aug 0.1
- 2021*: ₱3.30 -10.8% · H 4.22 L 3.30 · ₱31.2M/d · div ₱0.1000 (3.0%): 28Sep 0.1 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
