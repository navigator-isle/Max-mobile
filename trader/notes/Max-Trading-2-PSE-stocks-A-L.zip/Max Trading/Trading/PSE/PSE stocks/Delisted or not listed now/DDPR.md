---
tags: [trading, pse, stock, ddpr]
---
**DDPR**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-07-26 → 2020-10-09 (951 trading days)
- Last close ₱101.0 (2020-10-09) · all-time high ₱107.5 (2017-10-20) · low ₱94.60 (2018-11-05) · now -6.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱103.7 start · H 106.3 L 103.2 · ₱7.6M/d
- 2017: ₱106.7 +2.9% · H 107.5 L 103.0 · ₱3.7M/d
- 2018: ₱98.80 -7.4% · H 105.0 L 94.60 · ₱3.0M/d
- 2019: ₱100.5 +1.7% · H 102.0 L 95.10 · ₱2.2M/d
- 2020*: ₱101.0 +0.5% · H 103.4 L 97.25 · ₱3.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
