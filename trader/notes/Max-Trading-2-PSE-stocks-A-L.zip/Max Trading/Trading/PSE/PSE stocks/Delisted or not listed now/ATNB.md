---
tags: [trading, pse, stock, atnb]
---
**ATNB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-09-07 → 2021-03-10 (2,451 trading days)
- Last close ₱0.9000 (2021-03-10) · all-time high ₱1.58 (2018-08-08) · low ₱0.0900 (2013-01-16) · now -43.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.2000 start · H 0.3100 L 0.1480 · ₱210.0K/d
- 2007: ₱0.2800 +40.0% · H 0.3700 L 0.1500 · ₱2.0M/d
- 2008: ₱0.4700 +67.9% · H 0.7400 L 0.2280 · ₱2.3M/d
- 2009: ₱1.12 +139.4% · H 1.27 L 0.3800 · ₱2.5M/d
- 2010: ₱0.8450 -24.9% · H 1.12 L 0.6580 · ₱3.8M/d
- 2011: ₱0.2690 -68.2% · H 0.8500 L 0.2400 · ₱234.2K/d
- 2012: ₱0.0970 -63.9% · H 0.3450 L 0.0970 · ₱644.0K/d
- 2013: ₱0.1260 +29.9% · H 0.1690 L 0.0900 · ₱197.5K/d
- 2014: ₱0.2700 +114.3% · H 0.3240 L 0.1120 · ₱900.4K/d
- 2015: ₱0.2080 -23.0% · H 0.3400 L 0.2080 · ₱223.1K/d
- 2016: ₱0.3050 +46.6% · H 0.5000 L 0.1750 · ₱800.2K/d
- 2017: ₱0.4600 +50.8% · H 0.5500 L 0.3000 · ₱1.8M/d
- 2018: ₱1.42 +208.7% · H 1.58 L 0.4450 · ₱5.8M/d
- 2019: ₱0.9600 -32.4% · H 1.56 L 0.9300 · ₱1.1M/d
- 2020: ₱0.8800 -8.3% · H 1.08 L 0.3300 · ₱331.7K/d
- 2021*: ₱0.9000 +2.3% · H 1.00 L 0.8100 · ₱517.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
