---
tags: [trading, pse, stock, emp]
---
**EMP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2011-12-19 → 2021-03-12 (2,129 trading days)
- Last close ₱10.30 (2021-03-12) · all-time high ₱21.00 (2013-05-02) · low ₱3.50 (2012-02-29) · now -51.0% from high
- Cash dividends last 12 months ₱0.2300 = 2.2% yield
- Dividend events on record (2013 → 2026): 10

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱4.10 start · H 4.33 L 4.00 · ₱610.2K/d
- 2012: ₱7.51 +83.2% · H 10.28 L 3.50 · ₱2.5M/d
- 2013: ₱10.70 +42.5% · H 21.00 L 8.00 · ₱42.0M/d
- 2014: ₱10.38 -3.0% · H 12.72 L 10.14 · ₱82.6M/d · div ₱0.1600 (1.5%): 18Aug 0.16S
- 2015: ₱8.95 -13.8% · H 11.90 L 6.99 · ₱36.2M/d · div ₱0.1500 (1.7%): 30Jun 0.15
- 2016: ₱7.00 -21.8% · H 9.05 L 6.70 · ₱17.9M/d · div ₱0.1688 (2.4%): 27Jul 0.1688
- 2017: ₱7.35 +5.0% · H 8.25 L 5.99 · ₱14.1M/d · div ₱0.1865 (2.5%): 29Mar 0.1865
- 2018: ₱7.11 -3.3% · H 8.74 L 6.92 · ₱8.9M/d · div ₱0.1488 (2.1%): 26Apr 0.148834
- 2019: ₱7.21 +1.4% · H 7.77 L 7.00 · ₱12.2M/d
- 2020: ₱10.10 +40.1% · H 10.98 L 7.00 · ₱120.8M/d · div ₱0.1600 (1.6%): 02Jan 0.05, 13Aug 0.11
- 2021*: ₱10.30 +2.0% · H 10.88 L 9.91 · ₱12.0M/d · div ₱0.3200 (3.1%): 12Jan 0.12, 16Mar 0.09 (upcoming), 10Aug 0.11 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
