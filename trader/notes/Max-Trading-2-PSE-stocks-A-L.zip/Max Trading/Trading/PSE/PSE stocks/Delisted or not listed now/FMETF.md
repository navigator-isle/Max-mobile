---
tags: [trading, pse, stock, fmetf]
---
**FMETF**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2013-12-02 → 2021-03-12 (1,765 trading days)
- Last close ₱101.6 (2021-03-12) · all-time high ₱136.7 (2018-01-29) · low ₱71.20 (2020-03-19) · now -25.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱86.82 start · H 90.91 L 85.91 · ₱6.6M/d
- 2014: ₱106.4 +22.5% · H 108.2 L 86.36 · ₱2.6M/d
- 2015: ₱103.2 -3.0% · H 120.0 L 99.91 · ₱3.6M/d
- 2016: ₱102.7 -0.4% · H 120.8 L 90.73 · ₱2.8M/d
- 2017: ₱130.5 +27.0% · H 130.5 L 102.9 · ₱2.1M/d
- 2018: ₱111.5 -14.6% · H 136.7 L 103.2 · ₱2.8M/d
- 2019: ₱117.4 +5.3% · H 124.5 L 112.0 · ₱1.2M/d
- 2020: ₱108.0 -8.0% · H 117.6 L 71.20 · ₱3.0M/d
- 2021*: ₱101.6 -5.9% · H 110.5 L 100.2 · ₱3.1M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
