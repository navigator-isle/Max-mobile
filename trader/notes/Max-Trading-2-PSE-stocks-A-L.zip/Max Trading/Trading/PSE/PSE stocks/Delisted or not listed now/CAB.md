---
tags: [trading, pse, stock, cab]
---
**CAB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-11-21 → 2021-03-12 (521 trading days)
- Last close ₱56.60 (2021-03-12) · all-time high ₱155.0 (2016-12-27) · low ₱45.50 (2020-03-30) · now -63.5% from high
- Cash dividends last 12 months ₱1.30 = 2.3% yield
- Dividend events on record (2013 → 2026): 11

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱121.0 start · H 155.0 L 84.00 · ₱50.0K/d · div ₱1.09 (0.9%): 30Mar 1.092
- 2017: ₱83.00 -31.4% · H 120.0 L 82.00 · ₱25.9K/d · div ₱0.8454 (1.0%): 03Apr 0.845374
- 2018: ₱78.05 -6.0% · H 140.0 L 76.50 · ₱85.6K/d · div ₱0.9300 (1.2%): 26Mar 0.93
- 2019: ₱71.90 -7.9% · H 152.9 L 60.60 · ₱1.4M/d · div ₱1.15 (1.6%): 01Apr 1.15
- 2020: ₱60.10 -16.4% · H 87.10 L 45.50 · ₱238.5K/d · div ₱1.30 (2.2%): 07May 1.3
- 2021*: ₱56.60 -5.8% · H 67.00 L 54.20 · ₱38.0K/d · div ₱0.4500 (0.8%): 08Apr 0.45 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
