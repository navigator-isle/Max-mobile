---
tags: [trading, pse, stock, apb2r]
---
**APB2R**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2019-11-29 → 2020-10-07 (160 trading days)
- Last close ₱514.0 (2020-10-07) · all-time high ₱518.0 (2020-07-23) · low ₱485.0 (2020-04-01) · now -0.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱505.0 start · H 510.0 L 501.0 · ₱1.7M/d
- 2020*: ₱514.0 +1.8% · H 518.0 L 485.0 · ₱913.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
