---
tags: [trading, pse, stock, fbp2]
---
**FBP2**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-03-12 → 2020-02-11 (912 trading days)
- Last close ₱1,005 (2020-02-11) · all-time high ₱1,064 (2015-05-15) · low ₱960.0 (2019-06-28) · now -5.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱1,029 start · H 1,064 L 1,005 · ₱5.4M/d
- 2016: ₱1,028 -0.1% · H 1,048 L 1,008 · ₱3.5M/d
- 2017: ₱1,000 -2.7% · H 1,036 L 1,000 · ₱2.8M/d
- 2018: ₱997.0 -0.3% · H 1,009 L 966.0 · ₱2.7M/d
- 2019: ₱997.0 +0.0% · H 1,030 L 960.0 · ₱2.7M/d
- 2020*: ₱1,005 +0.8% · H 1,005 L 985.0 · ₱2.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
