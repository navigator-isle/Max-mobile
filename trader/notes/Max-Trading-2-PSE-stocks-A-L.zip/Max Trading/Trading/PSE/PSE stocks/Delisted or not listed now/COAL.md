---
tags: [trading, pse, stock, coal]
---
**COAL**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2012-10-23 → 2021-03-12 (1,892 trading days)
- Last close ₱0.3000 (2021-03-12) · all-time high ₱1.60 (2014-05-20) · low ₱0.1710 (2020-05-22) · now -81.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱1.02 start · H 1.50 L 1.02 · ₱36.4M/d
- 2013: ₱0.8400 -17.6% · H 1.11 L 0.8200 · ₱3.3M/d
- 2014: ₱0.9600 +14.3% · H 1.60 L 0.7800 · ₱10.4M/d
- 2015: ₱0.5800 -39.6% · H 0.9700 L 0.5600 · ₱829.9K/d
- 2016: ₱0.4500 -22.4% · H 0.5900 L 0.2900 · ₱916.4K/d
- 2017: ₱0.3100 -31.1% · H 0.5300 L 0.3000 · ₱506.9K/d
- 2018: ₱0.3000 -3.2% · H 0.3350 L 0.2850 · ₱167.9K/d
- 2019: ₱0.2700 -10.0% · H 0.3600 L 0.2650 · ₱167.3K/d
- 2020: ₱0.2900 +7.4% · H 0.3300 L 0.1710 · ₱291.0K/d
- 2021*: ₱0.3000 +3.4% · H 0.3600 L 0.2850 · ₱931.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
