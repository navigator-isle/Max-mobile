---
tags: [trading, pse, stock, kphb]
---
**KPHB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-10-04 → 2021-03-12 (485 trading days)
- Last close ₱4.50 (2021-03-12) · all-time high ₱7.48 (2016-03-31) · low ₱1.30 (2008-04-16) · now -39.8% from high
- Cash dividends last 12 months ₱0.1000 = 2.2% yield
- Dividend events on record (2013 → 2026): 11

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.50 start · H 1.90 L 1.48 · ₱32.7K/d
- 2007: ₱1.84 +22.7% · H 2.60 L 1.42 · ₱178.0K/d
- 2008: ₱2.00 +8.7% · H 2.55 L 1.30 · ₱76.8K/d
- 2009: ₱1.90 -5.0% · H 2.04 L 1.90 · ₱57.1K/d
- 2010: ₱2.65 +39.5% · H 3.95 L 1.92 · ₱89.6K/d
- 2011: ₱3.35 +26.4% · H 3.90 L 2.30 · ₱82.5K/d
- 2012: ₱5.00 +49.3% · H 5.00 L 3.36 · ₱70.2K/d
- 2013: ₱4.80 -4.0% · H 5.80 L 4.80 · ₱49.6K/d
- 2014: ₱5.10 +6.2% · H 7.00 L 4.30 · ₱49.1K/d · div ₱0.1000 (2.0%): 09Jun 0.1
- 2015: ₱4.99 -2.2% · H 7.20 L 4.80 · ₱37.0K/d · div ₱0.1000 (2.0%): 01Jul 0.1
- 2016: ₱7.18 +43.9% · H 7.48 L 4.51 · ₱121.7K/d · div ₱0.1000 (1.4%): 28Jun 0.1
- 2017: ₱5.70 -20.6% · H 6.48 L 5.10 · ₱136.2K/d · div ₱0.1000 (1.8%): 28Jun 0.1
- 2018: ₱4.91 -13.9% · H 6.57 L 2.94 · ₱93.2K/d · div ₱0.1000 (2.0%): 03Jul 0.1
- 2019: ₱5.79 +17.9% · H 6.30 L 4.85 · ₱341.9K/d · div ₱0.1000 (1.7%): 02Jul 0.1
- 2020: ₱5.06 -12.6% · H 6.80 L 4.68 · ₱3.0M/d · div ₱0.1000 (2.0%): 06Jul 0.1
- 2021*: ₱4.50 -11.1% · H 4.50 L 4.50 · ₱13.9K/d · div ₱0.1000 (2.2%): 05Jul 0.1 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
