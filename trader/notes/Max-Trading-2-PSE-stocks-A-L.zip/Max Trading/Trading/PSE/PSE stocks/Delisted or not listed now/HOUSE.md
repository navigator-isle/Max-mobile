---
tags: [trading, pse, stock, house]
---
**HOUSE**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2013-10-09 → 2021-03-12 (1,773 trading days)
- Last close ₱7.30 (2021-03-12) · all-time high ₱16.28 (2019-06-04) · low ₱4.90 (2017-10-17) · now -55.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 10

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱6.99 start · H 7.88 L 6.00 · ₱842.4K/d
- 2014: ₱7.12 +1.9% · H 8.56 L 6.00 · ₱23.3M/d · div ₱0.0500 (0.7%): 13Nov 0.05S
- 2015: ₱7.10 -0.3% · H 10.40 L 6.05 · ₱14.9M/d · div ₱0.2300 (3.2%): 27Feb 0.18, 05Aug 0.05
- 2016: ₱7.51 +5.8% · H 8.34 L 6.41 · ₱4.7M/d · div ₱0.3000 (4.0%): 11Feb 0.25, 16Nov 0.05S
- 2017: ₱6.73 -10.4% · H 7.78 L 4.90 · ₱4.1M/d · div ₱0.3000 (4.5%): 15Feb 0.25, 20Nov 0.05S
- 2018: ₱8.10 +20.4% · H 8.10 L 6.06 · ₱27.1M/d · div ₱0.5500 (6.8%): 14Feb 0.25, 15Nov 0.3
- 2019: ₱14.74 +82.0% · H 16.28 L 8.23 · ₱16.9M/d
- 2020: ₱8.24 -44.1% · H 14.86 L 6.41 · ₱3.4M/d
- 2021*: ₱7.30 -11.4% · H 8.24 L 7.15 · ₱525.6K/d · div ₱0.2000 (2.7%): 12Nov 0.2 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
