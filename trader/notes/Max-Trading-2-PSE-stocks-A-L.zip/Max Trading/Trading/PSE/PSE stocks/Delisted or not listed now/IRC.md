---
tags: [trading, pse, stock, irc]
---
**IRC**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1986-01-29 → 2021-03-12 (6,106 trading days)
- Last close ₱1.50 (2021-03-12) · all-time high ₱3.00 (1997-01-29) · low ₱0.1200 (2002-10-18) · now -50.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-10-08 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1986: ₱0.6600 start · H 0.6900 L 0.5500 · ₱262.1K/d
- 1987: ₱0.6200 -6.1% · H 0.8750 L 0.6000 · ₱400.0K/d
- 1988: ₱1.40 +125.8% · H 1.50 L 0.5800 · ₱1.1M/d
- 1989: ₱1.95 +39.3% · H 2.65 L 1.40 · ₱2.7M/d
- 1990: ₱1.00 -48.7% · H 2.15 L 0.9250 · ₱643.8K/d
- 1991: ₱1.70 +70.0% · H 2.95 L 0.9750 · ₱2.1M/d
- 1992: ₱1.50 -11.8% · H 1.90 L 1.10 · ₱808.1K/d
- 1993: ₱2.10 +40.0% · H 2.10 L 1.20 · ₱483.3K/d
- 1994: ₱1.90 -9.5% · H 2.80 L 1.10 · ₱7.7M/d
- 1995: ₱1.50 -21.1% · H 2.50 L 1.40 · ₱3.5M/d
- 1996: ₱2.40 +60.0% · H 2.50 L 1.20 · ₱2.7M/d
- 1997: ₱0.8000 -66.7% · H 3.00 L 0.8000 · ₱3.4M/d
- 1998: ₱0.8000 +0.0% · H 1.60 L 0.4000 · ₱194.7K/d
- 1999: ₱1.40 +75.0% · H 2.00 L 0.4600 · ₱1.5M/d
- 2000: ₱0.6500 -53.6% · H 1.50 L 0.4400 · ₱703.2K/d
- 2001: ₱0.3400 -47.7% · H 0.9000 L 0.2600 · ₱35.8K/d
- 2002: ₱0.1400 -58.8% · H 0.5500 L 0.1200 · ₱37.9K/d
- 2003: ₱0.3800 +171.4% · H 0.4000 L 0.1400 · ₱42.5K/d
- 2004: ₱0.3400 -10.5% · H 0.4600 L 0.3000 · ₱103.7K/d
- 2005: ₱0.3400 +0.0% · H 0.7000 L 0.3200 · ₱107.5K/d
- 2006: ₱0.8500 +150.0% · H 1.00 L 0.3400 · ₱362.4K/d
- 2007: ₱1.30 +52.9% · H 1.50 L 0.8000 · ₱1.2M/d
- 2008: ₱0.6900 -46.9% · H 1.00 L 0.5000 · ₱377.0K/d
- 2009: ₱0.8000 +15.9% · H 0.9000 L 0.4000 · ₱101.0K/d
- 2010: ₱0.8300 +3.7% · H 0.9600 L 0.6100 · ₱106.3K/d
- 2011: ₱0.7200 -13.3% · H 1.00 L 0.6200 · ₱109.4K/d
- 2012: ₱1.24 +72.2% · H 2.06 L 0.7400 · ₱2.3M/d
- 2013: ₱1.35 +8.9% · H 1.66 L 1.10 · ₱3.2M/d
- 2014: ₱1.49 +10.4% · H 1.74 L 1.20 · ₱3.3M/d
- 2015: ₱1.13 -24.2% · H 1.55 L 1.13 · ₱679.3K/d
- 2016: ₱1.25 +10.6% · H 1.43 L 1.00 · ₱347.8K/d
- 2017: ₱0.7400 -40.8% · H 1.40 L 0.7100 · ₱2.1M/d
- 2018: ₱2.25 +204.1% · H 2.85 L 0.6800 · ₱25.9M/d
- 2019: ₱1.25 -44.4% · H 2.44 L 1.25 · ₱7.6M/d
- 2020: ₱1.41 +12.8% · H 1.74 L 0.5900 · ₱3.7M/d
- 2021*: ₱1.50 +6.4% · H 1.67 L 1.29 · ₱7.6M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
