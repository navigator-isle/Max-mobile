---
tags: [trading, pse, stock, blfi]
---
**BLFI**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1997-01-06 → 2020-01-24 (3,466 trading days)
- Last close ₱3.16 (2020-01-24) · all-time high ₱4.45 (2017-02-23) · low ₱0.1212 (1998-01-26) · now -29.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1997: ₱0.2424 start · H 2.58 L 0.2182 · ₱8.4M/d
- 1998: ₱0.3212 +32.5% · H 0.6546 L 0.1212 · ₱737.6K/d
- 1999: ₱0.6000 +86.8% · H 1.73 L 0.3212 · ₱914.8K/d
- 2000: ₱0.5636 -6.1% · H 0.6818 L 0.4545 · ₱466.2K/d
- 2001: ₱0.1773 -68.5% · H 0.5909 L 0.1773 · ₱97.9K/d
- 2002: ₱0.3273 +84.6% · H 0.5000 L 0.2500 · ₱61.0K/d
- 2003: ₱0.6091 +86.1% · H 0.6818 L 0.2318 · ₱1.0M/d
- 2004: ₱0.6454 +6.0% · H 0.6636 L 0.6000 · ₱329.3K/d
- 2005: ₱1.02 +58.0% · H 1.13 L 0.6182 · ₱456.5K/d
- 2006: ₱1.02 +0.0% · H 1.06 L 0.9700 · ₱245.3K/d
- 2008: ₱1.04 start · H 1.96 L 1.00 · ₱982.2K/d
- 2009: ₱1.32 +26.9% · H 1.56 L 0.9300 · ₱233.9K/d
- 2010: ₱1.54 +16.7% · H 1.70 L 1.30 · ₱289.7K/d
- 2011: ₱1.61 +4.5% · H 1.90 L 1.42 · ₱111.2K/d
- 2012: ₱2.00 +24.2% · H 2.10 L 1.56 · ₱243.6K/d
- 2013: ₱2.00 +0.0% · H 2.40 L 1.85 · ₱280.7K/d · div ₱0.1500 (7.5%): 14May 0.15
- 2014: ₱2.15 +7.5% · H 2.25 L 1.96 · ₱191.0K/d · div ₱0.1500 (7.0%): 10Mar 0.15
- 2015: ₱2.45 +14.0% · H 2.55 L 2.11 · ₱169.4K/d · div ₱0.1750 (7.1%): 06Mar 0.175
- 2016: ₱3.79 +54.7% · H 4.20 L 2.40 · ₱804.0K/d · div ₱0.2000 (5.3%): 08Mar 0.2
- 2017: ₱3.82 +0.8% · H 4.45 L 3.70 · ₱181.5K/d · div ₱0.2000 (5.2%): 07Mar 0.2
- 2018: ₱2.19 -42.7% · H 3.91 L 2.14 · ₱200.9K/d · div ₱0.1000 (4.6%): 06Mar 0.1
- 2019: ₱1.87 -14.6% · H 2.44 L 1.76 · ₱349.0K/d
- 2020*: ₱3.16 +69.0% · H 3.16 L 1.85 · ₱2.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
