---
tags: [trading, pse, stock, gtppb]
---
**GTPPB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-10-27 → 2020-10-08 (656 trading days)
- Last close ₱1,015 (2020-10-08) · all-time high ₱1,049 (2017-10-13) · low ₱834.0 (2019-01-08) · now -3.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱1,020 start · H 1,030 L 1,004 · ₱4.2M/d
- 2017: ₱1,028 +0.8% · H 1,049 L 1,010 · ₱2.9M/d
- 2018: ₱900.0 -12.5% · H 1,030 L 881.5 · ₱1.9M/d
- 2019: ₱1,000 +11.1% · H 1,010 L 834.0 · ₱1.9M/d
- 2020*: ₱1,015 +1.5% · H 1,030 L 920.0 · ₱2.9M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
