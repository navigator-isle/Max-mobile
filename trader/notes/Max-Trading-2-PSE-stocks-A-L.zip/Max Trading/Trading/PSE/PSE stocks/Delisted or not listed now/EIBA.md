---
tags: [trading, pse, stock, eiba]
---
**EIBA**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2008-01-22 → 2009-05-14 (154 trading days)
- Last close ₱0.2600 (2009-05-14) · all-time high ₱0.4000 (2008-02-27) · low ₱0.1400 (2008-10-28) · now -35.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2008: ₱0.1500 start · H 0.4000 L 0.1400 · ₱661.7K/d
- 2009*: ₱0.2600 +73.3% · H 0.2600 L 0.1400 · ₱425.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
