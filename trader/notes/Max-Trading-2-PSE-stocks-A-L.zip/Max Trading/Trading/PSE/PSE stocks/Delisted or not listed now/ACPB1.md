---
tags: [trading, pse, stock, acpb1]
---
**ACPB1**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-11-05 → 2020-10-07 (994 trading days)
- Last close ₱515.0 (2020-10-07) · all-time high ₱549.5 (2016-12-06) · low ₱445.0 (2018-12-28) · now -6.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱501.0 start · H 501.0 L 490.0 · ₱3.0M/d
- 2015: ₱523.0 +4.4% · H 532.0 L 500.0 · ₱3.1M/d
- 2016: ₱545.0 +4.2% · H 549.5 L 516.0 · ₱3.6M/d
- 2017: ₱528.0 -3.1% · H 549.0 L 500.0 · ₱2.5M/d
- 2018: ₱445.0 -15.7% · H 531.0 L 445.0 · ₱1.3M/d
- 2019: ₱499.0 +12.1% · H 511.0 L 452.0 · ₱1.4M/d
- 2020*: ₱515.0 +3.2% · H 520.0 L 491.0 · ₱1.0M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
