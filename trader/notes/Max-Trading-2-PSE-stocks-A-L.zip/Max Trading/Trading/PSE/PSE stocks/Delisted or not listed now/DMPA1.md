---
tags: [trading, pse, stock, dmpa1]
---
**DMPA1**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2017-04-07 → 2020-10-09 (471 trading days)
- Last close ₱10.02 (2020-10-09) · all-time high ₱11.10 (2017-10-04) · low ₱9.50 (2020-09-01) · now -9.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱10.10 start · H 11.10 L 10.00 · ₱62.9K/d
- 2018: ₱10.00 -1.0% · H 10.70 L 10.00 · ₱82.7K/d
- 2019: ₱10.00 +0.0% · H 10.40 L 10.00 · ₱94.1K/d
- 2020*: ₱10.02 +0.2% · H 10.40 L 9.50 · ₱105.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
