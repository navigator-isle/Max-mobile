---
tags: [trading, pse, stock, cpv]
---
**CPV**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-05 → 2018-11-05 (560 trading days)
- Last close ₱6.80 (2018-11-05) · all-time high ₱7.40 (2018-03-01) · low ₱0.9000 (2006-04-28) · now -8.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 3
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-12-08 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.80 start · H 2.00 L 0.9000 · ₱113.5K/d
- 2007: ₱1.82 +1.1% · H 2.04 L 1.56 · ₱178.7K/d
- 2008: ₱1.26 -30.8% · H 1.84 L 1.26 · ₱100.8K/d
- 2009: ₱1.82 +44.4% · H 1.90 L 1.02 · ₱89.2K/d
- 2010: ₱2.00 +9.9% · H 2.00 L 1.60 · ₱293.6K/d
- 2011: ₱2.80 +40.0% · H 3.80 L 1.60 · ₱116.7K/d
- 2012: ₱5.00 +78.6% · H 5.60 L 2.50 · ₱186.1K/d
- 2013: ₱5.00 +0.0% · H 5.60 L 4.00 · ₱164.5K/d · div ₱0.1200 (2.4%): 30Oct 0.12
- 2014: ₱5.41 +8.2% · H 6.20 L 4.60 · ₱123.2K/d · div ₱0.1200 (2.2%): 20Nov 0.12
- 2015: ₱6.00 +10.9% · H 6.60 L 5.01 · ₱98.8K/d · div ₱0.1200 (2.0%): 11Dec 0.12
- 2016: ₱5.99 -0.2% · H 6.00 L 5.41 · ₱380.9K/d
- 2017: ₱6.20 +3.5% · H 6.20 L 5.40 · ₱65.1K/d
- 2018*: ₱6.80 +9.7% · H 7.40 L 5.76 · ₱85.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
