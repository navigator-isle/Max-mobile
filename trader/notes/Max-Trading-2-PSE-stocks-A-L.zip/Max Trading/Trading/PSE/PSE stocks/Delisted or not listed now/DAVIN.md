---
tags: [trading, pse, stock, davin]
---
**DAVIN**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2010-06-17 → 2021-03-12 (1,890 trading days)
- Last close ₱3.50 (2021-03-12) · all-time high ₱8.98 (2021-02-11) · low ₱0.5000 (2011-02-15) · now -61.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱0.7000 start · H 0.9900 L 0.6200 · ₱151.9K/d
- 2011: ₱3.20 +357.1% · H 3.70 L 0.5000 · ₱157.3K/d
- 2012: ₱5.85 +82.8% · H 6.48 L 2.10 · ₱3.3M/d
- 2013: ₱0.8600 -85.3% · H 7.60 L 0.8600 · ₱3.3M/d
- 2014: ₱1.74 +102.3% · H 4.39 L 0.8600 · ₱12.2M/d
- 2015: ₱1.60 -8.0% · H 2.34 L 1.19 · ₱3.3M/d
- 2016: ₱6.47 +304.4% · H 7.95 L 1.63 · ₱13.7M/d
- 2017: ₱5.39 -16.7% · H 7.00 L 5.10 · ₱1.3M/d
- 2018: ₱6.50 +20.6% · H 7.16 L 4.00 · ₱923.8K/d
- 2019: ₱5.00 -23.1% · H 6.74 L 5.00 · ₱361.3K/d
- 2020: ₱5.28 +5.6% · H 6.03 L 3.10 · ₱898.7K/d
- 2021*: ₱3.50 -33.7% · H 8.98 L 3.15 · ₱41.1M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
