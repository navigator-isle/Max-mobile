---
tags: [trading, pse, stock, hlcm]
---
**HLCM**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1996-06-17 → 2021-03-12 (5,512 trading days)
- Last close ₱5.40 (2021-03-12) · all-time high ₱17.28 (2017-02-13) · low ₱0.4000 (2003-01-30) · now -68.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 7
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-12-26 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱8.70 start · H 10.25 L 7.90 · ₱22.4M/d
- 1997: ₱3.05 -64.9% · H 11.25 L 2.60 · ₱7.9M/d
- 1998: ₱1.78 -41.6% · H 5.90 L 0.5100 · ₱2.8M/d
- 1999: ₱1.32 -25.8% · H 1.96 L 1.00 · ₱4.0M/d
- 2000: ₱0.7000 -47.0% · H 1.28 L 0.6500 · ₱2.2M/d
- 2001: ₱0.9600 +37.1% · H 1.30 L 0.6000 · ₱1.7M/d
- 2002: ₱0.4500 -53.1% · H 0.9000 L 0.4300 · ₱570.3K/d
- 2003: ₱1.08 +140.0% · H 1.10 L 0.4000 · ₱425.4K/d
- 2004: ₱1.98 +83.3% · H 2.70 L 1.02 · ₱4.6M/d
- 2005: ₱4.40 +122.2% · H 4.60 L 2.00 · ₱13.4M/d
- 2006: ₱7.80 +77.3% · H 8.00 L 4.00 · ₱13.1M/d
- 2007: ₱7.70 -1.3% · H 9.20 L 5.20 · ₱17.0M/d
- 2008: ₱1.90 -75.3% · H 7.80 L 1.86 · ₱12.8M/d
- 2009: ₱4.80 +152.6% · H 5.30 L 1.82 · ₱1.4M/d
- 2010: ₱15.50 +222.9% · H 16.20 L 4.25 · ₱9.4M/d
- 2011: ₱9.40 -39.4% · H 15.00 L 7.80 · ₱4.1M/d
- 2012: ₱14.00 +48.9% · H 14.00 L 9.90 · ₱4.2M/d
- 2013: ₱15.50 +10.7% · H 15.68 L 12.00 · ₱6.3M/d · div ₱0.5500 (3.5%): 18Jun 0.55
- 2014: ₱14.98 -3.4% · H 15.60 L 12.82 · ₱3.6M/d · div ₱0.7000 (4.7%): 09Jun 0.7
- 2015: ₱14.24 -4.9% · H 15.18 L 12.00 · ₱879.9K/d · div ₱0.8200 (5.8%): 09Jun 0.82
- 2016: ₱16.50 +15.9% · H 17.08 L 13.30 · ₱3.3M/d · div ₱0.8700 (5.3%): 10Jun 0.87
- 2017: ₱10.78 -34.7% · H 17.28 L 10.74 · ₱3.2M/d · div ₱0.9800 (9.1%): 09Jun 0.98
- 2018: ₱5.80 -46.2% · H 10.78 L 5.80 · ₱1.7M/d · div ₱0.4200 (7.2%): 11Jun 0.42
- 2019: ₱13.60 +134.5% · H 15.30 L 5.79 · ₱21.2M/d
- 2020: ₱7.25 -46.7% · H 13.90 L 4.63 · ₱16.7M/d
- 2021*: ₱5.40 -25.5% · H 7.40 L 5.40 · ₱8.9M/d · div ₱0.4300 (8.0%): 11Jun 0.43 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
