---
tags: [trading, pse, stock, eagle]
---
**EAGLE**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2017-05-29 → 2021-03-12 (918 trading days)
- Last close ₱11.84 (2021-03-12) · all-time high ₱16.38 (2019-02-06) · low ₱5.90 (2020-03-19) · now -27.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱14.78 start · H 16.30 L 14.40 · ₱44.6M/d
- 2018: ₱15.46 +4.6% · H 16.30 L 13.90 · ₱15.8M/d · div ₱0.2310 (1.5%): 28May 0.231023
- 2019: ₱14.86 -3.9% · H 16.38 L 14.00 · ₱11.5M/d · div ₱0.2600 (1.7%): 09Jul 0.26
- 2020: ₱14.48 -2.6% · H 16.10 L 5.90 · ₱9.2M/d
- 2021*: ₱11.84 -18.2% · H 14.50 L 11.80 · ₱4.9M/d · div ₱0.6600 (5.6%): 21May 0.33 (upcoming), 04Oct 0.33 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
