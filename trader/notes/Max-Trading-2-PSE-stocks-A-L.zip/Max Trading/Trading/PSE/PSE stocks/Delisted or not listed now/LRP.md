---
tags: [trading, pse, stock, lrp]
---
**LRP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2013-12-23 → 2019-12-20 (1,146 trading days)
- Last close ₱1.00 (2019-12-20) · all-time high ₱1.14 (2013-12-23) · low ₱0.9700 (2019-03-21) · now -12.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱1.02 start · H 1.14 L 1.02 · ₱65.3M/d
- 2014: ₱1.03 +1.0% · H 1.06 L 0.9900 · ₱1.3M/d
- 2015: ₱1.11 +7.8% · H 1.14 L 1.02 · ₱648.2K/d
- 2016: ₱1.04 -6.3% · H 1.12 L 0.9900 · ₱775.3K/d
- 2017: ₱1.04 +0.0% · H 1.10 L 1.02 · ₱257.0K/d
- 2018: ₱1.02 -1.9% · H 1.07 L 1.00 · ₱193.4K/d
- 2019*: ₱1.00 -2.0% · H 1.06 L 0.9700 · ₱531.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
