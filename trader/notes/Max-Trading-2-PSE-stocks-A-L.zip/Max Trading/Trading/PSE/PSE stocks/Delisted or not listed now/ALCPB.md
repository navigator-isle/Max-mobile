---
tags: [trading, pse, stock, alcpb]
---
**ALCPB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-12-06 → 2020-10-01 (427 trading days)
- Last close ₱100.8 (2020-10-01) · all-time high ₱109.0 (2018-02-01) · low ₱95.45 (2018-11-16) · now -7.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱102.6 start · H 104.0 L 101.5 · ₱5.4M/d
- 2017: ₱108.0 +5.3% · H 108.5 L 102.5 · ₱1.9M/d
- 2018: ₱101.0 -6.5% · H 109.0 L 95.45 · ₱777.9K/d
- 2019: ₱101.3 +0.3% · H 105.0 L 96.00 · ₱719.3K/d
- 2020*: ₱100.8 -0.5% · H 104.7 L 98.00 · ₱444.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
