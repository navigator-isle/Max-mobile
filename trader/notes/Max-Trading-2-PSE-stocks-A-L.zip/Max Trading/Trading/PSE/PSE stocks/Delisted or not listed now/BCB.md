---
tags: [trading, pse, stock, bcb]
---
**BCB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-07 → 2021-03-12 (1,802 trading days)
- Last close ₱2.94 (2021-03-12) · all-time high ₱12.67 (2006-04-12) · low ₱0.8100 (2020-04-06) · now -76.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱8.25 start · H 12.67 L 6.67 · ₱320.9K/d
- 2007: ₱8.67 +5.1% · H 11.67 L 8.33 · ₱88.3K/d
- 2008: ₱3.20 -63.1% · H 12.67 L 2.17 · ₱64.8K/d
- 2009: ₱6.17 +92.7% · H 7.00 L 2.33 · ₱142.2K/d
- 2010: ₱5.27 -14.6% · H 6.50 L 3.67 · ₱64.2K/d
- 2011: ₱8.60 +63.3% · H 10.67 L 4.30 · ₱388.6K/d
- 2012: ₱6.67 -22.5% · H 10.93 L 6.00 · ₱1.0M/d
- 2013: ₱2.11 -68.3% · H 6.65 L 2.08 · ₱230.5K/d
- 2014: ₱2.67 +26.2% · H 4.13 L 2.11 · ₱204.7K/d
- 2015: ₱2.17 -18.7% · H 2.83 L 1.83 · ₱123.0K/d
- 2016: ₱2.32 +7.1% · H 3.80 L 1.07 · ₱236.3K/d
- 2017: ₱1.75 -24.6% · H 2.39 L 1.65 · ₱103.0K/d
- 2018: ₱1.50 -14.3% · H 1.96 L 1.02 · ₱66.7K/d
- 2019: ₱1.02 -32.0% · H 1.66 L 1.02 · ₱88.4K/d
- 2020: ₱3.00 +194.1% · H 3.20 L 0.8100 · ₱256.2K/d
- 2021*: ₱2.94 -2.0% · H 3.50 L 2.72 · ₱285.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
