---
tags: [trading, pse, stock, land]
---
**LAND**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1999-12-13 → 2021-03-12 (2,139 trading days)
- Last close ₱1.07 (2021-03-12) · all-time high ₱2.51 (2007-06-05) · low ₱0.3480 (2001-10-11) · now -57.4% from high
- Cash dividends last 12 months ₱0.0292 = 2.7% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1999: ₱1.25 start · H 1.28 L 1.15 · ₱613.4K/d
- 2000: ₱0.7592 -39.2% · H 1.25 L 0.6959 · ₱4.0M/d
- 2001: ₱0.4428 -41.7% · H 0.7782 L 0.3480 · ₱140.4K/d
- 2002: ₱0.5694 +28.6% · H 0.6327 L 0.3480 · ₱148.9K/d
- 2003: ₱0.5948 +4.5% · H 0.6327 L 0.5694 · ₱40.5K/d
- 2004: ₱0.6327 +6.4% · H 0.6327 L 0.5061 · ₱57.4K/d
- 2005: ₱0.4745 -25.0% · H 0.5503 L 0.3795 · ₱41.7K/d
- 2006: ₱1.42 +199.5% · H 1.42 L 0.4745 · ₱4.1M/d
- 2007: ₱1.20 -15.4% · H 2.51 L 1.04 · ₱84.1K/d
- 2008: ₱1.07 -10.9% · H 1.20 L 0.8198 · ₱49.1K/d
- 2009: ₱0.7653 -28.6% · H 1.09 L 0.6449 · ₱84.9K/d
- 2010: ₱0.8144 +6.4% · H 1.02 L 0.6559 · ₱49.0K/d
- 2011: ₱0.8198 +0.7% · H 1.17 L 0.7106 · ₱181.7K/d
- 2012: ₱1.55 +88.8% · H 1.93 L 0.8198 · ₱160.2K/d
- 2013: ₱1.34 -13.6% · H 1.69 L 1.20 · ₱158.2K/d · div ₱0.1100 (8.2%): 21Jun 0.11
- 2014: ₱1.05 -21.7% · H 1.53 L 1.05 · ₱221.8K/d · div ₱0.0700 (6.7%): 25Jun 0.07
- 2015: ₱0.9238 -11.8% · H 1.13 L 0.7714 · ₱125.3K/d · div ₱0.0190 (2.1%): 30Jun 0.019S
- 2016: ₱1.00 +8.2% · H 1.20 L 0.8571 · ₱110.1K/d · div ₱0.0180 (1.8%): 27Jun 0.018
- 2017: ₱1.10 +10.0% · H 1.42 L 0.9524 · ₱452.3K/d · div ₱0.0130 (1.2%): 22Jun 0.013
- 2018: ₱0.8500 -22.7% · H 1.15 L 0.8000 · ₱123.0K/d · div ₱0.0294 (3.5%): 30May 0.0294
- 2019: ₱0.7700 -9.4% · H 0.9300 L 0.7100 · ₱137.0K/d · div ₱0.0417 (5.4%): 19Jun 0.0417
- 2020: ₱0.7300 -5.2% · H 0.8000 L 0.5900 · ₱55.9K/d · div ₱0.0292 (4.0%): 15Sep 0.0292
- 2021*: ₱1.07 +46.6% · H 1.24 L 0.6800 · ₱3.0M/d · div ₱0.0139 (1.3%): 29Jun 0.01392 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
