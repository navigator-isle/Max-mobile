---
tags: [trading, pse, stock, acpa]
---
**ACPA**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2008-11-25 → 2013-11-08 (644 trading days)
- Last close ₱500.0 (2013-11-08) · all-time high ₱580.0 (2012-04-12) · low ₱489.0 (2013-11-05) · now -13.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2008: ₱497.5 start · H 510.0 L 497.5 · ₱332.4K/d
- 2009: ₱525.0 +5.5% · H 530.0 L 497.5 · ₱6.5M/d
- 2010: ₱535.0 +1.9% · H 550.0 L 515.0 · ₱2.1M/d
- 2011: ₱550.0 +2.8% · H 553.0 L 521.5 · ₱856.2K/d
- 2012: ₱520.0 -5.5% · H 580.0 L 518.0 · ₱546.4K/d
- 2013*: ₱500.0 -3.8% · H 540.0 L 489.0 · ₱873.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
