---
tags: [trading, pse, stock, dmpa2]
---
**DMPA2**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2017-12-15 → 2020-10-01 (299 trading days)
- Last close ₱10.30 (2020-10-01) · all-time high ₱10.50 (2019-08-16) · low ₱9.60 (2020-04-15) · now -1.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱10.20 start · H 10.30 L 10.06 · ₱127.3K/d
- 2018: ₱10.10 -1.0% · H 10.40 L 9.70 · ₱77.9K/d
- 2019: ₱10.28 +1.8% · H 10.50 L 9.70 · ₱53.8K/d
- 2020*: ₱10.30 +0.2% · H 10.50 L 9.60 · ₱61.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
