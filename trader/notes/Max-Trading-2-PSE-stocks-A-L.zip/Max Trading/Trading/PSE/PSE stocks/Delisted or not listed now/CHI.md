---
tags: [trading, pse, stock, chi]
---
**CHI**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1994-02-14 → 2021-03-12 (5,064 trading days)
- Last close ₱7.01 (2021-03-12) · all-time high ₱8.59 (2012-03-29) · low ₱0.2300 (2001-08-24) · now -18.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 7

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱2.56 start · H 3.25 L 2.00 · ₱5.8M/d
- 1995: ₱1.84 -28.1% · H 2.60 L 1.78 · ₱1.9M/d
- 1996: ₱1.46 -20.9% · H 2.04 L 1.42 · ₱1.1M/d
- 1997: ₱1.00 -31.3% · H 2.12 L 1.00 · ₱1.6M/d
- 1998: ₱0.6500 -35.0% · H 1.04 L 0.4000 · ₱483.2K/d
- 1999: ₱0.8600 +32.3% · H 1.12 L 0.5400 · ₱225.8K/d
- 2000: ₱0.4000 -53.5% · H 0.9000 L 0.4000 · ₱82.6K/d
- 2001: ₱0.3100 -22.5% · H 0.4800 L 0.2300 · ₱140.3K/d
- 2002: ₱0.2500 -19.4% · H 0.4400 L 0.2500 · ₱78.9K/d
- 2003: ₱0.3300 +32.0% · H 0.3800 L 0.2600 · ₱100.3K/d
- 2004: ₱0.5400 +63.6% · H 0.5400 L 0.3300 · ₱262.5K/d
- 2005: ₱1.10 +103.7% · H 1.20 L 0.4900 · ₱1.0M/d
- 2006: ₱3.20 +190.9% · H 3.40 L 1.12 · ₱4.0M/d
- 2007: ₱3.60 +12.5% · H 4.70 L 3.15 · ₱2.4M/d
- 2008: ₱1.56 -56.7% · H 3.50 L 1.30 · ₱1.1M/d
- 2009: ₱2.50 +60.3% · H 2.50 L 1.36 · ₱1.0M/d
- 2010: ₱2.70 +8.0% · H 3.26 L 1.90 · ₱386.0K/d
- 2011: ₱2.50 -7.4% · H 2.98 L 2.20 · ₱1.4M/d
- 2012: ₱4.00 +60.0% · H 8.59 L 2.50 · ₱18.4M/d
- 2013: ₱5.73 +43.3% · H 6.69 L 3.73 · ₱9.5M/d · div ₱0.1100 (1.9%): 30Oct 0.11
- 2014: ₱5.16 -9.9% · H 5.88 L 5.00 · ₱2.0M/d · div ₱0.1200 (2.3%): 20Nov 0.12
- 2015: ₱5.18 +0.4% · H 5.43 L 4.65 · ₱3.5M/d · div ₱0.1200 (2.3%): 11Dec 0.12
- 2016: ₱4.90 -5.4% · H 5.31 L 4.30 · ₱369.7K/d · div ₱0.1200 (2.4%): 28Nov 0.12
- 2017: ₱5.75 +17.3% · H 5.87 L 5.01 · ₱638.7K/d · div ₱0.1500 (2.6%): 15Dec 0.15
- 2018: ₱6.37 +10.8% · H 6.50 L 5.00 · ₱2.1M/d · div ₱0.1500 (2.4%): 10Dec 0.15
- 2019: ₱6.80 +6.8% · H 6.98 L 5.81 · ₱249.2K/d · div ₱0.1500 (2.2%): 06Dec 0.15
- 2020: ₱5.90 -13.2% · H 6.90 L 5.50 · ₱221.1K/d
- 2021*: ₱7.01 +18.8% · H 7.20 L 5.48 · ₱779.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
