---
tags: [trading, pse, stock, all]
---
**ALL**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1996-11-15 → 2020-09-25 (5,839 trading days)
- Last close ₱3,521 (2020-09-25) · all-time high ₱5,273 (2018-01-29) · low ₱372.9 (1998-09-11) · now -33.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱1,019 start · H 1,021 L 999.2 · ₱6,956,936.5B/d
- 1997: ₱570.1 -44.1% · H 1,142 L 550.6 · ₱7,798,733.3B/d
- 1998: ₱622.3 +9.1% · H 710.6 L 372.9 · ₱683,753.3B/d
- 1999: ₱720.4 +15.8% · H 860.2 L 605.9 · ₱685,076.7B/d
- 2000: ₱829.9 +15.2% · H 829.9 L 586.5
- 2001: ₱682.9 -17.7% · H 837.4 L 618.0 · ₱29.2K/d
- 2002: ₱608.8 -10.8% · H 776.0 L 565.0 · ₱2.2M/d
- 2003: ₱874.8 +43.7% · H 874.8 L 606.2 · ₱251.1M/d
- 2004: ₱1,154 +32.0% · H 1,174 L 892.3 · ₱355.5M/d
- 2005: ₱1,273 +10.3% · H 1,287 L 1,118
- 2006: ₱1,860 +46.1% · H 1,860 L 1,269
- 2007: ₱2,217 +19.2% · H 2,437 L 1,840
- 2008: ₱1,197 -46.0% · H 2,216 L 1,138
- 2009: ₱1,919 +60.3% · H 1,926 L 1,163
- 2010: ₱3,006 +56.7% · H 3,006 L 1,799
- 2011: ₱3,045 +1.3% · H 3,147 L 2,701
- 2012: ₱3,699 +21.5% · H 3,731 L 3,057
- 2013: ₱3,614 -2.3% · H 4,567 L 3,516
- 2014: ₱4,265 +18.0% · H 4,341 L 3,590
- 2015: ₱3,990 -6.4% · H 4,635 L 3,872
- 2016: ₱4,156 +4.1% · H 4,846 L 3,520
- 2017: ₱4,990 +20.1% · H 4,990 L 4,167
- 2018: ₱4,518 -9.5% · H 5,273 L 4,211
- 2019: ₱4,650 +2.9% · H 5,044 L 4,521
- 2020*: ₱3,521 -24.3% · H 4,656 L 2,882

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
