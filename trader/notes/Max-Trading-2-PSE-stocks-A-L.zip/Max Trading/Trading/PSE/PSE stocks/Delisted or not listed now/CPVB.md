---
tags: [trading, pse, stock, cpvb]
---
**CPVB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-10 → 2018-11-05 (355 trading days)
- Last close ₱7.00 (2018-11-05) · all-time high ₱7.98 (2018-02-27) · low ₱0.9600 (2006-04-10) · now -12.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.90 start · H 2.10 L 0.9600 · ₱155.0K/d
- 2007: ₱1.82 -4.2% · H 2.06 L 1.70 · ₱196.9K/d
- 2008: ₱1.40 -23.1% · H 1.80 L 1.40 · ₱67.5K/d
- 2009: ₱1.82 +30.0% · H 1.92 L 1.72 · ₱151.1K/d
- 2010: ₱2.00 +9.9% · H 2.00 L 1.14 · ₱90.6K/d
- 2011: ₱2.65 +32.5% · H 2.65 L 2.00 · ₱186.2K/d
- 2012: ₱5.10 +92.5% · H 5.20 L 2.43 · ₱147.2K/d
- 2013: ₱5.20 +2.0% · H 5.50 L 4.75 · ₱176.2K/d · div ₱0.1200 (2.3%): 30Oct 0.12
- 2014: ₱6.30 +21.2% · H 7.00 L 4.60 · ₱110.7K/d
- 2015: ₱6.10 -3.2% · H 6.50 L 5.61 · ₱178.6K/d · div ₱0.1200 (2.0%): 11Dec 0.12
- 2016: ₱6.33 +3.8% · H 6.35 L 5.70 · ₱86.2K/d
- 2017: ₱6.20 -2.1% · H 6.49 L 5.50 · ₱42.2K/d
- 2018*: ₱7.00 +12.9% · H 7.98 L 5.82 · ₱27.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
