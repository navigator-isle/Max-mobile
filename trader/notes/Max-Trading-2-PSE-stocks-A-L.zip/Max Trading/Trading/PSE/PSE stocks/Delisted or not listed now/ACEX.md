---
tags: [trading, pse, stock, acex]
---
**ACEX**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-08-28 → 2021-03-12 (1,541 trading days)
- Last close ₱25.00 (2021-03-12) · all-time high ₱26.80 (2021-03-05) · low ₱1.71 (2016-01-26) · now -6.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-08-17 (÷2), 2015-08-18 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱4.20 start · H 7.40 L 3.95 · ₱3.8M/d
- 2015: ₱2.28 -45.7% · H 12.26 L 2.09 · ₱4.4M/d
- 2016: ₱3.00 +31.6% · H 4.65 L 1.71 · ₱2.1M/d
- 2017: ₱2.02 -32.7% · H 3.08 L 2.00 · ₱160.3K/d
- 2018: ₱3.37 +66.8% · H 4.70 L 2.00 · ₱729.4K/d
- 2019: ₱7.32 +117.2% · H 13.14 L 2.99 · ₱10.1M/d
- 2020: ₱11.50 +57.1% · H 12.30 L 4.70 · ₱2.8M/d
- 2021*: ₱25.00 +117.4% · H 26.80 L 12.22 · ₱20.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
