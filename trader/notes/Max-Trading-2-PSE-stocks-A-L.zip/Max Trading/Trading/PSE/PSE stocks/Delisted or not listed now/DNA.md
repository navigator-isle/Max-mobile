---
tags: [trading, pse, stock, dna]
---
**DNA**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2009-09-03 → 2018-05-17 (1,172 trading days)
- Last close ₱2.86 (2018-05-17) · all-time high ₱74.40 (2016-05-17) · low ₱0.7500 (2009-10-28) · now -96.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2016-07-21 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2009: ₱0.9500 start · H 1.12 L 0.7500 · ₱43.7K/d
- 2010: ₱1.04 +10.0% · H 1.10 L 0.7625 · ₱15.6K/d
- 2011: ₱1.10 +5.3% · H 1.19 L 1.04 · ₱33.9K/d
- 2012: ₱2.12 +93.2% · H 2.62 L 1.05 · ₱214.0K/d
- 2013: ₱2.75 +29.4% · H 4.50 L 1.81 · ₱39.2K/d
- 2014: ₱17.50 +536.4% · H 18.62 L 2.50 · ₱151.7K/d
- 2015: ₱16.40 -6.3% · H 22.45 L 13.20 · ₱290.1K/d
- 2016: ₱9.10 -44.5% · H 74.40 L 8.91 · ₱17.9M/d
- 2017: ₱3.74 -58.9% · H 9.27 L 3.00 · ₱1.5M/d
- 2018*: ₱2.86 -23.5% · H 4.79 L 2.81 · ₱2.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
