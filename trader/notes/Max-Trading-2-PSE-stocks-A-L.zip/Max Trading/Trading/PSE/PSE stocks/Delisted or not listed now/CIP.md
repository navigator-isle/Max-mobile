---
tags: [trading, pse, stock, cip]
---
**CIP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2011-12-28 → 2021-02-26 (753 trading days)
- Last close ₱142.2 (2021-02-26) · all-time high ₱419.0 (2018-03-07) · low ₱41.00 (2011-12-28) · now -66.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2
- Splits / stock dividends detected (prices before these dates are as traded then): 2012-07-23 (÷1.5), 2014-01-16 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱61.50 start · H 61.50 L 41.00 · ₱21.1M/d
- 2012: ₱102.9 +67.3% · H 299.8 L 80.00 · ₱101.0K/d
- 2013: ₱210.0 +104.1% · H 258.0 L 73.00 · ₱477.6K/d
- 2014: ₱120.0 -42.9% · H 299.0 L 72.00 · ₱30.6K/d
- 2015: ₱100.0 -16.7% · H 243.0 L 85.00 · ₱56.9K/d
- 2016: ₱142.0 +42.0% · H 230.0 L 97.00 · ₱66.3K/d · div ₱17.24 (12.1%): 11Nov 17.236S
- 2017: ₱188.0 +32.4% · H 198.5 L 140.8 · ₱180.7K/d
- 2018: ₱169.0 -10.1% · H 419.0 L 155.2 · ₱124.8K/d · div ₱17.17 (10.2%): 04Jan 17.17S
- 2019: ₱170.0 +0.6% · H 175.0 L 100.0 · ₱140.9K/d
- 2020: ₱126.8 -25.4% · H 228.0 L 104.0 · ₱161.1K/d
- 2021*: ₱142.2 +12.1% · H 170.0 L 127.8 · ₱44.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
