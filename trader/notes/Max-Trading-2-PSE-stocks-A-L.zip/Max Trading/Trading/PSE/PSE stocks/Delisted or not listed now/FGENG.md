---
tags: [trading, pse, stock, fgeng]
---
**FGENG**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2012-05-18 → 2020-10-06 (1,291 trading days)
- Last close ₱107.0 (2020-10-06) · all-time high ₱128.0 (2015-06-22) · low ₱99.00 (2018-08-20) · now -16.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱101.5 start · H 105.5 L 100.2 · ₱3.0M/d
- 2013: ₱112.0 +10.3% · H 117.0 L 101.5 · ₱2.6M/d
- 2014: ₱107.0 -4.5% · H 115.0 L 101.8 · ₱2.9M/d
- 2015: ₱118.0 +10.3% · H 128.0 L 105.0 · ₱1.8M/d
- 2016: ₱121.0 +2.5% · H 125.0 L 108.0 · ₱8.3M/d
- 2017: ₱117.0 -3.3% · H 121.9 L 108.1 · ₱1.7M/d
- 2018: ₱101.2 -13.5% · H 115.9 L 99.00 · ₱1.9M/d
- 2019: ₱111.9 +10.6% · H 113.0 L 100.0 · ₱6.7M/d
- 2020*: ₱107.0 -4.4% · H 111.9 L 100.1 · ₱1.6M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
