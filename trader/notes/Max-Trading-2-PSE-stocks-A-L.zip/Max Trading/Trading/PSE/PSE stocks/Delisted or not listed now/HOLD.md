---
tags: [trading, pse, stock, hold]
---
**HOLD**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-01-02 → 2021-03-12 (3,691 trading days)
- Last close ₱6,949 (2021-03-12) · all-time high ₱9,363 (2018-01-29) · low ₱797.2 (2008-12-05) · now -25.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1,731 start · H 1,731 L 989.8 · ₱208.5B/d
- 2007: ₱2,037 +17.6% · H 2,309 L 1,593 · ₱1,662.1B/d
- 2008: ₱897.5 -55.9% · H 1,992 L 797.2 · ₱493.6B/d
- 2009: ₱1,612 +79.6% · H 1,638 L 855.5 · ₱655.2B/d
- 2010: ₱3,389 +110.3% · H 3,568 L 1,522 · ₱2,489.1B/d
- 2011: ₱3,504 +3.4% · H 3,676 L 2,884 · ₱3,947.0B/d
- 2012: ₱5,151 +47.0% · H 5,166 L 3,503 · ₱6,147.2B/d
- 2013: ₱5,429 +5.4% · H 6,659 L 4,930 · ₱12,716.0B/d
- 2014: ₱6,300 +16.0% · H 6,449 L 5,280 · ₱12,596.3B/d
- 2015: ₱6,601 +4.8% · H 7,265 L 6,153 · ₱15,146.1B/d
- 2016: ₱6,992 +5.9% · H 7,995 L 5,682 · ₱14,448.7B/d
- 2017: ₱8,617 +23.2% · H 8,777 L 7,011 · ₱13,881.7B/d
- 2018: ₱7,342 -14.8% · H 9,363 L 6,691 · ₱12,812.5B/d
- 2019: ₱7,592 +3.4% · H 8,113 L 6,995 · ₱14,746.3B/d
- 2020: ₱7,355 -3.1% · H 7,729 L 4,436 · ₱9,961.2B/d
- 2021*: ₱6,949 -5.5% · H 7,433 L 6,742 · ₱13,502.5B/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
