---
tags: [trading, pse, stock, fbp]
---
**FBP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2011-03-03 → 2015-02-11 (858 trading days)
- Last close ₱1,011 (2015-02-11) · all-time high ₱1,080 (2013-05-20) · low ₱995.0 (2011-04-04) · now -6.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱1,020 start · H 1,030 L 995.0 · ₱5.0M/d
- 2012: ₱1,018 -0.2% · H 1,050 L 1,005 · ₱3.3M/d
- 2013: ₱1,045 +2.7% · H 1,080 L 1,010 · ₱7.5M/d
- 2014: ₱1,009 -3.4% · H 1,060 L 997.0 · ₱8.0M/d
- 2015*: ₱1,011 +0.2% · H 1,021 L 1,000 · ₱4.9M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
