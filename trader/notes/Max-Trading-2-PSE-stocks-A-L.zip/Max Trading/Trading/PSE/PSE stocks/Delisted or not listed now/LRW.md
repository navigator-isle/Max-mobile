---
tags: [trading, pse, stock, lrw]
---
**LRW**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2013-12-23 → 2021-03-12 (1,706 trading days)
- Last close ₱2.05 (2021-03-12) · all-time high ₱6.88 (2014-11-21) · low ₱0.0800 (2013-12-23) · now -70.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2014-02-25 (÷0.5), 2016-08-25 (÷0.5), 2021-02-26 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱0.5000 start · H 0.6400 L 0.0800 · ₱2.3M/d
- 2014: ₱4.30 +760.0% · H 6.88 L 0.2650 · ₱9.4M/d
- 2015: ₱2.40 -44.2% · H 4.97 L 2.40 · ₱2.4M/d
- 2016: ₱2.10 -12.5% · H 3.75 L 1.10 · ₱2.6M/d
- 2017: ₱2.47 +17.6% · H 3.28 L 2.04 · ₱1.6M/d
- 2018: ₱1.95 -21.1% · H 4.87 L 1.54 · ₱4.3M/d
- 2019: ₱1.29 -33.8% · H 2.27 L 1.20 · ₱409.1K/d
- 2020: ₱1.02 -20.9% · H 1.33 L 0.5700 · ₱179.7K/d
- 2021*: ₱2.05 +101.0% · H 2.40 L 0.8100 · ₱18.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
