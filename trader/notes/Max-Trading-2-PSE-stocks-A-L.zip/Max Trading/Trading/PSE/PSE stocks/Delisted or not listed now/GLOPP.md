---
tags: [trading, pse, stock, glopp]
---
**GLOPP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-08-22 → 2020-10-09 (915 trading days)
- Last close ₱508.0 (2020-10-09) · all-time high ₱560.0 (2016-09-29) · low ₱420.0 (2020-01-27) · now -9.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱502.0 start · H 507.0 L 485.0 · ₱7.5M/d
- 2015: ₱522.0 +4.0% · H 535.0 L 497.0 · ₱2.7M/d
- 2016: ₱540.0 +3.4% · H 560.0 L 507.0 · ₱2.3M/d
- 2017: ₱523.0 -3.1% · H 541.0 L 512.0 · ₱1.7M/d
- 2018: ₱480.0 -8.2% · H 530.0 L 441.0 · ₱1.9M/d
- 2019: ₱500.0 +4.2% · H 509.5 L 478.0 · ₱1.9M/d
- 2020*: ₱508.0 +1.6% · H 524.5 L 420.0 · ₱787.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
