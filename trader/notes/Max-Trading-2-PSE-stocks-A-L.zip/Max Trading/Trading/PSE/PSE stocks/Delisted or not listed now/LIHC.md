---
tags: [trading, pse, stock, lihc]
---
**LIHC**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2007-11-21 → 2020-09-25 (3,080 trading days)
- Last close ₱0.6200 (2020-09-25) · all-time high ₱2.30 (2007-12-05) · low ₱0.1420 (2007-11-21) · now -73.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱1.60 start · H 2.30 L 0.1420 · ₱10.1M/d
- 2008: ₱0.3100 -80.6% · H 1.62 L 0.2800 · ₱7.6M/d
- 2009: ₱0.9500 +206.5% · H 1.27 L 0.1720 · ₱12.4M/d
- 2010: ₱0.7700 -18.9% · H 0.9500 L 0.4850 · ₱3.5M/d
- 2011: ₱0.7400 -3.9% · H 1.27 L 0.6600 · ₱9.0M/d
- 2012: ₱0.9600 +29.7% · H 1.49 L 0.7600 · ₱12.9M/d
- 2013: ₱0.6300 -34.4% · H 1.04 L 0.6100 · ₱454.9K/d
- 2014: ₱0.6200 -1.6% · H 0.8600 L 0.6000 · ₱394.1K/d
- 2015: ₱0.6900 +11.3% · H 0.8900 L 0.5400 · ₱582.4K/d
- 2016: ₱1.12 +62.3% · H 1.69 L 0.5000 · ₱4.6M/d
- 2017: ₱0.6900 -38.4% · H 1.31 L 0.6000 · ₱4.9M/d
- 2018: ₱0.5600 -18.8% · H 0.7700 L 0.4900 · ₱350.3K/d
- 2019: ₱0.5000 -10.7% · H 0.6800 L 0.4800 · ₱181.1K/d
- 2020*: ₱0.6200 +24.0% · H 0.7600 L 0.3750 · ₱935.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
