---
tags: [trading, pse, stock, 2go]
---
**2GO**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-03 → 2021-03-12 (2,884 trading days)
- Last close ₱9.10 (2021-03-12) · all-time high ₱29.15 (2017-06-05) · low ₱1.00 (2008-06-20) · now -68.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.30 start · H 1.68 L 1.14 · ₱158.7K/d
- 2007: ₱1.26 -3.1% · H 2.10 L 1.20 · ₱542.5K/d
- 2008: ₱1.64 +30.2% · H 1.90 L 1.00 · ₱434.2K/d
- 2009: ₱1.18 -28.0% · H 1.66 L 1.12 · ₱275.0K/d
- 2010: ₱1.83 +55.1% · H 1.94 L 1.02 · ₱535.3K/d
- 2011: ₱1.33 -27.3% · H 1.95 L 1.25 · ₱60.6K/d
- 2012: ₱1.62 +21.8% · H 4.45 L 1.33 · ₱326.3K/d
- 2013: ₱1.70 +4.9% · H 2.00 L 1.50 · ₱36.5K/d
- 2014: ₱3.34 +96.5% · H 5.50 L 1.70 · ₱977.3K/d
- 2015: ₱6.88 +106.0% · H 11.32 L 3.48 · ₱10.8M/d
- 2016: ₱7.64 +11.0% · H 8.20 L 6.00 · ₱2.1M/d
- 2017: ₱18.48 +141.9% · H 29.15 L 7.40 · ₱10.1M/d
- 2018: ₱13.78 -25.4% · H 22.85 L 9.60 · ₱2.5M/d
- 2019: ₱10.50 -23.8% · H 15.02 L 9.42 · ₱483.5K/d
- 2020: ₱8.30 -21.0% · H 11.50 L 4.19 · ₱1.4M/d
- 2021*: ₱9.10 +9.6% · H 9.23 L 8.20 · ₱9.8M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
