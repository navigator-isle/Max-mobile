---
tags: [trading, pse, stock, gtppa]
---
**GTPPA**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-10-27 → 2020-10-05 (453 trading days)
- Last close ₱1,002 (2020-10-05) · all-time high ₱1,050 (2017-10-13) · low ₱836.0 (2018-12-03) · now -4.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱1,016 start · H 1,030 L 1,003 · ₱5.0M/d
- 2017: ₱1,030 +1.4% · H 1,050 L 1,000 · ₱3.6M/d
- 2018: ₱900.0 -12.6% · H 1,010 L 836.0 · ₱2.7M/d
- 2019: ₱990.0 +10.0% · H 1,000 L 860.0 · ₱1.6M/d
- 2020*: ₱1,002 +1.2% · H 1,038 L 904.5 · ₱2.7M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
