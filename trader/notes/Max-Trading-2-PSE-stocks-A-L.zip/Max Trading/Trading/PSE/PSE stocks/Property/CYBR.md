---
tags: [trading, pse, stock, cybr]
---
**CYBR — Cyber Bay Corporation**
- Status: listed on PSE · sector Property › Property · listed Mar 19, 1991
- Data: 1991-03-19 → 2021-06-17 (5,772 trading days)
- Last close ₱0.3300 (2021-06-17) · all-time high ₱5.50 (1996-05-17) · low ₱0.1000 (2002-10-25) · now -94.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1991: ₱0.8200 start · H 1.02 L 0.8200 · ₱494.7K/d
- 1992: ₱1.20 +46.3% · H 1.34 L 0.7000 · ₱745.1K/d
- 1993: ₱2.95 +145.8% · H 2.95 L 1.02 · ₱951.6K/d
- 1994: ₱2.50 -15.3% · H 2.50 L 2.00 · ₱567.4K/d
- 1995: ₱2.70 +8.0% · H 4.00 L 1.76 · ₱354.9K/d
- 1996: ₱3.00 +11.1% · H 5.50 L 2.50 · ₱25.5M/d
- 1997: ₱0.2800 -90.7% · H 3.50 L 0.2700 · ₱11.4M/d
- 1998: ₱0.6800 +142.9% · H 0.7500 L 0.1900 · ₱2.1M/d
- 1999: ₱1.04 +52.9% · H 1.58 L 0.5900 · ₱11.1M/d
- 2000: ₱0.4200 -59.6% · H 1.16 L 0.2800 · ₱7.0M/d
- 2001: ₱0.3100 -26.2% · H 0.5500 L 0.2000 · ₱678.9K/d
- 2002: ₱0.1100 -64.5% · H 0.5700 L 0.1000 · ₱1.7M/d
- 2003: ₱0.1200 +9.1% · H 0.2600 L 0.1100 · ₱740.3K/d
- 2004: ₱0.1350 +12.5% · H 0.1800 L 0.1100 · ₱230.6K/d
- 2005: ₱0.2000 +48.1% · H 0.4100 L 0.1300 · ₱1.5M/d
- 2006: ₱0.3100 +55.0% · H 0.3500 L 0.1650 · ₱1.8M/d
- 2007: ₱0.3500 +12.9% · H 0.7800 L 0.2500 · ₱3.8M/d
- 2008: ₱0.2000 -42.9% · H 0.3800 L 0.1800 · ₱1.4M/d
- 2009: ₱0.5100 +155.0% · H 0.8000 L 0.1800 · ₱6.4M/d
- 2010: ₱0.6700 +31.4% · H 0.7700 L 0.5100 · ₱5.6M/d
- 2011: ₱0.7700 +14.9% · H 1.43 L 0.7000 · ₱20.3M/d
- 2012: ₱0.8100 +5.2% · H 1.07 L 0.7600 · ₱3.9M/d
- 2013: ₱0.5200 -35.8% · H 0.8200 L 0.4900 · ₱1.5M/d
- 2014: ₱0.4900 -5.8% · H 0.8700 L 0.4700 · ₱4.2M/d
- 2015: ₱0.4450 -9.2% · H 0.6000 L 0.3800 · ₱2.7M/d
- 2016: ₱0.5600 +25.8% · H 0.8200 L 0.3550 · ₱7.1M/d
- 2017: ₱0.4550 -18.8% · H 0.6700 L 0.4300 · ₱2.2M/d
- 2018: ₱0.3800 -16.5% · H 0.4950 L 0.3250 · ₱440.2K/d
- 2019: ₱0.3800 +0.0% · H 0.5000 L 0.3600 · ₱1.1M/d
- 2020: ₱0.3300 -13.2% · H 0.4350 L 0.2220 · ₱1.1M/d
- 2021*: ₱0.3300 +0.0% · H 0.4100 L 0.3100 · ₱951.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
