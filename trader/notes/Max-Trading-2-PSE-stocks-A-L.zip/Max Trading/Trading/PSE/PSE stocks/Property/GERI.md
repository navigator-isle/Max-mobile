---
tags: [trading, pse, stock, geri]
---
**GERI — Global-Estate Resorts, Inc.**
- Status: listed on PSE · sector Property › Property · listed Nov 23, 1995
- Data: 1995-11-23 → 2026-11-06 (6,696 trading days)
- Last close ₱0.6200 (2026-11-06) · all-time high ₱10.83 (1996-05-29) · low ₱0.1100 (2002-12-11) · now -94.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱6.32 start · H 6.63 L 6.32 · ₱44.7M/d
- 1996: ₱7.32 +15.7% · H 10.83 L 6.40 · ₱37.1M/d
- 1997: ₱1.01 -86.3% · H 7.62 L 0.9572 · ₱14.3M/d
- 1998: ₱0.7125 -29.2% · H 1.46 L 0.4801 · ₱6.3M/d
- 1999: ₱0.7863 +10.4% · H 1.54 L 0.4786 · ₱4.8M/d
- 2000: ₱0.3000 -61.8% · H 0.8889 L 0.2200 · ₱253.2K/d
- 2001: ₱0.1900 -36.7% · H 0.5500 L 0.1500 · ₱164.4K/d
- 2002: ₱0.1200 -36.8% · H 0.4600 L 0.1100 · ₱304.6K/d
- 2003: ₱0.1700 +41.7% · H 0.2600 L 0.1200 · ₱179.6K/d
- 2004: ₱0.5400 +217.6% · H 0.5921 L 0.1500 · ₱477.7K/d
- 2005: ₱0.4800 -11.1% · H 0.8400 L 0.3000 · ₱355.9K/d
- 2006: ₱0.6400 +33.3% · H 0.8900 L 0.3900 · ₱970.2K/d
- 2007: ₱0.9100 +42.2% · H 1.44 L 0.6500 · ₱14.0M/d
- 2008: ₱0.2450 -73.1% · H 0.9600 L 0.1750 · ₱767.7K/d
- 2009: ₱0.3000 +22.4% · H 0.3800 L 0.1600 · ₱1.1M/d
- 2010: ₱1.46 +386.7% · H 1.46 L 0.2600 · ₱10.1M/d
- 2011: ₱2.12 +45.2% · H 3.01 L 1.29 · ₱34.7M/d
- 2012: ₱1.96 -7.5% · H 2.39 L 1.70 · ₱12.6M/d
- 2013: ₱1.35 -31.1% · H 2.67 L 1.31 · ₱14.5M/d
- 2014: ₱1.70 +25.9% · H 2.20 L 1.23 · ₱12.9M/d
- 2015: ₱1.03 -39.4% · H 1.78 L 1.00 · ₱3.8M/d
- 2016: ₱1.00 -2.9% · H 1.21 L 0.8300 · ₱5.3M/d
- 2017: ₱1.43 +43.0% · H 1.84 L 0.9600 · ₱15.4M/d
- 2018: ₱1.13 -21.0% · H 1.59 L 0.9600 · ₱3.3M/d
- 2019: ₱1.20 +6.2% · H 1.46 L 1.11 · ₱2.0M/d
- 2020: ₱0.9200 -23.3% · H 1.20 L 0.6500 · ₱680.1K/d
- 2021: ₱1.01 +9.8% · H 1.33 L 0.8000 · ₱1.4M/d
- 2022: ₱0.9300 -7.9% · H 0.9800 L 0.7800 · ₱292.9K/d
- 2023: ₱0.9500 +2.2% · H 0.9500 L 0.7400 · ₱166.5K/d · div ₱0.0113 (1.2%): 25Jul 0.011295
- 2024: ₱0.6400 -32.6% · H 0.9400 L 0.5500 · ₱400.0K/d
- 2025: ₱0.6900 +7.8% · H 0.7100 L 0.5000 · ₱232.2K/d · div ₱0.0109 (1.6%): 17Jul 0.010923
- 2026*: ₱0.6200 -10.1% · H 0.7800 L 0.5700 · ₱181.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
