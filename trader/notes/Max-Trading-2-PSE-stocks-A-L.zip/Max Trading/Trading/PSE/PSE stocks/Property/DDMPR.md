---
tags: [trading, pse, stock, ddmpr]
---
**DDMPR — DDMP REIT, Inc.**
- Status: listed on PSE · sector Property › Property · listed Mar 24, 2021
- Data: 2021-03-24 → 2026-11-06 (1,377 trading days)
- Last close ₱1.04 (2026-11-06) · all-time high ₱2.28 (2021-04-06) · low ₱0.9800 (2024-08-21) · now -54.4% from high
- Cash dividends last 12 months ₱0.0725 = 7.0% yield
- Dividend events on record (2013 → 2026): 25

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱1.79 start · H 2.28 L 1.77 · ₱38.6M/d · div ₱0.0964 (5.4%): 23Apr 0.020477, 25May 0.020136, 25Aug 0.027778, 24Nov 0.028
- 2022: ₱1.29 -27.9% · H 1.81 L 1.18 · ₱4.1M/d · div ₱0.1103 (8.5%): 16May 0.027814, 03Jun 0.027868, 25Aug 0.027299, 07Dec 0.027273
- 2023: ₱1.21 -6.2% · H 1.47 L 1.18 · ₱1.9M/d · div ₱0.1235 (10.2%): 02May 0.02266, 02May 0.027273, 14Jun 0.02266, 14Jun 0.025389, 03Nov 0.025477
- 2024: ₱1.03 -14.9% · H 1.25 L 0.9800 · ₱2.4M/d · div ₱0.0959 (9.3%): 19Jan 0.025682, 06May 0.023137, 18Jun 0.023476, 30Oct 0.023561
- 2025: ₱1.02 -1.0% · H 1.10 L 1.02 · ₱2.1M/d · div ₱0.0929 (9.1%): 21Jan 0.023605, 06May 0.022568, 19Jun 0.023054, 29Oct 0.023702
- 2026*: ₱1.04 +2.0% · H 1.10 L 1.02 · ₱3.1M/d · div ₱0.0968 (9.3%): 29Jan 0.024043, 18May 0.024222, 30Jul 0.024253, 26Nov 0.024289 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
