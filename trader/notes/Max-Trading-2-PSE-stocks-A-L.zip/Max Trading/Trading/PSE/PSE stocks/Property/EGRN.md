---
tags: [trading, pse, stock, egrn]
---
**EGRN — Everwoods Green Resources and Holdings, Inc.**
- Status: listed on PSE · sector Property › Property · listed Sep 16, 1996
- Data: 2015-01-05 → 2026-11-06 (2,219 trading days)
- Last close ₱0.0250 (2026-11-06) · all-time high ₱0.6800 (2021-06-18) · low ₱0.0240 (2026-10-08) · now -96.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱0.1600 start · H 0.2340 L 0.1560 · ₱270.5K/d
- 2016: ₱0.1250 -21.9% · H 0.1680 L 0.1230 · ₱107.7K/d
- 2017: ₱0.1480 +18.4% · H 0.1930 L 0.1250 · ₱440.5K/d
- 2018: ₱0.1210 -18.2% · H 0.1470 L 0.1030 · ₱42.6K/d
- 2019: ₱0.1000 -17.4% · H 0.1450 L 0.1000 · ₱165.2K/d
- 2020: ₱0.0850 -15.0% · H 0.1330 L 0.0510 · ₱278.0K/d
- 2021: ₱0.3300 +288.2% · H 0.6800 L 0.0820 · ₱23.9M/d
- 2022: ₱0.2550 -22.7% · H 0.3450 L 0.2400 · ₱2.7M/d
- 2023: ₱0.2900 +13.7% · H 0.3000 L 0.2220 · ₱442.5K/d
- 2024: ₱0.2550 -12.1% · H 0.3000 L 0.2350 · ₱106.2K/d
- 2025: ₱0.2000 -21.6% · H 0.2850 L 0.1970 · ₱46.5K/d
- 2026*: ₱0.0250 -87.5% · H 0.0490 L 0.0240 · ₱89.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
