---
tags: [trading, pse, stock, areit]
---
**AREIT — AREIT, Inc.**
- Status: listed on PSE · sector Property › Property · listed Aug 13, 2020
- Data: 2020-08-13 → 2026-11-06 (1,523 trading days)
- Last close ₱36.00 (2026-11-06) · all-time high ₱52.35 (2022-02-23) · low ₱24.10 (2020-08-14) · now -31.2% from high
- Cash dividends last 12 months ₱2.49 = 6.9% yield
- Dividend events on record (2013 → 2026): 26

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2020: ₱29.35 start · H 29.90 L 24.10 · ₱57.4M/d · div ₱0.9300 (3.2%): 27Aug 0.28, 27Aug 0.31, 02Dec 0.34
- 2021: ₱48.60 +65.6% · H 49.65 L 28.95 · ₱33.9M/d · div ₱1.69 (3.5%): 10Mar 0.39, 08Jun 0.42, 23Aug 0.44, 01Oct 0.44
- 2022: ₱35.40 -27.2% · H 52.35 L 30.95 · ₱32.6M/d · div ₱1.93 (5.5%): 08Mar 0.47, 30May 0.48, 23Aug 0.49, 20Oct 0.49
- 2023: ₱33.40 -5.6% · H 36.35 L 29.05 · ₱24.2M/d · div ₱2.12 (6.3%): 07Mar 0.52, 26May 0.52, 29Aug 0.53, 30Nov 0.55
- 2024: ₱37.95 +13.6% · H 40.45 L 31.50 · ₱49.3M/d · div ₱2.25 (5.9%): 01Mar 0.55, 27May 0.56, 25Jul 0.56, 26Nov 0.58
- 2025: ₱43.50 +14.6% · H 45.50 L 38.10 · ₱65.9M/d · div ₱2.37 (5.4%): 04Mar 0.58, 26May 0.58, 28Aug 0.59, 25Nov 0.62
- 2026*: ₱36.00 -17.2% · H 44.70 L 35.70 · ₱50.4M/d · div ₱1.87 (5.2%): 04Mar 0.62, 26May 0.62, 24Aug 0.63

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
