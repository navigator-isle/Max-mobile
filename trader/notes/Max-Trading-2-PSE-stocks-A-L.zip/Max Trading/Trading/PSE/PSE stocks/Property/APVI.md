---
tags: [trading, pse, stock, apvi]
---
**APVI — Altus Property Ventures, Inc.**
- Status: listed on PSE · sector Property › Property · listed Jun 26, 2020
- Data: 2020-06-26 → 2026-11-06 (1,375 trading days)
- Last close ₱11.00 (2026-11-06) · all-time high ₱42.10 (2020-07-01) · low ₱8.10 (2025-03-06) · now -73.9% from high
- Cash dividends last 12 months ₱1.30 = 11.8% yield
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2020: ₱12.40 start · H 42.10 L 8.33 · ₱38.8M/d
- 2021: ₱19.34 +56.0% · H 28.60 L 11.70 · ₱6.1M/d
- 2022: ₱12.50 -35.4% · H 20.00 L 11.54 · ₱252.9K/d
- 2023: ₱9.29 -25.7% · H 12.90 L 8.70 · ₱120.6K/d
- 2024: ₱8.32 -10.4% · H 10.74 L 8.12 · ₱100.0K/d
- 2025: ₱8.40 +1.0% · H 9.27 L 8.10 · ₱119.8K/d
- 2026*: ₱11.00 +31.0% · H 12.50 L 8.40 · ₱364.0K/d · div ₱1.30 (11.8%): 25May 1.3

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
