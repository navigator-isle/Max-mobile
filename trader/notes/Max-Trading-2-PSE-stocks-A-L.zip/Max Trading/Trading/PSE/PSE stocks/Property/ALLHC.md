---
tags: [trading, pse, stock, allhc]
---
**ALLHC — AyalaLand Logistics Holdings Corp.**
- Status: listed on PSE · sector Property › Property · listed Feb 28, 1990
- Data: 1990-02-28 → 2026-11-06 (7,393 trading days)
- Last close ₱1.09 (2026-11-06) · all-time high ₱7.10 (1996-05-23) · low ₱0.007 (2002-12-13) · now -84.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-12-16 (÷0.1), 2003-09-11 (÷0.1), 2003-10-03 (÷0.1)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1990: ₱0.6900 start · H 1.16 L 0.6900 · ₱647.2K/d
- 1991: ₱1.40 +102.9% · H 1.98 L 0.6500 · ₱2.0M/d
- 1992: ₱1.68 +20.0% · H 2.26 L 1.40 · ₱2.1M/d
- 1993: ₱4.35 +158.9% · H 4.75 L 1.68 · ₱6.7M/d
- 1994: ₱4.20 -3.4% · H 5.40 L 2.65 · ₱6.3M/d
- 1995: ₱4.00 -4.8% · H 5.00 L 2.90 · ₱4.9M/d
- 1996: ₱4.90 +22.5% · H 7.10 L 3.85 · ₱20.1M/d
- 1997: ₱0.7700 -84.3% · H 5.30 L 0.6700 · ₱6.0M/d
- 1998: ₱0.9200 +19.5% · H 1.50 L 0.2900 · ₱2.5M/d
- 1999: ₱1.00 +8.7% · H 1.14 L 0.6500 · ₱1.6M/d
- 2000: ₱0.2300 -77.0% · H 1.04 L 0.1800 · ₱578.9K/d
- 2001: ₱0.1400 -39.1% · H 0.3400 L 0.1000 · ₱166.9K/d
- 2002: ₱0.0600 -57.1% · H 0.2250 L 0.007 · ₱113.4K/d
- 2003: ₱0.1400 +133.3% · H 0.3300 L 0.0270 · ₱490.4K/d
- 2004: ₱0.1500 +7.1% · H 0.2100 L 0.1200 · ₱455.7K/d
- 2005: ₱0.2000 +33.3% · H 0.4200 L 0.1500 · ₱595.2K/d
- 2006: ₱0.1900 -5.0% · H 0.2800 L 0.1550 · ₱815.9K/d
- 2007: ₱0.5100 +168.4% · H 0.7000 L 0.1900 · ₱3.5M/d
- 2008: ₱0.1700 -66.7% · H 0.5100 L 0.1700 · ₱273.7K/d
- 2009: ₱0.4100 +141.2% · H 0.6000 L 0.1500 · ₱1.1M/d
- 2010: ₱0.4500 +9.8% · H 0.5100 L 0.3800 · ₱334.5K/d
- 2011: ₱0.4400 -2.2% · H 0.7200 L 0.4400 · ₱1.4M/d
- 2012: ₱0.5500 +25.0% · H 0.6300 L 0.4300 · ₱1.1M/d
- 2013: ₱0.4000 -27.3% · H 0.7200 L 0.4000 · ₱1.0M/d
- 2014: ₱0.6900 +72.5% · H 0.7900 L 0.4100 · ₱717.9K/d
- 2015: ₱1.83 +165.2% · H 2.35 L 0.6500 · ₱9.9M/d
- 2016: ₱1.90 +3.8% · H 2.22 L 1.70 · ₱2.3M/d
- 2017: ₱2.05 +7.9% · H 2.40 L 1.85 · ₱1.9M/d
- 2018: ₱2.37 +15.6% · H 3.74 L 2.05 · ₱11.2M/d
- 2019: ₱2.99 +26.2% · H 4.28 L 2.42 · ₱13.6M/d
- 2020: ₱3.40 +13.7% · H 3.68 L 1.43 · ₱7.0M/d
- 2021: ₱6.73 +97.9% · H 6.73 L 2.70 · ₱23.3M/d
- 2022: ₱2.97 -55.9% · H 6.63 L 2.88 · ₱7.9M/d
- 2023: ₱1.77 -40.4% · H 3.37 L 1.45 · ₱3.9M/d
- 2024: ₱1.70 -4.0% · H 2.18 L 1.63 · ₱1.7M/d
- 2025: ₱1.30 -23.5% · H 1.74 L 1.25 · ₱620.4K/d
- 2026*: ₱1.09 -16.2% · H 1.56 L 1.03 · ₱665.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
