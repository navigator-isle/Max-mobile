---
tags: [trading, pse, stock, jas]
---
**JAS — Jackstones, Inc.**
- Status: listed on PSE · sector Property › Property · listed Oct 27, 1967
- Data: 2006-04-26 → 2026-11-05 (1,889 trading days)
- Last close ₱1.63 (2026-11-05) · all-time high ₱6.02 (2013-11-12) · low ₱0.7500 (2024-01-24) · now -72.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱3.00 start · H 3.00 L 3.00 · ₱435.0K/d
- 2013: ₱2.17 start · H 6.02 L 1.68 · ₱863.0K/d
- 2014: ₱4.15 +91.2% · H 5.58 L 2.14 · ₱2.2M/d
- 2015: ₱2.03 -51.1% · H 4.14 L 1.90 · ₱634.1K/d
- 2016: ₱3.52 +73.4% · H 3.94 L 1.88 · ₱847.3K/d
- 2017: ₱3.07 -12.8% · H 3.85 L 2.88 · ₱790.7K/d
- 2018: ₱3.39 +10.4% · H 5.29 L 3.03 · ₱767.1K/d
- 2019: ₱2.00 -41.0% · H 3.40 L 1.89 · ₱146.0K/d
- 2020: ₱2.11 +5.5% · H 2.40 L 1.51 · ₱621.0K/d
- 2021: ₱1.74 -17.5% · H 2.45 L 1.68 · ₱157.8K/d
- 2022: ₱1.66 -4.6% · H 1.88 L 1.20 · ₱24.5K/d
- 2023: ₱1.04 -37.3% · H 1.79 L 0.8000 · ₱20.0K/d
- 2024: ₱1.13 +8.7% · H 1.83 L 0.7500 · ₱12.7K/d
- 2025: ₱1.55 +37.2% · H 2.18 L 1.00 · ₱18.0K/d
- 2026*: ₱1.63 +5.2% · H 2.10 L 1.56 · ₱25.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
