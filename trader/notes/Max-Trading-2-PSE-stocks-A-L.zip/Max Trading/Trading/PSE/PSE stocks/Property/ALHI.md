---
tags: [trading, pse, stock, alhi]
---
**ALHI — Anchor Land Holdings, Inc.**
- Status: listed on PSE · sector Property › Property · listed Aug 08, 2007
- Data: 2007-08-08 → 2026-10-22 (2,269 trading days)
- Last close ₱3.05 (2026-10-22) · all-time high ₱26.50 (2017-12-19) · low ₱1.67 (2008-12-03) · now -88.5% from high
- Cash dividends last 12 months ₱0.0400 = 1.3% yield
- Dividend events on record (2013 → 2026): 14
- Splits / stock dividends detected (prices before these dates are as traded then): 2017-12-20 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱2.27 start · H 2.70 L 2.07 · ₱1.6M/d
- 2008: ₱1.97 -13.2% · H 2.40 L 1.67 · ₱192.7K/d
- 2009: ₱2.77 +40.7% · H 3.00 L 1.67 · ₱4.8M/d
- 2010: ₱4.00 +44.6% · H 4.00 L 2.73 · ₱9.2M/d
- 2011: ₱6.10 +52.5% · H 6.67 L 3.67 · ₱334.9K/d
- 2012: ₱11.33 +85.8% · H 16.63 L 6.20 · ₱183.0K/d
- 2013: ₱14.10 +24.4% · H 17.60 L 11.00 · ₱320.3K/d · div ₱0.1500 (1.1%): 25Jun 0.15
- 2014: ₱10.02 -28.9% · H 15.50 L 10.02 · ₱94.9K/d · div ₱0.1200 (1.2%): 13Jun 0.12
- 2015: ₱7.50 -25.1% · H 10.94 L 5.72 · ₱50.7K/d · div ₱0.0700 (0.9%): 12May 0.07
- 2016: ₱6.98 -6.9% · H 8.04 L 5.67 · ₱97.1K/d · div ₱0.0500 (0.7%): 25May 0.05
- 2017: ₱12.88 +84.5% · H 26.50 L 6.00 · ₱726.2K/d · div ₱0.0600 (0.5%): 17May 0.06
- 2018: ₱11.46 -11.0% · H 19.48 L 10.40 · ₱921.8K/d · div ₱0.0700 (0.6%): 17May 0.07
- 2019: ₱8.95 -21.9% · H 11.88 L 8.81 · ₱91.0K/d · div ₱0.0800 (0.9%): 31May 0.08
- 2020: ₱8.15 -8.9% · H 9.69 L 6.41 · ₱1.1M/d · div ₱0.0900 (1.1%): 17Aug 0.09
- 2021: ₱5.51 -32.4% · H 8.75 L 5.10 · ₱153.1K/d · div ₱0.0200 (0.4%): 24May 0.02
- 2022: ₱5.89 +6.9% · H 7.89 L 4.02 · ₱931.8K/d · div ₱0.0200 (0.3%): 14Jun 0.02
- 2023: ₱4.01 -31.9% · H 7.48 L 3.25 · ₱31.5K/d · div ₱0.0300 (0.7%): 29May 0.03
- 2024: ₱4.80 +19.7% · H 7.99 L 3.94 · ₱9.0K/d · div ₱0.0400 (0.8%): 05Jun 0.04
- 2025: ₱3.87 -19.4% · H 7.00 L 3.80 · ₱279.2K/d · div ₱0.0400 (1.0%): 05Jun 0.04
- 2026*: ₱3.05 -21.2% · H 4.50 L 3.01 · ₱17.4K/d · div ₱0.0400 (1.3%): 04Jun 0.04

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
