---
tags: [trading, pse, stock, filrt]
---
**FILRT — Filinvest REIT Corp.**
- Status: listed on PSE · sector Property › Property · listed Aug 12, 2021
- Data: 2021-08-12 → 2026-11-06 (1,281 trading days)
- Last close ₱2.90 (2026-11-06) · all-time high ₱7.98 (2021-11-18) · low ₱2.58 (2023-12-21) · now -63.7% from high
- Cash dividends last 12 months ₱0.2370 = 8.2% yield
- Dividend events on record (2013 → 2026): 22

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱7.40 start · H 7.98 L 7.02 · ₱37.4M/d · div ₱0.2240 (3.0%): 10Sep 0.112, 29Nov 0.112
- 2022: ₱5.50 -25.7% · H 7.85 L 5.24 · ₱12.0M/d · div ₱0.4040 (7.3%): 24Feb 0.112, 03May 0.116, 25Aug 0.088, 25Nov 0.088
- 2023: ₱2.58 -53.1% · H 5.82 L 2.58 · ₱5.4M/d · div ₱0.2840 (11.0%): 28Feb 0.071, 09Jun 0.071, 30Aug 0.071, 28Nov 0.071
- 2024: ₱2.95 +14.3% · H 3.28 L 2.62 · ₱3.5M/d · div ₱0.2530 (8.6%): 08Mar 0.067, 23May 0.062, 22Aug 0.062, 19Nov 0.062
- 2025: ₱3.10 +5.1% · H 3.68 L 2.79 · ₱5.6M/d · div ₱0.2430 (7.8%): 11Mar 0.062, 19Jun 0.062, 19Aug 0.062, 19Nov 0.057
- 2026*: ₱2.90 -6.5% · H 3.08 L 2.73 · ₱2.7M/d · div ₱0.2400 (8.3%): 06Mar 0.06, 22May 0.06, 19Aug 0.06, 23Nov 0.06 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
