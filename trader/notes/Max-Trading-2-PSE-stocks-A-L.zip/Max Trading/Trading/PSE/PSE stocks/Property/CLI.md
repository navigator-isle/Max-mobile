---
tags: [trading, pse, stock, cli]
---
**CLI — Cebu Landmasters, Inc.**
- Status: listed on PSE · sector Property › Property · listed Jun 02, 2017
- Data: 2017-06-02 → 2026-11-06 (2,298 trading days)
- Last close ₱1.94 (2026-11-06) · all-time high ₱7.27 (2021-06-14) · low ₱1.92 (2026-11-05) · now -73.3% from high
- Cash dividends last 12 months ₱0.1800 = 9.3% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱4.88 start · H 5.90 L 4.61 · ₱27.7M/d
- 2018: ₱4.14 -15.2% · H 5.05 L 3.70 · ₱3.9M/d · div ₱0.1500 (3.6%): 20Mar 0.15
- 2019: ₱4.83 +16.7% · H 5.26 L 4.00 · ₱4.1M/d · div ₱0.2000 (4.1%): 21Mar 0.2
- 2020: ₱5.05 +4.6% · H 5.19 L 3.65 · ₱4.7M/d · div ₱0.2500 (5.0%): 31Mar 0.25
- 2021: ₱3.00 -40.6% · H 7.27 L 2.72 · ₱9.1M/d · div ₱0.2500 (8.3%): 13Apr 0.25
- 2022: ₱2.80 -6.7% · H 3.01 L 2.30 · ₱1.3M/d · div ₱0.1500 (5.4%): 19Apr 0.038S, 19Apr 0.112
- 2023: ₱2.47 -11.8% · H 2.77 L 2.34 · ₱800.6K/d · div ₱0.1800 (7.3%): 13Apr 0.03S, 13Apr 0.15
- 2024: ₱2.65 +7.3% · H 2.95 L 2.50 · ₱1.4M/d · div ₱0.1800 (6.8%): 16Apr 0.03S, 16Apr 0.15
- 2025: ₱2.35 -11.3% · H 2.70 L 2.20 · ₱1.2M/d · div ₱0.1800 (7.7%): 10Apr 0.03S, 10Apr 0.15
- 2026*: ₱1.94 -17.4% · H 2.54 L 1.92 · ₱693.7K/d · div ₱0.1800 (9.3%): 21Apr 0.18

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
