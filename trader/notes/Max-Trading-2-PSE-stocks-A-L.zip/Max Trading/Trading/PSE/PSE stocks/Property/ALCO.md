---
tags: [trading, pse, stock, alco]
---
**ALCO — Arthaland Corporation**
- Status: listed on PSE · sector Property › Property · listed Mar 19, 1996
- Data: 2009-01-14 → 2026-11-04 (3,666 trading days)
- Last close ₱0.4200 (2026-11-04) · all-time high ₱1.66 (2017-02-09) · low ₱0.0900 (2009-02-16) · now -74.7% from high
- Cash dividends last 12 months ₱0.0120 = 2.9% yield
- Dividend events on record (2013 → 2026): 15

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2009: ₱0.1600 start · H 0.2700 L 0.0900 · ₱475.2K/d
- 2010: ₱0.1780 +11.2% · H 0.2700 L 0.1500 · ₱1.0M/d
- 2011: ₱0.1600 -10.1% · H 0.2090 L 0.1450 · ₱385.2K/d
- 2012: ₱0.1780 +11.2% · H 0.1940 L 0.1620 · ₱123.4K/d
- 2013: ₱0.1930 +8.4% · H 0.2300 L 0.1840 · ₱288.8K/d · div ₱0.0120 (6.2%): 23Jul 0.012
- 2014: ₱0.2600 +34.7% · H 0.3650 L 0.1870 · ₱783.7K/d · div ₱0.0360 (13.8%): 25Mar 0.012, 25Mar 0.024S
- 2015: ₱0.2200 -15.4% · H 0.2850 L 0.1800 · ₱99.5K/d · div ₱0.0120 (5.5%): 18Mar 0.012
- 2016: ₱0.4000 +81.8% · H 0.4900 L 0.2000 · ₱2.1M/d
- 2017: ₱0.9000 +125.0% · H 1.66 L 0.4400 · ₱23.5M/d · div ₱0.0120 (1.3%): 09Mar 0.012
- 2018: ₱0.9600 +6.7% · H 1.07 L 0.5100 · ₱2.2M/d · div ₱0.0220 (2.3%): 03Apr 0.01, 03Apr 0.012
- 2019: ₱0.8100 -15.6% · H 1.14 L 0.7300 · ₱4.8M/d · div ₱0.0120 (1.5%): 03Jul 0.012
- 2020: ₱0.6500 -19.8% · H 0.8800 L 0.4700 · ₱925.6K/d · div ₱0.0120 (1.8%): 07Jul 0.012
- 2021: ₱0.6400 -1.5% · H 0.7700 L 0.6100 · ₱613.2K/d · div ₱0.0120 (1.9%): 06Jul 0.012
- 2022: ₱0.5600 -12.5% · H 0.6400 L 0.4800 · ₱548.9K/d · div ₱0.0120 (2.1%): 06Jul 0.012
- 2023: ₱0.4600 -17.9% · H 0.6000 L 0.3500 · ₱83.5K/d · div ₱0.0120 (2.6%): 12Jul 0.012
- 2024: ₱0.3650 -20.7% · H 0.5400 L 0.3300 · ₱97.7K/d · div ₱0.0120 (3.3%): 18Jul 0.012
- 2025: ₱0.4200 +15.1% · H 0.4700 L 0.3100 · ₱215.7K/d · div ₱0.0120 (2.9%): 14Jul 0.012
- 2026*: ₱0.4200 +0.0% · H 0.4900 L 0.4150 · ₱151.5K/d · div ₱0.0120 (2.9%): 09Jul 0.012

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
