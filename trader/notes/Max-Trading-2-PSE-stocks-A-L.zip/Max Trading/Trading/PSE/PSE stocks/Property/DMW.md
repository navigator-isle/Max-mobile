---
tags: [trading, pse, stock, dmw]
---
**DMW — D.M. Wenceslao &amp; Associates, Incorporated**
- Status: listed on PSE · sector Property › Property · listed Jun 29, 2018
- Data: 2018-06-29 → 2026-11-06 (2,034 trading days)
- Last close ₱4.68 (2026-11-06) · all-time high ₱12.38 (2019-04-02) · low ₱4.60 (2026-07-27) · now -62.2% from high
- Cash dividends last 12 months ₱0.1000 = 2.1% yield
- Dividend events on record (2013 → 2026): 8

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2018: ₱7.80 start · H 10.46 L 7.55 · ₱10.2M/d
- 2019: ₱9.90 +26.9% · H 12.38 L 7.70 · ₱7.6M/d · div ₱0.0353 (0.4%): 27Feb 0.035337S
- 2020: ₱7.60 -23.2% · H 9.80 L 5.08 · ₱3.1M/d · div ₱0.0471 (0.6%): 06May 0.047116
- 2021: ₱6.78 -10.8% · H 7.60 L 6.35 · ₱1.1M/d · div ₱0.0471 (0.7%): 17Mar 0.047116
- 2022: ₱6.70 -1.2% · H 7.00 L 6.50 · ₱871.2K/d · div ₱0.0609 (0.9%): 22Mar 0.060945
- 2023: ₱5.16 -23.0% · H 6.96 L 5.16 · ₱327.4K/d · div ₱0.0750 (1.5%): 27Mar 0.074974
- 2024: ₱5.52 +7.0% · H 6.05 L 4.90 · ₱231.5K/d · div ₱0.0790 (1.4%): 11Apr 0.078972
- 2025: ₱5.00 -9.4% · H 5.49 L 4.68 · ₱248.3K/d · div ₱0.0950 (1.9%): 10Apr 0.095
- 2026*: ₱4.68 -6.4% · H 6.19 L 4.60 · ₱127.9K/d · div ₱0.1000 (2.1%): 08Apr 0.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
