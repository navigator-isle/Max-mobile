---
tags: [trading, pse, stock, creit]
---
**CREIT — Citicore Energy REIT Corp.**
- Status: listed on PSE · sector Property › Property · listed Feb 22, 2022
- Data: 2022-02-22 → 2026-11-06 (1,149 trading days)
- Last close ₱2.71 (2026-11-06) · all-time high ₱3.90 (2025-09-04) · low ₱1.99 (2022-10-27) · now -30.5% from high
- Cash dividends last 12 months ₱0.2030 = 7.5% yield
- Dividend events on record (2013 → 2026): 20

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱2.29 start · H 2.84 L 1.99 · ₱25.1M/d · div ₱0.1670 (7.3%): 23Mar 0.035, 03Jun 0.044, 16Aug 0.044, 05Dec 0.044
- 2023: ₱2.56 +11.8% · H 2.61 L 2.28 · ₱4.6M/d · div ₱0.1960 (7.7%): 18Apr 0.007S, 18Apr 0.044, 06Jun 0.047, 08Sep 0.049, 22Dec 0.049
- 2024: ₱3.05 +19.1% · H 3.09 L 2.57 · ₱8.0M/d · div ₱0.2010 (6.6%): 17Apr 0.054, 11Jun 0.049, 09Sep 0.049, 11Dec 0.049
- 2025: ₱3.57 +17.0% · H 3.90 L 3.06 · ₱6.5M/d · div ₱0.2020 (5.7%): 23Apr 0.055, 05Jun 0.049, 11Sep 0.049, 10Dec 0.049
- 2026*: ₱2.71 -24.1% · H 3.68 L 2.68 · ₱7.4M/d · div ₱0.1540 (5.7%): 23Apr 0.056, 10Jun 0.049, 10Sep 0.049

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
