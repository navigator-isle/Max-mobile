---
tags: [trading, pse, stock, eli]
---
**ELI — Empire East Land Holdings, Inc.**
- Status: listed on PSE · sector Property › Property · listed Jun 28, 1996
- Data: 1996-06-28 → 2026-11-06 (7,069 trading days)
- Last close ₱0.1010 (2026-11-06) · all-time high ₱6.49 (1996-07-05) · low ₱0.0940 (2023-09-08) · now -98.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱4.64 start · H 6.49 L 4.46 · ₱61.0M/d
- 1997: ₱0.6104 -86.8% · H 5.01 L 0.5756 · ₱45.0M/d
- 1998: ₱0.5756 -5.7% · H 0.8748 L 0.3252 · ₱23.7M/d
- 1999: ₱0.5687 -1.2% · H 1.12 L 0.5409 · ₱49.8M/d
- 2000: ₱0.4157 -26.9% · H 0.6035 L 0.3670 · ₱3.9M/d
- 2001: ₱0.3600 -13.4% · H 0.5548 L 0.3322 · ₱3.9M/d
- 2002: ₱0.2835 -21.3% · H 0.4435 L 0.2765 · ₱1.4M/d
- 2003: ₱0.3530 +24.5% · H 0.3878 L 0.2765 · ₱1.9M/d
- 2004: ₱0.4365 +23.7% · H 0.4991 L 0.3322 · ₱4.1M/d
- 2005: ₱0.4922 +12.8% · H 0.6244 L 0.4087 · ₱7.1M/d
- 2006: ₱0.5400 +9.7% · H 0.7009 L 0.4500 · ₱9.3M/d
- 2007: ₱0.8000 +48.1% · H 0.9700 L 0.5300 · ₱23.8M/d
- 2008: ₱0.3300 -58.8% · H 0.8000 L 0.1900 · ₱4.1M/d
- 2009: ₱0.4300 +30.3% · H 0.5100 L 0.2150 · ₱1.2M/d
- 2010: ₱0.5300 +23.3% · H 0.6500 L 0.3500 · ₱2.2M/d
- 2011: ₱0.5900 +11.3% · H 0.8700 L 0.5300 · ₱18.2M/d
- 2012: ₱0.9900 +67.8% · H 1.11 L 0.6000 · ₱21.8M/d
- 2013: ₱0.9200 -7.1% · H 1.18 L 0.9200 · ₱12.4M/d
- 2014: ₱0.9000 -2.2% · H 1.07 L 0.8600 · ₱1.3M/d
- 2015: ₱0.7700 -14.4% · H 0.9600 L 0.7400 · ₱893.7K/d
- 2016: ₱0.6900 -10.4% · H 0.8900 L 0.6600 · ₱1.4M/d
- 2017: ₱0.6500 -5.8% · H 0.8000 L 0.6400 · ₱1.7M/d
- 2018: ₱0.4850 -25.4% · H 0.7100 L 0.4750 · ₱778.6K/d
- 2019: ₱0.4300 -11.3% · H 0.5700 L 0.4100 · ₱1.1M/d
- 2020: ₱0.3150 -26.7% · H 0.4350 L 0.2400 · ₱904.7K/d
- 2021: ₱0.2550 -19.0% · H 0.3450 L 0.2550 · ₱352.5K/d
- 2022: ₱0.1880 -26.3% · H 0.2650 L 0.1820 · ₱107.3K/d
- 2023: ₱0.1260 -33.0% · H 0.2140 L 0.0940 · ₱579.1K/d
- 2024: ₱0.1200 -4.8% · H 0.1890 L 0.1180 · ₱393.2K/d
- 2025: ₱0.1040 -13.3% · H 0.1280 L 0.1030 · ₱66.7K/d
- 2026*: ₱0.1010 -2.9% · H 0.1150 L 0.0960 · ₱75.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
