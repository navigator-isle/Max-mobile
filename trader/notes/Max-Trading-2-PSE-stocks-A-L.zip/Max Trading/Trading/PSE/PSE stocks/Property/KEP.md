---
tags: [trading, pse, stock, kep]
---
**KEP — Keppel Philippines Properties, Inc.**
- Status: listed on PSE · sector Property › Property · listed Sep 11, 1989
- Data: 2006-04-19 → 2026-10-30 (1,433 trading days)
- Last close ₱2.40 (2026-10-30) · all-time high ₱16.86 (2024-04-25) · low ₱0.7000 (2006-04-19) · now -85.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.30 start · H 1.32 L 0.7000 · ₱126.2K/d
- 2007: ₱1.60 +23.1% · H 2.90 L 1.28 · ₱102.0K/d
- 2008: ₱0.9000 -43.8% · H 2.10 L 0.8500 · ₱787.8K/d
- 2009: ₱1.20 +33.3% · H 1.50 L 0.7000 · ₱98.8K/d
- 2010: ₱1.46 +21.7% · H 2.00 L 1.06 · ₱142.6K/d
- 2011: ₱1.62 +11.0% · H 2.15 L 1.50 · ₱39.6K/d
- 2012: ₱2.60 +60.5% · H 3.60 L 1.60 · ₱67.8K/d
- 2013: ₱2.80 +7.7% · H 3.50 L 2.25 · ₱38.5K/d
- 2014: ₱4.82 +72.1% · H 6.00 L 2.80 · ₱142.8K/d
- 2015: ₱3.75 -22.2% · H 7.37 L 3.00 · ₱76.9K/d
- 2016: ₱4.42 +17.9% · H 6.75 L 3.50 · ₱91.0K/d
- 2017: ₱4.03 -8.8% · H 5.59 L 4.01 · ₱50.0K/d
- 2018: ₱3.52 -12.7% · H 4.98 L 3.52 · ₱23.9K/d
- 2019: ₱4.00 +13.6% · H 4.86 L 3.65 · ₱150.5K/d
- 2020: ₱3.38 -15.5% · H 4.27 L 2.81 · ₱98.5K/d
- 2021: ₱3.05 -9.8% · H 3.99 L 2.71 · ₱39.6K/d
- 2022: ₱3.97 +30.2% · H 3.97 L 2.80 · ₱39.1K/d
- 2023: ₱6.90 +73.8% · H 9.45 L 2.78 · ₱131.9K/d
- 2024: ₱2.79 -59.6% · H 16.86 L 2.45 · ₱2.5M/d · div ₱15.14 (542.7%): 26Apr 15.14S
- 2025: ₱2.20 -21.1% · H 3.13 L 2.03 · ₱62.4K/d
- 2026*: ₱2.40 +9.1% · H 3.60 L 2.20 · ₱103.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
