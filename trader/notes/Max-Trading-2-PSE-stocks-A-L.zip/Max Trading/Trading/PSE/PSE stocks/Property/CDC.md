---
tags: [trading, pse, stock, cdc]
---
**CDC — Cityland Development Corporation**
- Status: listed on PSE · sector Property › Property · listed Aug 02, 1983
- Data: 2006-04-03 → 2026-11-06 (3,627 trading days)
- Last close ₱0.5100 (2026-11-06) · all-time high ₱2.75 (2007-06-20) · low ₱0.5000 (2026-11-05) · now -81.5% from high
- Cash dividends last 12 months ₱0.0326 = 6.4% yield
- Dividend events on record (2013 → 2026): 15

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1.52 start · H 1.70 L 1.23 · ₱85.6K/d
- 2007: ₱1.52 +0.0% · H 2.75 L 1.42 · ₱259.1K/d
- 2008: ₱1.33 -12.5% · H 1.89 L 0.9905 · ₱41.6K/d
- 2009: ₱1.45 +9.2% · H 2.06 L 1.03 · ₱80.8K/d
- 2010: ₱1.24 -14.6% · H 1.89 L 0.8571 · ₱397.6K/d
- 2011: ₱1.12 -9.9% · H 1.53 L 1.03 · ₱220.2K/d
- 2012: ₱1.10 -1.9% · H 1.24 L 1.00 · ₱228.9K/d
- 2013: ₱0.9905 -9.7% · H 1.14 L 0.9619 · ₱451.3K/d · div ₱0.0300 (3.0%): 14Jun 0.03
- 2014: ₱0.9714 -1.9% · H 1.12 L 0.9333 · ₱416.0K/d · div ₱0.0300 (3.1%): 19Jun 0.03
- 2015: ₱1.03 +6.0% · H 1.19 L 0.9500 · ₱131.3K/d · div ₱0.0270 (2.6%): 23Jun 0.027S
- 2016: ₱1.36 +32.0% · H 1.49 L 0.9500 · ₱1.4M/d · div ₱0.0660 (4.9%): 14Jun 0.066
- 2017: ₱1.17 -14.0% · H 1.68 L 1.14 · ₱1.2M/d · div ₱0.0760 (6.5%): 01Jun 0.036, 01Jun 0.04
- 2018: ₱0.8700 -25.6% · H 1.18 L 0.8500 · ₱1.2M/d · div ₱0.0301 (3.5%): 18May 0.0301
- 2019: ₱0.8500 -2.3% · H 0.9800 L 0.8200 · ₱136.8K/d · div ₱0.0450 (5.3%): 11Jun 0.045
- 2020: ₱0.8100 -4.7% · H 0.8800 L 0.6500 · ₱64.3K/d · div ₱0.0300 (3.7%): 08Sep 0.03
- 2021: ₱0.7600 -6.2% · H 1.25 L 0.7200 · ₱1.2M/d · div ₱0.0212 (2.8%): 13Jul 0.0212
- 2022: ₱0.6800 -10.5% · H 0.7700 L 0.6300 · ₱236.8K/d · div ₱0.0222 (3.3%): 08Jun 0.0222
- 2023: ₱0.6900 +1.5% · H 0.8000 L 0.6600 · ₱438.8K/d · div ₱0.0295 (4.3%): 27Jun 0.0295
- 2024: ₱0.6800 -1.4% · H 0.7400 L 0.6200 · ₱182.3K/d · div ₱0.0477 (7.0%): 20Jun 0.0477
- 2025: ₱0.5900 -13.2% · H 0.6800 L 0.5200 · ₱141.4K/d · div ₱0.0375 (6.4%): 23May 0.0375
- 2026*: ₱0.5100 -13.6% · H 0.6300 L 0.5000 · ₱131.1K/d · div ₱0.0326 (6.4%): 14Aug 0.0326

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
