---
tags: [trading, pse, stock, infra]
---
**INFRA — Philippine Infradev Holdings, Inc.**
- Status: listed on PSE · sector Property › Property · listed Feb 27, 1978
- Data: 2015-01-05 → 2026-05-29 (2,545 trading days)
- Last close ₱0.3200 (2026-05-29) · all-time high ₱2.85 (2018-10-26) · low ₱0.2100 (2025-03-14) · now -88.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱1.13 start · H 1.55 L 1.13 · ₱675.6K/d
- 2016: ₱1.25 +10.6% · H 1.43 L 1.00 · ₱346.3K/d
- 2017: ₱0.7400 -40.8% · H 1.40 L 0.7100 · ₱2.1M/d
- 2018: ₱2.25 +204.1% · H 2.85 L 0.6800 · ₱25.8M/d
- 2019: ₱1.25 -44.4% · H 2.44 L 1.25 · ₱7.6M/d
- 2020: ₱1.41 +12.8% · H 1.74 L 0.5900 · ₱3.7M/d
- 2021: ₱1.12 -20.6% · H 1.67 L 1.09 · ₱2.5M/d
- 2022: ₱0.9200 -17.9% · H 1.20 L 0.8400 · ₱708.8K/d
- 2023: ₱0.5500 -40.2% · H 1.02 L 0.4200 · ₱994.5K/d
- 2024: ₱0.3200 -41.8% · H 0.7100 L 0.2500 · ₱129.8K/d
- 2025: ₱0.3150 -1.6% · H 0.4450 L 0.2100 · ₱120.9K/d
- 2026*: ₱0.3200 +1.6% · H 0.3800 L 0.3150 · ₱57.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
