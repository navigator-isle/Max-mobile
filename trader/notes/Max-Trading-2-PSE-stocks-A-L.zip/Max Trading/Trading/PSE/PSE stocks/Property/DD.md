---
tags: [trading, pse, stock, dd]
---
**DD — DoubleDragon Corporation**
- Status: listed on PSE · sector Property › Property · listed Apr 07, 2014
- Data: 2014-04-07 → 2026-11-06 (3,065 trading days)
- Last close ₱12.46 (2026-11-06) · all-time high ₱70.00 (2016-06-09) · low ₱3.00 (2014-04-07) · now -82.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱7.50 start · H 10.00 L 3.00 · ₱44.2M/d
- 2015: ₱24.40 +225.3% · H 25.35 L 7.26 · ₱29.7M/d · div ₱0.0500 (0.2%): 08Jul 0.05
- 2016: ₱38.40 +57.4% · H 70.00 L 20.00 · ₱67.6M/d
- 2017: ₱39.70 +3.4% · H 55.50 L 37.00 · ₱21.8M/d
- 2018: ₱17.84 -55.1% · H 41.70 L 17.20 · ₱16.9M/d
- 2019: ₱18.90 +5.9% · H 27.05 L 17.88 · ₱14.1M/d
- 2020: ₱14.90 -21.2% · H 20.05 L 13.90 · ₱17.2M/d
- 2021: ₱7.26 -51.3% · H 15.84 L 6.90 · ₱14.6M/d · div ₱0.2002 (2.8%): 18Aug 0.2002
- 2022: ₱6.72 -7.4% · H 11.44 L 5.55 · ₱4.7M/d · div ₱0.2324 (3.5%): 11Oct 0.2324
- 2023: ₱7.60 +13.1% · H 8.31 L 6.60 · ₱1.2M/d · div ₱0.2624 (3.5%): 05Jun 0.2624
- 2024: ₱10.20 +34.2% · H 12.60 L 7.39 · ₱3.6M/d · div ₱0.2648 (2.6%): 05Nov 0.2648
- 2025: ₱9.28 -9.0% · H 14.98 L 8.30 · ₱4.3M/d
- 2026*: ₱12.46 +34.3% · H 12.68 L 8.80 · ₱3.7M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
