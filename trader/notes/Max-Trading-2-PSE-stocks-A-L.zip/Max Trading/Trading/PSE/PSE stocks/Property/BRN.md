---
tags: [trading, pse, stock, brn]
---
**BRN — A Brown Company, Inc.**
- Status: listed on PSE · sector Property › Property · listed Feb 08, 1994
- Data: 1994-02-08 → 2026-11-06 (6,071 trading days)
- Last close ₱0.8300 (2026-11-06) · all-time high ₱2.77 (2008-02-01) · low ₱0.1600 (1998-10-19) · now -70.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱0.8834 start · H 1.18 L 0.5174 · ₱645.2K/d
- 1995: ₱0.9772 +10.6% · H 1.11 L 0.6926 · ₱455.1K/d
- 1996: ₱1.58 +61.4% · H 1.65 L 0.7950 · ₱1.3M/d
- 1997: ₱0.5440 -65.5% · H 1.46 L 0.5334 · ₱1.8M/d
- 1998: ₱0.2666 -51.0% · H 0.5866 L 0.1600 · ₱116.0K/d
- 1999: ₱0.2666 +0.0% · H 0.3466 L 0.1866 · ₱124.3K/d
- 2000: ₱0.2774 +4.1% · H 0.3734 L 0.1866 · ₱101.7K/d
- 2001: ₱0.2400 -13.5% · H 0.4000 L 0.1866 · ₱50.7K/d
- 2002: ₱0.4000 +66.7% · H 0.4000 L 0.1600 · ₱314.3K/d
- 2003: ₱0.3734 -6.7% · H 0.4000 L 0.2666 · ₱50.3K/d
- 2004: ₱0.2720 -27.2% · H 0.3734 L 0.1866 · ₱514.5K/d
- 2005: ₱0.5174 +90.2% · H 0.5866 L 0.2934 · ₱169.4K/d
- 2006: ₱1.05 +103.6% · H 1.33 L 0.4000 · ₱6.0M/d
- 2007: ₱1.40 +32.9% · H 1.53 L 0.6666 · ₱3.9M/d
- 2008: ₱2.17 +54.8% · H 2.77 L 1.33 · ₱8.9M/d
- 2009: ₱2.50 +15.4% · H 2.67 L 1.61 · ₱6.7M/d
- 2010: ₱1.80 -28.0% · H 2.70 L 1.77 · ₱2.0M/d
- 2011: ₱1.80 +0.0% · H 1.83 L 1.16 · ₱592.4K/d
- 2012: ₱2.01 +11.5% · H 2.35 L 1.58 · ₱2.2M/d
- 2013: ₱0.8333 -58.5% · H 2.07 L 0.8333 · ₱919.5K/d
- 2014: ₱0.8917 +7.0% · H 1.30 L 0.8333 · ₱1.5M/d
- 2015: ₱0.7500 -15.9% · H 1.15 L 0.5500 · ₱2.7M/d
- 2016: ₱1.04 +38.7% · H 1.52 L 0.5900 · ₱6.3M/d
- 2017: ₱1.00 -3.8% · H 1.64 L 0.9200 · ₱12.0M/d
- 2018: ₱0.7800 -22.0% · H 1.24 L 0.6900 · ₱6.8M/d
- 2019: ₱0.7100 -9.0% · H 0.9300 L 0.6900 · ₱1.7M/d
- 2020: ₱0.9000 +26.8% · H 1.03 L 0.4750 · ₱3.7M/d
- 2021: ₱0.7900 -12.2% · H 1.04 L 0.7700 · ₱2.8M/d
- 2022: ₱0.7300 -7.6% · H 0.9600 L 0.6900 · ₱305.2K/d
- 2023: ₱0.6500 -11.0% · H 0.8100 L 0.6300 · ₱89.9K/d
- 2024: ₱0.5600 -13.8% · H 0.6800 L 0.5100 · ₱165.8K/d · div ₱0.0250 (4.5%): 31Jul 0.025
- 2025: ₱0.9300 +66.1% · H 1.00 L 0.5000 · ₱924.5K/d · div ₱0.0250 (2.7%): 31Jul 0.025
- 2026*: ₱0.8300 -10.8% · H 1.07 L 0.6100 · ₱799.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
