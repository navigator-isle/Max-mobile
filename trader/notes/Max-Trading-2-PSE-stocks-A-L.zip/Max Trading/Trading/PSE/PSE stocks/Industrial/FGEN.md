---
tags: [trading, pse, stock, fgen]
---
**FGEN — First Gen Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Feb 10, 2006
- Data: 2006-02-10 → 2026-11-06 (5,046 trading days)
- Last close ₱19.96 (2026-11-06) · all-time high ₱33.95 (2021-09-30) · low ₱6.83 (2008-12-23) · now -41.2% from high
- Cash dividends last 12 months ₱0.8000 = 4.0% yield
- Dividend events on record (2013 → 2026): 20
- Splits / stock dividends detected (prices before these dates are as traded then): 2009-12-22 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱18.13 start · H 18.37 L 14.38 · ₱15.5M/d
- 2007: ₱18.85 +4.0% · H 21.27 L 16.31 · ₱27.6M/d
- 2008: ₱6.83 -63.8% · H 18.97 L 6.83 · ₱16.6M/d
- 2009: ₱9.70 +42.0% · H 24.50 L 9.70 · ₱55.0M/d
- 2010: ₱12.18 +25.6% · H 14.12 L 8.80 · ₱77.2M/d
- 2011: ₱14.62 +20.0% · H 15.50 L 10.82 · ₱69.7M/d
- 2012: ₱22.30 +52.5% · H 23.75 L 12.88 · ₱62.1M/d
- 2013: ₱13.06 -41.4% · H 26.70 L 12.40 · ₱64.2M/d · div ₱0.5000 (3.8%): 22Jul 0.5
- 2014: ₱25.50 +95.3% · H 27.00 L 14.02 · ₱85.4M/d · div ₱0.3500 (1.4%): 13Oct 0.35
- 2015: ₱22.60 -11.4% · H 31.20 L 21.60 · ₱98.4M/d · div ₱0.3500 (1.5%): 31Jul 0.35
- 2016: ₱22.00 -2.7% · H 26.05 L 17.68 · ₱70.1M/d · div ₱0.3500 (1.6%): 23Sep 0.35
- 2017: ₱17.00 -22.7% · H 22.90 L 16.82 · ₱36.9M/d · div ₱0.3500 (2.1%): 05Oct 0.35
- 2018: ₱19.98 +17.5% · H 20.40 L 14.14 · ₱23.1M/d · div ₱0.3500 (1.8%): 09Oct 0.35
- 2019: ₱24.15 +20.9% · H 27.50 L 19.50 · ₱52.5M/d · div ₱0.5500 (2.3%): 20May 0.55
- 2020: ₱28.15 +16.6% · H 29.70 L 14.30 · ₱39.1M/d · div ₱0.5600 (2.0%): 19Jun 0.28, 02Dec 0.28
- 2021: ₱27.85 -1.1% · H 33.95 L 26.00 · ₱37.0M/d · div ₱0.7000 (2.5%): 14Jun 0.3, 22Nov 0.4
- 2022: ₱16.94 -39.2% · H 28.35 L 15.02 · ₱12.3M/d · div ₱0.7700 (4.5%): 01Jun 0.35, 12Dec 0.42
- 2023: ₱17.40 +2.7% · H 21.70 L 15.82 · ₱7.3M/d · div ₱0.9000 (5.2%): 02Jun 0.4, 04Dec 0.5
- 2024: ₱16.12 -7.4% · H 20.15 L 16.04 · ₱7.6M/d · div ₱0.9000 (5.6%): 14Jun 0.45, 11Dec 0.45
- 2025: ₱17.74 +10.0% · H 19.22 L 15.10 · ₱8.9M/d · div ₱0.8000 (4.5%): 16Jun 0.4, 12Dec 0.4
- 2026*: ₱19.96 +12.5% · H 30.70 L 15.40 · ₱30.6M/d · div ₱0.4000 (2.0%): 10Jun 0.4

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
