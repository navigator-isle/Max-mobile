---
tags: [trading, pse, stock, cnpf]
---
**CNPF — Century Pacific Food, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed May 06, 2014
- Data: 2014-05-06 → 2026-11-06 (3,046 trading days)
- Last close ₱28.50 (2026-11-06) · all-time high ₱45.00 (2024-12-13) · low ₱9.75 (2014-05-07) · now -36.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 16

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱10.89 start · H 11.27 L 9.75 · ₱18.7M/d
- 2015: ₱16.48 +51.3% · H 20.55 L 16.20 · ₱9.9M/d · div ₱0.1000 (0.6%): 27Jul 0.1S
- 2016: ₱16.18 -1.8% · H 24.30 L 14.84 · ₱28.8M/d · div ₱0.1000 (0.6%): 12Jul 0.1S
- 2017: ₱16.18 +0.0% · H 18.96 L 14.00 · ₱37.5M/d · div ₱0.1800 (1.1%): 25Jul 0.08S, 25Jul 0.1
- 2018: ₱15.20 -6.1% · H 17.60 L 12.90 · ₱13.7M/d · div ₱0.1800 (1.2%): 12Jul 0.08S, 12Jul 0.1
- 2019: ₱15.18 -0.1% · H 16.52 L 13.50 · ₱15.7M/d · div ₱0.1800 (1.2%): 26Jul 0.08S, 26Jul 0.1
- 2020: ₱17.50 +15.3% · H 18.30 L 10.08 · ₱26.3M/d · div ₱0.1800 (1.0%): 27Jul 0.18S
- 2021: ₱29.25 +67.1% · H 29.25 L 17.10 · ₱43.5M/d · div ₱0.1800 (0.6%): 06Apr 0.18S
- 2022: ₱25.80 -11.8% · H 28.50 L 19.98 · ₱30.0M/d · div ₱0.1800 (0.7%): 26Jul 0.18S
- 2023: ₱30.95 +20.0% · H 33.25 L 22.50 · ₱58.9M/d · div ₱0.2000 (0.6%): 15Mar 0.2S
- 2024: ₱41.95 +35.5% · H 45.00 L 31.00 · ₱56.3M/d · div ₱0.7200 (1.7%): 20Mar 0.24S, 30Jul 0.48S
- 2025: ₱39.00 -7.0% · H 44.50 L 32.00 · ₱56.6M/d · div ₱1.10 (2.8%): 28Feb 0.55, 29Jul 0.55S
- 2026*: ₱28.50 -26.9% · H 40.60 L 25.00 · ₱47.9M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
