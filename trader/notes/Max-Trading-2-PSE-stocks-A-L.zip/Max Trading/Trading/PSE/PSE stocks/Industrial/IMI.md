---
tags: [trading, pse, stock, imi]
---
**IMI — Integrated Micro-Electronics, Inc.**
- Status: listed on PSE · sector Industrial › Electrical Components &amp; Equipment · listed Jan 21, 2010
- Data: 2010-01-21 → 2026-11-06 (4,041 trading days)
- Last close ₱5.50 (2026-11-06) · all-time high ₱45.50 (2010-01-27) · low ₱1.43 (2025-01-28) · now -87.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱8.20 start · H 45.50 L 7.91 · ₱2.2M/d
- 2011: ₱4.99 -39.1% · H 8.55 L 4.75 · ₱407.5K/d
- 2012: ₱3.98 -20.2% · H 5.30 L 3.86 · ₱299.7K/d
- 2013: ₱2.50 -37.2% · H 4.20 L 1.88 · ₱420.6K/d
- 2014: ₱6.77 +170.8% · H 8.84 L 2.50 · ₱5.5M/d · div ₱0.0632 (0.9%): 26Feb 0.06319
- 2015: ₱5.64 -16.7% · H 7.00 L 5.16 · ₱5.2M/d · div ₱0.1868 (3.3%): 27Feb 0.1868
- 2016: ₱6.08 +7.8% · H 7.40 L 4.85 · ₱5.0M/d · div ₱0.2204 (3.6%): 18Feb 0.2204
- 2017: ₱18.82 +209.5% · H 22.30 L 6.05 · ₱37.5M/d · div ₱0.2274 (1.2%): 17Apr 0.22739
- 2018: ₱10.60 -43.7% · H 22.60 L 7.51 · ₱27.9M/d · div ₱0.2350 (2.2%): 02Mar 0.235
- 2019: ₱7.89 -25.6% · H 13.70 L 7.68 · ₱7.1M/d · div ₱0.1054 (1.3%): 22Apr 0.10542
- 2020: ₱9.10 +15.3% · H 9.50 L 3.31 · ₱4.9M/d
- 2021: ₱8.40 -7.7% · H 14.84 L 7.50 · ₱13.1M/d
- 2022: ₱4.87 -42.0% · H 10.56 L 4.55 · ₱3.0M/d
- 2023: ₱3.16 -35.1% · H 5.84 L 3.03 · ₱2.4M/d
- 2024: ₱1.49 -52.8% · H 3.19 L 1.48 · ₱1.4M/d
- 2025: ₱3.47 +132.9% · H 3.66 L 1.43 · ₱2.1M/d
- 2026*: ₱5.50 +58.5% · H 8.55 L 2.62 · ₱14.6M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
