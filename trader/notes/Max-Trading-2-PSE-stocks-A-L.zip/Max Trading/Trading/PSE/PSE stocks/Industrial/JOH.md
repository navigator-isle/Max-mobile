---
tags: [trading, pse, stock, joh]
---
**JOH — Jolliville Holdings Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Jun 17, 2002
- Data: 2002-06-17 → 2026-11-04 (1,718 trading days)
- Last close ₱2.80 (2026-11-04) · all-time high ₱8.96 (2023-12-29) · low ₱0.6100 (2007-02-26) · now -68.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2006-07-17 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2002: ₱1.02 start · H 1.28 L 0.7400 · ₱133.4K/d
- 2003: ₱2.04 +100.0% · H 2.04 L 1.20 · ₱149.4K/d
- 2004: ₱1.94 -4.9% · H 2.02 L 1.10 · ₱697.6K/d
- 2006: ₱0.6300 start · H 1.04 L 0.6300 · ₱20.5K/d
- 2007: ₱1.80 +185.7% · H 4.90 L 0.6100 · ₱1.6M/d
- 2008: ₱1.00 -44.4% · H 1.80 L 1.00 · ₱624.2K/d
- 2009: ₱1.86 +86.0% · H 3.80 L 1.00 · ₱2.9M/d
- 2010: ₱2.85 +53.2% · H 3.05 L 1.56 · ₱197.4K/d
- 2011: ₱2.42 -15.1% · H 4.08 L 2.32 · ₱308.0K/d
- 2012: ₱5.70 +135.5% · H 8.18 L 2.08 · ₱377.2K/d
- 2013: ₱5.80 +1.8% · H 8.10 L 4.50 · ₱152.6K/d
- 2014: ₱3.80 -34.5% · H 6.00 L 3.71 · ₱47.4K/d
- 2015: ₱3.70 -2.6% · H 6.37 L 2.88 · ₱80.3K/d
- 2016: ₱4.30 +16.2% · H 6.20 L 3.35 · ₱77.4K/d
- 2017: ₱6.00 +39.5% · H 6.90 L 3.85 · ₱191.4K/d
- 2018: ₱6.78 +13.0% · H 6.78 L 4.29 · ₱165.8K/d
- 2019: ₱6.65 -1.9% · H 6.65 L 5.00 · ₱80.4K/d
- 2020: ₱5.20 -21.8% · H 6.99 L 4.22 · ₱704.3K/d
- 2021: ₱5.45 +4.8% · H 6.78 L 4.20 · ₱104.8K/d
- 2022: ₱6.11 +12.1% · H 6.11 L 3.57 · ₱21.1K/d
- 2023: ₱8.96 +46.6% · H 8.96 L 3.43 · ₱47.0K/d
- 2024: ₱6.79 -24.2% · H 8.30 L 4.50 · ₱88.5K/d
- 2025: ₱3.08 -54.6% · H 7.26 L 3.08 · ₱78.7K/d
- 2026*: ₱2.80 -9.1% · H 4.30 L 2.80 · ₱35.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
