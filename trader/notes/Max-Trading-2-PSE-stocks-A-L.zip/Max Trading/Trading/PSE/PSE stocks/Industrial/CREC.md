---
tags: [trading, pse, stock, crec]
---
**CREC — Citicore Renewable Energy Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power and Water · listed Jun 07, 2024
- Data: 2024-06-07 → 2026-11-06 (591 trading days)
- Last close ₱4.50 (2026-11-06) · all-time high ₱5.02 (2026-09-01) · low ₱2.56 (2024-07-08) · now -10.4% from high
- Cash dividends last 12 months ₱0.0224 = 0.5% yield
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2024: ₱3.21 start · H 3.40 L 2.56 · ₱5.8M/d
- 2025: ₱4.28 +33.3% · H 4.50 L 3.24 · ₱4.2M/d
- 2026*: ₱4.50 +5.1% · H 5.02 L 4.00 · ₱1.1M/d · div ₱0.0224 (0.5%): 16Jul 0.0224

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
