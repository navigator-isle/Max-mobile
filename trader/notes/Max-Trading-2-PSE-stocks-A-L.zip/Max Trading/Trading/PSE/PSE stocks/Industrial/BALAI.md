---
tags: [trading, pse, stock, balai]
---
**BALAI — Balai Ni Fruitas Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage, &amp; Tobacco · listed Jun 30, 2022
- Data: 2022-06-30 → 2026-11-03 (928 trading days)
- Last close ₱0.2900 (2026-11-03) · all-time high ₱1.05 (2022-08-30) · low ₱0.2800 (2026-09-24) · now -72.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱0.5800 start · H 1.05 L 0.5500 · ₱8.8M/d
- 2023: ₱0.3900 -32.8% · H 0.7300 L 0.3800 · ₱3.1M/d · div ₱0.005 (1.3%): 26May 0.005
- 2024: ₱0.3600 -7.7% · H 0.4900 L 0.3400 · ₱146.3K/d · div ₱0.005 (1.4%): 23Oct 0.005
- 2025: ₱0.3500 -2.8% · H 0.4100 L 0.2900 · ₱213.1K/d · div ₱0.005 (1.4%): 26Jun 0.005
- 2026*: ₱0.2900 -17.1% · H 0.3950 L 0.2800 · ₱119.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
