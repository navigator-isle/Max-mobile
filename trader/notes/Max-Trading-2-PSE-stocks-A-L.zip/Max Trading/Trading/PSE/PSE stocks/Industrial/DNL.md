---
tags: [trading, pse, stock, dnl]
---
**DNL — D&amp;L Industries, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Dec 12, 2012
- Data: 2012-12-12 → 2026-11-06 (3,384 trading days)
- Last close ₱3.57 (2026-11-06) · all-time high ₱22.85 (2015-08-06) · low ₱2.18 (2012-12-12) · now -84.4% from high
- Cash dividends last 12 months ₱0.2360 = 6.6% yield
- Dividend events on record (2013 → 2026): 25
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-05 (÷0.5), 2015-08-17 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱2.20 start · H 2.23 L 2.18 · ₱34.1M/d
- 2013: ₱3.15 +43.2% · H 4.25 L 2.18 · ₱25.5M/d · div ₱0.1500 (4.8%): 19Jul 0.05S, 19Jul 0.1
- 2014: ₱8.33 +164.4% · H 8.42 L 3.23 · ₱33.2M/d · div ₱0.1000 (1.2%): 13Jun 0.1S
- 2015: ₱9.15 +9.8% · H 22.85 L 7.98 · ₱100.6M/d · div ₱0.1500 (1.6%): 25Jun 0.15
- 2016: ₱11.40 +24.6% · H 12.10 L 7.02 · ₱57.5M/d · div ₱0.2000 (1.8%): 15Jun 0.04S, 15Jun 0.16
- 2017: ₱11.06 -3.0% · H 13.48 L 10.00 · ₱65.0M/d · div ₱0.2350 (2.1%): 24Jul 0.05S, 24Jul 0.185
- 2018: ₱10.98 -0.7% · H 12.76 L 9.68 · ₱29.8M/d · div ₱0.2600 (2.4%): 15Jun 0.055S, 15Jun 0.205
- 2019: ₱9.50 -13.5% · H 11.90 L 8.26 · ₱30.0M/d · div ₱0.2860 (3.0%): 21Jun 0.063S, 21Jun 0.223
- 2020: ₱7.70 -18.9% · H 9.60 L 3.97 · ₱20.6M/d · div ₱0.1830 (2.4%): 29Sep 0.183
- 2021: ₱9.45 +22.7% · H 9.45 L 6.63 · ₱28.2M/d · div ₱0.1910 (2.0%): 16Jun 0.05S, 16Jun 0.141
- 2022: ₱7.90 -16.4% · H 9.00 L 6.50 · ₱19.8M/d · div ₱0.2400 (3.0%): 16Jun 0.055S, 16Jun 0.185
- 2023: ₱6.31 -20.1% · H 8.73 L 5.98 · ₱16.7M/d · div ₱0.3000 (4.8%): 15Jun 0.06S, 15Jun 0.24
- 2024: ₱6.09 -3.5% · H 7.00 L 5.78 · ₱10.3M/d · div ₱0.2090 (3.4%): 18Jun 0.048S, 18Jun 0.161
- 2025: ₱3.85 -36.8% · H 6.21 L 3.28 · ₱16.9M/d · div ₱0.2130 (5.5%): 17Jun 0.049S, 17Jun 0.164
- 2026*: ₱3.57 -7.3% · H 4.49 L 3.31 · ₱10.5M/d · div ₱0.2360 (6.6%): 22Jun 0.054, 22Jun 0.182

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
