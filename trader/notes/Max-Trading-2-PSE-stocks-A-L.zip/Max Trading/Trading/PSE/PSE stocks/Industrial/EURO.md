---
tags: [trading, pse, stock, euro]
---
**EURO — Euro-Med Laboratories Phil., Inc.**
- Status: listed on PSE · sector Industrial › Chemicals · listed Jul 02, 1998
- Data: 1998-07-02 → 2026-11-06 (2,872 trading days)
- Last close ₱1.26 (2026-11-06) · all-time high ₱5.33 (1999-08-12) · low ₱0.7000 (2023-07-25) · now -76.3% from high
- Cash dividends last 12 months ₱0.0700 = 5.6% yield
- Dividend events on record (2013 → 2026): 14
- Splits / stock dividends detected (prices before these dates are as traded then): 2006-02-22 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1998: ₱3.89 start · H 4.05 L 1.95 · ₱5.3M/d
- 1999: ₱4.95 +27.2% · H 5.33 L 3.74 · ₱1.6M/d
- 2000: ₱4.67 -5.7% · H 5.23 L 3.93 · ₱62.0K/d
- 2001: ₱4.67 +0.0% · H 4.95 L 2.71 · ₱193.1K/d
- 2002: ₱4.58 -2.0% · H 4.95 L 3.74 · ₱67.0K/d
- 2003: ₱2.80 -38.8% · H 4.53 L 2.48 · ₱23.6K/d
- 2004: ₱2.66 -5.0% · H 3.55 L 1.89 · ₱16.9K/d
- 2005: ₱3.41 +28.1% · H 3.74 L 1.87 · ₱51.4K/d
- 2006: ₱2.20 -35.5% · H 3.69 L 2.06 · ₱51.9K/d
- 2007: ₱2.00 -9.1% · H 2.50 L 1.44 · ₱76.5K/d
- 2008: ₱1.76 -12.0% · H 2.00 L 1.20 · ₱54.5K/d
- 2009: ₱1.70 -3.4% · H 2.00 L 1.30 · ₱49.1K/d
- 2010: ₱1.50 -11.8% · H 1.78 L 1.06 · ₱59.6K/d
- 2011: ₱1.51 +0.7% · H 1.80 L 1.00 · ₱22.9K/d
- 2012: ₱1.80 +19.2% · H 2.85 L 1.20 · ₱262.1K/d
- 2013: ₱1.50 -16.7% · H 2.30 L 1.01 · ₱60.3K/d · div ₱0.0500 (3.3%): 17Jun 0.05
- 2014: ₱1.36 -9.3% · H 2.02 L 1.21 · ₱71.3K/d · div ₱0.0500 (3.7%): 16Jun 0.05
- 2015: ₱1.66 +22.1% · H 2.69 L 1.30 · ₱194.9K/d · div ₱0.0500 (3.0%): 15Jun 0.05
- 2016: ₱1.80 +8.4% · H 1.90 L 1.51 · ₱42.7K/d · div ₱0.0500 (2.8%): 13Jun 0.05
- 2017: ₱1.66 -7.8% · H 1.82 L 1.54 · ₱54.6K/d · div ₱0.0500 (3.0%): 26Jun 0.05
- 2018: ₱1.70 +2.4% · H 1.86 L 1.46 · ₱41.5K/d · div ₱0.0500 (2.9%): 18Jun 0.05
- 2019: ₱1.60 -5.9% · H 1.77 L 1.51 · ₱67.8K/d · div ₱0.0700 (4.4%): 17Jun 0.07
- 2020: ₱2.34 +46.2% · H 3.83 L 1.58 · ₱7.8M/d · div ₱0.0500 (2.1%): 12Aug 0.05
- 2021: ₱1.40 -40.2% · H 2.76 L 1.40 · ₱565.1K/d
- 2022: ₱0.8700 -37.9% · H 1.50 L 0.8000 · ₱32.9K/d · div ₱0.0350 (4.0%): 04Jan 0.015, 28Oct 0.02
- 2023: ₱0.7500 -13.8% · H 1.00 L 0.7000 · ₱22.5K/d · div ₱0.0350 (4.7%): 09Nov 0.035
- 2024: ₱0.8200 +9.3% · H 0.9200 L 0.7100 · ₱28.6K/d · div ₱0.0600 (7.3%): 14Nov 0.06
- 2025: ₱1.00 +22.0% · H 1.10 L 0.7200 · ₱33.7K/d · div ₱0.0700 (7.0%): 13Nov 0.07
- 2026*: ₱1.26 +26.0% · H 1.30 L 0.9800 · ₱36.8K/d · div ₱0.0750 (6.0%): 12Nov 0.075 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
