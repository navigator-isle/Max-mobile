---
tags: [trading, pse, stock, aslag]
---
**ASLAG — Raslag Corp.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Jun 06, 2022
- Data: 2022-06-06 → 2026-11-06 (1,049 trading days)
- Last close ₱1.11 (2026-11-06) · all-time high ₱2.25 (2022-09-06) · low ₱0.7500 (2025-11-11) · now -50.7% from high
- Cash dividends last 12 months ₱0.0500 = 4.5% yield
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱1.66 start · H 2.25 L 1.60 · ₱16.5M/d · div ₱0.0334 (2.0%): 05Dec 0.0334
- 2023: ₱1.29 -22.3% · H 1.79 L 1.14 · ₱807.8K/d · div ₱0.0500 (3.9%): 06Nov 0.05
- 2024: ₱1.03 -20.2% · H 1.43 L 0.9600 · ₱277.5K/d · div ₱0.0500 (4.9%): 30Oct 0.05
- 2025: ₱0.8200 -20.4% · H 1.09 L 0.7500 · ₱126.0K/d · div ₱0.0500 (6.1%): 27Nov 0.0133, 27Nov 0.0367
- 2026*: ₱1.11 +35.4% · H 1.20 L 0.7700 · ₱1.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
