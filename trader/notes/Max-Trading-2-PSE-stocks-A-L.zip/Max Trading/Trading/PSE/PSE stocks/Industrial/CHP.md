---
tags: [trading, pse, stock, chp]
---
**CHP — Concreat Holdings Philippines, Inc.**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Jul 18, 2016
- Data: 2016-07-18 → 2026-11-06 (2,514 trading days)
- Last close ₱1.15 (2026-11-06) · all-time high ₱12.66 (2016-08-19) · low ₱0.5900 (2022-07-13) · now -90.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱11.10 start · H 12.66 L 10.64 · ₱187.9M/d
- 2017: ₱4.88 -56.0% · H 11.90 L 4.00 · ₱72.4M/d
- 2018: ₱1.90 -61.1% · H 5.30 L 1.63 · ₱19.5M/d
- 2019: ₱2.01 +5.8% · H 3.34 L 1.82 · ₱37.1M/d
- 2020: ₱1.45 -27.9% · H 2.09 L 0.8900 · ₱21.4M/d
- 2021: ₱1.05 -27.6% · H 1.56 L 1.00 · ₱5.0M/d
- 2022: ₱0.6100 -41.9% · H 1.10 L 0.5900 · ₱2.5M/d
- 2023: ₱0.9400 +54.1% · H 1.22 L 0.6000 · ₱4.5M/d
- 2024: ₱1.78 +89.4% · H 2.18 L 0.8900 · ₱13.1M/d
- 2025: ₱1.09 -38.8% · H 1.93 L 1.00 · ₱1.6M/d
- 2026*: ₱1.15 +5.5% · H 1.43 L 0.7000 · ₱1.6M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
