---
tags: [trading, pse, stock, jfc]
---
**JFC — Jollibee Foods Corporation**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Jul 14, 1993
- Data: 1993-07-14 → 2026-11-06 (8,153 trading days)
- Last close ₱149.0 (2026-11-06) · all-time high ₱325.2 (2019-01-21) · low ₱6.40 (1995-03-23) · now -54.2% from high
- Cash dividends last 12 months ₱3.44 = 2.3% yield
- Dividend events on record (2013 → 2026): 28

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱9.49 start · H 10.03 L 6.83 · ₱5.4M/d
- 1994: ₱8.80 -7.3% · H 10.13 L 7.52 · ₱3.8M/d
- 1995: ₱14.20 +61.4% · H 14.60 L 6.40 · ₱8.3M/d
- 1996: ₱27.50 +93.7% · H 29.00 L 14.20 · ₱6.5M/d
- 1997: ₱16.75 -39.1% · H 28.50 L 12.75 · ₱3.3M/d
- 1998: ₱15.00 -10.4% · H 20.00 L 9.30 · ₱2.1M/d
- 1999: ₱16.25 +8.3% · H 22.50 L 13.00 · ₱3.0M/d
- 2000: ₱9.70 -40.3% · H 16.50 L 9.60 · ₱2.1M/d
- 2001: ₱12.25 +26.3% · H 14.00 L 9.50 · ₱5.3M/d
- 2002: ₱18.25 +49.0% · H 18.25 L 11.75 · ₱6.5M/d
- 2003: ₱18.25 +0.0% · H 18.75 L 15.25 · ₱9.3M/d
- 2004: ₱28.50 +56.2% · H 31.00 L 16.25 · ₱8.2M/d
- 2005: ₱40.50 +42.1% · H 44.00 L 25.50 · ₱12.2M/d
- 2006: ₱42.00 +3.7% · H 42.00 L 30.50 · ₱16.6M/d
- 2007: ₱52.00 +23.8% · H 60.00 L 42.00 · ₱35.2M/d
- 2008: ₱41.50 -20.2% · H 52.50 L 32.00 · ₱34.0M/d
- 2009: ₱55.00 +32.5% · H 55.00 L 39.00 · ₱32.8M/d
- 2010: ₱88.90 +61.6% · H 97.00 L 52.00 · ₱46.2M/d
- 2011: ₱90.45 +1.7% · H 98.50 L 68.05 · ₱45.4M/d
- 2012: ₱102.0 +12.8% · H 119.5 L 89.20 · ₱46.9M/d
- 2013: ₱173.1 +69.7% · H 185.0 L 104.2 · ₱107.0M/d · div ₱3.36 (1.9%): 02May 0.65, 16Sep 2S, 26Nov 0.71
- 2014: ₱215.0 +24.2% · H 215.0 L 151.0 · ₱112.9M/d · div ₱1.64 (0.8%): 05May 0.75, 24Nov 0.89
- 2015: ₱219.0 +1.9% · H 235.8 L 180.0 · ₱166.0M/d · div ₱1.77 (0.8%): 04May 0.8, 20Nov 0.97
- 2016: ₱194.0 -11.4% · H 260.0 L 185.5 · ₱175.3M/d · div ₱1.86 (1.0%): 18Apr 0.86, 23Nov 1
- 2017: ₱253.0 +30.4% · H 259.8 L 182.1 · ₱160.6M/d · div ₱2.18 (0.9%): 18Apr 1, 22Nov 1.18
- 2018: ₱291.8 +15.3% · H 305.4 L 243.0 · ₱206.8M/d · div ₱2.48 (0.8%): 19Apr 1.14, 21Nov 1.34
- 2019: ₱216.0 -26.0% · H 325.2 L 184.1 · ₱238.8M/d · div ₱2.58 (1.2%): 23Apr 1.23, 21Nov 1.35
- 2020: ₱195.2 -9.6% · H 217.0 L 91.10 · ₱193.0M/d · div ₱1.30 (0.7%): 22Apr 0.62, 19Nov 0.68S
- 2021: ₱216.4 +10.9% · H 259.8 L 167.2 · ₱150.6M/d · div ₱1.67 (0.8%): 21Apr 0.78, 18Nov 0.89
- 2022: ₱230.0 +6.3% · H 256.0 L 192.0 · ₱147.8M/d · div ₱2.30 (1.0%): 02May 1.07, 18Nov 1.23
- 2023: ₱251.4 +9.3% · H 261.0 L 205.0 · ₱145.7M/d · div ₱2.30 (0.9%): 27Apr 1.07, 23Nov 1.23
- 2024: ₱269.0 +7.0% · H 278.6 L 211.0 · ₱157.2M/d · div ₱2.97 (1.1%): 08May 1.15, 22Nov 1.82
- 2025: ₱180.0 -33.1% · H 268.0 L 177.0 · ₱179.6M/d · div ₱3.44 (1.9%): 30Apr 1.33, 27Nov 2.11
- 2026*: ₱149.0 -17.2% · H 219.4 L 122.0 · ₱240.3M/d · div ₱1.33 (0.9%): 04May 1.33

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
