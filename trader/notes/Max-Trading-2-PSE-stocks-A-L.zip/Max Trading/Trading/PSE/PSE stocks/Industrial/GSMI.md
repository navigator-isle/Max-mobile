---
tags: [trading, pse, stock, gsmi]
---
**GSMI — Ginebra San Miguel,  Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Apr 18, 1995
- Data: 1995-04-18 → 2026-11-06 (7,048 trading days)
- Last close ₱209.8 (2026-11-06) · all-time high ₱308.0 (2025-03-07) · low ₱8.00 (1998-09-10) · now -31.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 43

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱29.00 start · H 34.00 L 23.00 · ₱5.0M/d
- 1996: ₱65.00 +124.1% · H 68.00 L 25.50 · ₱16.3M/d
- 1997: ₱18.50 -71.5% · H 75.00 L 17.50 · ₱12.0M/d
- 1998: ₱31.00 +67.6% · H 33.00 L 8.00 · ₱7.0M/d
- 1999: ₱32.00 +3.2% · H 51.50 L 27.50 · ₱24.4M/d
- 2000: ₱30.50 -4.7% · H 35.00 L 20.50 · ₱6.7M/d
- 2001: ₱23.50 -23.0% · H 39.00 L 23.00 · ₱5.3M/d
- 2002: ₱35.00 +48.9% · H 35.50 L 21.75 · ₱13.3M/d
- 2003: ₱32.00 -8.6% · H 36.00 L 25.00 · ₱2.6M/d
- 2004: ₱30.50 -4.7% · H 32.50 L 27.00 · ₱1.7M/d
- 2005: ₱23.75 -22.1% · H 38.00 L 22.00 · ₱2.7M/d
- 2006: ₱21.00 -11.6% · H 25.00 L 18.00 · ₱1.5M/d
- 2007: ₱26.00 +23.8% · H 28.00 L 20.50 · ₱1.7M/d
- 2008: ₱13.25 -49.0% · H 26.00 L 12.75 · ₱2.0M/d
- 2009: ₱21.75 +64.2% · H 23.25 L 12.00 · ₱1.1M/d
- 2010: ₱33.00 +51.7% · H 33.20 L 19.75 · ₱3.5M/d
- 2011: ₱23.30 -29.4% · H 34.00 L 22.80 · ₱1.1M/d
- 2012: ₱17.80 -23.6% · H 24.40 L 17.00 · ₱1.4M/d
- 2013: ₱23.00 +29.2% · H 27.20 L 12.50 · ₱4.8M/d
- 2014: ₱15.88 -31.0% · H 22.65 L 15.12 · ₱589.2K/d
- 2015: ₱12.28 -22.7% · H 15.88 L 10.52 · ₱284.7K/d
- 2016: ₱12.70 +3.4% · H 15.70 L 11.00 · ₱354.1K/d
- 2017: ₱26.85 +111.4% · H 28.90 L 12.10 · ₱6.9M/d
- 2018: ₱26.75 -0.4% · H 32.50 L 18.00 · ₱5.2M/d
- 2019: ₱38.00 +42.1% · H 68.30 L 25.00 · ₱7.8M/d · div ₱1.00 (2.6%): 25Mar 0.25, 21May 0.25, 27Aug 0.25, 19Nov 0.25
- 2020: ₱49.40 +30.0% · H 53.50 L 29.85 · ₱2.5M/d · div ₱1.00 (2.0%): 24Mar 0.25, 09Jun 0.25, 18Aug 0.25, 16Nov 0.25
- 2021: ₱113.8 +130.4% · H 118.5 L 50.00 · ₱7.2M/d · div ₱4.00 (3.5%): 22Mar 0.25, 18May 0.25, 18May 1S, 16Aug 0.25, 16Aug 1S, 22Nov 0.25, 22Nov 1S
- 2022: ₱105.0 -7.7% · H 124.0 L 96.70 · ₱2.8M/d · div ₱5.50 (5.2%): 22Mar 0.375, 22Mar 1S, 13May 0.375, 13May 1S, 16Aug 0.375, 16Aug 1S, 21Nov 0.375, 21Nov 1S
- 2023: ₱168.7 +60.7% · H 171.4 L 103.6 · ₱6.6M/d · div ₱10.00 (5.9%): 21Mar 0.75, 21Mar 1.75S, 19May 0.75, 19May 1.75S, 11Aug 0.75, 11Aug 1.75S, 21Nov 0.75, 21Nov 1.75S
- 2024: ₱275.0 +63.0% · H 278.8 L 155.6 · ₱5.7M/d · div ₱9.50 (3.5%): 20Mar 0.75, 20Mar 1.75S, 16May 1.5S, 21Aug 1.5S, 20Nov 1.5S, 20Nov 2.5
- 2025: ₱295.0 +7.3% · H 308.0 L 271.8 · ₱5.3M/d · div ₱12.00 (4.1%): 19Mar 1.5S, 19Mar 2.5, 19May 1.5S, 19May 2.5, 19Aug 1.5S, 19Aug 2.5
- 2026*: ₱209.8 -28.9% · H 301.0 L 199.5 · ₱10.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
