---
tags: [trading, pse, stock, crown]
---
**CROWN — Crown Asia Chemicals Corporation**
- Status: listed on PSE · sector Industrial › Chemicals · listed Apr 27, 2015
- Data: 2015-04-27 → 2026-11-06 (2,750 trading days)
- Last close ₱1.89 (2026-11-06) · all-time high ₱3.20 (2015-08-10) · low ₱1.26 (2022-09-21) · now -40.9% from high
- Cash dividends last 12 months ₱0.2000 = 10.6% yield
- Dividend events on record (2013 → 2026): 18

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱2.35 start · H 3.20 L 1.53 · ₱13.2M/d
- 2016: ₱1.85 -21.3% · H 2.55 L 1.84 · ₱2.7M/d · div ₱0.0500 (2.7%): 05May 0.018, 05May 0.032S
- 2017: ₱1.90 +2.7% · H 2.20 L 1.87 · ₱1.2M/d · div ₱0.0900 (4.7%): 07Apr 0.04, 21Jun 0.05
- 2018: ₱1.80 -5.3% · H 2.13 L 1.35 · ₱540.8K/d · div ₱0.0900 (5.0%): 06Apr 0.04, 21Jun 0.05
- 2019: ₱2.15 +19.4% · H 2.19 L 1.73 · ₱684.3K/d · div ₱0.0900 (4.2%): 08Apr 0.05, 04Jul 0.04
- 2020: ₱1.87 -13.0% · H 2.19 L 1.72 · ₱253.1K/d · div ₱0.0400 (2.1%): 23Jun 0.04
- 2021: ₱1.69 -9.6% · H 2.20 L 1.64 · ₱1.2M/d · div ₱0.0225 (1.3%): 20May 0.0225
- 2022: ₱1.55 -8.3% · H 1.88 L 1.26 · ₱476.6K/d · div ₱0.1000 (6.5%): 22Mar 0.05, 23Jun 0.05
- 2023: ₱1.56 +0.6% · H 1.62 L 1.47 · ₱178.1K/d · div ₱0.0900 (5.8%): 31Mar 0.05, 30Aug 0.04
- 2024: ₱1.71 +9.6% · H 2.07 L 1.51 · ₱235.7K/d · div ₱0.1000 (5.8%): 27May 0.1
- 2025: ₱1.68 -1.8% · H 1.83 L 1.60 · ₱367.1K/d · div ₱0.1000 (6.0%): 21Mar 0.1
- 2026*: ₱1.89 +12.5% · H 1.94 L 1.63 · ₱304.9K/d · div ₱0.2000 (10.6%): 24Mar 0.1, 19Aug 0.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
