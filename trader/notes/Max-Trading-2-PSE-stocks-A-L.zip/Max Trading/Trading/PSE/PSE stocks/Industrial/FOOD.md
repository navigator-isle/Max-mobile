---
tags: [trading, pse, stock, food]
---
**FOOD — Alliance Select Foods International, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Nov 08, 2006
- Data: 2010-08-05 → 2026-11-06 (3,435 trading days)
- Last close ₱0.5900 (2026-11-06) · all-time high ₱2.19 (2012-11-27) · low ₱0.2600 (2026-07-08) · now -73.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱1.43 start · H 1.63 L 1.38 · ₱734.9K/d
- 2011: ₱1.42 -0.7% · H 1.82 L 0.9800 · ₱2.2M/d
- 2012: ₱1.97 +38.7% · H 2.19 L 1.24 · ₱5.0M/d
- 2013: ₱1.00 -49.2% · H 2.14 L 0.9300 · ₱2.9M/d
- 2014: ₱1.24 +24.0% · H 1.65 L 0.9600 · ₱929.7K/d
- 2015: ₱0.7900 -36.3% · H 1.30 L 0.7000 · ₱584.7K/d
- 2016: ₱0.8500 +7.6% · H 1.35 L 0.5700 · ₱2.0M/d
- 2017: ₱0.6200 -27.1% · H 0.9500 L 0.6100 · ₱1.1M/d
- 2018: ₱1.06 +71.0% · H 1.29 L 0.5300 · ₱7.1M/d
- 2019: ₱0.5100 -51.9% · H 1.18 L 0.5000 · ₱2.5M/d
- 2020: ₱0.6600 +29.4% · H 0.7400 L 0.4500 · ₱688.5K/d
- 2021: ₱0.6200 -6.1% · H 0.6900 L 0.5200 · ₱322.9K/d
- 2022: ₱0.5500 -11.3% · H 0.6400 L 0.5100 · ₱58.9K/d
- 2023: ₱0.4600 -16.4% · H 0.5600 L 0.4600 · ₱144.0K/d
- 2024: ₱0.3800 -17.4% · H 0.5000 L 0.3700 · ₱86.1K/d
- 2025: ₱0.3700 -2.6% · H 0.5800 L 0.3600 · ₱95.5K/d
- 2026*: ₱0.5900 +59.5% · H 0.7000 L 0.2600 · ₱414.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
