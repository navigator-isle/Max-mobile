---
tags: [trading, pse, stock, axlm]
---
**AXLM — Axelum Resources Corp.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Oct 07, 2019
- Data: 2019-10-07 → 2026-11-06 (1,679 trading days)
- Last close ₱2.77 (2026-11-06) · all-time high ₱4.70 (2019-10-08) · low ₱1.68 (2025-11-03) · now -41.1% from high
- Cash dividends last 12 months ₱0.0638 = 2.3% yield
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱2.61 start · H 4.70 L 2.46 · ₱39.4M/d
- 2020: ₱3.50 +34.1% · H 3.82 L 1.88 · ₱11.4M/d · div ₱0.0300 (0.9%): 27Mar 0.03
- 2021: ₱3.00 -14.3% · H 3.60 L 2.53 · ₱4.4M/d
- 2022: ₱2.52 -16.0% · H 2.90 L 2.05 · ₱809.4K/d
- 2023: ₱2.40 -4.8% · H 3.51 L 1.82 · ₱1.6M/d
- 2024: ₱2.59 +7.9% · H 2.59 L 1.80 · ₱863.9K/d
- 2025: ₱2.36 -8.9% · H 2.37 L 1.68 · ₱428.7K/d · div ₱0.0515 (2.2%): 07May 0.0515S
- 2026*: ₱2.77 +17.4% · H 3.08 L 1.91 · ₱935.4K/d · div ₱0.0638 (2.3%): 07May 0.063775

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
