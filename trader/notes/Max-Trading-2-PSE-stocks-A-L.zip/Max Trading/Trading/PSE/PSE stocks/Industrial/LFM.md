---
tags: [trading, pse, stock, lfm]
---
**LFM — Liberty Flour Mills, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Apr 25, 1985
- Data: 2006-04-05 → 2026-11-06 (2,039 trading days)
- Last close ₱18.98 (2026-11-06) · all-time high ₱106.0 (2011-02-15) · low ₱10.58 (2023-09-18) · now -82.1% from high
- Cash dividends last 12 months ₱0.6000 = 3.2% yield
- Dividend events on record (2013 → 2026): 20
- Splits / stock dividends detected (prices before these dates are as traded then): 2018-07-03 (÷2), 2020-02-06 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱16.00 start · H 16.00 L 16.00 · ₱6.5M/d
- 2007: ₱26.00 +62.5% · H 27.00 L 20.00 · ₱433.7K/d
- 2008: ₱28.00 +7.7% · H 30.00 L 27.00 · ₱204.7K/d
- 2009: ₱30.00 +7.1% · H 30.00 L 28.00 · ₱2.7M/d
- 2010: ₱36.50 +21.7% · H 36.50 L 30.00 · ₱824.4K/d
- 2011: ₱55.00 +50.7% · H 106.0 L 28.75 · ₱152.4K/d
- 2012: ₱45.00 -18.2% · H 62.00 L 38.00 · ₱94.5K/d
- 2013: ₱48.55 +7.9% · H 55.50 L 48.00 · ₱195.0K/d · div ₱1.50 (3.1%): 18Jun 1, 11Nov 0.5
- 2014: ₱60.80 +25.2% · H 76.50 L 51.05 · ₱174.6K/d · div ₱1.00 (1.6%): 10Apr 1
- 2015: ₱26.00 -57.2% · H 70.00 L 26.00 · ₱136.2K/d · div ₱2.00 (7.7%): 05Jun 1, 12Oct 1
- 2016: ₱74.95 +188.3% · H 94.00 L 23.60 · ₱156.9K/d · div ₱1.50 (2.0%): 08Mar 1.5
- 2017: ₱58.55 -21.9% · H 79.00 L 36.20 · ₱530.3K/d · div ₱0.7500 (1.3%): 04Apr 0.75
- 2018: ₱45.00 -23.1% · H 65.00 L 26.40 · ₱262.4K/d · div ₱1.00 (2.2%): 03Apr 0.5, 07Nov 0.5
- 2019: ₱41.65 -7.4% · H 59.25 L 26.40 · ₱206.5K/d · div ₱0.3000 (0.7%): 07May 0.3
- 2020: ₱38.60 -7.3% · H 67.90 L 27.05 · ₱1.2M/d · div ₱0.5000 (1.3%): 09Jul 0.5
- 2021: ₱27.20 -29.5% · H 40.80 L 27.00 · ₱329.2K/d · div ₱0.5000 (1.8%): 08Jun 0.5
- 2022: ₱19.48 -28.4% · H 28.85 L 16.62 · ₱61.4K/d · div ₱0.3000 (1.5%): 13Dec 0.3
- 2023: ₱15.98 -18.0% · H 19.00 L 10.58 · ₱25.1K/d · div ₱0.7000 (4.4%): 14Apr 0.5, 14Nov 0.2
- 2024: ₱17.92 +12.1% · H 18.98 L 12.00 · ₱78.9K/d · div ₱0.3000 (1.7%): 18Jun 0.3
- 2025: ₱33.80 +88.6% · H 36.60 L 13.20 · ₱207.8K/d · div ₱6.80 (20.1%): 09Jan 2, 05Jun 2S, 27Oct 2.8
- 2026*: ₱18.98 -43.8% · H 35.50 L 18.98 · ₱121.8K/d · div ₱0.6000 (3.2%): 14Jan 0.6

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
