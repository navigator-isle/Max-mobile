---
tags: [trading, pse, stock, ap]
---
**AP — Aboitiz Power Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Jul 16, 2007
- Data: 2007-07-16 → 2026-11-06 (4,694 trading days)
- Last close ₱44.70 (2026-11-06) · all-time high ₱48.90 (2016-06-07) · low ₱3.25 (2008-10-28) · now -8.6% from high
- Cash dividends last 12 months ₱2.28 = 5.1% yield
- Dividend events on record (2013 → 2026): 18

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱5.30 start · H 5.80 L 3.90 · ₱54.7M/d
- 2008: ₱3.80 -28.3% · H 6.00 L 3.25 · ₱25.3M/d
- 2009: ₱8.60 +126.3% · H 8.90 L 3.90 · ₱39.5M/d
- 2010: ₱31.10 +261.6% · H 35.80 L 8.60 · ₱191.2M/d
- 2011: ₱29.90 -3.9% · H 32.60 L 26.20 · ₱157.4M/d
- 2012: ₱36.95 +23.6% · H 37.50 L 28.75 · ₱124.7M/d
- 2013: ₱34.00 -8.0% · H 39.95 L 31.00 · ₱97.0M/d · div ₱1.66 (4.9%): 14Mar 1.66
- 2014: ₱42.90 +26.2% · H 42.90 L 33.90 · ₱140.9M/d · div ₱1.66 (3.9%): 20Mar 0.4S, 20Mar 1.26
- 2015: ₱41.70 -2.8% · H 46.50 L 39.10 · ₱116.8M/d · div ₱1.66 (4.0%): 19Mar 0.52S, 19Mar 1.14
- 2016: ₱41.70 +0.0% · H 48.90 L 39.40 · ₱84.4M/d · div ₱1.66 (4.0%): 17Mar 0.46S, 17Mar 1.2
- 2017: ₱41.55 -0.4% · H 44.25 L 38.30 · ₱63.9M/d · div ₱1.36 (3.3%): 16Mar 1.36
- 2018: ₱35.10 -15.5% · H 41.80 L 31.20 · ₱59.5M/d · div ₱1.39 (4.0%): 19Mar 1.39
- 2019: ₱34.20 -2.6% · H 40.40 L 33.00 · ₱56.9M/d · div ₱1.47 (4.3%): 18Mar 1.47
- 2020: ₱26.55 -22.4% · H 35.00 L 23.45 · ₱42.0M/d · div ₱1.18 (4.4%): 17Mar 1.18
- 2021: ₱29.70 +11.9% · H 34.20 L 20.50 · ₱98.4M/d · div ₱0.8500 (2.9%): 16Mar 0.85
- 2022: ₱34.05 +14.6% · H 37.00 L 28.50 · ₱47.0M/d · div ₱1.45 (4.3%): 15Mar 1.45
- 2023: ₱37.80 +11.0% · H 39.80 L 30.00 · ₱86.8M/d · div ₱1.87 (4.9%): 14Mar 1.87
- 2024: ₱37.70 -0.3% · H 39.75 L 32.40 · ₱40.4M/d · div ₱2.30 (6.1%): 18Mar 2.3
- 2025: ₱44.00 +16.7% · H 44.55 L 35.00 · ₱61.2M/d · div ₱2.35 (5.3%): 20Mar 2.35
- 2026*: ₱44.70 +1.6% · H 48.00 L 40.00 · ₱53.3M/d · div ₱2.28 (5.1%): 18Mar 0.93, 18Mar 1.35

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
