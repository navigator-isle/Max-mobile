---
tags: [trading, pse, stock, fruit]
---
**FRUIT — Fruitas Holdings, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Nov 29, 2019
- Data: 2019-11-29 → 2026-11-06 (1,689 trading days)
- Last close ₱0.6700 (2026-11-06) · all-time high ₱2.03 (2020-02-10) · low ₱0.6000 (2024-12-19) · now -67.0% from high
- Cash dividends last 12 months ₱0.0100 = 1.5% yield
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱1.21 start · H 1.71 L 1.06 · ₱136.7M/d
- 2020: ₱1.70 +40.5% · H 2.03 L 1.00 · ₱28.4M/d · div ₱0.0100 (0.6%): 24Aug 0.01
- 2021: ₱1.22 -28.2% · H 1.77 L 1.17 · ₱16.6M/d
- 2022: ₱1.12 -8.2% · H 1.29 L 0.9500 · ₱5.0M/d · div ₱0.0100 (0.9%): 03Aug 0.01
- 2023: ₱0.9600 -14.3% · H 1.36 L 0.9500 · ₱7.3M/d · div ₱0.0100 (1.0%): 07Nov 0.01
- 2024: ₱0.6400 -33.3% · H 0.9600 L 0.6000 · ₱528.8K/d · div ₱0.0100 (1.6%): 08Nov 0.01
- 2025: ₱0.6400 +0.0% · H 0.7100 L 0.6000 · ₱224.1K/d · div ₱0.0100 (1.6%): 13Nov 0.01
- 2026*: ₱0.6700 +4.7% · H 0.7000 L 0.6200 · ₱209.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
