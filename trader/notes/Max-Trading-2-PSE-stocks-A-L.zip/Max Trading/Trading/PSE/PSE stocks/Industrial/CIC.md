---
tags: [trading, pse, stock, cic]
---
**CIC — Concepcion Industrial Corporation**
- Status: listed on PSE · sector Industrial › Electrical Components &amp; Equipment · listed Nov 27, 2013
- Data: 2013-11-27 → 2026-11-06 (2,825 trading days)
- Last close ₱10.78 (2026-11-06) · all-time high ₱89.00 (2017-06-27) · low ₱10.46 (2026-11-04) · now -87.9% from high
- Cash dividends last 12 months ₱1.00 = 9.3% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱20.42 start · H 21.67 L 19.83 · ₱7.1M/d
- 2014: ₱35.83 +75.5% · H 44.58 L 18.75 · ₱8.7M/d · div ₱0.5900 (1.6%): 28Mar 0.59
- 2015: ₱43.00 +20.0% · H 65.80 L 40.00 · ₱9.8M/d · div ₱0.5900 (1.4%): 17Apr 0.59
- 2016: ₱58.00 +34.9% · H 64.00 L 37.00 · ₱6.5M/d · div ₱0.6900 (1.2%): 19Apr 0.69
- 2017: ₱63.20 +9.0% · H 89.00 L 56.00 · ₱11.3M/d · div ₱1.00 (1.6%): 17Apr 1
- 2018: ₱37.00 -41.5% · H 65.40 L 33.45 · ₱10.5M/d · div ₱1.20 (3.2%): 18Apr 1.2
- 2019: ₱30.00 -18.9% · H 48.90 L 28.00 · ₱4.1M/d · div ₱1.20 (4.0%): 15Apr 1.2
- 2020: ₱23.40 -22.0% · H 32.50 L 17.58 · ₱2.0M/d · div ₱0.7000 (3.0%): 22May 0.7
- 2021: ₱20.40 -12.8% · H 24.00 L 19.70 · ₱1.7M/d · div ₱1.00 (4.9%): 09Mar 1
- 2022: ₱17.10 -16.2% · H 22.70 L 15.90 · ₱992.2K/d · div ₱1.00 (5.8%): 14Mar 1
- 2023: ₱14.50 -15.2% · H 17.28 L 12.22 · ₱143.8K/d · div ₱0.5000 (3.4%): 13Apr 0.5
- 2024: ₱13.38 -7.7% · H 14.50 L 11.30 · ₱861.7K/d · div ₱0.7000 (5.2%): 12Apr 0.7
- 2025: ₱13.60 +1.6% · H 15.44 L 12.86 · ₱1.2M/d · div ₱1.00 (7.4%): 10Apr 1
- 2026*: ₱10.78 -20.7% · H 14.60 L 10.46 · ₱959.4K/d · div ₱1.00 (9.3%): 13Apr 1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
