---
tags: [trading, pse, stock, green]
---
**GREEN — Greenergy Holdings Incorporated**
- Status: listed on PSE · sector Industrial › Electrical Components &amp; Equipment · listed Sep 26, 1996
- Data: 2000-01-03 → 2026-11-06 (5,258 trading days)
- Last close ₱0.1350 (2026-11-06) · all-time high ₱57.50 (2000-03-29) · low ₱0.1220 (2025-07-29) · now -99.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2018-11-05 (÷0.25)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱14.25 start · H 57.50 L 13.50 · ₱20.8M/d
- 2001: ₱1.65 -88.4% · H 17.50 L 1.55 · ₱1.3M/d
- 2002: ₱0.5000 -69.7% · H 2.05 L 0.4000 · ₱785.3K/d
- 2003: ₱1.65 +230.0% · H 2.40 L 0.4500 · ₱931.3K/d
- 2004: ₱1.62 -1.8% · H 1.98 L 1.32 · ₱477.0K/d
- 2005: ₱1.10 -32.1% · H 1.86 L 1.10 · ₱153.3K/d
- 2006: ₱1.30 +18.2% · H 1.46 L 1.06 · ₱149.2K/d
- 2007: ₱2.04 +56.9% · H 2.22 L 1.14 · ₱1.3M/d
- 2008: ₱1.15 -43.6% · H 3.30 L 1.00 · ₱4.2M/d
- 2009: ₱1.20 +4.3% · H 1.40 L 0.7300 · ₱4.7M/d
- 2010: ₱0.8800 -26.7% · H 1.20 L 0.6700 · ₱1.6M/d
- 2011: ₱1.20 +36.4% · H 1.30 L 0.6700 · ₱1.6M/d
- 2012: ₱2.20 +83.3% · H 2.50 L 1.10 · ₱8.5M/d
- 2013: ₱1.10 -50.0% · H 2.20 L 1.10 · ₱2.4M/d
- 2014: ₱0.4900 -55.5% · H 1.20 L 0.4200 · ₱1.1M/d
- 2015: ₱0.3700 -24.5% · H 0.5400 L 0.3700 · ₱207.2K/d
- 2018: ₱1.99 start · H 2.33 L 1.48 · ₱41.1M/d
- 2019: ₱1.87 -6.0% · H 3.51 L 1.87 · ₱28.4M/d
- 2020: ₱2.60 +39.0% · H 2.74 L 0.6500 · ₱12.9M/d
- 2021: ₱2.28 -12.3% · H 4.83 L 2.10 · ₱47.8M/d
- 2022: ₱1.46 -36.0% · H 2.27 L 1.45 · ₱13.7M/d
- 2023: ₱0.2290 -84.3% · H 1.50 L 0.2240 · ₱21.7M/d
- 2024: ₱0.1900 -17.0% · H 0.2500 L 0.1890 · ₱1.3M/d
- 2025: ₱0.1800 -5.3% · H 0.2040 L 0.1220 · ₱305.4K/d
- 2026*: ₱0.1350 -25.0% · H 0.1900 L 0.1280 · ₱319.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
