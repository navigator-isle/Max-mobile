---
tags: [trading, pse, stock, ca]
---
**CA — Concrete Aggregates Corporation**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Oct 20, 1972
- Data: 2006-04-04 → 2026-11-06 (1,733 trading days)
- Last close ₱58.00 (2026-11-06) · all-time high ₱391.8 (2016-04-07) · low ₱7.00 (2006-04-04) · now -85.2% from high
- Cash dividends last 12 months ₱1.77 = 3.1% yield
- Dividend events on record (2013 → 2026): 12

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱7.00 start · H 7.00 L 7.00 · ₱105.0K/d
- 2007: ₱36.00 +414.3% · H 40.00 L 7.30 · ₱94.6K/d
- 2008: ₱45.00 +25.0% · H 78.50 L 30.00 · ₱113.4K/d
- 2009: ₱81.00 +80.0% · H 81.00 L 32.00 · ₱38.4K/d
- 2010: ₱65.00 -19.8% · H 65.00 L 30.50 · ₱21.7K/d
- 2011: ₱60.00 -7.7% · H 100.0 L 36.00 · ₱126.5K/d
- 2012: ₱64.00 +6.7% · H 99.95 L 50.00 · ₱55.2K/d
- 2013: ₱39.00 -39.1% · H 65.00 L 39.00 · ₱3.9M/d
- 2014: ₱70.00 +79.5% · H 79.00 L 36.05 · ₱33.5K/d · div ₱0.9000 (1.3%): 31Mar 0.9
- 2015: ₱45.00 -35.7% · H 70.00 L 43.00 · ₱351.0K/d
- 2016: ₱90.00 +100.0% · H 391.8 L 33.10 · ₱452.5K/d · div ₱1.09 (1.2%): 30Mar 1.092
- 2017: ₱60.00 -33.3% · H 105.5 L 60.00 · ₱110.8K/d · div ₱0.8454 (1.4%): 03Apr 0.845374
- 2018: ₱64.95 +8.3% · H 84.00 L 53.00 · ₱282.1K/d · div ₱0.9300 (1.4%): 26Mar 0.93
- 2019: ₱65.00 +0.1% · H 133.3 L 59.30 · ₱1.6M/d · div ₱1.15 (1.8%): 01Apr 1.15
- 2020: ₱53.55 -17.6% · H 75.50 L 45.80 · ₱213.7K/d · div ₱1.30 (2.4%): 07May 1.3
- 2021: ₱41.25 -23.0% · H 62.45 L 41.25 · ₱244.1K/d · div ₱0.4500 (1.1%): 08Apr 0.45
- 2022: ₱32.00 -22.4% · H 48.00 L 32.00 · ₱107.4K/d · div ₱0.7700 (2.4%): 08Apr 0.77
- 2023: ₱40.00 +25.0% · H 44.65 L 29.05 · ₱80.6K/d · div ₱0.8430 (2.1%): 04Apr 0.843
- 2024: ₱40.10 +0.2% · H 59.00 L 40.00 · ₱49.3K/d · div ₱1.07 (2.7%): 08Apr 1.072
- 2025: ₱48.30 +20.4% · H 64.80 L 36.05 · ₱236.1K/d · div ₱1.64 (3.4%): 10Apr 1.6385
- 2026*: ₱58.00 +20.1% · H 59.70 L 49.00 · ₱219.3K/d · div ₱1.77 (3.1%): 08Apr 1.7746

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
