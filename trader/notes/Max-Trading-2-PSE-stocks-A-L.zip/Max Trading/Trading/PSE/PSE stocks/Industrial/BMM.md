---
tags: [trading, pse, stock, bmm]
---
**BMM — Bogo-Medellin Milling Company, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Nov 16, 1950
- Data: 2006-10-06 → 2022-12-23 (991 trading days)
- Last close ₱52.00 (2022-12-23) · all-time high ₱215.6 (2017-07-19) · low ₱18.00 (2006-10-06) · now -75.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-05-23 (÷2), 2012-12-18 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱35.00 start · H 35.00 L 18.00 · ₱16.7K/d
- 2008: ₱37.00 start · H 38.00 L 37.00 · ₱103.7K/d
- 2009: ₱32.00 -13.5% · H 32.00 L 30.00 · ₱738.0K/d
- 2010: ₱90.00 +181.2% · H 102.0 L 28.00 · ₱206.2K/d
- 2011: ₱54.00 -40.0% · H 135.0 L 45.00 · ₱314.9K/d
- 2012: ₱53.00 -1.9% · H 86.00 L 49.00 · ₱76.3K/d
- 2013: ₱53.00 +0.0% · H 61.00 L 46.60 · ₱27.7K/d
- 2014: ₱42.40 -20.0% · H 89.40 L 40.20 · ₱75.7K/d
- 2015: ₱49.40 +16.5% · H 63.50 L 44.60 · ₱94.2K/d
- 2016: ₱97.00 +96.4% · H 132.0 L 38.65 · ₱166.5K/d
- 2017: ₱120.1 +23.8% · H 215.6 L 86.00 · ₱111.6K/d
- 2018: ₱98.15 -18.3% · H 200.2 L 90.15 · ₱167.9K/d
- 2019: ₱88.10 -10.2% · H 110.0 L 88.00 · ₱34.5K/d
- 2020: ₱79.00 -10.3% · H 103.6 L 70.00 · ₱21.4K/d
- 2021: ₱61.00 -22.8% · H 81.50 L 58.00 · ₱11.7K/d
- 2022*: ₱52.00 -14.8% · H 74.50 L 50.00 · ₱5.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
