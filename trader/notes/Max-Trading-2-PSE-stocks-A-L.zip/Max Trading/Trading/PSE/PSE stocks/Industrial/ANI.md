---
tags: [trading, pse, stock, ani]
---
**ANI — AgriNurture, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed May 25, 2009
- Data: 2009-05-25 → 2026-06-15 (4,040 trading days)
- Last close ₱0.4750 (2026-06-15) · all-time high ₱27.92 (2009-10-30) · low ₱0.4150 (2025-10-30) · now -98.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2020-02-06 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2009: ₱20.62 start · H 27.92 L 9.58 · ₱15.1M/d
- 2010: ₱8.62 -58.2% · H 22.50 L 8.17 · ₱11.4M/d
- 2011: ₱8.73 +1.4% · H 10.25 L 6.25 · ₱3.9M/d
- 2012: ₱8.40 -3.8% · H 11.10 L 6.60 · ₱2.3M/d
- 2013: ₱5.30 -36.9% · H 8.67 L 5.00 · ₱658.4K/d
- 2014: ₱2.10 -60.4% · H 5.60 L 2.10 · ₱874.7K/d
- 2015: ₱4.73 +125.2% · H 5.15 L 1.25 · ₱1.0M/d
- 2016: ₱4.60 -2.7% · H 5.82 L 3.09 · ₱5.8M/d
- 2017: ₱12.20 +165.2% · H 12.72 L 4.40 · ₱15.5M/d
- 2018: ₱17.00 +39.3% · H 18.30 L 10.46 · ₱15.9M/d
- 2019: ₱13.50 -20.6% · H 17.00 L 12.54 · ₱8.6M/d
- 2020: ₱8.00 -40.7% · H 13.46 L 6.21 · ₱6.3M/d
- 2021: ₱4.98 -37.7% · H 7.98 L 3.98 · ₱9.8M/d
- 2022: ₱7.09 +42.4% · H 8.08 L 4.45 · ₱9.8M/d
- 2023: ₱0.7500 -89.4% · H 7.71 L 0.6500 · ₱31.5M/d
- 2024: ₱0.5100 -32.0% · H 0.8100 L 0.4600 · ₱2.4M/d
- 2025: ₱0.5400 +5.9% · H 0.5900 L 0.4150 · ₱444.1K/d
- 2026*: ₱0.4750 -12.0% · H 0.5700 L 0.4700 · ₱735.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
