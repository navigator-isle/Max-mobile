---
tags: [trading, pse, stock, cat]
---
**CAT — Central Azucarera de Tarlac, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Apr 12, 1977
- Data: 2006-04-04 → 2026-11-06 (2,412 trading days)
- Last close ₱8.75 (2026-11-06) · all-time high ₱240.0 (2016-03-30) · low ₱0.1220 (2006-04-10) · now -96.4% from high
- Cash dividends last 12 months ₱0.4192 = 4.8% yield
- Dividend events on record (2013 → 2026): 4
- Splits / stock dividends detected (prices before these dates are as traded then): 2007-02-14 (÷1.5), 2007-06-12 (÷1.5), 2015-01-05 (÷0.1)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.6800 start · H 0.6900 L 0.1220 · ₱77.4K/d
- 2007: ₱0.2080 -69.4% · H 0.6600 L 0.2080 · ₱95.3K/d
- 2008: ₱0.2950 +41.8% · H 0.3750 L 0.1320 · ₱16.5K/d
- 2009: ₱1.10 +272.9% · H 1.30 L 0.2750 · ₱112.9K/d
- 2010: ₱1.18 +7.3% · H 1.45 L 0.8000 · ₱210.0K/d
- 2011: ₱1.31 +10.8% · H 2.50 L 1.31 · ₱350.5K/d
- 2012: ₱1.31 -0.2% · H 2.00 L 1.25 · ₱130.7K/d
- 2013: ₱1.25 -4.1% · H 1.60 L 1.20 · ₱51.0K/d
- 2014: ₱8.92 +612.5% · H 13.00 L 1.60 · ₱1.4M/d
- 2015: ₱99.95 +1020.5% · H 100.0 L 71.55 · ₱504.1K/d
- 2016: ₱22.00 -78.0% · H 240.0 L 20.00 · ₱264.2K/d
- 2017: ₱20.35 -7.5% · H 26.80 L 14.02 · ₱612.5K/d
- 2018: ₱16.00 -21.4% · H 46.85 L 15.48 · ₱1.8M/d · div ₱0.1800 (1.1%): 13Jul 0.18
- 2019: ₱17.48 +9.3% · H 21.50 L 14.52 · ₱229.1K/d
- 2020: ₱14.64 -16.2% · H 22.80 L 11.00 · ₱330.3K/d · div ₱1.81 (12.4%): 19Nov 1.81S
- 2021: ₱13.00 -11.2% · H 15.02 L 12.80 · ₱78.3K/d
- 2022: ₱9.77 -24.8% · H 13.78 L 8.50 · ₱31.8K/d
- 2023: ₱11.50 +17.7% · H 12.50 L 8.20 · ₱118.1K/d
- 2024: ₱11.20 -2.6% · H 21.20 L 10.00 · ₱324.2K/d · div ₱6.44 (57.5%): 21Feb 6.44S
- 2025: ₱10.20 -8.9% · H 16.50 L 9.02 · ₱53.2K/d
- 2026*: ₱8.75 -14.2% · H 10.42 L 8.55 · ₱21.3K/d · div ₱0.4192 (4.8%): 13Mar 0.4192

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
