---
tags: [trading, pse, stock, delm]
---
**DELM — Del Monte Pacific Limited**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Jun 10, 2013
- Data: 2013-06-10 → 2026-11-06 (3,168 trading days)
- Last close ₱3.34 (2026-11-06) · all-time high ₱33.45 (2013-10-14) · low ₱2.50 (2020-03-20) · now -90.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱22.70 start · H 33.45 L 22.50 · ₱14.3M/d
- 2014: ₱15.48 -31.8% · H 24.00 L 13.80 · ₱6.6M/d
- 2015: ₱13.44 -13.2% · H 16.88 L 9.49 · ₱2.7M/d
- 2016: ₱12.90 -4.0% · H 13.00 L 10.60 · ₱890.3K/d
- 2017: ₱10.92 -15.3% · H 12.36 L 10.80 · ₱413.7K/d · div ₱0.3100 (2.8%): 23Aug 0.31
- 2018: ₱6.38 -41.6% · H 11.20 L 6.32 · ₱231.0K/d
- 2019: ₱4.85 -24.0% · H 6.85 L 4.82 · ₱252.5K/d · div ₱0.2700 (5.6%): 09Jul 0.27
- 2020: ₱7.21 +48.7% · H 8.10 L 2.50 · ₱628.4K/d · div ₱0.7500 (10.4%): 07Aug 0.75S
- 2021: ₱15.52 +115.3% · H 17.98 L 7.26 · ₱5.1M/d · div ₱0.6017 (3.9%): 08Jul 0.601656
- 2022: ₱14.00 -9.8% · H 16.16 L 12.10 · ₱597.7K/d · div ₱0.9600 (6.9%): 08Jul 0.96
- 2023: ₱6.49 -53.6% · H 14.18 L 6.40 · ₱284.2K/d · div ₱0.0720 (1.1%): 06Jul 0.072
- 2024: ₱3.99 -38.5% · H 6.35 L 3.70 · ₱171.2K/d
- 2025: ₱4.70 +17.8% · H 5.29 L 2.66 · ₱186.4K/d
- 2026*: ₱3.34 -28.9% · H 5.93 L 3.26 · ₱231.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
