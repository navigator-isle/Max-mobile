---
tags: [trading, pse, stock, emi]
---
**EMI — Emperador Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Dec 19, 2011
- Data: 2015-01-05 → 2026-11-06 (2,888 trading days)
- Last close ₱15.14 (2026-11-06) · all-time high ₱24.30 (2022-02-04) · low ₱5.99 (2017-03-30) · now -37.7% from high
- Cash dividends last 12 months ₱51.00 = 336.9% yield
- Dividend events on record (2013 → 2026): 4

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱8.95 start · H 11.90 L 6.99 · ₱36.1M/d
- 2016: ₱7.00 -21.8% · H 9.05 L 6.70 · ₱17.9M/d
- 2017: ₱7.35 +5.0% · H 8.25 L 5.99 · ₱14.1M/d
- 2018: ₱7.11 -3.3% · H 8.74 L 6.92 · ₱8.9M/d
- 2019: ₱7.21 +1.4% · H 7.77 L 7.00 · ₱12.2M/d
- 2020: ₱10.10 +40.1% · H 10.98 L 7.00 · ₱120.3M/d
- 2021: ₱20.80 +105.9% · H 20.90 L 9.28 · ₱65.3M/d
- 2022: ₱20.60 -1.0% · H 24.30 L 13.24 · ₱111.6M/d
- 2023: ₱20.85 +1.2% · H 21.70 L 20.15 · ₱49.1M/d · div ₱0.2900 (1.4%): 26Apr 0.29
- 2024: ₱18.06 -13.4% · H 21.10 L 16.40 · ₱35.2M/d · div ₱0.2400 (1.3%): 30Apr 0.24
- 2025: ₱16.00 -11.4% · H 18.14 L 11.90 · ₱46.1M/d · div ₱0.1900 (1.2%): 30Jan 0.19
- 2026*: ₱15.14 -5.4% · H 16.34 L 14.82 · ₱37.4M/d · div ₱51.00 (336.9%): 19Jan 51

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
