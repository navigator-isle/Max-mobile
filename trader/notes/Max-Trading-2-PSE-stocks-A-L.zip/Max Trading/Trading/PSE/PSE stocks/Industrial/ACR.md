---
tags: [trading, pse, stock, acr]
---
**ACR — Alsons Consolidated Resources, Inc.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Apr 12, 1993
- Data: 1993-04-12 → 2026-11-06 (6,308 trading days)
- Last close ₱0.9200 (2026-11-06) · all-time high ₱2.38 (1996-09-23) · low ₱0.0600 (2001-11-23) · now -61.3% from high
- Cash dividends last 12 months ₱0.0200 = 2.2% yield
- Dividend events on record (2013 → 2026): 16

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱1.30 start · H 1.40 L 0.9500 · ₱1.3M/d
- 1994: ₱1.00 -23.1% · H 1.40 L 0.7500 · ₱1.0M/d
- 1995: ₱1.24 +24.0% · H 1.32 L 0.9500 · ₱4.1M/d
- 1996: ₱2.18 +75.8% · H 2.38 L 1.24 · ₱15.9M/d
- 1997: ₱1.14 -47.7% · H 2.20 L 1.10 · ₱3.2M/d
- 1998: ₱0.7900 -30.7% · H 1.24 L 0.3600 · ₱1.2M/d
- 1999: ₱0.5000 -36.7% · H 1.02 L 0.4600 · ₱275.0K/d
- 2000: ₱0.2500 -50.0% · H 0.7000 L 0.2000 · ₱23.0K/d
- 2001: ₱0.0800 -68.0% · H 0.4400 L 0.0600 · ₱470.6K/d
- 2002: ₱0.0800 +0.0% · H 0.1500 L 0.0600 · ₱174.3K/d
- 2003: ₱0.1600 +100.0% · H 0.2200 L 0.0800 · ₱33.7K/d
- 2004: ₱0.2800 +75.0% · H 0.3700 L 0.1500 · ₱45.6K/d
- 2005: ₱0.4300 +53.6% · H 0.9600 L 0.2800 · ₱2.2M/d
- 2006: ₱0.6500 +51.2% · H 0.7300 L 0.4300 · ₱1.3M/d
- 2007: ₱0.6900 +6.2% · H 1.26 L 0.6300 · ₱770.3K/d
- 2008: ₱0.2500 -63.8% · H 0.7300 L 0.2500 · ₱161.3K/d
- 2009: ₱1.22 +388.0% · H 1.48 L 0.2050 · ₱9.2M/d
- 2010: ₱1.41 +15.6% · H 1.62 L 0.6900 · ₱6.9M/d
- 2011: ₱1.25 -11.3% · H 1.62 L 1.10 · ₱2.8M/d
- 2012: ₱1.29 +3.2% · H 1.58 L 1.22 · ₱2.8M/d
- 2013: ₱1.34 +3.9% · H 1.50 L 1.22 · ₱1.6M/d · div ₱0.0160 (1.2%): 20May 0.016
- 2014: ₱2.03 +51.5% · H 2.25 L 1.29 · ₱10.7M/d · div ₱0.0160 (0.8%): 25Jun 0.016
- 2015: ₱1.34 -34.0% · H 2.27 L 1.33 · ₱4.1M/d · div ₱0.0105 (0.8%): 02Jun 0.0005S, 02Jun 0.01
- 2016: ₱1.23 -8.2% · H 2.10 L 1.19 · ₱6.6M/d · div ₱0.0160 (1.3%): 27Jun 0.016
- 2017: ₱1.35 +9.8% · H 1.85 L 1.25 · ₱3.1M/d · div ₱0.0160 (1.2%): 27Jun 0.016
- 2018: ₱1.28 -5.2% · H 1.38 L 1.14 · ₱647.2K/d · div ₱0.0360 (2.8%): 27Jun 0.016, 27Jun 0.02S
- 2019: ₱1.21 -5.5% · H 1.57 L 1.21 · ₱806.6K/d · div ₱0.0200 (1.7%): 26Jun 0.02
- 2020: ₱1.36 +12.4% · H 1.48 L 0.8000 · ₱3.5M/d · div ₱0.0200 (1.5%): 20Jul 0.02
- 2021: ₱1.20 -11.8% · H 1.42 L 1.03 · ₱1.7M/d · div ₱0.0200 (1.7%): 25Jun 0.02
- 2022: ₱0.7800 -35.0% · H 1.19 L 0.7600 · ₱198.4K/d · div ₱0.0200 (2.6%): 27Jun 0.02
- 2023: ₱0.5400 -30.8% · H 0.9200 L 0.5300 · ₱129.8K/d · div ₱0.0200 (3.7%): 30Jun 0.02
- 2024: ₱0.4600 -14.8% · H 0.6100 L 0.4350 · ₱282.6K/d · div ₱0.0200 (4.3%): 14Jun 0.02
- 2025: ₱0.4700 +2.2% · H 0.6100 L 0.4000 · ₱374.9K/d · div ₱0.0200 (4.3%): 27Jun 0.02
- 2026*: ₱0.9200 +95.7% · H 1.40 L 0.4650 · ₱4.8M/d · div ₱0.0200 (2.2%): 17Jun 0.02

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
