---
tags: [trading, pse, stock, alter]
---
**ALTER — Alternergy Holdings Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power, &amp; Water · listed Mar 24, 2023
- Data: 2023-03-24 → 2026-11-06 (882 trading days)
- Last close ₱0.6500 (2026-11-06) · all-time high ₱1.28 (2023-03-24) · low ₱0.6000 (2026-10-29) · now -49.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2023: ₱0.7700 start · H 1.28 L 0.7100 · ₱6.1M/d
- 2024: ₱1.20 +55.8% · H 1.20 L 0.6100 · ₱1.0M/d
- 2025: ₱0.8400 -30.0% · H 1.22 L 0.8000 · ₱1.3M/d · div ₱0.0100 (1.2%): 13Aug 0.01S
- 2026*: ₱0.6500 -22.6% · H 0.8800 L 0.6000 · ₱459.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
