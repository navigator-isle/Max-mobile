---
tags: [trading, pse, stock, fcg]
---
**FCG — Figaro Culinary Group, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Jan 24, 2022
- Data: 2022-01-24 → 2026-11-06 (1,169 trading days)
- Last close ₱0.7900 (2026-11-06) · all-time high ₱1.10 (2023-03-10) · low ₱0.4800 (2022-05-17) · now -28.2% from high
- Cash dividends last 12 months ₱0.0184 = 2.3% yield
- Dividend events on record (2013 → 2026): 4

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱0.6300 start · H 0.9200 L 0.4800 · ₱21.6M/d · div ₱0.0194 (3.1%): 16Nov 0.01936
- 2023: ₱0.6000 -4.8% · H 1.10 L 0.5900 · ₱27.0M/d · div ₱0.0270 (4.5%): 16Nov 0.027
- 2024: ₱0.8600 +43.3% · H 0.9200 L 0.6100 · ₱6.0M/d · div ₱0.0270 (3.1%): 13Nov 0.027
- 2025: ₱0.5800 -32.6% · H 0.8900 L 0.5400 · ₱1.1M/d · div ₱0.0184 (3.2%): 18Nov 0.0184
- 2026*: ₱0.7900 +36.2% · H 0.7900 L 0.5100 · ₱1.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
