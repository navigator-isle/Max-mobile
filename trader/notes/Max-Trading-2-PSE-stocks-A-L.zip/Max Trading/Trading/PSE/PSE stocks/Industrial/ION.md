---
tags: [trading, pse, stock, ion]
---
**ION — Ionics, Inc.**
- Status: listed on PSE · sector Industrial › Electrical Components &amp; Equipment · listed Jul 18, 1995
- Data: 1995-07-18 → 2026-11-06 (6,613 trading days)
- Last close ₱2.73 (2026-11-06) · all-time high ₱5.81 (1997-09-25) · low ₱0.1450 (2003-05-16) · now -53.0% from high
- Cash dividends last 12 months ₱0.1000 = 3.7% yield
- Dividend events on record (2013 → 2026): 3
- Splits / stock dividends detected (prices before these dates are as traded then): 2006-04-05 (÷0.5), 2006-05-03 (÷2), 2006-08-01 (÷0.5), 2006-08-22 (÷2), 2006-09-01 (÷0.5), 2008-10-23 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱1.42 start · H 1.64 L 0.9900 · ₱5.7M/d
- 1996: ₱3.00 +111.3% · H 3.84 L 1.46 · ₱2.2M/d
- 1997: ₱4.12 +37.5% · H 5.81 L 2.04 · ₱7.4M/d
- 1998: ₱2.38 -42.4% · H 5.50 L 1.50 · ₱4.1M/d
- 1999: ₱3.50 +47.4% · H 4.06 L 1.93 · ₱4.5M/d
- 2000: ₱3.94 +12.5% · H 4.12 L 2.33 · ₱4.5M/d
- 2001: ₱1.57 -60.0% · H 3.94 L 1.43 · ₱1.0M/d
- 2002: ₱0.2400 -84.8% · H 2.35 L 0.1750 · ₱227.5K/d
- 2003: ₱0.3600 +50.0% · H 0.4850 L 0.1450 · ₱480.4K/d
- 2004: ₱0.3700 +2.8% · H 0.5900 L 0.2750 · ₱394.0K/d
- 2005: ₱0.2750 -25.7% · H 0.4650 L 0.2550 · ₱140.8K/d
- 2006: ₱1.08 +292.7% · H 1.11 L 0.2750 · ₱506.0K/d
- 2007: ₱0.7100 -34.3% · H 1.43 L 0.7000 · ₱529.7K/d
- 2008: ₱0.2000 -71.8% · H 0.7100 L 0.1500 · ₱44.6K/d
- 2009: ₱0.6500 +225.0% · H 1.04 L 0.1800 · ₱299.7K/d
- 2010: ₱0.6250 -3.8% · H 0.7500 L 0.4450 · ₱129.4K/d
- 2011: ₱0.4800 -23.2% · H 0.7300 L 0.4750 · ₱135.8K/d
- 2012: ₱0.6300 +31.2% · H 1.02 L 0.4800 · ₱415.3K/d
- 2013: ₱0.3650 -42.1% · H 0.8300 L 0.3200 · ₱436.5K/d
- 2014: ₱0.6200 +69.9% · H 0.8400 L 0.3800 · ₱1.2M/d
- 2015: ₱2.46 +296.8% · H 3.82 L 0.4300 · ₱21.9M/d
- 2016: ₱1.58 -35.8% · H 3.06 L 1.52 · ₱7.6M/d
- 2017: ₱2.23 +41.1% · H 2.52 L 1.50 · ₱4.3M/d
- 2018: ₱1.81 -18.8% · H 3.20 L 1.47 · ₱7.6M/d
- 2019: ₱1.30 -28.2% · H 1.95 L 1.29 · ₱481.4K/d
- 2020: ₱1.20 -7.7% · H 1.68 L 0.9100 · ₱1.2M/d
- 2021: ₱0.7200 -40.0% · H 1.56 L 0.6900 · ₱785.4K/d
- 2022: ₱0.5600 -22.2% · H 0.8300 L 0.4650 · ₱168.9K/d
- 2023: ₱1.01 +80.4% · H 1.58 L 0.5500 · ₱3.6M/d · div ₱0.1000 (9.9%): 23Mar 0.1
- 2024: ₱0.8400 -16.8% · H 1.36 L 0.7200 · ₱1.5M/d
- 2025: ₱1.02 +21.4% · H 1.08 L 0.7200 · ₱526.6K/d · div ₱0.1000 (9.8%): 27Mar 0.1
- 2026*: ₱2.73 +167.6% · H 4.12 L 1.00 · ₱5.5M/d · div ₱0.1000 (3.7%): 28May 0.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
