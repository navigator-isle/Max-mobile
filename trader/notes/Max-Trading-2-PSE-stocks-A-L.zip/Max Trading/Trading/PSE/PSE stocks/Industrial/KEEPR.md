---
tags: [trading, pse, stock, keepr]
---
**KEEPR — The Keepers Holdings, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Sep 03, 1991
- Data: 2015-01-05 → 2026-11-06 (2,511 trading days)
- Last close ₱1.83 (2026-11-06) · all-time high ₱8.98 (2021-02-11) · low ₱1.03 (2022-10-03) · now -79.6% from high
- Cash dividends last 12 months ₱0.1200 = 6.6% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱1.60 start · H 2.34 L 1.19 · ₱3.5M/d
- 2016: ₱6.47 +304.4% · H 7.95 L 1.63 · ₱13.6M/d
- 2017: ₱5.39 -16.7% · H 7.00 L 5.10 · ₱1.3M/d
- 2018: ₱6.50 +20.6% · H 7.16 L 4.10 · ₱964.4K/d
- 2019: ₱5.00 -23.1% · H 6.74 L 5.00 · ₱362.2K/d
- 2020: ₱5.28 +5.6% · H 6.03 L 3.10 · ₱898.3K/d
- 2021: ₱1.32 -75.0% · H 8.98 L 1.30 · ₱38.8M/d
- 2022: ₱1.27 -3.8% · H 1.51 L 1.03 · ₱4.8M/d · div ₱0.0240 (1.9%): 05Jan 0.024
- 2023: ₱1.48 +16.5% · H 1.74 L 1.28 · ₱7.9M/d · div ₱0.1310 (8.9%): 05Jan 0.054, 27Dec 0.077
- 2024: ₱2.23 +50.7% · H 2.23 L 1.30 · ₱4.6M/d · div ₱0.1000 (4.5%): 27May 0.1
- 2025: ₱2.48 +11.2% · H 2.90 L 2.22 · ₱5.8M/d · div ₱0.1200 (4.8%): 05May 0.12
- 2026*: ₱1.83 -26.2% · H 2.48 L 1.74 · ₱4.1M/d · div ₱0.1200 (6.6%): 16Apr 0.12

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
