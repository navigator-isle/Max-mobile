---
tags: [trading, pse, stock, fb]
---
**FB — San Miguel Food and Beverage, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Oct 28, 1971
- Data: 2004-09-17 → 2026-11-06 (3,508 trading days)
- Last close ₱47.50 (2026-11-06) · all-time high ₱3,000 (2011-01-27) · low ₱34.25 (2022-11-03) · now -98.4% from high
- Cash dividends last 12 months ₱3.32 = 7.0% yield
- Dividend events on record (2013 → 2026): 47
- Splits / stock dividends detected (prices before these dates are as traded then): 2012-11-21 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2004: ₱60.00 start · H 70.00 L 60.00 · ₱6.5K/d
- 2005: ₱56.00 -6.7% · H 56.00 L 55.00 · ₱9.8K/d
- 2006: ₱60.00 +7.1% · H 60.00 L 56.00 · ₱5.8K/d
- 2007: ₱40.00 -33.3% · H 40.00 L 40.00 · ₱4.0K/d
- 2008: ₱49.50 +23.8% · H 82.00 L 49.50 · ₱16.1K/d
- 2009: ₱55.00 +11.1% · H 55.00 L 55.00 · ₱22.0K/d
- 2010: ₱800.0 +1354.5% · H 800.0 L 91.00 · ₱39.1K/d
- 2011: ₱1,407 +75.9% · H 3,000 L 800.0 · ₱82.2K/d
- 2012: ₱244.0 -82.7% · H 1,430 L 240.0 · ₱6.7M/d
- 2013: ₱238.0 -2.5% · H 310.0 L 214.8 · ₱27.3M/d
- 2014: ₱208.0 -12.6% · H 266.0 L 208.0 · ₱11.0M/d
- 2015: ₱129.0 -38.0% · H 210.8 L 121.0 · ₱5.7M/d
- 2016: ₱231.0 +79.1% · H 235.0 L 114.1 · ₱3.8M/d
- 2017: ₱529.0 +129.0% · H 563.0 L 226.0 · ₱11.8M/d · div ₱3.00 (0.6%): 18Aug 1.5, 23Nov 1.5
- 2018: ₱82.00 -84.5% · H 656.0 L 58.90 · ₱66.3M/d · div ₱3.00 (3.7%): 13Feb 2, 21May 0.2, 17Aug 0.4, 17Oct 0.4
- 2019: ₱85.00 +3.7% · H 117.5 L 81.70 · ₱47.4M/d · div ₱1.60 (1.9%): 15Feb 0.4, 20May 0.4, 16Aug 0.4, 18Nov 0.4
- 2020: ₱67.00 -21.2% · H 84.50 L 45.00 · ₱16.5M/d · div ₱1.60 (2.4%): 12Feb 0.4, 08Jun 0.4, 17Aug 0.4, 13Nov 0.4
- 2021: ₱71.40 +6.6% · H 85.00 L 58.50 · ₱13.0M/d · div ₱1.70 (2.4%): 15Feb 0.4, 17May 0.4, 16Aug 0.4, 19Nov 0.1S, 19Nov 0.4
- 2022: ₱38.70 -45.8% · H 70.55 L 34.25 · ₱10.7M/d · div ₱2.12 (5.5%): 15Feb 0.4, 16May 0.4, 15Aug 0.26S, 15Aug 0.4, 18Nov 0.26S, 18Nov 0.4
- 2023: ₱51.00 +31.8% · H 53.50 L 38.10 · ₱6.2M/d · div ₱2.70 (5.3%): 14Feb 0.4, 19May 0.4, 11Aug 0.4, 11Aug 0.55S, 21Nov 0.4, 21Nov 0.55S
- 2024: ₱52.75 +3.4% · H 56.95 L 44.20 · ₱3.5M/d · div ₱2.80 (5.3%): 15Feb 0.45, 22May 0.45, 21Aug 0.45S, 19Nov 0.45, 19Nov 1S
- 2025: ₱55.00 +4.3% · H 55.95 L 49.20 · ₱4.6M/d · div ₱2.55 (4.6%): 18Feb 0.5, 21May 0.5, 19Aug 0.5S, 24Nov 0.5, 24Nov 0.55
- 2026*: ₱47.50 -13.6% · H 56.00 L 42.05 · ₱3.5M/d · div ₱4.75 (10.0%): 19Feb 0.5, 20May 0.5, 18Aug 0.5, 18Aug 0.77, 17Nov 0.5 (upcoming), 17Nov 1.98 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
