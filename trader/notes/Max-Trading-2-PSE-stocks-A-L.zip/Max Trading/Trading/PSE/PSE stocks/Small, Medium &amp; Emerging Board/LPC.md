---
tags: [trading, pse, stock, lpc]
---
**LPC — LFM Properties Corporation**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Nov 09, 2022
- Data: 2022-11-09 → 2026-11-06 (537 trading days)
- Last close ₱0.0200 (2026-11-06) · all-time high ₱0.2050 (2022-11-09) · low ₱0.0170 (2026-09-23) · now -90.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱0.1300 start · H 0.2050 L 0.1300 · ₱1.1M/d
- 2023: ₱0.0600 -53.8% · H 0.1350 L 0.0510 · ₱42.7K/d
- 2024: ₱0.0450 -25.0% · H 0.0970 L 0.0450 · ₱30.5K/d
- 2025: ₱0.0410 -8.9% · H 0.0710 L 0.0350 · ₱37.2K/d
- 2026*: ₱0.0200 -51.2% · H 0.0440 L 0.0170 · ₱35.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
