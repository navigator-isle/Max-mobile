---
tags: [trading, pse, stock, idc]
---
**IDC — Italpinas Development Corporation**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Dec 07, 2015
- Data: 2015-12-07 → 2026-11-05 (2,612 trading days)
- Last close ₱0.6200 (2026-11-05) · all-time high ₱16.82 (2017-11-10) · low ₱0.5600 (2026-06-09) · now -96.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2021-12-15 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱3.25 start · H 4.22 L 2.84 · ₱22.9M/d
- 2016: ₱4.39 +35.1% · H 6.30 L 2.02 · ₱4.4M/d
- 2017: ₱10.20 +132.3% · H 16.82 L 3.50 · ₱11.1M/d
- 2018: ₱4.85 -52.5% · H 12.20 L 3.32 · ₱13.4M/d
- 2019: ₱3.79 -21.9% · H 7.90 L 3.59 · ₱6.2M/d
- 2020: ₱3.18 -16.1% · H 4.15 L 1.53 · ₱11.0M/d
- 2021: ₱1.21 -61.9% · H 3.74 L 1.21 · ₱3.5M/d
- 2022: ₱0.8000 -33.9% · H 1.20 L 0.6100 · ₱334.5K/d
- 2023: ₱0.6900 -13.8% · H 1.05 L 0.6200 · ₱397.9K/d
- 2024: ₱1.30 +88.4% · H 1.54 L 0.6200 · ₱825.1K/d
- 2025: ₱0.8700 -33.1% · H 1.28 L 0.8400 · ₱165.4K/d
- 2026*: ₱0.6200 -28.7% · H 0.9100 L 0.5600 · ₱53.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
