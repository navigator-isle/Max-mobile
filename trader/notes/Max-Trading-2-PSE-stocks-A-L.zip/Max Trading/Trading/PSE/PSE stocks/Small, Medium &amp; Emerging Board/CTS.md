---
tags: [trading, pse, stock, cts]
---
**CTS — CTS Global Equity Group, Inc.**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Apr 13, 2022
- Data: 2022-04-13 → 2026-11-06 (970 trading days)
- Last close ₱0.3200 (2026-11-06) · all-time high ₱1.11 (2022-04-13) · low ₱0.3200 (2026-06-16) · now -71.2% from high
- Cash dividends last 12 months ₱0.00146 = 0.5% yield
- Dividend events on record (2013 → 2026): 8

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱0.9600 start · H 1.11 L 0.8200 · ₱11.8M/d
- 2023: ₱0.7500 -21.9% · H 0.9700 L 0.7300 · ₱1.5M/d · div ₱0.0031 (0.4%): 06Jun 0.000776, 06Jun 0.002328S
- 2024: ₱0.6500 -13.3% · H 0.7700 L 0.5600 · ₱604.6K/d · div ₱0.00264 (0.4%): 29May 0.000669, 29May 0.001971S
- 2025: ₱0.3600 -44.6% · H 0.6800 L 0.3600 · ₱444.7K/d · div ₱0.00437 (1.2%): 27May 0.001877, 27May 0.002491S
- 2026*: ₱0.3200 -11.1% · H 0.4100 L 0.3200 · ₱316.6K/d · div ₱0.00146 (0.5%): 28May 0.00008, 28May 0.001376

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
