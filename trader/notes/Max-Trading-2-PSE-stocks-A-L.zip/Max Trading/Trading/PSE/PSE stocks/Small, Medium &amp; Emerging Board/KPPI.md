---
tags: [trading, pse, stock, kppi]
---
**KPPI — Kepwealth Property Phils., Inc.**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Aug 19, 2019
- Data: 2019-08-19 → 2026-11-03 (1,007 trading days)
- Last close ₱1.40 (2026-11-03) · all-time high ₱18.32 (2019-08-22) · low ₱1.04 (2026-01-14) · now -92.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱9.70 start · H 18.32 L 8.15 · ₱42.5M/d
- 2020: ₱6.10 -37.1% · H 11.72 L 4.84 · ₱1.4M/d
- 2021: ₱2.98 -51.1% · H 6.64 L 2.93 · ₱142.6K/d
- 2022: ₱1.53 -48.7% · H 3.97 L 1.46 · ₱36.3K/d
- 2023: ₱1.53 +0.0% · H 2.15 L 1.50 · ₱13.0K/d
- 2024: ₱1.26 -17.6% · H 2.48 L 1.19 · ₱24.3K/d
- 2025: ₱1.19 -5.6% · H 1.80 L 1.10 · ₱18.2K/d
- 2026*: ₱1.40 +17.6% · H 1.59 L 1.04 · ₱20.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
