---
tags: [trading, pse, stock, hti]
---
**HTI — Haus Talk, Inc.**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Jan 17, 2022
- Data: 2022-01-17 → 2026-11-06 (1,136 trading days)
- Last close ₱1.37 (2026-11-06) · all-time high ₱1.60 (2022-01-17) · low ₱0.7600 (2022-10-11) · now -14.4% from high
- Cash dividends last 12 months ₱0.0300 = 2.2% yield
- Dividend events on record (2013 → 2026): 4

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱1.08 start · H 1.60 L 0.7600 · ₱4.7M/d
- 2023: ₱0.9500 -12.0% · H 1.06 L 0.8600 · ₱660.1K/d · div ₱0.0111 (1.2%): 07Nov 0.011076
- 2024: ₱1.05 +10.5% · H 1.17 L 0.9300 · ₱1.0M/d · div ₱0.0200 (1.9%): 07Nov 0.02
- 2025: ₱1.10 +4.8% · H 1.19 L 0.9600 · ₱878.7K/d · div ₱0.0300 (2.7%): 14Nov 0.03
- 2026*: ₱1.37 +24.5% · H 1.50 L 1.02 · ₱923.3K/d · div ₱0.0300 (2.2%): 23Nov 0.03 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
