---
tags: [trading, pse, stock, aetf]
---
**AETF — ATR FAMI Philippine Equity Exchange Traded Fund, Inc.**
- Status: listed on PSE · sector ETF › ETF-Equity · listed Dec 02, 2013
- Data: 2015-01-05 → 2026-11-06 (2,888 trading days)
- Last close ₱97.10 (2026-11-06) · all-time high ₱136.7 (2018-01-29) · low ₱71.20 (2020-03-19) · now -29.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱113.5 start · H 132.0 L 109.9 · ₱3.6M/d
- 2016: ₱113.0 -0.4% · H 132.9 L 99.80 · ₱2.8M/d
- 2017: ₱130.5 +15.5% · H 131.5 L 113.2 · ₱2.1M/d
- 2018: ₱111.5 -14.6% · H 136.7 L 103.2 · ₱2.8M/d
- 2019: ₱117.4 +5.3% · H 124.5 L 112.0 · ₱1.2M/d
- 2020: ₱108.0 -8.0% · H 117.6 L 71.20 · ₱3.0M/d
- 2021: ₱108.3 +0.3% · H 113.2 L 94.00 · ₱2.6M/d
- 2022: ₱101.0 -6.7% · H 114.0 L 89.00 · ₱2.0M/d
- 2023: ₱102.7 +1.7% · H 109.0 L 93.70 · ₱1.8M/d
- 2024: ₱105.6 +2.8% · H 121.3 L 99.00 · ₱2.4M/d
- 2025: ₱101.0 -4.4% · H 107.0 L 93.00 · ₱1.5M/d
- 2026*: ₱97.10 -3.9% · H 109.4 L 97.00 · ₱1.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
