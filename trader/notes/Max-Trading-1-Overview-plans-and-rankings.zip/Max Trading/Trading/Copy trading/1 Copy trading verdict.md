---
tags: [trading, copy-trading, core, strategy]
---
**Copy trading — verdict: watch only**
- Real copy-trader records exist only on Hyperliquid (the exchange Invo copies), from 2023
- For 20+ years: tested copying or opposing big traders through CFTC weekly positions (1998–2026) → no lasting edge

**What the tests showed**
- Median trader month: -0.17% · only 47.9% of trader-months were positive
- Copying the "hottest" traders (best last 30–90 days, what app leaderboards show) lost 45–97%
- Copying "steady" traders made money, but the record is only about 3 years and biased toward survivors

**Max's rule**
- Paper only, small, steady traders with long low-turnover records; never leverage
- Two watch-only paper books run live: copy steady traders, copy hot traders
