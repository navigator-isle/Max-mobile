---
tags: [trading, copy-trading, strategy]
---
**Copy strategies ranked**

**Hyperliquid traders (Mar 2023 → Oct 2026)**
| # | Strategy | Per year | Worst drop | Green months | Verdict |
|---|---|---|---|---|---|
| 1 | Copy top-5 steady (≥4/6 green months, 90d>0, ≥$100k) | +143.2% | -36.9% | 63% green months | ⚠️ short record |
| 2 | Copy top-5 smoothest 6 months | +142.2% | -53.3% | 66% green months | ⚠️ big drops |
| 3 | Copy top-10 steady (≥4/6 green months, 90d>0, ≥$100k) | +138.9% | -30.7% | 63% green months | ⚠️ short record |
| 4 | Copy top-20 smoothest 6 months | +120.9% | -21.2% | 69% green months | 👍 good |
| 5 | Copy top-10 smoothest 6 months | +106.6% | -42.5% | 62% green months | 🆗 ok |
| 6 | Copy top-20 steady (≥4/6 green months, 90d>0, ≥$100k) | +97.6% | -10.8% | 68% green months | ⚠️ short record |
| 7 | Copy top-20 biggest profit 90 days | +57.1% | -43.5% | 70% green months | 🆗 ok |
| 8 | Copy top-20 best last 180 days | +23.3% | -40.4% | 50% green months | 🆗 ok |
| 9 | Copy top-10 best last 180 days | +17.6% | -59.0% | 58% green months | ⚠️ big drops |
| 10 | Copy everyone (average active trader) | +16.8% | -61.8% | 49% green months | ⚠️ big drops |
| 11 | Copy top-10 biggest profit 90 days | +15.4% | -69.9% | 59% green months | ⚠️ big drops |
| 12 | Copy top-5 biggest profit 90 days | +8.5% | -80.9% | 54% green months | ⚠️ big drops |
| 13 | Copy top-20 best last 90 days | -10.1% | -72.6% | 52% green months | ❌ avoid |
| 14 | Copy top-5 best last 180 days | -13.0% | -82.3% | 62% green months | ❌ avoid |
| 15 | Copy top-5 best last 90 days | -18.5% | -94.4% | 40% green months | ❌ avoid |
| 16 | Copy top-10 best last 90 days | -19.3% | -92.9% | 53% green months | ❌ avoid |
| 17 | Copy top-10 best last 30 days | -50.2% | -95.2% | 47% green months | ❌ avoid |
| 18 | Copy top-20 best last 30 days | -50.6% | -94.9% | 50% green months | ❌ avoid |
| 19 | Copy top-5 best last 30 days | -69.0% | -99.2% | 43% green months | ❌ avoid |

**Copy or oppose big traders via CFTC (2000 → Oct 2026)**
- Columns = per year in 2000-08 / 2009-16 / 2017-26
| # | Strategy | Per year | Worst drop | 2000-08 / 2009-16 / 2017-26 | Verdict |
|---|---|---|---|---|---|
| 1 | COPY big companies/hedgers in gold (change vs 13-wk avg) | +1.3% | -49.9% | +5.4 / -5.1 / +3.4 | ⚠️ big drops |
| 2 | COPY speculators (non-commercial): level | +0.8% | -12.1% | +2.2 / +1.6 / -1.1 | ❌ avoid |
| 3 | FADE big companies/hedgers (commercial): level | +0.7% | -16.5% | +2.5 / +1.5 / -1.7 | ❌ avoid |
| 4 | FADE big companies/hedgers (commercial): change vs 13-wk avg | +0.7% | -20.6% | +1.5 / +2.6 / -1.6 | ❌ avoid |
| 5 | FADE speculators in gold (change vs 13-wk avg) | +0.7% | -49.7% | +5.0 / -4.8 / +1.8 | ❌ avoid |
| 6 | COPY speculators (non-commercial): change vs 13-wk avg | +0.3% | -25.8% | +2.1 / +1.5 / -2.2 | ❌ avoid |
| 7 | COPY hedge funds (leveraged funds, 2006+): level | +0.1% | -20.9% | +1.5 / +0.7 / -1.7 | ❌ avoid |
| 8 | FADE hedge funds (leveraged funds, 2006+): change vs 13-wk avg | -0.0% | -24.7% | -1.2 / -1.8 / +2.5 | ❌ avoid |
| 9 | COPY asset managers (2006+): level | +0.0% | -21.1% | +1.8 / -1.6 / -0.1 | ❌ avoid |
| 10 | FADE asset managers (2006+): level | -0.4% | -20.4% | -1.9 / +0.9 / -0.3 | ❌ avoid |
| 11 | COPY asset managers (2006+): change vs 13-wk avg | -0.4% | -21.0% | -0.1 / +0.5 / -1.5 | ❌ avoid |
| 12 | FADE asset managers (2006+): change vs 13-wk avg | -0.5% | -19.7% | -0.3 / -1.7 / +0.3 | ❌ avoid |
| 13 | FADE hedge funds (leveraged funds, 2006+): level | -0.7% | -25.3% | -1.8 / -1.5 / +1.0 | ❌ avoid |
| 14 | COPY hedge funds (leveraged funds, 2006+): change vs 13-wk avg | -1.0% | -32.3% | +0.8 / +0.6 / -3.7 | ❌ avoid |
| 15 | COPY big companies/hedgers (commercial): level | -1.3% | -40.3% | -3.3 / -2.3 / +1.2 | ❌ avoid |
| 16 | FADE speculators (non-commercial): level | -1.5% | -39.5% | -3.1 / -2.4 / +0.7 | ❌ avoid |
| 17 | FADE speculators (non-commercial): change vs 13-wk avg | -1.6% | -44.2% | -3.5 / -2.7 / +1.1 | ❌ avoid |
| 18 | COPY big companies/hedgers (commercial): change vs 13-wk avg | -1.9% | -46.6% | -2.9 / -3.8 / +0.6 | ❌ avoid |
| 19 | COPY speculators in gold (change vs 13-wk avg) | -4.7% | -78.2% | -8.8 / +0.9 / -5.5 | ❌ avoid |
| 20 | FADE big companies/hedgers in gold (change vs 13-wk avg) | -5.2% | -79.6% | -9.1 / +1.2 / -6.9 | ❌ avoid |
