---
tags: [trading, copy-trading, platforms]
---
**Copy trading platforms**
- **Tradency "Mirror Trader"** (about 2005): early automatic system to copy a strategy's trades
- **ZuluTrade** (founded 2007; beta 2008; EU portfolio-management licence 2015; US 2020; bought by Finvasia Dec 2021; dropped profit-share fees 2022)
- **eToro CopyTrader** (trademark 2012): copy "Popular Investors"; users in 140+ countries
- **FxPro SuperTrader**: closed 2017; many brokers closed copy services after regulators cleaned up scams
- **MetaQuotes MQL5 Signals**: copy MetaTrader signal providers for a monthly fee
- **Crypto exchanges** (Binance, Bybit, Bitget, OKX and others): copy futures traders; profit share to the lead trader; leverage common
- **Invo** (runs on Hyperliquid perpetuals): taker 0.0768%, maker rebate 0.048%; copied traders get 15% of the fees their copiers generate — paid for activity, not for winning
- **Hyperliquid** itself: every trade is public on-chain → the only place with full, checkable trader records (2023 →)

**Rules and research**
- 2014: UK FCA said copy-trading firms act as portfolio/investment managers (must be authorised); ESMA MiFID Q&A treats copying as automatic execution of signals
- Research: copied trades lose more when they lose (Pelster & Hofmann 2018); showing others' success raises risk-taking
- KuCoin research: about 400,000 wallets on Invo and 5 similar apps lost about $280M; for BTC trades, fees exceeded users' gains

**Max's rule**
- Copy only traders with long, steady records and low turnover; paper first; never leverage

**Sources**
- https://en.wikipedia.org/wiki/Copy_trading · https://en.wikipedia.org/wiki/ZuluTrade
- https://www.invoapp.com/guides/fees · https://www.kucoin.com/blog/hyperliquid-retail-traders-280-million-losses
