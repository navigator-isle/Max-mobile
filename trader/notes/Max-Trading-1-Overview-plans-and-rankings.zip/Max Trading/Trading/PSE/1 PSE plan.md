---
tags: [trading, pse, core, strategy]
---
**PSE plan — high-dividend top 20**
- 40% of the total plan · paper ₱100,000 · COL fees

**Which stocks**
- All PSE stocks, price at least ₱1, at least ₱5M traded a day
- Paid cash dividends in the last 12 months of at least 3% of the price
- Rank by dividend yield → buy the top 20, about equal pesos each, whole board lots

**When to buy and sell**
- Buy at the next trading day's close after the list is made
- Every 3 months: re-check; keep a stock while it is still in the top 40 (so it can still pay its dividend); sell if it falls below 40
- Safety stop: sell if a stock closes 25% below its highest close since buying; the cash waits for the next re-check
- Dividends are added on the ex-date after 10% tax

**What Max does not do (tested, worse)**
- Dividend capture (buy before ex-date, sell after) — lost 27–48%
- Market filter on dividend stocks — cut returns
- Tighter stops (20%, 200-day average) — sold too often

**Tested (2014 → Nov 2026)**
- 8.4% a year · worst drop -23.7% (without the stop: -41.6%)
- See 2 PSE strategies ranked for all other versions
