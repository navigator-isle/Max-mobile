---
tags: [trading, pse, psei]
---
**PSEi by year (year-end close)**
- 2002: PSEi 1,018 (–) · stocks with prices 144 · cash dividend payments on record n/a (reports start 2013)
- 2003: PSEi 1,442 (+41.6%) · stocks with prices 145 · cash dividend payments on record n/a (reports start 2013)
- 2004: PSEi 1,823 (+26.4%) · stocks with prices 153 · cash dividend payments on record n/a (reports start 2013)
- 2005: PSEi 2,096 (+15.0%) · stocks with prices 154 · cash dividend payments on record n/a (reports start 2013)
- 2006: PSEi 2,983 (+42.3%) · stocks with prices 200 · cash dividend payments on record n/a (reports start 2013)
- 2007: PSEi 3,622 (+21.4%) · stocks with prices 210 · cash dividend payments on record n/a (reports start 2013)
- 2008: PSEi 1,873 (-48.3%) · stocks with prices 214 · cash dividend payments on record n/a (reports start 2013)
- 2009: PSEi 3,053 (+63.0%) · stocks with prices 216 · cash dividend payments on record n/a (reports start 2013)
- 2010: PSEi 4,201 (+37.6%) · stocks with prices 224 · cash dividend payments on record n/a (reports start 2013)
- 2011: PSEi 4,372 (+4.1%) · stocks with prices 238 · cash dividend payments on record n/a (reports start 2013)
- 2012: PSEi 5,813 (+33.0%) · stocks with prices 251 · cash dividend payments on record n/a (reports start 2013)
- 2013: PSEi 5,890 (+1.3%) · stocks with prices 263 · cash dividend payments on record 183
- 2014: PSEi 7,231 (+22.8%) · stocks with prices 276 · cash dividend payments on record 184
- 2015: PSEi 6,952 (-3.9%) · stocks with prices 299 · cash dividend payments on record 195
- 2016: PSEi 6,841 (-1.6%) · stocks with prices 308 · cash dividend payments on record 189
- 2017: PSEi 8,558 (+25.1%) · stocks with prices 316 · cash dividend payments on record 196
- 2018: PSEi 7,466 (-12.8%) · stocks with prices 319 · cash dividend payments on record 209
- 2019: PSEi 7,815 (+4.7%) · stocks with prices 323 · cash dividend payments on record 192
- 2020: PSEi 7,140 (-8.6%) · stocks with prices 324 · cash dividend payments on record 167
- 2021: PSEi 7,123 (-0.2%) · stocks with prices 291 · cash dividend payments on record 193
- 2022: PSEi 6,566 (-7.8%) · stocks with prices 259 · cash dividend payments on record 229
- 2023: PSEi 6,450 (-1.8%) · stocks with prices 261 · cash dividend payments on record 249
- 2024: PSEi 6,529 (+1.2%) · stocks with prices 263 · cash dividend payments on record 249
- 2025: PSEi 6,053 (-7.3%) · stocks with prices 267 · cash dividend payments on record 250
- 2026 (to 6 Nov): PSEi 5,762 (-4.8%) · stocks with prices 266 · cash dividend payments on record 212

**Notes**
- PSEi 2002–2020 from the PSE archive; 2021–2025 year-end closes from PSE/news reports; 2026 = 6 Nov close (Yahoo Finance)
- All-time PSEi high in this data: 9,059 (2018-01-29)

**Sources**
- PSE archive PSEI series · https://www.pse.com.ph/yearone/2024 (2023 6,450.04; 2024 6,528.79) · https://insiderph.com/pse-closes-most-challenging-year-since-pandemic-as-index-slides-73 (2025 6,052.92, −7.29%)
