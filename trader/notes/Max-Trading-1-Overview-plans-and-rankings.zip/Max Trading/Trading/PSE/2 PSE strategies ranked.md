---
tags: [trading, pse, strategy]
---
**PSE strategies ranked (best → worst)**
- Fees and 10% dividend tax included · trade at next close · delisted stocks included

**Dividend strategies (2014 → Nov 2026)**
| # | Strategy | Per year | Worst drop | Since 2020 | Verdict |
|---|---|---|---|---|---|
| 1 | Dividend top-20 · keep while in top-40 · 25% trailing stop | +8.4% | -23.7% | +10.8% | ✅ chosen |
| 2 | Dividend top-20 · 25% trailing stop | +8.4% | -24.1% | +11.3% | 👍 good |
| 3 | Dividend top-20 · 30% trailing stop | +8.4% | -26.3% | +11.1% | 👍 good |
| 4 | Dividend top-20 · 20% trailing stop | +6.5% | -21.9% | +9.8% | 🆗 ok |
| 5 | Dividend top-20 · sell if 20% below buy price | +7.3% | -33.5% | +10.0% | 🆗 ok |
| 6 | Dividend top-20 · re-check every 6 months | +8.5% | -41.8% | +10.0% | 🆗 ok |
| 7 | Dividend top-20 · re-check every 3 months (no stop) | +8.3% | -41.6% | +10.8% | 🆗 ok |
| 8 | 50% dividend + 50% momentum | +8.0% | -40.6% | +10.3% | 🆗 ok |
| 9 | Dividend top-20 · keep while in top-40 (no stop) | +7.0% | -43.1% | +7.9% | 🆗 ok |
| 10 | Dividend top-20 · skip "trap" stocks | +7.0% | -44.0% | +10.6% | 🆗 ok |
| 11 | Dividend top-20 · re-check every 12 months | +6.4% | -41.0% | +6.3% | 🆗 ok |
| 12 | Dividend top-20 · regular dividends only | +5.7% | -40.8% | +5.8% | 🆗 ok |
| 13 | Dividend top-20 · keep while in top-60 | +6.0% | -43.0% | +6.8% | 🆗 ok |
| 14 | Dividend top-20 · must pay 2 years in a row | +5.7% | -41.5% | +9.3% | 🆗 ok |
| 15 | Dividend top-20 · sell when below 200-day average | +1.8% | -16.7% | +2.8% | 👎 weak |
| 16 | Dividend · all filters + stop | +2.7% | -32.9% | +5.3% | 👎 weak |
| 17 | Dividend top-10 · all filters | +3.1% | -43.3% | +8.4% | 👎 weak |
| 18 | Dividend · all filters together | +2.2% | -44.3% | +4.7% | 👎 weak |
| 19 | Hold all liquid stocks (the market) | +1.1% | -51.5% | -0.9% | — benchmark |

**Price-only strategies (24 years, 2003 → Nov 2026)**
| # | Strategy | Per year | Worst drop | Since 2020 | Verdict |
|---|---|---|---|---|---|
| 1 | Momentum top-10 · only when market above 200-day avg | +14.7% | -65.0% | +8.4% | ⚠️ big drops |
| 2 | Momentum top-10 · market filter · 15% trailing stop | +12.8% | -49.9% | +5.7% | ⚠️ big drops |
| 3 | Momentum top-10 (every month) | +14.4% | -73.1% | +6.9% | ⚠️ big drops |
| 4 | Momentum top-10 · market filter · 20% trailing stop | +12.3% | -59.6% | +4.5% | ⚠️ big drops |
| 5 | Hold all liquid stocks (the market) | +9.0% | -62.5% | -0.9% | — benchmark |

**Other strategies (2021 → Nov 2026 only)**
| # | Strategy | Per year | Worst drop | Verdict |
|---|---|---|---|---|
| 1 | Swing breakout + trailing stop | +2.7% | -28.0% | 👎 weak |
| 2 | Trend per stock (above its average) | -5.5% | -29.1% | ❌ avoid |
| 3 | Low-volatility stocks | -2.3% | -22.4% | ❌ avoid |
| 4 | RSI(2) dip buying | -1.8% | -19.1% | ❌ avoid |
| 5 | Dividend capture (buy before ex-date, sell after) | -10.7% | -49.1% | ❌ avoid |

**Summary**
- Best: dividend top-20 with a 25% trailing stop and the top-40 buffer — steady, smallest drop
- Momentum earned more over 24 years but mostly in 2003–2013 and can drop 50–65%
- Day trading the PSE loses to fees (~0.9% per round trip)
