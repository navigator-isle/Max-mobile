---
tags: [trading, core, strategy]
---
**My plan — MAX-MASTER-3 (from 9 Nov 2026)**

**The four parts**
- **40% PSE dividend stocks** — the 20 highest dividend payers; see PSE › 1 PSE plan
- **21% crypto swing** — buy strong coins breaking out, only when Bitcoin is healthy; see Crypto › 1 Crypto plan
- **9% Bitcoin trend** — hold Bitcoin only in an uptrend
- **30% gold trend** — hold gold only in an uptrend; see Forex and Gold › 1 plan

**Why this mix**
- The three parts rarely move together, so when one falls the others often hold up
- Each part has a rule that cuts losses (trailing stop or "only in an uptrend")

**Tested results (2014 → Oct 2026, fees included)**
- About 17.6% a year · worst drop -11.6% · worst month -5.0%
- First half 2014–2019: 17.7% a year · second half 2020–2026: 17.4% a year
- By year: 2014 +10% · 2015 +5% · 2016 +21% · 2017 +70% · 2018 -8% · 2019 +21% · 2020 +34% · 2021 +35% · 2022 -6% · 2023 +16% · 2024 +36% · 2025 +18% · 2026 -6%

**Not used (watch only)**
- Forex and copy trading: no lasting edge in 26 years of tests
- Crypto momentum and copying "hot" traders: lost money in tests

**Limits**
- Past results don't guarantee the future; crypto and gold are in US dollars, PSE in pesos
