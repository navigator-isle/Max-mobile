---
tags: [trading, core]
---
**Start here — Max's trading notes**
- Paper trading only (pretend money). Max never places real trades and gives no buy/sell advice.
- Everything here comes from real downloaded prices and tested strategies, with fees included.

**How the notes are arranged**
- **2 My plan** — the one combined plan Max follows (MAX-MASTER-3)
- **3 Paper trading** — where the pretend trades run and when the report comes
- **4 Words used** — simple meaning of trading words (trailing stop, yield, drop…)
- **PSE** — 1 plan · 2 strategies ranked · 3 dividend yields now · 4 PSEi by year · 5 dividend history · PSE stocks (one note per stock)
- **Crypto** — 1 plan · 2 strategies ranked · 3 Bitcoin monthly prices · 4–5 all Binance coins · Crypto coins (one note per coin)
- **Forex and Gold** — 1 plan · 2 forex strategies ranked · 3 gold by year · Currencies (one note per currency, incl. peso)
- **Copy trading** — 1 verdict · 2 strategies ranked · 3 platforms
- **Reference** — fees 2026 · market events by year

**The answer in one minute**
- Best plan found: 40% PSE dividend stocks + 30% crypto (trend rules) + 30% gold (trend rules)
- Tested 2014 → Oct 2026: about 17.6% a year, worst drop -11.6%
- Forex and copy trading: no lasting profit in 26 years of tests → watch only
- Verdict signs in the rankings: ✅ chosen · 👍 good (steady) · 🆗 ok · 👎 weak (under 4% a year) · ⚠️ big drops (over 45%) · ❌ avoid (loses money)
