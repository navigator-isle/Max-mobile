---
tags: [trading, paper]
---
**Paper trading — how it runs**
- Started 8 Nov 2026 with pretend money: ₱100,000 per strategy
- Runs every Sunday on the dashboard: https://claude.ai/artifact/25fnUcKASedJmKSZBRbW9H
- Report by email every Sunday 5:57 pm Manila, every buy and sell explained (signal, price, stop, risk, result)
- Trades fill at the next day's closing price with real fees (COL for PSE, Binance for crypto)

**Main books (count in the plan)**
- PSE dividend top-20 · Crypto swing · Bitcoin trend · Gold trend

**Watch-only books (to confirm they fail live)**
- Forex fade big traders · Copy steady traders · Copy hot traders · Crypto momentum rotation

**When to judge**
- Too early before about 12 weeks; a full year with dividends is better
