---
tags: [trading, glossary]
---
**Words used in the trading notes**
- **Paper trading** — trading with pretend money to test a strategy
- **Per year** — average growth each year (compound)
- **Worst drop** — biggest fall from a high point before recovering (also called drawdown)
- **Dividend yield** — cash dividends of the last 12 months ÷ today's price
- **Ex-date** — buy before this date to get the dividend
- **Rebalance** — re-check the list and sell/buy to match the rules
- **Board lot** — the minimum number of shares you can buy on the PSE
- **Trailing stop** — a sell level that moves up as the price rises and never goes down; it locks in profit
- **ATR** — the average daily price move; a 2×ATR stop sits two "normal days" below the price
- **Breakout** — the price closes above its highest close of the last 20 days
- **Uptrend filter** — only trade when the price is above its 50-, 100- or 200-day average
- **R** — profit or loss compared with the amount risked (+2R = won twice the risk)
- **Momentum** — buying what went up most recently
- **Carry** — earning the interest gap between two currencies
- **Fade** — doing the opposite of a group of traders
- **Sharpe** — return compared with how bumpy the ride was (higher = smoother)
