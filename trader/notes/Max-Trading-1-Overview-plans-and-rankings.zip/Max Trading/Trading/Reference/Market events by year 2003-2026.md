---
tags: [trading, events]
---
**Market events by year**
- 🇵🇭 Philippines · 🌍 global · ₿ crypto
- After each event: how much the PSEi, Bitcoin and gold moved in the next 30 days

**2003**
- 20/03 🌍 US-led invasion of Iraq begins → 30 days: PSEi +10.3% · gold -0.8%

**2004**
- 10/05 🇵🇭 Philippine presidential election (Arroyo re-elected) → 30 days: PSEi -0.7% · gold +1.5%

**2005**
- 08/07 🇵🇭 "Hello Garci" political crisis; 10 cabinet members resign → 30 days: PSEi +6.9% · gold +2.7%

**2006**
- 24/02 🇵🇭 State of emergency declared (Proclamation 1017) → 30 days: PSEi +5.0% · gold +3.4%

**2007**
- 27/02 🌍 China stock crash spreads worldwide → 30 days: PSEi -6.8% · gold -3.6%
- 09/08 🌍 BNP Paribas freezes funds — start of the subprime crisis → 30 days: PSEi -2.8% · gold +4.3%

**2008**
- 15/09 🌍 Lehman Brothers collapses — global financial crisis → 30 days: PSEi -15.4% · gold +9.9%

**2009**
- 03/01 ₿ Bitcoin genesis block mined → 30 days: PSEi -2.1% · gold +3.2%

**2010**
- 06/05 🌍 US "flash crash"; Greek debt crisis → 30 days: PSEi +2.8% · gold +5.5%
- 10/05 🇵🇭 Philippine election (Aquino III) → 30 days: PSEi +3.6% · gold +1.5%

**2011**
- 11/03 🌍 Japan earthquake and tsunami (Fukushima) → 30 days: PSEi +6.8% · Bitcoin -20.4% · gold +3.9%
- 05/08 🌍 S&P downgrades US credit rating → 30 days: PSEi -2.6% · Bitcoin -17.4% · gold +12.9%

**2013**
- 27/03 🇵🇭 Philippines gets first investment-grade rating (Fitch) → 30 days: PSEi +5.4% · Bitcoin +72.0% · gold -8.9%
- 22/05 🌍 Fed "taper tantrum" — emerging markets sell off → 30 days: PSEi -15.6% · Bitcoin -13.4% · gold -6.3%
- 08/11 🇵🇭 Typhoon Haiyan (Yolanda) → 30 days: PSEi -6.6% · Bitcoin +170.4% · gold -5.6%

**2014**
- 24/02 ₿ Mt. Gox collapses → 30 days: PSEi +0.6% · Bitcoin -4.7% · gold -1.5%

**2015**
- 15/01 🌍 Swiss central bank removes the franc cap (CHF +30% in minutes) → 30 days: PSEi +3.9% · Bitcoin +49.9% · gold -2.1%
- 11/08 🌍 China devalues the yuan; global sell-off → 30 days: PSEi -8.5% · Bitcoin -9.7% · gold +0.5%

**2016**
- 09/05 🇵🇭 Philippine election (Duterte) → 30 days: PSEi +10.5% · Bitcoin +27.2% · gold -2.6%
- 23/06 🌍 UK votes for Brexit → 30 days: PSEi +3.8% · Bitcoin +9.0% · gold +4.0%
- 08/11 🌍 US election (Trump) → 30 days: PSEi -2.4% · Bitcoin +9.1% · gold -8.5%

**2017**
- 23/05 🇵🇭 Marawi siege; martial law in Mindanao → 30 days: PSEi +0.7% · Bitcoin +29.2% · gold -1.0%
- 17/12 ₿ Bitcoin peaks near $20,000; CME futures launch → 30 days: PSEi +6.3% · Bitcoin -40.7% · gold +6.5%

**2018**
- 01/01 🇵🇭 TRAIN tax law takes effect; PSEi record high late Jan 2018 → 30 days: PSEi +2.4% · Bitcoin -26.9% · gold +2.5%
- 05/02 🌍 US volatility shock ("Volmageddon") → 30 days: PSEi -4.6% · Bitcoin +21.0% · gold -0.6%
- 22/03 🌍 US–China trade war tariffs begin → 30 days: PSEi -2.4% · Bitcoin +0.3% · gold +0.1%
- 07/09 🇵🇭 Inflation reaches 6.4–6.7%; BSP hikes rates through 2018 → 30 days: PSEi -7.7% · Bitcoin +1.3% · gold -1.1%

**2020**
- 12/01 🇵🇭 Taal Volcano eruption → 30 days: PSEi -4.3% · Bitcoin +28.1% · gold +0.5%
- 12/03 ₿ COVID "Black Thursday" — Bitcoin −39% in a day → 30 days: PSEi -11.7% · Bitcoin -13.3% · gold +6.3%
- 16/03 🇵🇭 Luzon COVID lockdown; PSE closes 17–18 Mar 2020 → 30 days: PSEi +2.6% · Bitcoin +23.9% · gold +14.0%
- 11/05 ₿ Third Bitcoin halving → 30 days: PSEi +14.5% · Bitcoin +13.3% · gold +0.6%
- 13/08 🇵🇭 AREIT lists — first Philippine REIT → 30 days: PSEi +0.0% · Bitcoin -9.7% · gold +0.8%

**2021**
- 26/03 🇵🇭 CREATE law cuts corporate income tax → 30 days: PSEi +3.4% · Bitcoin -4.3% · gold +3.2%
- 19/05 ₿ Crypto crash (China mining ban, Tesla stops BTC payments) → 30 days: PSEi +11.2% · Bitcoin -16.4% · gold -5.3%
- 10/11 ₿ Bitcoin record ~$69,000 → 30 days: PSEi -3.7% · Bitcoin -29.6% · gold -2.5%

**2022**
- 24/02 🌍 Russia invades Ukraine; oil and inflation spike → 30 days: PSEi -3.1% · Bitcoin +19.5% · gold +1.5%
- 16/03 🌍 Fed starts fastest rate hikes since 1980s → 30 days: PSEi +3.2% · Bitcoin +3.2% · gold +2.9%
- 09/05 ₿ TerraUSD/LUNA collapse → 30 days: PSEi +0.1% · Bitcoin -11.3% · gold -1.4%
- 09/05 🇵🇭 Philippine election (Marcos Jr.) → 30 days: PSEi +0.1% · Bitcoin -11.3% · gold -1.4%
- 15/09 ₿ Ethereum "Merge" to proof-of-stake → 30 days: PSEi -6.9% · Bitcoin -5.8% · gold -2.6%
- 03/10 🇵🇭 Peso hits ₱59 per USD; BSP rate hikes to 6.5% by 2023 → 30 days: PSEi +3.6% · Bitcoin +5.8% · gold -1.3%
- 08/11 ₿ FTX exchange collapses → 30 days: PSEi +4.7% · Bitcoin -16.3% · gold +7.2%

**2023**
- 10/03 🌍 Silicon Valley Bank fails → 30 days: PSEi -1.1% · Bitcoin +39.1% · gold +9.2%

**2024**
- 10/01 ₿ US approves spot Bitcoin ETFs → 30 days: PSEi +3.1% · Bitcoin +2.2% · gold +0.3%
- 20/04 ₿ Fourth Bitcoin halving → 30 days: PSEi +9.1% · Bitcoin +11.9% · gold +1.0%
- 15/08 🇵🇭 BSP starts cutting rates → 30 days: PSEi +3.3% · Bitcoin +2.2% · gold +5.2%
- 05/11 🌍 US election (Trump returns) → 30 days: PSEi -3.0% · Bitcoin +43.1% · gold -3.6%

**2025**
- 02/04 🌍 US "Liberation Day" tariffs; global sell-off → 30 days: PSEi +3.6% · Bitcoin +13.8% · gold +3.1%
- 01/07 🇵🇭 Stock transaction tax cut from 0.6% to 0.1% (CMEPA) → 30 days: PSEi +2.5% · Bitcoin +8.0% · gold -0.4%
- 01/09 🇵🇭 Flood-control corruption scandal hits markets; PSEi 2025 worst year since 2013 (−7.3%) → 30 days: PSEi +2.0% · Bitcoin +9.6% · gold +10.8%
- 06/10 ₿ Bitcoin all-time high ~$126,000 → 30 days: PSEi -3.6% · Bitcoin -15.9% · gold +2.1%
- 10/10 ₿ US 100% China tariff threat; >$19B crypto liquidations in a day → 30 days: PSEi -3.8% · Bitcoin -14.0% · gold +3.8%

**2026**
- 06/02 ₿ Bitcoin falls ~52% from peak, near $60,000 → 30 days: PSEi -4.0% · Bitcoin +5.1% · gold +4.4%
- 28/02 🌍 US and Israeli strikes on Iran → 30 days: PSEi -5.9% · Bitcoin +1.3% · gold -13.8%
- 07/04 🌍 US–Iran two-week ceasefire → 30 days: PSEi +4.4% · Bitcoin +16.2% · gold +0.6%
- 02/09 🇵🇭 Peso record low ₱62.565 per USD → 30 days: PSEi -2.3% · Bitcoin +9.2% · gold -5.3%
- 01/10 🇵🇭 PSEi 2026 low 5,679.48 → 30 days: PSEi +0.5% · Bitcoin -7.3% · gold -5.2%

**Sources**
- Dates: public record; 2025–2026: https://www.fticonsulting.com/insights/articles/crypto-crash-october-2025-leverage-met-liquidity · https://learn.backpack.exchange/articles/bitcoin-crash · https://radar.ph/peso-hits-record-low-for-fourth-straight-session-as-psei-falls-september-2-2026/ · https://www.manilatimes.net/2026/10/01/business/top-business/psei-falls-to-2026-low-as-investor-worries-rise/2436568 · https://insiderph.com/pse-closes-most-challenging-year-since-pandemic-as-index-slides-73
- Moves: PSE archive/PSE Edge, Bitstamp, Yahoo Finance GC=F
