---
tags: [trading, crypto, core, strategy]
---
**Crypto plan — swing + Bitcoin trend**
- 30% of the total plan (21% swing + 9% Bitcoin trend) · Binance fees

**Swing (70% of crypto)**
- Watch the 20 most-traded coins on Binance
- Buy when a coin closes above its highest close of the last 20 days (breakout)
- Only when Bitcoin is above its 50-day average (tested: more profit, fewer bad trades)
- Stop 2×ATR below; it trails up as the price rises; risk 0.5% of the book per trade; at most 8 coins

**Bitcoin trend (30% of crypto)**
- Hold Bitcoin only while it closes above its 100-day average; otherwise cash
- Size so the swings stay near 40% a year

**What Max does not do (tested, failed recently)**
- Momentum (buying the strongest coins weekly) — lost money 2022–2026
- Holding many coins — the top-20 lost about 10% a year 2022–2026
- Day trading Bitcoin — loses with normal spot fees

**Tested**
- 70/30 mix: 49.0% a year all years · 17.8% a year 2022–2026 · worst drop -25.9%
- Bitcoin only exists since 2009 (prices from Jul 2010); coins from 2013
