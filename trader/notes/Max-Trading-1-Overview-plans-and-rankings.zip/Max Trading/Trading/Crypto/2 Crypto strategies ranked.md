---
tags: [trading, crypto, strategy]
---
**Crypto strategies ranked (best → worst, judged mainly on 2022–2026)**
- Early years show huge numbers (Bitcoin $0.30 → $126,000), so 2022–2026 matters most
- Fees: 0.30% per trade before 2017, 0.15% after

| # | Strategy | Per year | Worst drop | 2022–26 | Verdict |
|---|---|---|---|---|---|
| 1 | 70% swing + 30% Bitcoin trend | +49.0% | -25.9% | +17.8% | ✅ chosen |
| 2 | Swing breakout · only when Bitcoin above 50-day avg | +46.1% | -27.7% | +16.4% | 👍 good |
| 3 | Bitcoin only above 100-day avg · sized | +62.6% | -35.2% | +16.5% | 🆗 ok |
| 4 | 50% Bitcoin trend + 50% swing | +78.4% | -43.8% | +20.4% | 🆗 ok |
| 5 | Bitcoin 55-day breakout + trailing stop | +109.7% | -53.7% | +20.3% | ⚠️ big drops |
| 6 | Bitcoin only above 200-day avg | +99.9% | -90.3% | +26.5% | ⚠️ big drops |
| 7 | Bitcoin only above 50-day avg | +136.0% | -72.1% | +19.2% | ⚠️ big drops |
| 8 | Bitcoin only above 100-day avg | +132.7% | -74.9% | +19.8% | ⚠️ big drops |
| 9 | Swing breakout · no Bitcoin filter | +47.0% | -31.4% | +8.2% | 🆗 ok |
| 10 | Swing breakout · wider 3×ATR stop | +30.2% | -27.2% | +4.1% | 🆗 ok |
| 11 | Bitcoin golden cross (50 > 200 days) | +99.6% | -86.0% | +11.0% | ⚠️ big drops |
| 12 | Buy and hold Bitcoin | +119.1% | -92.3% | +10.7% | ⚠️ big drops |
| 13 | Bitcoin 20-day breakout + trailing stop | +111.9% | -62.8% | +1.9% | ⚠️ big drops |
| 14 | Momentum: 5 strongest coins (60 days) | +110.4% | -69.0% | +0.0% | ❌ avoid |
| 15 | Hold the top-20 coins | +154.0% | -90.5% | -9.6% | ❌ avoid |
| 16 | Momentum: 5 strongest coins weekly | +139.8% | -73.2% | -7.9% | ❌ avoid |

**Trade only the best chances? (all Binance coins, 2022 → Nov 2026)**
| # | Strategy | Per year | Worst drop | Trades | Verdict |
|---|---|---|---|---|---|
| 1 | only when BTC above 50-day avg | +9.1% | -28.3% | 453 trades | ✅ chosen |
| 2 | every breakout (current) | +5.5% | -30.2% | 589 trades | 🆗 ok |
| 3 | coin above its 50-day avg + BTC above 200-day | +5.0% | -27.8% | 337 trades | 🆗 ok |
| 4 | all filters (BTC>200d, coin>50d, 1.5x volume) | +4.9% | -18.4% | 226 trades | 🆗 ok |
| 5 | breakout with 1.5x volume | +3.8% | -31.3% | 391 trades | 👎 weak |
| 6 | only when BTC above 200-day avg | +2.2% | -31.1% | 369 trades | 👎 weak |

**Summary**
- Swing with the Bitcoin filter made money in every period with the smallest drop
- Adding 30% Bitcoin trend helped a little and catches Bitcoin bull runs
