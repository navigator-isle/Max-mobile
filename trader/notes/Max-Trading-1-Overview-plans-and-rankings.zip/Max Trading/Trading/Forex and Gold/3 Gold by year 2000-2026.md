---
tags: [trading, gold]
---
**Gold by year (USD per ounce)**
- All-time high in data $5,318 (2026-01-29) · last $4,075 (2026-11-06)

- 2000: close $272.0/oz (first year) · high $278.4 · low $263.9 · speculators net -10%
- 2001: close $278.7/oz (+2.5%) · high $293.3 · low $255.1 · speculators net -5%
- 2002: close $347.6/oz (+24.7%) · high $349.2 · low $278.1 · speculators net +18%
- 2003: close $415.7/oz (+19.6%) · high $416.9 · low $321.5 · speculators net +28%
- 2004: close $437.5/oz (+5.2%) · high $456.0 · low $374.8 · speculators net +28%
- 2005: close $517.1/oz (+18.2%) · high $528.4 · low $412.6 · speculators net +33%
- 2006: close $635.2/oz (+22.8%) · high $719.8 · low $526.3 · speculators net +31%
- 2007: close $834.9/oz (+31.4%) · high $839.6 · low $604.9 · speculators net +29%
- 2008: close $883.6/oz (+5.8%) · high $1,003 · low $704.9 · speculators net +36%
- 2009: close $1,095/oz (+23.9%) · high $1,217 · low $806.7 · speculators net +45%
- 2010: close $1,421/oz (+29.8%) · high $1,421 · low $1,052 · speculators net +39%
- 2011: close $1,566/oz (+10.2%) · high $1,889 · low $1,318 · speculators net +35%
- 2012: close $1,675/oz (+7.0%) · high $1,794 · low $1,536 · speculators net +35%
- 2013: close $1,202/oz (-28.2%) · high $1,693 · low $1,195 · speculators net +19%
- 2014: close $1,184/oz (-1.5%) · high $1,379 · low $1,142 · speculators net +25%
- 2015: close $1,060/oz (-10.4%) · high $1,301 · low $1,051 · speculators net +20%
- 2016: close $1,150/oz (+8.5%) · high $1,365 · low $1,074 · speculators net +39%
- 2017: close $1,306/oz (+13.6%) · high $1,346 · low $1,160 · speculators net +33%
- 2018: close $1,278/oz (-2.1%) · high $1,362 · low $1,176 · speculators net +17%
- 2019: close $1,520/oz (+18.9%) · high $1,550 · low $1,269 · speculators net +33%
- 2020: close $1,895/oz (+24.7%) · high $2,069 · low $1,477 · speculators net +46%
- 2021: close $1,829/oz (-3.5%) · high $1,954 · low $1,678 · speculators net +41%
- 2022: close $1,826/oz (-0.1%) · high $2,043 · low $1,631 · speculators net +30%
- 2023: close $2,072/oz (+13.4%) · high $2,093 · low $1,817 · speculators net +33%
- 2024: close $2,641/oz (+27.5%) · high $2,801 · low $2,004 · speculators net +47%
- 2025: close $4,341/oz (+64.4%) · high $4,553 · low $2,647 · speculators net +47%
- 2026: close $4,075/oz (-6.1%) · high $5,318 · low $3,899 · speculators net +48%

**Sources**
- Yahoo Finance GC=F daily · CFTC legacy COT (gold)
