---
tags: [trading, forex, strategy]
---
**Forex strategies ranked (2000 → Oct 2026)**
- Columns "2000-08 / 2009-16 / 2017-26" = per year in each period
- No leverage · interest gap included · 0.03% per trade

| # | Strategy | Per year | Worst drop | 2000-08 / 2009-16 / 2017-26 | Verdict |
|---|---|---|---|---|---|
| 1 | Carry, only when the currency trend agrees (6-month) | +0.8% | -25.5% | +1.9 / +2.9 / -1.9 | ❌ avoid |
| 2 | Carry: long 3 highest rates, short 3 lowest (monthly) | +0.7% | -17.3% | -0.3 / +0.7 / +1.6 | ❌ avoid |
| 3 | Carry + trend 50/50 | +0.7% | -10.0% | +1.6 / +1.6 / -0.9 | ❌ avoid |
| 4 | Hold all 10 currencies vs USD equally (with interest) | +0.5% | -38.3% | +2.5 / -0.5 / -0.5 | — benchmark |
| 5 | Trend: each currency long/short by its 126-day direction | +0.5% | -29.1% | +3.1 / +2.4 / -3.3 | ❌ avoid |
| 6 | Carry: long 2 highest, short 2 lowest | +0.4% | -29.8% | -1.0 / -0.6 / +2.4 | ❌ avoid |
| 7 | Trend: each currency long/short by its 252-day direction | +0.4% | -31.6% | +4.7 / -1.7 / -1.5 | ❌ avoid |
| 8 | Trend: each currency long/short by its 63-day direction | +0.1% | -26.2% | +2.1 / -0.1 / -1.4 | ❌ avoid |
| 9 | Momentum: long 3 strongest, short 3 weakest (252-day) | +0.1% | -22.1% | +1.7 / -0.4 / -1.1 | ❌ avoid |
| 10 | Momentum: long 3 strongest, short 3 weakest (63-day) | -0.4% | -29.8% | +0.9 / -1.0 / -1.0 | ❌ avoid |

**Summary**
- None earns money over the long run → forex is watch only
