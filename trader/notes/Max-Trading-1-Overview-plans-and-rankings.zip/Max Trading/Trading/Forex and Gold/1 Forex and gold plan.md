---
tags: [trading, forex, gold, core, strategy]
---
**Forex and gold plan**

**Forex — watch only**
- 26 years of tests (2000–2026, 10 currencies, interest included): no strategy kept a profit
- Results between −1.9% and +0.8% a year, and they flip between periods
- Forex makes money only with leverage, which multiplies losses too → not used
- A watch-only paper book (fade big traders) keeps running to confirm

**Gold trend — 30% of the total plan**
- Hold gold only while it closes above its 200-day average; otherwise cash
- Size so the swings stay near 12% a year
- Holding gold 2000–2026: 10.3% a year, worst drop -44.4%
- With the trend rule: about 6.3% a year, worst drop −34% — smaller drops, and it moves differently from stocks and crypto
