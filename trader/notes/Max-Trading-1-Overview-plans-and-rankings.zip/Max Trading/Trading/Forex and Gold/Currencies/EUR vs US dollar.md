---
tags: [trading, forex]
---
**EUR — Euro**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: EUR/USD close 0.9388 · EUR vs USD – · EUR 3-month rate 4.39% vs USD 6.33% · total return holding EUR – · speculators net +2% of open interest
- 2001: EUR/USD close 0.8901 · EUR vs USD -5.2% · EUR 3-month rate 4.26% vs USD 3.64% · total return holding EUR -4.6% · speculators net +12% of open interest
- 2002: EUR/USD close 1.05 · EUR vs USD +17.8% · EUR 3-month rate 3.32% vs USD 1.70% · total return holding EUR +19.4% · speculators net +20% of open interest
- 2003: EUR/USD close 1.26 · EUR vs USD +20.1% · EUR 3-month rate 2.33% vs USD 1.13% · total return holding EUR +21.3% · speculators net +20% of open interest
- 2004: EUR/USD close 1.35 · EUR vs USD +7.5% · EUR 3-month rate 2.11% vs USD 1.52% · total return holding EUR +8.0% · speculators net +16% of open interest
- 2005: EUR/USD close 1.18 · EUR vs USD -12.5% · EUR 3-month rate 2.18% vs USD 3.44% · total return holding EUR -13.8% · speculators net +0% of open interest
- 2006: EUR/USD close 1.32 · EUR vs USD +11.5% · EUR 3-month rate 3.08% vs USD 5.06% · total return holding EUR +9.5% · speculators net +33% of open interest · hedge funds net +27%
- 2007: EUR/USD close 1.46 · EUR vs USD +10.6% · EUR 3-month rate 4.28% vs USD 5.13% · total return holding EUR +9.8% · speculators net +37% of open interest · hedge funds net +26%
- 2008: EUR/USD close 1.39 · EUR vs USD -4.7% · EUR 3-month rate 4.63% vs USD 2.64% · total return holding EUR -2.7% · speculators net -1% of open interest · hedge funds net +1%
- 2009: EUR/USD close 1.43 · EUR vs USD +3.0% · EUR 3-month rate 1.23% vs USD 0.42% · total return holding EUR +3.8% · speculators net +6% of open interest · hedge funds net +5%
- 2010: EUR/USD close 1.33 · EUR vs USD -7.4% · EUR 3-month rate 0.81% vs USD 0.29% · total return holding EUR -6.9% · speculators net -15% of open interest · hedge funds net -21%
- 2011: EUR/USD close 1.30 · EUR vs USD -2.2% · EUR 3-month rate 1.39% vs USD 0.21% · total return holding EUR -1.1% · speculators net -1% of open interest · hedge funds net -2%
- 2012: EUR/USD close 1.32 · EUR vs USD +1.6% · EUR 3-month rate 0.57% vs USD 0.20% · total return holding EUR +2.0% · speculators net -37% of open interest · hedge funds net -28%
- 2013: EUR/USD close 1.38 · EUR vs USD +4.5% · EUR 3-month rate 0.22% vs USD 0.14% · total return holding EUR +4.6% · speculators net +0% of open interest · hedge funds net +3%
- 2014: EUR/USD close 1.21 · EUR vs USD -12.2% · EUR 3-month rate 0.21% vs USD 0.12% · total return holding EUR -12.1% · speculators net -16% of open interest · hedge funds net -10%
- 2015: EUR/USD close 1.09 · EUR vs USD -10.3% · EUR 3-month rate -0.02% vs USD 0.23% · total return holding EUR -10.5% · speculators net -35% of open interest · hedge funds net -25%
- 2016: EUR/USD close 1.06 · EUR vs USD -2.8% · EUR 3-month rate -0.26% vs USD 0.64% · total return holding EUR -3.7% · speculators net -21% of open interest · hedge funds net -22%
- 2017: EUR/USD close 1.20 · EUR vs USD +13.9% · EUR 3-month rate -0.33% vs USD 1.15% · total return holding EUR +12.5% · speculators net +8% of open interest · hedge funds net -7%
- 2018: EUR/USD close 1.15 · EUR vs USD -4.7% · EUR 3-month rate -0.32% vs USD 2.19% · total return holding EUR -7.2% · speculators net +9% of open interest · hedge funds net -7%
- 2019: EUR/USD close 1.12 · EUR vs USD -2.0% · EUR 3-month rate -0.36% vs USD 2.21% · total return holding EUR -4.6% · speculators net -12% of open interest · hedge funds net -18%
- 2020: EUR/USD close 1.22 · EUR vs USD +8.9% · EUR 3-month rate -0.43% vs USD 0.53% · total return holding EUR +8.0% · speculators net +14% of open interest · hedge funds net -5%
- 2021: EUR/USD close 1.13 · EUR vs USD -7.4% · EUR 3-month rate -0.55% vs USD 0.11% · total return holding EUR -8.1% · speculators net +9% of open interest · hedge funds net -3%
- 2022: EUR/USD close 1.07 · EUR vs USD -5.5% · EUR 3-month rate 0.34% vs USD 2.23% · total return holding EUR -7.4% · speculators net +5% of open interest · hedge funds net -2%
- 2023: EUR/USD close 1.11 · EUR vs USD +3.4% · EUR 3-month rate 3.43% vs USD 5.18% · total return holding EUR +1.7% · speculators net +19% of open interest · hedge funds net +1%
- 2024: EUR/USD close 1.04 · EUR vs USD -6.4% · EUR 3-month rate 3.57% vs USD 5.05% · total return holding EUR -7.9% · speculators net +4% of open interest · hedge funds net -1%
- 2025: EUR/USD close 1.17 · EUR vs USD +13.4% · EUR 3-month rate 2.18% vs USD 4.17% · total return holding EUR +11.4% · speculators net +9% of open interest · hedge funds net +2%
- 2026: EUR/USD close 1.12 · EUR vs USD -4.9% · EUR 3-month rate 2.31% vs USD 3.79% · total return holding EUR -6.4% · speculators net +1% of open interest · hedge funds net -2%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
