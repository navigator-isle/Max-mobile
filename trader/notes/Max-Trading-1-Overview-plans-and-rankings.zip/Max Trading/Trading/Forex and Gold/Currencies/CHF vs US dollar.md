---
tags: [trading, forex]
---
**CHF — Switzerland**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: USD/CHF close 1.62 · CHF vs USD – · CHF 3-month rate 2.94% vs USD 6.33% · total return holding CHF – · speculators net -22% of open interest
- 2001: USD/CHF close 1.66 · CHF vs USD -2.4% · CHF 3-month rate 2.81% vs USD 3.64% · total return holding CHF -3.2% · speculators net -3% of open interest
- 2002: USD/CHF close 1.38 · CHF vs USD +20.0% · CHF 3-month rate 1.05% vs USD 1.70% · total return holding CHF +19.3% · speculators net +7% of open interest
- 2003: USD/CHF close 1.24 · CHF vs USD +11.7% · CHF 3-month rate 0.22% vs USD 1.13% · total return holding CHF +10.8% · speculators net +9% of open interest
- 2004: USD/CHF close 1.14 · CHF vs USD +8.5% · CHF 3-month rate 0.38% vs USD 1.52% · total return holding CHF +7.3% · speculators net +10% of open interest
- 2005: USD/CHF close 1.31 · CHF vs USD -13.2% · CHF 3-month rate 0.71% vs USD 3.44% · total return holding CHF -15.9% · speculators net -36% of open interest
- 2006: USD/CHF close 1.22 · CHF vs USD +7.8% · CHF 3-month rate 1.41% vs USD 5.06% · total return holding CHF +4.2% · speculators net -26% of open interest · hedge funds net -30%
- 2007: USD/CHF close 1.13 · CHF vs USD +7.6% · CHF 3-month rate 2.34% vs USD 5.13% · total return holding CHF +4.9% · speculators net -26% of open interest · hedge funds net -25%
- 2008: USD/CHF close 1.07 · CHF vs USD +6.1% · CHF 3-month rate 1.84% vs USD 2.64% · total return holding CHF +5.3% · speculators net -10% of open interest · hedge funds net -8%
- 2009: USD/CHF close 1.04 · CHF vs USD +3.0% · CHF 3-month rate 0.09% vs USD 0.42% · total return holding CHF +2.7% · speculators net +10% of open interest · hedge funds net +15%
- 2010: USD/CHF close 0.9369 · CHF vs USD +10.6% · CHF 3-month rate 0.15% vs USD 0.29% · total return holding CHF +10.4% · speculators net +5% of open interest · hedge funds net +1%
- 2011: USD/CHF close 0.9374 · CHF vs USD -0.1% · CHF 3-month rate 0.06% vs USD 0.21% · total return holding CHF -0.2% · speculators net +14% of open interest · hedge funds net +19%
- 2012: USD/CHF close 0.9155 · CHF vs USD +2.4% · CHF 3-month rate -0.06% vs USD 0.20% · total return holding CHF +2.1% · speculators net -23% of open interest · hedge funds net +1%
- 2013: USD/CHF close 0.8904 · CHF vs USD +2.8% · CHF 3-month rate -0.05% vs USD 0.14% · total return holding CHF +2.6% · speculators net +0% of open interest · hedge funds net +8%
- 2014: USD/CHF close 0.9934 · CHF vs USD -10.4% · CHF 3-month rate 0.00% vs USD 0.12% · total return holding CHF -10.5% · speculators net -9% of open interest · hedge funds net -9%
- 2015: USD/CHF close 1.00 · CHF vs USD -0.8% · CHF 3-month rate -0.72% vs USD 0.23% · total return holding CHF -1.8% · speculators net -3% of open interest · hedge funds net -10%
- 2016: USD/CHF close 1.02 · CHF vs USD -1.4% · CHF 3-month rate -0.77% vs USD 0.64% · total return holding CHF -2.8% · speculators net -2% of open interest · hedge funds net -18%
- 2017: USD/CHF close 0.9738 · CHF vs USD +4.3% · CHF 3-month rate -0.85% vs USD 1.15% · total return holding CHF +2.3% · speculators net -21% of open interest · hedge funds net -7%
- 2018: USD/CHF close 0.9832 · CHF vs USD -1.0% · CHF 3-month rate -0.81% vs USD 2.19% · total return holding CHF -4.0% · speculators net -31% of open interest · hedge funds net -18%
- 2019: USD/CHF close 0.9677 · CHF vs USD +1.6% · CHF 3-month rate -0.77% vs USD 2.21% · total return holding CHF -1.4% · speculators net -26% of open interest · hedge funds net +0%
- 2020: USD/CHF close 0.8841 · CHF vs USD +9.5% · CHF 3-month rate -0.70% vs USD 0.53% · total return holding CHF +8.2% · speculators net +17% of open interest · hedge funds net +23%
- 2021: USD/CHF close 0.9146 · CHF vs USD -3.3% · CHF 3-month rate -0.74% vs USD 0.11% · total return holding CHF -4.2% · speculators net +1% of open interest · hedge funds net +14%
- 2022: USD/CHF close 0.9241 · CHF vs USD -1.0% · CHF 3-month rate -0.18% vs USD 2.23% · total return holding CHF -3.4% · speculators net -23% of open interest · hedge funds net -9%
- 2023: USD/CHF close 0.8405 · CHF vs USD +9.9% · CHF 3-month rate 1.52% vs USD 5.18% · total return holding CHF +6.3% · speculators net -17% of open interest · hedge funds net -3%
- 2024: USD/CHF close 0.9068 · CHF vs USD -7.3% · CHF 3-month rate 1.24% vs USD 5.05% · total return holding CHF -11.1% · speculators net -34% of open interest · hedge funds net -8%
- 2025: USD/CHF close 0.7936 · CHF vs USD +14.3% · CHF 3-month rate 0.09% vs USD 4.17% · total return holding CHF +10.2% · speculators net -37% of open interest · hedge funds net -7%
- 2026: USD/CHF close 0.8230 · CHF vs USD -3.6% · CHF 3-month rate -0.04% vs USD 3.79% · total return holding CHF -7.4% · speculators net -31% of open interest · hedge funds net -6%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
