---
tags: [trading, forex]
---
**CAD — Canada**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: USD/CAD close 1.50 · CAD vs USD – · CAD 3-month rate 5.44% vs USD 6.33% · total return holding CAD – · speculators net -16% of open interest
- 2001: USD/CAD close 1.59 · CAD vs USD -5.8% · CAD 3-month rate 3.86% vs USD 3.64% · total return holding CAD -5.6% · speculators net -15% of open interest
- 2002: USD/CAD close 1.58 · CAD vs USD +0.8% · CAD 3-month rate 2.51% vs USD 1.70% · total return holding CAD +1.6% · speculators net +5% of open interest
- 2003: USD/CAD close 1.29 · CAD vs USD +22.3% · CAD 3-month rate 2.86% vs USD 1.13% · total return holding CAD +24.0% · speculators net +29% of open interest
- 2004: USD/CAD close 1.20 · CAD vs USD +7.4% · CAD 3-month rate 2.22% vs USD 1.52% · total return holding CAD +8.1% · speculators net +16% of open interest
- 2005: USD/CAD close 1.17 · CAD vs USD +3.2% · CAD 3-month rate 2.70% vs USD 3.44% · total return holding CAD +2.5% · speculators net +11% of open interest
- 2006: USD/CAD close 1.17 · CAD vs USD +0.0% · CAD 3-month rate 4.01% vs USD 5.06% · total return holding CAD -1.0% · speculators net +7% of open interest · hedge funds net +1%
- 2007: USD/CAD close 0.9881 · CAD vs USD +17.9% · CAD 3-month rate 4.14% vs USD 5.13% · total return holding CAD +16.9% · speculators net +11% of open interest · hedge funds net +10%
- 2008: USD/CAD close 1.22 · CAD vs USD -19.3% · CAD 3-month rate 2.34% vs USD 2.64% · total return holding CAD -19.6% · speculators net +2% of open interest · hedge funds net -5%
- 2009: USD/CAD close 1.05 · CAD vs USD +17.0% · CAD 3-month rate 0.33% vs USD 0.42% · total return holding CAD +16.9% · speculators net +9% of open interest · hedge funds net +11%
- 2010: USD/CAD close 1.00 · CAD vs USD +4.5% · CAD 3-month rate 0.56% vs USD 0.29% · total return holding CAD +4.8% · speculators net +29% of open interest · hedge funds net +30%
- 2011: USD/CAD close 1.02 · CAD vs USD -1.6% · CAD 3-month rate 0.91% vs USD 0.21% · total return holding CAD -0.9% · speculators net +14% of open interest · hedge funds net +9%
- 2012: USD/CAD close 0.9958 · CAD vs USD +2.1% · CAD 3-month rate 0.94% vs USD 0.20% · total return holding CAD +2.8% · speculators net +23% of open interest · hedge funds net +6%
- 2013: USD/CAD close 1.06 · CAD vs USD -6.4% · CAD 3-month rate 0.97% vs USD 0.14% · total return holding CAD -5.6% · speculators net -15% of open interest · hedge funds net -18%
- 2014: USD/CAD close 1.16 · CAD vs USD -8.3% · CAD 3-month rate 0.91% vs USD 0.12% · total return holding CAD -7.5% · speculators net -16% of open interest · hedge funds net -23%
- 2015: USD/CAD close 1.38 · CAD vs USD -16.2% · CAD 3-month rate 0.53% vs USD 0.23% · total return holding CAD -15.9% · speculators net -24% of open interest · hedge funds net -23%
- 2016: USD/CAD close 1.34 · CAD vs USD +3.1% · CAD 3-month rate 0.49% vs USD 0.64% · total return holding CAD +2.9% · speculators net -4% of open interest · hedge funds net -11%
- 2017: USD/CAD close 1.25 · CAD vs USD +7.3% · CAD 3-month rate 0.69% vs USD 1.15% · total return holding CAD +6.8% · speculators net +5% of open interest · hedge funds net +0%
- 2018: USD/CAD close 1.36 · CAD vs USD -8.3% · CAD 3-month rate 1.37% vs USD 2.19% · total return holding CAD -9.1% · speculators net -9% of open interest · hedge funds net -11%
- 2019: USD/CAD close 1.30 · CAD vs USD +5.3% · CAD 3-month rate 1.66% vs USD 2.21% · total return holding CAD +4.7% · speculators net -8% of open interest · hedge funds net -10%
- 2020: USD/CAD close 1.28 · CAD vs USD +1.6% · CAD 3-month rate 0.45% vs USD 0.53% · total return holding CAD +1.6% · speculators net -11% of open interest · hedge funds net -15%
- 2021: USD/CAD close 1.28 · CAD vs USD -0.2% · CAD 3-month rate 0.11% vs USD 0.11% · total return holding CAD -0.2% · speculators net +4% of open interest · hedge funds net -0%
- 2022: USD/CAD close 1.35 · CAD vs USD -5.6% · CAD 3-month rate 2.18% vs USD 2.23% · total return holding CAD -5.6% · speculators net +0% of open interest · hedge funds net -7%
- 2023: USD/CAD close 1.32 · CAD vs USD +2.5% · CAD 3-month rate 4.74% vs USD 5.18% · total return holding CAD +2.1% · speculators net -20% of open interest · hedge funds net -11%
- 2024: USD/CAD close 1.44 · CAD vs USD -8.3% · CAD 3-month rate 4.37% vs USD 5.05% · total return holding CAD -9.0% · speculators net -33% of open interest · hedge funds net -21%
- 2025: USD/CAD close 1.37 · CAD vs USD +5.0% · CAD 3-month rate 2.58% vs USD 4.17% · total return holding CAD +3.4% · speculators net -42% of open interest · hedge funds net -20%
- 2026: USD/CAD close 1.40 · CAD vs USD -1.8% · CAD 3-month rate 2.27% vs USD 3.79% · total return holding CAD -3.3% · speculators net -21% of open interest · hedge funds net -21%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
