---
tags: [trading, forex]
---
**ZAR — South Africa**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: USD/ZAR close 7.57 · ZAR vs USD – · ZAR 3-month rate 10.11% vs USD 6.33% · total return holding ZAR – · speculators net +3% of open interest
- 2001: USD/ZAR close 12.00 · ZAR vs USD -36.9% · ZAR 3-month rate 9.68% vs USD 3.64% · total return holding ZAR -30.9%
- 2002: USD/ZAR close 8.59 · ZAR vs USD +39.8% · ZAR 3-month rate 11.16% vs USD 1.70% · total return holding ZAR +49.2%
- 2003: USD/ZAR close 6.70 · ZAR vs USD +28.1% · ZAR 3-month rate 10.67% vs USD 1.13% · total return holding ZAR +37.7%
- 2004: USD/ZAR close 5.64 · ZAR vs USD +18.7% · ZAR 3-month rate 7.53% vs USD 1.52% · total return holding ZAR +24.7%
- 2005: USD/ZAR close 6.33 · ZAR vs USD -10.8% · ZAR 3-month rate 6.91% vs USD 3.44% · total return holding ZAR -7.4%
- 2006: USD/ZAR close 7.04 · ZAR vs USD -10.1% · ZAR 3-month rate 7.34% vs USD 5.06% · total return holding ZAR -7.8%
- 2007: USD/ZAR close 6.86 · ZAR vs USD +2.6% · ZAR 3-month rate 9.11% vs USD 5.13% · total return holding ZAR +6.6%
- 2008: USD/ZAR close 9.30 · ZAR vs USD -26.2% · ZAR 3-month rate 10.81% vs USD 2.64% · total return holding ZAR -18.1%
- 2009: USD/ZAR close 7.36 · ZAR vs USD +26.3% · ZAR 3-month rate 7.85% vs USD 0.42% · total return holding ZAR +33.8%
- 2010: USD/ZAR close 6.67 · ZAR vs USD +10.4% · ZAR 3-month rate 6.42% vs USD 0.29% · total return holding ZAR +16.5% · speculators net -40% of open interest · hedge funds net -32%
- 2011: USD/ZAR close 8.08 · ZAR vs USD -17.4% · ZAR 3-month rate 5.49% vs USD 0.21% · total return holding ZAR -12.1%
- 2012: USD/ZAR close 8.48 · ZAR vs USD -4.8% · ZAR 3-month rate 5.29% vs USD 0.20% · total return holding ZAR +0.3%
- 2013: USD/ZAR close 10.48 · ZAR vs USD -19.1% · ZAR 3-month rate 5.08% vs USD 0.14% · total return holding ZAR -14.1%
- 2014: USD/ZAR close 11.54 · ZAR vs USD -9.2% · ZAR 3-month rate 5.80% vs USD 0.12% · total return holding ZAR -3.5% · speculators net -19% of open interest · hedge funds net -19%
- 2015: USD/ZAR close 15.47 · ZAR vs USD -25.4% · ZAR 3-month rate 6.05% vs USD 0.23% · total return holding ZAR -19.5% · speculators net -37% of open interest · hedge funds net -2%
- 2016: USD/ZAR close 13.70 · ZAR vs USD +12.9% · ZAR 3-month rate 7.23% vs USD 0.64% · total return holding ZAR +19.5% · speculators net -16% of open interest · hedge funds net -8%
- 2017: USD/ZAR close 12.37 · ZAR vs USD +10.7% · ZAR 3-month rate 7.33% vs USD 1.15% · total return holding ZAR +16.9% · speculators net +34% of open interest · hedge funds net +7%
- 2018: USD/ZAR close 14.38 · ZAR vs USD -13.9% · ZAR 3-month rate 7.16% vs USD 2.19% · total return holding ZAR -9.0% · speculators net +38% of open interest · hedge funds net +2%
- 2019: USD/ZAR close 13.97 · ZAR vs USD +2.9% · ZAR 3-month rate 7.08% vs USD 2.21% · total return holding ZAR +7.8% · speculators net +27% of open interest · hedge funds net -26%
- 2020: USD/ZAR close 14.65 · ZAR vs USD -4.6% · ZAR 3-month rate 4.55% vs USD 0.53% · total return holding ZAR -0.6% · speculators net +37% of open interest · hedge funds net -11%
- 2021: USD/ZAR close 15.93 · ZAR vs USD -8.0% · ZAR 3-month rate 3.78% vs USD 0.11% · total return holding ZAR -4.4% · speculators net +28% of open interest · hedge funds net -16%
- 2022: USD/ZAR close 17.00 · ZAR vs USD -6.3% · ZAR 3-month rate 5.06% vs USD 2.23% · total return holding ZAR -3.4% · speculators net +31% of open interest · hedge funds net +1%
- 2023: USD/ZAR close 18.26 · ZAR vs USD -6.9% · ZAR 3-month rate 7.94% vs USD 5.18% · total return holding ZAR -4.2% · speculators net -15% of open interest · hedge funds net -5%
- 2024: USD/ZAR close 18.88 · ZAR vs USD -3.3% · ZAR 3-month rate 8.28% vs USD 5.05% · total return holding ZAR -0.0% · speculators net +28% of open interest · hedge funds net -22%
- 2025: USD/ZAR close 16.55 · ZAR vs USD +14.1% · ZAR 3-month rate 7.17% vs USD 4.17% · total return holding ZAR +17.1% · speculators net +34% of open interest · hedge funds net +5%
- 2026: USD/ZAR close 16.71 · ZAR vs USD -0.9% · ZAR 3-month rate 6.87% vs USD 3.79% · total return holding ZAR +2.1% · speculators net +30% of open interest · hedge funds net +13%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
