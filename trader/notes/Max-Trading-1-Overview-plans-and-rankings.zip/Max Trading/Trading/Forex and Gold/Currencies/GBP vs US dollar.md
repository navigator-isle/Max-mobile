---
tags: [trading, forex]
---
**GBP — United Kingdom**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: GBP/USD close 1.50 · GBP vs USD – · GBP 3-month rate 6.19% vs USD 6.33% · total return holding GBP – · speculators net -16% of open interest
- 2001: GBP/USD close 1.45 · GBP vs USD -2.7% · GBP 3-month rate 5.04% vs USD 3.64% · total return holding GBP -1.3% · speculators net -5% of open interest
- 2002: GBP/USD close 1.61 · GBP vs USD +10.7% · GBP 3-month rate 4.06% vs USD 1.70% · total return holding GBP +13.0% · speculators net +3% of open interest
- 2003: GBP/USD close 1.78 · GBP vs USD +10.8% · GBP 3-month rate 3.74% vs USD 1.13% · total return holding GBP +13.5% · speculators net +14% of open interest
- 2004: GBP/USD close 1.92 · GBP vs USD +7.4% · GBP 3-month rate 4.64% vs USD 1.52% · total return holding GBP +10.5% · speculators net +22% of open interest
- 2005: GBP/USD close 1.72 · GBP vs USD -10.3% · GBP 3-month rate 4.76% vs USD 3.44% · total return holding GBP -9.0% · speculators net +1% of open interest
- 2006: GBP/USD close 1.96 · GBP vs USD +13.9% · GBP 3-month rate 4.85% vs USD 5.06% · total return holding GBP +13.7% · speculators net +21% of open interest · hedge funds net +40%
- 2007: GBP/USD close 1.98 · GBP vs USD +1.3% · GBP 3-month rate 6.00% vs USD 5.13% · total return holding GBP +2.2% · speculators net +37% of open interest · hedge funds net +41%
- 2008: GBP/USD close 1.46 · GBP vs USD -26.3% · GBP 3-month rate 5.51% vs USD 2.64% · total return holding GBP -23.4% · speculators net -18% of open interest · hedge funds net -3%
- 2009: GBP/USD close 1.62 · GBP vs USD +10.6% · GBP 3-month rate 1.21% vs USD 0.42% · total return holding GBP +11.4% · speculators net -26% of open interest · hedge funds net -6%
- 2010: GBP/USD close 1.54 · GBP vs USD -4.8% · GBP 3-month rate 0.70% vs USD 0.29% · total return holding GBP -4.4% · speculators net -24% of open interest · hedge funds net -10%
- 2011: GBP/USD close 1.55 · GBP vs USD +0.9% · GBP 3-month rate 0.87% vs USD 0.21% · total return holding GBP +1.6% · speculators net -4% of open interest · hedge funds net +5%
- 2012: GBP/USD close 1.63 · GBP vs USD +4.7% · GBP 3-month rate 0.83% vs USD 0.20% · total return holding GBP +5.3% · speculators net -1% of open interest · hedge funds net +14%
- 2013: GBP/USD close 1.66 · GBP vs USD +1.9% · GBP 3-month rate 0.51% vs USD 0.14% · total return holding GBP +2.3% · speculators net -14% of open interest · hedge funds net -2%
- 2014: GBP/USD close 1.56 · GBP vs USD -6.0% · GBP 3-month rate 0.54% vs USD 0.12% · total return holding GBP -5.6% · speculators net +6% of open interest · hedge funds net +33%
- 2015: GBP/USD close 1.47 · GBP vs USD -5.4% · GBP 3-month rate 0.57% vs USD 0.23% · total return holding GBP -5.0% · speculators net -12% of open interest · hedge funds net +5%
- 2016: GBP/USD close 1.23 · GBP vs USD -16.3% · GBP 3-month rate 0.50% vs USD 0.64% · total return holding GBP -16.5% · speculators net -25% of open interest · hedge funds net -20%
- 2017: GBP/USD close 1.35 · GBP vs USD +9.7% · GBP 3-month rate 0.36% vs USD 1.15% · total return holding GBP +8.9% · speculators net -17% of open interest · hedge funds net -7%
- 2018: GBP/USD close 1.28 · GBP vs USD -5.7% · GBP 3-month rate 0.72% vs USD 2.19% · total return holding GBP -7.1% · speculators net -8% of open interest · hedge funds net +8%
- 2019: GBP/USD close 1.33 · GBP vs USD +4.0% · GBP 3-month rate 0.81% vs USD 2.21% · total return holding GBP +2.6% · speculators net -19% of open interest · hedge funds net -5%
- 2020: GBP/USD close 1.37 · GBP vs USD +3.0% · GBP 3-month rate 0.29% vs USD 0.53% · total return holding GBP +2.7% · speculators net -1% of open interest · hedge funds net +2%
- 2021: GBP/USD close 1.35 · GBP vs USD -1.2% · GBP 3-month rate 0.09% vs USD 0.11% · total return holding GBP -1.2% · speculators net +4% of open interest · hedge funds net +8%
- 2022: GBP/USD close 1.21 · GBP vs USD -10.5% · GBP 3-month rate 2.00% vs USD 2.23% · total return holding GBP -10.8% · speculators net -17% of open interest · hedge funds net +6%
- 2023: GBP/USD close 1.27 · GBP vs USD +5.5% · GBP 3-month rate 4.95% vs USD 5.18% · total return holding GBP +5.3% · speculators net +3% of open interest · hedge funds net +10%
- 2024: GBP/USD close 1.25 · GBP vs USD -1.8% · GBP 3-month rate 5.00% vs USD 5.05% · total return holding GBP -1.8% · speculators net +21% of open interest · hedge funds net +17%
- 2025: GBP/USD close 1.34 · GBP vs USD +7.4% · GBP 3-month rate 4.12% vs USD 4.17% · total return holding GBP +7.3% · speculators net -1% of open interest · hedge funds net +15%
- 2026: GBP/USD close 1.34 · GBP vs USD -0.4% · GBP 3-month rate 3.67% vs USD 3.79% · total return holding GBP -0.5% · speculators net -23% of open interest · hedge funds net +11%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
