---
tags: [trading, forex]
---
**BRL — Brazil**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: USD/BRL close 1.95 · BRL vs USD –
- 2001: USD/BRL close 2.31 · BRL vs USD -15.6%
- 2002: USD/BRL close 3.54 · BRL vs USD -34.7%
- 2003: USD/BRL close 2.90 · BRL vs USD +22.3%
- 2004: USD/BRL close 2.65 · BRL vs USD +9.0%
- 2005: USD/BRL close 2.33 · BRL vs USD +13.8%
- 2006: USD/BRL close 2.13 · BRL vs USD +9.4%
- 2007: USD/BRL close 1.78 · BRL vs USD +20.0%
- 2008: USD/BRL close 2.31 · BRL vs USD -23.1%
- 2009: USD/BRL close 1.74 · BRL vs USD +32.7%
- 2010: USD/BRL close 1.66 · BRL vs USD +4.8%
- 2011: USD/BRL close 1.86 · BRL vs USD -10.7% · speculators net +17% of open interest · hedge funds net +8%
- 2012: USD/BRL close 2.05 · BRL vs USD -9.0% · speculators net +19% of open interest · hedge funds net +4%
- 2013: USD/BRL close 2.36 · BRL vs USD -13.3% · speculators net +19% of open interest · hedge funds net +7%
- 2014: USD/BRL close 2.66 · BRL vs USD -11.1% · speculators net +2% of open interest · hedge funds net +17%
- 2015: USD/BRL close 3.96 · BRL vs USD -32.9% · speculators net -2% of open interest · hedge funds net -7%
- 2016: USD/BRL close 3.25 · BRL vs USD +21.7% · speculators net +25% of open interest · hedge funds net +39%
- 2017: USD/BRL close 3.31 · BRL vs USD -1.8% · speculators net +38% of open interest · hedge funds net +38%
- 2018: USD/BRL close 3.88 · BRL vs USD -14.6% · speculators net -31% of open interest · hedge funds net +6%
- 2019: USD/BRL close 4.02 · BRL vs USD -3.4% · speculators net -37% of open interest · hedge funds net +8%
- 2020: USD/BRL close 5.19 · BRL vs USD -22.6% · speculators net -50% of open interest · hedge funds net -0%
- 2021: USD/BRL close 5.57 · BRL vs USD -6.8% · speculators net -6% of open interest · hedge funds net -8%
- 2022: USD/BRL close 5.29 · BRL vs USD +5.5% · speculators net +39% of open interest · hedge funds net -11%
- 2023: USD/BRL close 4.85 · BRL vs USD +8.9% · speculators net +49% of open interest · hedge funds net +14%
- 2024: USD/BRL close 6.18 · BRL vs USD -21.5% · speculators net -17% of open interest · hedge funds net -7%
- 2025: USD/BRL close 5.48 · BRL vs USD +12.9% · speculators net +33% of open interest · hedge funds net -0%
- 2026: USD/BRL close 5.43 · BRL vs USD +1.0% · speculators net +39% of open interest · hedge funds net +7%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
