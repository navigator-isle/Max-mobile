---
tags: [trading, forex]
---
**JPY — Japan**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: USD/JPY close 114.3 · JPY vs USD – · speculators net -24% of open interest
- 2001: USD/JPY close 131.0 · JPY vs USD -12.7% · speculators net -10% of open interest
- 2002: USD/JPY close 118.8 · JPY vs USD +10.3% · JPY 3-month rate 0.09% vs USD 1.70% · total return holding JPY +8.7% · speculators net -2% of open interest
- 2003: USD/JPY close 107.1 · JPY vs USD +10.8% · JPY 3-month rate 0.09% vs USD 1.13% · total return holding JPY +9.8% · speculators net +18% of open interest
- 2004: USD/JPY close 102.7 · JPY vs USD +4.3% · JPY 3-month rate 0.09% vs USD 1.52% · total return holding JPY +2.9% · speculators net +6% of open interest
- 2005: USD/JPY close 117.9 · JPY vs USD -12.9% · JPY 3-month rate 0.09% vs USD 3.44% · total return holding JPY -16.2% · speculators net -22% of open interest
- 2006: USD/JPY close 119.0 · JPY vs USD -1.0% · JPY 3-month rate 0.32% vs USD 5.06% · total return holding JPY -5.7% · speculators net -21% of open interest · hedge funds net -33%
- 2007: USD/JPY close 111.7 · JPY vs USD +6.5% · JPY 3-month rate 0.75% vs USD 5.13% · total return holding JPY +2.2% · speculators net -22% of open interest · hedge funds net -25%
- 2008: USD/JPY close 90.79 · JPY vs USD +23.0% · JPY 3-month rate 0.85% vs USD 2.64% · total return holding JPY +21.2% · speculators net +18% of open interest · hedge funds net +10%
- 2009: USD/JPY close 93.08 · JPY vs USD -2.5% · JPY 3-month rate 0.58% vs USD 0.42% · total return holding JPY -2.3% · speculators net +17% of open interest · hedge funds net +22%
- 2010: USD/JPY close 81.67 · JPY vs USD +14.0% · JPY 3-month rate 0.38% vs USD 0.29% · total return holding JPY +14.1% · speculators net +10% of open interest · hedge funds net +10%
- 2011: USD/JPY close 76.98 · JPY vs USD +6.1% · JPY 3-month rate 0.33% vs USD 0.21% · total return holding JPY +6.2% · speculators net +17% of open interest · hedge funds net +19%
- 2012: USD/JPY close 86.64 · JPY vs USD -11.1% · JPY 3-month rate 0.33% vs USD 0.20% · total return holding JPY -11.0% · speculators net -5% of open interest · hedge funds net -7%
- 2013: USD/JPY close 105.2 · JPY vs USD -17.7% · JPY 3-month rate 0.24% vs USD 0.14% · total return holding JPY -17.6% · speculators net -42% of open interest · hedge funds net -32%
- 2014: USD/JPY close 119.8 · JPY vs USD -12.2% · JPY 3-month rate 0.20% vs USD 0.12% · total return holding JPY -12.1% · speculators net -42% of open interest · hedge funds net -32%
- 2015: USD/JPY close 120.3 · JPY vs USD -0.3% · JPY 3-month rate 0.17% vs USD 0.23% · total return holding JPY -0.4% · speculators net -22% of open interest · hedge funds net -28%
- 2016: USD/JPY close 116.8 · JPY vs USD +3.0% · JPY 3-month rate 0.07% vs USD 0.64% · total return holding JPY +2.4% · speculators net +23% of open interest · hedge funds net +17%
- 2017: USD/JPY close 112.7 · JPY vs USD +3.6% · JPY 3-month rate 0.06% vs USD 1.15% · total return holding JPY +2.5% · speculators net -34% of open interest · hedge funds net -21%
- 2018: USD/JPY close 109.7 · JPY vs USD +2.7% · JPY 3-month rate 0.07% vs USD 2.19% · total return holding JPY +0.6% · speculators net -29% of open interest · hedge funds net -16%
- 2019: USD/JPY close 108.7 · JPY vs USD +0.9% · JPY 3-month rate 0.03% vs USD 2.21% · total return holding JPY -1.2% · speculators net -16% of open interest · hedge funds net -0%
- 2020: USD/JPY close 103.2 · JPY vs USD +5.3% · JPY 3-month rate -0.04% vs USD 0.53% · total return holding JPY +4.7% · speculators net +12% of open interest · hedge funds net -1%
- 2021: USD/JPY close 115.2 · JPY vs USD -10.4% · JPY 3-month rate -0.07% vs USD 0.11% · total return holding JPY -10.6% · speculators net -22% of open interest · hedge funds net -17%
- 2022: USD/JPY close 131.8 · JPY vs USD -12.6% · JPY 3-month rate -0.03% vs USD 2.23% · total return holding JPY -14.9% · speculators net -31% of open interest · hedge funds net -16%
- 2023: USD/JPY close 140.9 · JPY vs USD -6.5% · JPY 3-month rate 0.00% vs USD 5.18% · total return holding JPY -11.6% · speculators net -34% of open interest · hedge funds net -18%
- 2024: USD/JPY close 157.4 · JPY vs USD -10.5% · JPY 3-month rate 0.19% vs USD 5.05% · total return holding JPY -15.3% · speculators net -22% of open interest · hedge funds net -17%
- 2025: USD/JPY close 156.8 · JPY vs USD +0.4% · JPY 3-month rate 0.81% vs USD 4.17% · total return holding JPY -3.0% · speculators net +25% of open interest · hedge funds net -8%
- 2026: USD/JPY close 157.5 · JPY vs USD -0.4% · JPY 3-month rate 1.36% vs USD 3.79% · total return holding JPY -2.9% · speculators net -12% of open interest · hedge funds net -16%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
