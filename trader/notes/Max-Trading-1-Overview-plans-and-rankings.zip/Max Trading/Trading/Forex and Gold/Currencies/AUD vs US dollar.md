---
tags: [trading, forex]
---
**AUD — Australia**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: AUD/USD close 0.5560 · AUD vs USD – · AUD 3-month rate 6.18% vs USD 6.33% · total return holding AUD – · speculators net -13% of open interest
- 2001: AUD/USD close 0.5117 · AUD vs USD -8.0% · AUD 3-month rate 4.90% vs USD 3.64% · total return holding AUD -6.7% · speculators net +0% of open interest
- 2002: AUD/USD close 0.5625 · AUD vs USD +9.9% · AUD 3-month rate 4.75% vs USD 1.70% · total return holding AUD +13.0% · speculators net +22% of open interest
- 2003: AUD/USD close 0.7520 · AUD vs USD +33.7% · AUD 3-month rate 4.90% vs USD 1.13% · total return holding AUD +37.5% · speculators net +34% of open interest
- 2004: AUD/USD close 0.7805 · AUD vs USD +3.8% · AUD 3-month rate 5.48% vs USD 1.52% · total return holding AUD +7.8% · speculators net +24% of open interest
- 2005: AUD/USD close 0.7342 · AUD vs USD -5.9% · AUD 3-month rate 5.64% vs USD 3.44% · total return holding AUD -3.7% · speculators net +28% of open interest
- 2006: AUD/USD close 0.7884 · AUD vs USD +7.4% · AUD 3-month rate 5.99% vs USD 5.06% · total return holding AUD +8.3% · speculators net +35% of open interest · hedge funds net +49%
- 2007: AUD/USD close 0.8776 · AUD vs USD +11.3% · AUD 3-month rate 6.67% vs USD 5.13% · total return holding AUD +12.8% · speculators net +48% of open interest · hedge funds net +46%
- 2008: AUD/USD close 0.6983 · AUD vs USD -20.4% · AUD 3-month rate 6.97% vs USD 2.64% · total return holding AUD -16.1% · speculators net +23% of open interest · hedge funds net +20%
- 2009: AUD/USD close 0.8979 · AUD vs USD +28.6% · AUD 3-month rate 3.43% vs USD 0.42% · total return holding AUD +31.6% · speculators net +28% of open interest · hedge funds net +30%
- 2010: AUD/USD close 1.01 · AUD vs USD +12.7% · AUD 3-month rate 4.68% vs USD 0.29% · total return holding AUD +17.1% · speculators net +39% of open interest · hedge funds net +38%
- 2011: AUD/USD close 1.03 · AUD vs USD +1.3% · AUD 3-month rate 4.85% vs USD 0.21% · total return holding AUD +5.9% · speculators net +40% of open interest · hedge funds net +42%
- 2012: AUD/USD close 1.04 · AUD vs USD +1.4% · AUD 3-month rate 3.73% vs USD 0.20% · total return holding AUD +4.9% · speculators net +29% of open interest · hedge funds net +26%
- 2013: AUD/USD close 0.8929 · AUD vs USD -14.1% · AUD 3-month rate 2.78% vs USD 0.14% · total return holding AUD -11.4% · speculators net -9% of open interest · hedge funds net +0%
- 2014: AUD/USD close 0.8173 · AUD vs USD -8.5% · AUD 3-month rate 2.68% vs USD 0.12% · total return holding AUD -5.9% · speculators net -5% of open interest · hedge funds net +5%
- 2015: AUD/USD close 0.7286 · AUD vs USD -10.9% · AUD 3-month rate 2.26% vs USD 0.23% · total return holding AUD -8.8% · speculators net -25% of open interest · hedge funds net -22%
- 2016: AUD/USD close 0.7230 · AUD vs USD -0.8% · AUD 3-month rate 1.99% vs USD 0.64% · total return holding AUD +0.6% · speculators net +15% of open interest · hedge funds net +14%
- 2017: AUD/USD close 0.7815 · AUD vs USD +8.1% · AUD 3-month rate 1.74% vs USD 1.15% · total return holding AUD +8.7% · speculators net +28% of open interest · hedge funds net +30%
- 2018: AUD/USD close 0.7046 · AUD vs USD -9.8% · AUD 3-month rate 1.95% vs USD 2.19% · total return holding AUD -10.1% · speculators net -20% of open interest · hedge funds net -3%
- 2019: AUD/USD close 0.7030 · AUD vs USD -0.2% · AUD 3-month rate 1.34% vs USD 2.21% · total return holding AUD -1.1% · speculators net -31% of open interest · hedge funds net -8%
- 2020: AUD/USD close 0.7709 · AUD vs USD +9.7% · AUD 3-month rate 0.26% vs USD 0.53% · total return holding AUD +9.4% · speculators net -11% of open interest · hedge funds net +7%
- 2021: AUD/USD close 0.7260 · AUD vs USD -5.8% · AUD 3-month rate 0.03% vs USD 0.11% · total return holding AUD -5.9% · speculators net -19% of open interest · hedge funds net +5%
- 2022: AUD/USD close 0.6805 · AUD vs USD -6.3% · AUD 3-month rate 1.64% vs USD 2.23% · total return holding AUD -6.9% · speculators net -32% of open interest · hedge funds net -11%
- 2023: AUD/USD close 0.6828 · AUD vs USD +0.3% · AUD 3-month rate 3.98% vs USD 5.18% · total return holding AUD -0.9% · speculators net -30% of open interest · hedge funds net -2%
- 2024: AUD/USD close 0.6185 · AUD vs USD -9.4% · AUD 3-month rate 4.39% vs USD 5.05% · total return holding AUD -10.1% · speculators net -19% of open interest · hedge funds net -4%
- 2025: AUD/USD close 0.6669 · AUD vs USD +7.8% · AUD 3-month rate 3.82% vs USD 4.17% · total return holding AUD +7.5% · speculators net -36% of open interest · hedge funds net -8%
- 2026: AUD/USD close 0.7038 · AUD vs USD +5.5% · AUD 3-month rate 4.36% vs USD 3.79% · total return holding AUD +6.1% · speculators net +0% of open interest · hedge funds net +17%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
