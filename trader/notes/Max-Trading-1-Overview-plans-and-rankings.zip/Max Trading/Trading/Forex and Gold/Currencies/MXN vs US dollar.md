---
tags: [trading, forex]
---
**MXN — Mexico**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: USD/MXN close 9.62 · MXN vs USD – · MXN 3-month rate 17.23% vs USD 6.33% · total return holding MXN – · speculators net +20% of open interest
- 2001: USD/MXN close 9.16 · MXN vs USD +5.0% · MXN 3-month rate 13.43% vs USD 3.64% · total return holding MXN +14.8% · speculators net +27% of open interest
- 2002: USD/MXN close 10.43 · MXN vs USD -12.2% · MXN 3-month rate 8.45% vs USD 1.70% · total return holding MXN -5.4% · speculators net +0% of open interest
- 2003: USD/MXN close 11.24 · MXN vs USD -7.3% · MXN 3-month rate 7.16% vs USD 1.13% · total return holding MXN -1.2% · speculators net -20% of open interest
- 2004: USD/MXN close 11.15 · MXN vs USD +0.8% · MXN 3-month rate 7.44% vs USD 1.52% · total return holding MXN +6.7% · speculators net +15% of open interest
- 2005: USD/MXN close 10.63 · MXN vs USD +5.0% · MXN 3-month rate 9.63% vs USD 3.44% · total return holding MXN +11.1% · speculators net +60% of open interest
- 2006: USD/MXN close 10.80 · MXN vs USD -1.6% · MXN 3-month rate 7.69% vs USD 5.06% · total return holding MXN +1.0% · speculators net +21% of open interest · hedge funds net +14%
- 2007: USD/MXN close 10.92 · MXN vs USD -1.1% · MXN 3-month rate 7.78% vs USD 5.13% · total return holding MXN +1.6% · speculators net +24% of open interest · hedge funds net +20%
- 2008: USD/MXN close 13.83 · MXN vs USD -21.1% · MXN 3-month rate 8.35% vs USD 2.64% · total return holding MXN -15.4% · speculators net +48% of open interest · hedge funds net +45%
- 2009: USD/MXN close 13.06 · MXN vs USD +5.9% · MXN 3-month rate 5.93% vs USD 0.42% · total return holding MXN +11.4% · speculators net +28% of open interest · hedge funds net +25%
- 2010: USD/MXN close 12.38 · MXN vs USD +5.5% · MXN 3-month rate 5.00% vs USD 0.29% · total return holding MXN +10.2% · speculators net +56% of open interest · hedge funds net +55%
- 2011: USD/MXN close 13.95 · MXN vs USD -11.2% · MXN 3-month rate 4.86% vs USD 0.21% · total return holding MXN -6.6% · speculators net +36% of open interest · hedge funds net +27%
- 2012: USD/MXN close 12.96 · MXN vs USD +7.6% · MXN 3-month rate 4.81% vs USD 0.20% · total return holding MXN +12.2% · speculators net +32% of open interest · hedge funds net +7%
- 2013: USD/MXN close 13.10 · MXN vs USD -1.0% · MXN 3-month rate 4.29% vs USD 0.14% · total return holding MXN +3.1% · speculators net +40% of open interest · hedge funds net +6%
- 2014: USD/MXN close 14.75 · MXN vs USD -11.2% · MXN 3-month rate 3.53% vs USD 0.12% · total return holding MXN -7.8% · speculators net +11% of open interest · hedge funds net -12%
- 2015: USD/MXN close 17.20 · MXN vs USD -14.2% · MXN 3-month rate 3.34% vs USD 0.23% · total return holding MXN -11.1% · speculators net -27% of open interest · hedge funds net -17%
- 2016: USD/MXN close 20.62 · MXN vs USD -16.6% · MXN 3-month rate 4.57% vs USD 0.64% · total return holding MXN -12.7% · speculators net -38% of open interest · hedge funds net -28%
- 2017: USD/MXN close 19.64 · MXN vs USD +5.0% · MXN 3-month rate 7.12% vs USD 1.15% · total return holding MXN +10.9% · speculators net +20% of open interest · hedge funds net +15%
- 2018: USD/MXN close 19.64 · MXN vs USD +0.0% · MXN 3-month rate 8.06% vs USD 2.19% · total return holding MXN +5.9% · speculators net +22% of open interest · hedge funds net +8%
- 2019: USD/MXN close 18.86 · MXN vs USD +4.1% · MXN 3-month rate 8.27% vs USD 2.21% · total return holding MXN +10.2% · speculators net +49% of open interest · hedge funds net +15%
- 2020: USD/MXN close 19.89 · MXN vs USD -5.2% · MXN 3-month rate 5.67% vs USD 0.53% · total return holding MXN -0.0% · speculators net +18% of open interest · hedge funds net +7%
- 2021: USD/MXN close 20.51 · MXN vs USD -3.0% · MXN 3-month rate 4.66% vs USD 0.11% · total return holding MXN +1.5% · speculators net -12% of open interest · hedge funds net +21%
- 2022: USD/MXN close 19.50 · MXN vs USD +5.2% · MXN 3-month rate 8.19% vs USD 2.23% · total return holding MXN +11.2% · speculators net -0% of open interest · hedge funds net +15%
- 2023: USD/MXN close 16.90 · MXN vs USD +15.4% · MXN 3-month rate 11.46% vs USD 5.18% · total return holding MXN +21.6% · speculators net +20% of open interest · hedge funds net +12%
- 2024: USD/MXN close 20.86 · MXN vs USD -19.0% · MXN 3-month rate 11.27% vs USD 5.05% · total return holding MXN -12.8% · speculators net +29% of open interest · hedge funds net +8%
- 2025: USD/MXN close 18.01 · MXN vs USD +15.8% · MXN 3-month rate 8.75% vs USD 4.17% · total return holding MXN +20.4% · speculators net +33% of open interest · hedge funds net +7%
- 2026: USD/MXN close 18.79 · MXN vs USD -4.2% · MXN 3-month rate 6.98% vs USD 3.79% · total return holding MXN -1.0% · speculators net +31% of open interest · hedge funds net +26%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
