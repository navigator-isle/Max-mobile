---
tags: [trading, forex]
---
**NZD — New Zealand**
- Data: 2000-01-03 → 2026-10-30 daily
- "Total return holding" = price change + interest gap vs USD (the forex version of a dividend)
- Net positions: (long − short) ÷ all open contracts, yearly average, CFTC

**Year by year**
- 2000: NZD/USD close 0.4423 · NZD vs USD – · NZD 3-month rate 6.52% vs USD 6.33% · total return holding NZD – · speculators net -14% of open interest
- 2001: NZD/USD close 0.4161 · NZD vs USD -5.9% · NZD 3-month rate 5.74% vs USD 3.64% · total return holding NZD -3.8%
- 2002: NZD/USD close 0.5239 · NZD vs USD +25.9% · NZD 3-month rate 5.67% vs USD 1.70% · total return holding NZD +29.9%
- 2003: NZD/USD close 0.6557 · NZD vs USD +25.2% · NZD 3-month rate 5.42% vs USD 1.13% · total return holding NZD +29.5% · speculators net +39% of open interest
- 2004: NZD/USD close 0.7203 · NZD vs USD +9.9% · NZD 3-month rate 6.13% vs USD 1.52% · total return holding NZD +14.5% · speculators net +38% of open interest
- 2005: NZD/USD close 0.6845 · NZD vs USD -5.0% · NZD 3-month rate 7.11% vs USD 3.44% · total return holding NZD -1.3% · speculators net +51% of open interest
- 2006: NZD/USD close 0.7046 · NZD vs USD +2.9% · NZD 3-month rate 7.55% vs USD 5.06% · total return holding NZD +5.4% · speculators net +44% of open interest · hedge funds net +49%
- 2007: NZD/USD close 0.7678 · NZD vs USD +9.0% · NZD 3-month rate 8.33% vs USD 5.13% · total return holding NZD +12.2% · speculators net +59% of open interest · hedge funds net +45%
- 2008: NZD/USD close 0.5815 · NZD vs USD -24.3% · NZD 3-month rate 8.02% vs USD 2.64% · total return holding NZD -18.9% · speculators net +15% of open interest · hedge funds net +4%
- 2009: NZD/USD close 0.7255 · NZD vs USD +24.8% · NZD 3-month rate 3.04% vs USD 0.42% · total return holding NZD +27.4% · speculators net +36% of open interest · hedge funds net +24%
- 2010: NZD/USD close 0.7687 · NZD vs USD +6.0% · NZD 3-month rate 3.00% vs USD 0.29% · total return holding NZD +8.7% · speculators net +44% of open interest · hedge funds net +35%
- 2011: NZD/USD close 0.7805 · NZD vs USD +1.5% · NZD 3-month rate 2.80% vs USD 0.21% · total return holding NZD +4.1% · speculators net +39% of open interest · hedge funds net +35%
- 2012: NZD/USD close 0.8267 · NZD vs USD +5.9% · NZD 3-month rate 2.67% vs USD 0.20% · total return holding NZD +8.4% · speculators net +39% of open interest · hedge funds net +39%
- 2013: NZD/USD close 0.8229 · NZD vs USD -0.5% · NZD 3-month rate 2.66% vs USD 0.14% · total return holding NZD +2.1% · speculators net +36% of open interest · hedge funds net +27%
- 2014: NZD/USD close 0.7796 · NZD vs USD -5.3% · NZD 3-month rate 3.42% vs USD 0.12% · total return holding NZD -2.0% · speculators net +31% of open interest · hedge funds net +26%
- 2015: NZD/USD close 0.6842 · NZD vs USD -12.2% · NZD 3-month rate 3.24% vs USD 0.23% · total return holding NZD -9.2% · speculators net -7% of open interest · hedge funds net -12%
- 2016: NZD/USD close 0.6958 · NZD vs USD +1.7% · NZD 3-month rate 2.33% vs USD 0.64% · total return holding NZD +3.4% · speculators net -1% of open interest · hedge funds net +35%
- 2017: NZD/USD close 0.7100 · NZD vs USD +2.0% · NZD 3-month rate 1.96% vs USD 1.15% · total return holding NZD +2.8% · speculators net +2% of open interest · hedge funds net +14%
- 2018: NZD/USD close 0.6711 · NZD vs USD -5.5% · NZD 3-month rate 1.95% vs USD 2.19% · total return holding NZD -5.7% · speculators net -17% of open interest · hedge funds net -16%
- 2019: NZD/USD close 0.6745 · NZD vs USD +0.5% · NZD 3-month rate 1.52% vs USD 2.21% · total return holding NZD -0.2% · speculators net -26% of open interest · hedge funds net -13%
- 2020: NZD/USD close 0.7194 · NZD vs USD +6.7% · NZD 3-month rate 0.48% vs USD 0.53% · total return holding NZD +6.6% · speculators net -5% of open interest · hedge funds net -7%
- 2021: NZD/USD close 0.6839 · NZD vs USD -4.9% · NZD 3-month rate 0.49% vs USD 0.11% · total return holding NZD -4.6% · speculators net +15% of open interest · hedge funds net +15%
- 2022: NZD/USD close 0.6342 · NZD vs USD -7.3% · NZD 3-month rate 2.77% vs USD 2.23% · total return holding NZD -6.7% · speculators net -13% of open interest · hedge funds net -4%
- 2023: NZD/USD close 0.6340 · NZD vs USD -0.0% · NZD 3-month rate 5.48% vs USD 5.18% · total return holding NZD +0.3% · speculators net -7% of open interest · hedge funds net +5%
- 2024: NZD/USD close 0.5596 · NZD vs USD -11.7% · NZD 3-month rate 5.26% vs USD 5.05% · total return holding NZD -11.5% · speculators net -5% of open interest · hedge funds net +9%
- 2025: NZD/USD close 0.5755 · NZD vs USD +2.8% · NZD 3-month rate 3.21% vs USD 4.17% · total return holding NZD +1.9% · speculators net -35% of open interest · hedge funds net -9%
- 2026: NZD/USD close 0.5637 · NZD vs USD -2.1% · NZD 3-month rate 2.76% vs USD 3.79% · total return holding NZD -3.1% · speculators net -40% of open interest · hedge funds net -18%

**Sources**
- Exchange rates: Federal Reserve H.10 via FRED (daily)
- 3-month interest rates: OECD (IR3TIB)
- Positions: CFTC Commitments of Traders (legacy 1998+, Traders in Financial Futures 2006+)
