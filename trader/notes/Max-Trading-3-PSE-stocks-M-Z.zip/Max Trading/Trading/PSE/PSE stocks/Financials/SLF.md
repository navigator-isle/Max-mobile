---
tags: [trading, pse, stock, slf]
---
**SLF — Sun Life Financial Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Mar 24, 2000
- Data: 2000-03-24 → 2026-11-06 (5,394 trading days)
- Last close ₱4,900 (2026-11-06) · all-time high ₱5,080 (2026-11-03) · low ₱345.0 (2000-03-29) · now -3.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 52

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱1,280 start · H 1,280 L 345.0 · ₱25.1M/d
- 2001: ₱1,050 -18.0% · H 1,330 L 805.0 · ₱11.3M/d
- 2002: ₱900.0 -14.3% · H 1,150 L 770.0 · ₱8.0M/d
- 2003: ₱1,365 +51.7% · H 1,385 L 905.0 · ₱3.4M/d
- 2004: ₱1,830 +34.1% · H 1,850 L 1,390 · ₱2.4M/d
- 2005: ₱2,130 +16.4% · H 2,195 L 1,600 · ₱2.3M/d
- 2006: ₱2,045 -4.0% · H 2,220 L 1,895 · ₱1.9M/d
- 2007: ₱2,260 +10.5% · H 2,500 L 1,970 · ₱1.8M/d
- 2008: ₱880.0 -61.1% · H 2,250 L 850.0 · ₱603.7K/d
- 2009: ₱1,220 +38.6% · H 1,580 L 700.0 · ₱324.0K/d
- 2010: ₱1,251 +2.5% · H 1,400 L 1,050 · ₱362.0K/d
- 2011: ₱1,000 -20.1% · H 1,460 L 1,000 · ₱313.9K/d
- 2012: ₱995.0 -0.5% · H 1,040 L 880.0 · ₱380.2K/d
- 2013: ₱1,360 +36.7% · H 1,450 L 1,010 · ₱465.0K/d · div ₱59.02 (4.3%): 22Feb 14.3, 24May 14.75, 22Aug 15.3, 22Nov 14.67
- 2014: ₱1,535 +12.9% · H 1,650 L 1,305 · ₱600.2K/d · div ₱57.04 (3.7%): 25Feb 14.41, 23May 14.31, 20Aug 14.22, 21Nov 14.1
- 2015: ₱1,440 -6.2% · H 1,560 L 1,000 · ₱396.2K/d · div ₱53.17 (3.7%): 20Feb 12.55, 22May 13.49, 20Aug 13.4, 20Nov 13.73
- 2016: ₱1,631 +13.3% · H 1,794 L 1,230 · ₱286.3K/d · div ₱58.22 (3.6%): 26Feb 13.61, 27May 14.44, 25Aug 14.48, 25Nov 15.69
- 2017: ₱1,930 +18.3% · H 1,950 L 1,595 · ₱1.1M/d · div ₱67.85 (3.5%): 28Feb 16.05, 26May 15.87, 24Aug 17.93, 24Nov 18.0043
- 2018: ₱1,800 -6.7% · H 1,995 L 1,800 · ₱396.0K/d · div ₱76.71 (4.3%): 26Feb 18.16, 25May 19.26, 23Aug 19.51, 23Nov 19.78
- 2019: ₱1,825 +1.4% · H 1,894 L 1,720 · ₱338.2K/d · div ₱119.3 (6.5%): 26Feb 19.54, 24May 20.04, 24May 38.18, 22Aug 20.48, 22Nov 21.06
- 2020: ₱2,000 +9.6% · H 2,080 L 1,350 · ₱272.5K/d · div ₱81.19 (4.1%): 26Feb 20.76, 22May 20.08, 20Aug 20.27, 20Nov 20.08
- 2021: ₱2,788 +39.4% · H 2,890 L 1,951 · ₱462.0K/d · div ₱64.36 (2.3%): 23Feb 21.07, 21May 21.62, 20Aug 21.67
- 2022: ₱2,600 -6.7% · H 2,892 L 1,786 · ₱426.2K/d · div ₱115.6 (4.4%): 24Feb 26.82, 27May 28.91, 19Aug 29.7, 18Nov 30.19
- 2023: ₱2,720 +4.6% · H 2,720 L 2,300 · ₱426.5K/d · div ₱123.2 (4.5%): 24Feb 28.87, 26May 31.28, 29Aug 31.2, 28Nov 31.81
- 2024: ₱3,400 +25.0% · H 3,750 L 2,502 · ₱702.9K/d · div ₱135.3 (4.0%): 27Feb 32.1, 28May 34.53, 27Aug 33.49, 26Nov 35.19
- 2025: ₱3,440 +1.2% · H 3,600 L 3,000 · ₱1.1M/d · div ₱105.5 (3.1%): 25Feb 33.6, 27May 35.48, 26Aug 36.43
- 2026*: ₱4,900 +42.4% · H 5,080 L 3,500 · ₱813.5K/d · div ₱44.61 (0.9%): 24Nov 44.608 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
