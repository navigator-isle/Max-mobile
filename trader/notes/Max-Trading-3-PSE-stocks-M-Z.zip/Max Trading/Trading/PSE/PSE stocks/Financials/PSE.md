---
tags: [trading, pse, stock, pse]
---
**PSE — The Philippine Stock Exchange, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Dec 15, 2003
- Data: 2003-12-15 → 2026-11-06 (5,145 trading days)
- Last close ₱205.0 (2026-11-06) · all-time high ₱423.3 (2013-03-11) · low ₱21.04 (2004-07-26) · now -51.6% from high
- Cash dividends last 12 months ₱11.00 = 5.4% yield
- Dividend events on record (2013 → 2026): 25

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2003: ₱41.67 start · H 50.00 L 41.67 · ₱3.1M/d
- 2004: ₱22.71 -45.5% · H 41.67 L 21.04 · ₱917.0K/d
- 2005: ₱31.25 +37.6% · H 32.29 L 21.88 · ₱3.1M/d
- 2006: ₱58.33 +86.7% · H 61.46 L 29.17 · ₱1.8M/d
- 2007: ₱212.5 +264.3% · H 271.9 L 59.90 · ₱15.1M/d
- 2008: ₱56.25 -73.5% · H 214.6 L 45.83 · ₱2.1M/d
- 2009: ₱130.2 +131.5% · H 143.8 L 49.17 · ₱3.6M/d
- 2010: ₱152.1 +16.8% · H 179.2 L 102.1 · ₱2.7M/d
- 2011: ₱190.0 +24.9% · H 222.9 L 141.7 · ₱5.1M/d
- 2012: ₱346.7 +82.5% · H 385.8 L 195.8 · ₱12.6M/d
- 2013: ₱300.0 -13.5% · H 423.3 L 293.3 · ₱9.1M/d · div ₱9.00 (3.0%): 26Mar 4.41S, 26Mar 4.59
- 2014: ₱297.8 -0.7% · H 308.2 L 276.0 · ₱5.6M/d · div ₱9.00 (3.0%): 31Mar 3.53S, 31Mar 5.47
- 2015: ₱275.0 -7.7% · H 361.2 L 275.0 · ₱3.7M/d · div ₱9.00 (3.3%): 20Mar 3.5S, 20Mar 5.5
- 2016: ₱238.4 -13.3% · H 292.8 L 235.0 · ₱4.1M/d · div ₱7.00 (2.9%): 23Mar 2.71S, 23Mar 4.29
- 2017: ₱240.0 +0.7% · H 254.0 L 228.0 · ₱1.8M/d · div ₱7.00 (2.9%): 28Mar 2.22S, 28Mar 4.78
- 2018: ₱180.0 -25.0% · H 248.8 L 169.0 · ₱1.7M/d · div ₱9.00 (5.0%): 05Feb 3.76S, 05Feb 5.24
- 2019: ₱175.0 -2.8% · H 198.0 L 172.1 · ₱455.2K/d · div ₱4.35 (2.5%): 08Apr 4.35S
- 2020: ₱153.9 -12.1% · H 178.8 L 132.1 · ₱718.6K/d
- 2021: ₱215.0 +39.7% · H 247.0 L 141.1 · ₱2.8M/d · div ₱8.00 (3.7%): 17Mar 3.77, 17Mar 4.23S
- 2022: ₱158.0 -26.5% · H 225.0 L 153.0 · ₱647.1K/d · div ₱11.00 (7.0%): 04Mar 4, 04Mar 7S
- 2023: ₱170.0 +7.6% · H 189.0 L 158.5 · ₱511.4K/d · div ₱10.00 (5.9%): 31Mar 4.75, 31Mar 5.25S
- 2024: ₱164.0 -3.5% · H 201.0 L 159.0 · ₱1.2M/d · div ₱10.00 (6.1%): 07Mar 4.35S, 07Mar 5.65
- 2025: ₱205.4 +25.2% · H 210.0 L 165.0 · ₱1.9M/d · div ₱10.00 (4.9%): 13May 4.36, 13May 5.64S
- 2026*: ₱205.0 -0.2% · H 220.0 L 198.7 · ₱2.4M/d · div ₱11.00 (5.4%): 07May 5.5, 30Sep 5.5

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
