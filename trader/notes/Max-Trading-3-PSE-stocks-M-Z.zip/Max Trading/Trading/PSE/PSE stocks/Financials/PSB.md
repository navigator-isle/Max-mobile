---
tags: [trading, pse, stock, psb]
---
**PSB — Philippine Savings Bank**
- Status: listed on PSE · sector Financials › Banks · listed Oct 10, 1994
- Data: 1994-10-10 → 2026-11-06 (5,880 trading days)
- Last close ₱50.05 (2026-11-06) · all-time high ₱145.0 (2013-05-08) · low ₱8.82 (1998-01-23) · now -65.5% from high
- Cash dividends last 12 months ₱3.75 = 7.5% yield
- Dividend events on record (2013 → 2026): 57

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱28.84 start · H 32.02 L 22.89 · ₱28.2M/d
- 1995: ₱33.45 +16.0% · H 47.58 L 24.08 · ₱4.1M/d
- 1996: ₱45.82 +37.0% · H 50.91 L 33.45 · ₱5.5M/d
- 1997: ₱12.50 -72.7% · H 48.73 L 12.00 · ₱4.4M/d
- 1998: ₱18.18 +45.5% · H 19.09 L 8.82 · ₱1.7M/d
- 1999: ₱35.00 +92.5% · H 35.00 L 16.36 · ₱680.1K/d
- 2000: ₱30.00 -14.3% · H 35.00 L 23.00 · ₱793.7K/d
- 2001: ₱30.00 +0.0% · H 30.00 L 27.50 · ₱229.9K/d
- 2002: ₱29.00 -3.3% · H 31.00 L 21.00 · ₱213.8K/d
- 2003: ₱26.50 -8.6% · H 28.50 L 25.00 · ₱209.9K/d
- 2004: ₱28.50 +7.5% · H 30.00 L 26.00 · ₱4.2M/d
- 2005: ₱35.00 +22.8% · H 38.00 L 28.50 · ₱193.2K/d
- 2006: ₱48.00 +37.1% · H 48.00 L 35.00 · ₱2.5M/d
- 2007: ₱58.50 +21.9% · H 68.00 L 48.00 · ₱1.1M/d
- 2008: ₱41.00 -29.9% · H 60.00 L 40.00 · ₱1.1M/d
- 2009: ₱57.50 +40.2% · H 58.00 L 36.00 · ₱1.2M/d
- 2010: ₱64.00 +11.3% · H 64.00 L 49.50 · ₱197.2K/d
- 2011: ₱85.00 +32.8% · H 85.00 L 62.00 · ₱1.9M/d
- 2012: ₱100.0 +17.6% · H 102.0 L 72.00 · ₱607.7K/d
- 2013: ₱140.0 +40.0% · H 145.0 L 100.0 · ₱1.0M/d · div ₱6.00 (4.3%): 28Feb 0.75, 13Jun 0.75, 30Aug 0.75, 26Nov 0.75, 26Nov 3S
- 2014: ₱106.0 -24.3% · H 139.5 L 99.90 · ₱368.8K/d · div ₱2.25 (2.1%): 28Feb 0.75, 26Jun 0.75, 28Aug 0.75
- 2015: ₱102.9 -2.9% · H 108.1 L 85.00 · ₱263.7K/d · div ₱3.75 (3.6%): 07Jan 0.75, 25Mar 0.75, 09Jul 0.75, 21Oct 0.75, 11Nov 0.75
- 2016: ₱90.00 -12.5% · H 107.0 L 90.00 · ₱180.7K/d · div ₱3.00 (3.3%): 27Jan 0.75, 06May 0.75, 03Aug 0.75, 04Nov 0.75
- 2017: ₱87.15 -3.2% · H 92.00 L 86.00 · ₱132.9K/d · div ₱3.00 (3.4%): 07Feb 0.75, 05May 0.75, 08Aug 0.75, 09Nov 0.75
- 2018: ₱62.30 -28.5% · H 89.50 L 61.80 · ₱136.0K/d · div ₱3.00 (4.8%): 30Jan 0.75, 04May 0.75, 01Aug 0.75, 25Oct 0.75
- 2019: ₱57.50 -7.7% · H 63.50 L 57.00 · ₱359.7K/d · div ₱3.00 (5.2%): 29Jan 0.75, 29Apr 0.75, 31Jul 0.75, 24Oct 0.75
- 2020: ₱54.60 -5.0% · H 60.05 L 34.20 · ₱146.2K/d · div ₱3.00 (5.5%): 28Jan 0.75, 04May 0.75, 04Aug 0.75, 04Nov 0.75
- 2021: ₱57.50 +5.3% · H 77.00 L 53.60 · ₱157.1K/d · div ₱3.00 (5.2%): 02Feb 0.75, 06May 0.75, 03Aug 0.75, 03Nov 0.75
- 2022: ₱56.50 -1.7% · H 58.80 L 55.00 · ₱117.5K/d · div ₱3.00 (5.3%): 27Jan 0.75, 05May 0.75, 02Aug 0.75, 02Nov 0.75
- 2023: ₱53.00 -6.2% · H 57.95 L 50.75 · ₱143.8K/d · div ₱3.00 (5.7%): 07Feb 0.75, 10May 0.75, 01Aug 0.75, 07Nov 0.75
- 2024: ₱58.20 +9.8% · H 61.70 L 52.00 · ₱115.2K/d · div ₱3.00 (5.2%): 01Feb 0.75, 10May 0.75, 08Aug 0.75, 31Oct 0.75
- 2025: ₱54.00 -7.2% · H 59.90 L 52.55 · ₱162.1K/d · div ₱3.00 (5.6%): 31Jan 0.75, 09May 0.75, 07Aug 0.75, 07Nov 0.75
- 2026*: ₱50.05 -7.3% · H 58.85 L 49.00 · ₱151.5K/d · div ₱3.00 (6.0%): 29Jan 0.75, 08May 0.75, 30Jul 0.75, 06Nov 0.75

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
