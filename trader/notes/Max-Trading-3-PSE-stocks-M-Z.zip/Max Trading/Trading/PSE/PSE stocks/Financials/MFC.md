---
tags: [trading, pse, stock, mfc]
---
**MFC — Manulife Financial Corporation**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Sep 27, 1999
- Data: 1999-09-27 → 2026-11-06 (4,619 trading days)
- Last close ₱2,750 (2026-11-06) · all-time high ₱3,350 (2006-04-28) · low ₱212.5 (2000-02-23) · now -17.9% from high
- Cash dividends last 12 months ₱53.84 = 2.0% yield
- Dividend events on record (2013 → 2026): 53
- Splits / stock dividends detected (prices before these dates are as traded then): 2006-04-03 (÷0.5), 2006-05-03 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1999: ₱237.5 start · H 282.5 L 215.0 · ₱24.6M/d
- 2000: ₱765.0 +222.1% · H 765.0 L 212.5 · ₱11.2M/d
- 2001: ₱625.0 -18.3% · H 820.0 L 550.0 · ₱5.2M/d
- 2002: ₱575.0 -8.0% · H 740.0 L 465.0 · ₱2.4M/d
- 2003: ₱875.0 +52.2% · H 880.0 L 575.0 · ₱2.4M/d
- 2004: ₱1,240 +41.7% · H 1,328 L 882.5 · ₱1.4M/d
- 2005: ₱1,580 +27.4% · H 1,580 L 1,175 · ₱1.7M/d
- 2006: ₱1,650 +4.4% · H 3,350 L 1,535 · ₱1.6M/d
- 2007: ₱1,620 -1.8% · H 1,970 L 1,580 · ₱1.5M/d
- 2008: ₱750.0 -53.7% · H 1,660 L 750.0 · ₱953.1K/d
- 2009: ₱770.0 +2.7% · H 1,100 L 400.0 · ₱201.9K/d
- 2010: ₱710.0 -7.8% · H 860.0 L 550.0 · ₱427.8K/d
- 2011: ₱487.0 -31.4% · H 820.0 L 480.0 · ₱501.4K/d
- 2012: ₱505.0 +3.7% · H 580.0 L 435.0 · ₱166.8K/d
- 2013: ₱775.0 +53.5% · H 810.0 L 510.0 · ₱222.1K/d · div ₱21.36 (2.8%): 15Feb 5.2, 08May 5.27, 15Aug 5.49, 14Nov 5.4
- 2014: ₱847.0 +9.3% · H 880.0 L 711.0 · ₱323.8K/d · div ₱22.84 (2.7%): 21Feb 5.24, 08May 5.23, 14Aug 6.19, 20Nov 6.18
- 2015: ₱695.0 -17.9% · H 850.0 L 695.0 · ₱364.1K/d · div ₱23.60 (3.4%): 20Feb 5.42, 15May 6.16, 13Aug 6.01, 17Nov 6.01
- 2016: ₱780.0 +12.2% · H 825.0 L 520.0 · ₱171.5K/d · div ₱26.47 (3.4%): 19Feb 6.41, 12May 6.59, 11Aug 6.65, 17Nov 6.82
- 2017: ₱945.0 +21.2% · H 975.0 L 770.0 · ₱500.8K/d · div ₱31.99 (3.4%): 17Feb 7.85, 11May 7.61, 16Aug 8.35, 16Nov 8.18
- 2018: ₱750.0 -20.6% · H 1,020 L 750.0 · ₱197.2K/d · div ₱36.88 (4.9%): 15Feb 9, 09May 8.96, 16Aug 9.03, 15Nov 9.89
- 2019: ₱849.0 +13.2% · H 850.0 L 710.0 · ₱200.3K/d · div ₱38.98 (4.6%): 21Feb 9.86, 09May 9.71, 15Aug 9.87, 14Nov 9.54
- 2020: ₱820.0 -3.4% · H 880.0 L 600.0 · ₱132.4K/d · div ₱41.62 (5.1%): 20Feb 10.73, 14May 10.24, 12Aug 10.3, 18Nov 10.35
- 2021: ₱946.5 +15.4% · H 1,010 L 775.0 · ₱178.9K/d · div ₱33.15 (3.5%): 18Feb 10.86, 13May 11.17, 12Aug 11.12
- 2022: ₱920.0 -2.8% · H 1,110 L 851.5 · ₱168.3K/d · div ₱54.95 (6.0%): 18Feb 13.19, 20May 13.44, 18Aug 14.27, 17Nov 14.05
- 2023: ₱1,130 +22.8% · H 1,130 L 810.0 · ₱130.9K/d · div ₱59.75 (5.3%): 23Feb 14.74, 19May 14.97, 17Aug 15.29, 21Nov 14.75
- 2024: ₱1,997 +76.7% · H 2,086 L 1,001 · ₱439.6K/d · div ₱67.08 (3.4%): 27Feb 16.58, 21May 17.03, 20Aug 16.62, 19Nov 16.85
- 2025: ₱1,880 -5.9% · H 2,050 L 1,506 · ₱583.3K/d · div ₱79.60 (4.2%): 04Mar 17.89, 20May 17.76, 19Aug 18.04, 25Nov 25.9147
- 2026*: ₱2,750 +46.3% · H 2,798 L 1,900 · ₱351.6K/d · div ₱49.56 (1.8%): 24Feb 27.9287, 19Nov 21.6349 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
