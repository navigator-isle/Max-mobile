---
tags: [trading, pse, stock, pbc]
---
**PBC — Philippine Bank of Communications**
- Status: listed on PSE · sector Financials › Banks · listed May 12, 1988
- Data: 1988-09-05 → 2026-11-06 (2,333 trading days)
- Last close ₱14.80 (2026-11-06) · all-time high ₱556.2 (1997-03-14) · low ₱12.72 (2022-10-18) · now -97.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1988: ₱84.94 start · H 84.94 L 84.94 · ₱429.0K/d
- 1989: ₱91.34 +7.5% · H 91.34 L 84.94 · ₱2.7M/d
- 1992: ₱148.9 start · H 148.9 L 148.9 · ₱223.3K/d
- 1993: ₱196.2 +31.8% · H 196.2 L 166.2 · ₱37.2M/d
- 1994: ₱350.0 +78.3% · H 350.0 L 200.0 · ₱53.5K/d
- 1995: ₱428.8 +22.5% · H 466.2 L 320.0 · ₱1.4M/d
- 1996: ₱511.2 +19.2% · H 511.2 L 374.4 · ₱2.2M/d
- 1997: ₱147.0 -71.2% · H 556.2 L 147.0 · ₱4.6M/d
- 1998: ₱150.0 +2.0% · H 150.0 L 80.00 · ₱528.8K/d
- 1999: ₱160.0 +6.7% · H 192.0 L 90.00 · ₱13.1M/d
- 2000: ₱125.0 -21.9% · H 170.0 L 117.0 · ₱759.3K/d
- 2001: ₱100.0 -20.0% · H 150.0 L 100.0 · ₱36.9K/d
- 2002: ₱80.00 -20.0% · H 100.0 L 60.00 · ₱45.4K/d
- 2003: ₱85.00 +6.2% · H 100.0 L 85.00 · ₱41.0K/d
- 2004: ₱23.00 -72.9% · H 85.00 L 23.00 · ₱68.3K/d
- 2005: ₱80.00 +247.8% · H 100.0 L 66.00 · ₱1.1M/d
- 2006: ₱69.00 -13.7% · H 70.00 L 42.00 · ₱62.5K/d
- 2007: ₱55.00 -20.3% · H 62.00 L 47.00 · ₱96.4K/d
- 2008: ₱33.00 -40.0% · H 40.00 L 28.00 · ₱559.3K/d
- 2009: ₱41.00 +24.2% · H 45.00 L 25.00 · ₱888.8K/d
- 2010: ₱54.00 +31.7% · H 62.00 L 24.00 · ₱64.5K/d
- 2011: ₱84.80 +57.0% · H 120.0 L 35.00 · ₱279.9K/d
- 2012: ₱72.00 -15.1% · H 86.00 L 65.00 · ₱114.2K/d
- 2013: ₱68.00 -5.6% · H 79.80 L 67.90 · ₱92.2K/d
- 2014: ₱32.00 -52.9% · H 71.50 L 32.00 · ₱2.8M/d
- 2015: ₱22.50 -29.7% · H 33.50 L 22.45 · ₱329.2K/d
- 2016: ₱24.70 +9.8% · H 25.45 L 21.20 · ₱1.6M/d
- 2017: ₱24.00 -2.8% · H 26.50 L 22.00 · ₱333.2K/d
- 2018: ₱20.20 -15.8% · H 26.00 L 16.90 · ₱88.3K/d
- 2019: ₱20.50 +1.5% · H 23.00 L 18.42 · ₱400.6K/d
- 2020: ₱21.05 +2.7% · H 22.90 L 16.00 · ₱161.8K/d
- 2021: ₱17.80 -15.4% · H 23.40 L 17.20 · ₱433.5K/d
- 2022: ₱12.92 -27.4% · H 18.98 L 12.72 · ₱941.6K/d
- 2023: ₱14.12 +9.3% · H 19.20 L 14.00 · ₱62.0K/d
- 2024: ₱15.90 +12.6% · H 17.88 L 14.04 · ₱30.5K/d
- 2025: ₱16.70 +5.0% · H 20.40 L 15.48 · ₱149.5K/d · div ₱1.00 (6.0%): 08Jul 1S
- 2026*: ₱14.80 -11.4% · H 16.94 L 14.64 · ₱100.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
