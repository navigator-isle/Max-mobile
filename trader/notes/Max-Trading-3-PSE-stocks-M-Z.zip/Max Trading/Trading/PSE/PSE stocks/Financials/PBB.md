---
tags: [trading, pse, stock, pbb]
---
**PBB — Philippine Business Bank**
- Status: listed on PSE · sector Financials › Banks · listed Feb 19, 2013
- Data: 2013-02-19 → 2026-11-06 (2,833 trading days)
- Last close ₱6.97 (2026-11-06) · all-time high ₱20.61 (2013-02-28) · low ₱6.39 (2022-08-08) · now -66.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱11.71 start · H 20.61 L 11.52 · ₱15.7M/d
- 2014: ₱12.53 +7.1% · H 16.19 L 12.00 · ₱1.9M/d
- 2015: ₱16.98 +35.5% · H 19.80 L 14.70 · ₱3.4M/d
- 2016: ₱14.36 -15.4% · H 16.80 L 13.90 · ₱1.9M/d
- 2017: ₱11.98 -16.6% · H 16.26 L 11.58 · ₱632.2K/d
- 2018: ₱11.98 +0.0% · H 13.70 L 10.50 · ₱506.8K/d
- 2019: ₱12.70 +6.0% · H 14.36 L 11.98 · ₱597.7K/d
- 2020: ₱12.80 +0.8% · H 13.30 L 7.81 · ₱399.4K/d
- 2021: ₱10.00 -21.9% · H 12.46 L 8.50 · ₱355.6K/d
- 2022: ₱10.20 +2.0% · H 10.20 L 6.39 · ₱336.7K/d
- 2023: ₱8.70 -14.7% · H 11.40 L 7.00 · ₱643.6K/d · div ₱0.3500 (4.0%): 28Jul 0.35
- 2024: ₱9.70 +11.5% · H 9.70 L 7.90 · ₱356.9K/d · div ₱0.4500 (4.6%): 28May 0.45
- 2025: ₱7.70 -20.6% · H 10.00 L 7.02 · ₱171.9K/d · div ₱0.4500 (5.8%): 10Jul 0.45
- 2026*: ₱6.97 -9.5% · H 7.80 L 6.90 · ₱246.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
