---
tags: [trading, pse, stock, rcb]
---
**RCB — Rizal Commercial Banking Corporation**
- Status: listed on PSE · sector Financials › Banks · listed Nov 06, 1986
- Data: 2002-01-03 → 2026-11-06 (5,458 trading days)
- Last close ₱19.60 (2026-11-06) · all-time high ₱74.00 (2013-04-30) · low ₱8.26 (2002-08-02) · now -73.5% from high
- Cash dividends last 12 months ₱0.8100 = 4.1% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2002: ₱8.70 start · H 14.47 L 8.26 · ₱164.7K/d
- 2003: ₱10.65 +22.4% · H 12.61 L 8.26 · ₱308.6K/d
- 2004: ₱12.17 +14.3% · H 12.17 L 9.78 · ₱181.0K/d
- 2005: ₱11.74 -3.5% · H 15.43 L 8.91 · ₱399.4K/d
- 2006: ₱24.00 +104.4% · H 31.00 L 10.87 · ₱1.7M/d
- 2007: ₱24.00 +0.0% · H 44.00 L 20.75 · ₱60.9M/d
- 2008: ₱9.80 -59.2% · H 23.75 L 9.30 · ₱10.3M/d
- 2009: ₱17.25 +76.0% · H 19.25 L 8.80 · ₱5.5M/d
- 2010: ₱28.40 +64.6% · H 30.70 L 16.00 · ₱17.6M/d
- 2011: ₱30.10 +6.0% · H 34.50 L 25.50 · ₱23.2M/d
- 2012: ₱60.00 +99.3% · H 60.00 L 30.00 · ₱28.5M/d
- 2013: ₱42.50 -29.2% · H 74.00 L 41.00 · ₱48.5M/d · div ₱1.00 (2.4%): 16May 1
- 2014: ₱48.00 +12.9% · H 57.70 L 42.25 · ₱24.4M/d · div ₱1.00 (2.1%): 05Jun 1
- 2015: ₱33.00 -31.2% · H 48.50 L 29.25 · ₱13.7M/d
- 2016: ₱33.55 +1.7% · H 38.00 L 29.10 · ₱10.8M/d · div ₱0.7200 (2.1%): 28Jun 0.72
- 2017: ₱55.35 +65.0% · H 65.40 L 34.20 · ₱24.7M/d · div ₱0.5520 (1.0%): 09May 0.552
- 2018: ₱28.50 -48.5% · H 56.85 L 24.85 · ₱7.4M/d · div ₱0.6160 (2.2%): 17Apr 0.616
- 2019: ₱23.00 -19.3% · H 30.70 L 22.10 · ₱3.6M/d · div ₱0.4460 (1.9%): 10May 0.446
- 2020: ₱18.88 -17.9% · H 23.50 L 14.54 · ₱3.1M/d · div ₱0.5560 (2.9%): 04Jun 0.556
- 2021: ₱20.00 +5.9% · H 24.40 L 16.82 · ₱7.1M/d · div ₱0.4850 (2.4%): 05May 0.485
- 2022: ₱23.70 +18.5% · H 25.55 L 18.92 · ₱2.2M/d · div ₱0.6180 (2.6%): 06Apr 0.618
- 2023: ₱23.00 -3.0% · H 25.15 L 21.10 · ₱1.2M/d · div ₱1.08 (4.7%): 05Apr 1.08
- 2024: ₱24.85 +8.0% · H 27.20 L 21.15 · ₱1.7M/d · div ₱1.01 (4.1%): 11Apr 1.014
- 2025: ₱25.95 +4.4% · H 27.30 L 24.00 · ₱1.1M/d · div ₱0.7000 (2.7%): 15Apr 0.7
- 2026*: ₱19.60 -24.5% · H 26.20 L 19.60 · ₱538.6K/d · div ₱0.8100 (4.1%): 15Apr 0.81

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
