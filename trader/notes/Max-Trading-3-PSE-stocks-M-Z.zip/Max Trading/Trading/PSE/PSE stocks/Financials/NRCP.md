---
tags: [trading, pse, stock, nrcp]
---
**NRCP — National Reinsurance Corporation of the Philippines**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Apr 27, 2007
- Data: 2007-04-27 → 2026-11-06 (4,001 trading days)
- Last close ₱1.23 (2026-11-06) · all-time high ₱4.75 (2007-06-18) · low ₱0.3500 (2024-01-10) · now -74.1% from high
- Cash dividends last 12 months ₱0.1370 = 11.1% yield
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱3.30 start · H 4.75 L 2.80 · ₱32.4M/d
- 2008: ₱1.26 -61.8% · H 3.20 L 1.20 · ₱2.0M/d
- 2009: ₱1.58 +25.4% · H 2.10 L 1.22 · ₱921.8K/d
- 2010: ₱1.76 +11.4% · H 2.42 L 1.44 · ₱2.6M/d
- 2011: ₱1.86 +5.7% · H 1.86 L 1.30 · ₱1.0M/d
- 2012: ₱1.70 -8.6% · H 3.03 L 1.70 · ₱3.8M/d
- 2013: ₱1.36 -20.0% · H 2.00 L 1.34 · ₱497.6K/d · div ₱0.0200 (1.5%): 28May 0.02
- 2014: ₱0.9000 -33.8% · H 1.53 L 0.9000 · ₱299.9K/d
- 2015: ₱0.9400 +4.4% · H 1.21 L 0.9000 · ₱401.8K/d
- 2016: ₱0.7700 -18.1% · H 1.05 L 0.7600 · ₱806.2K/d
- 2017: ₱0.9600 +24.7% · H 1.22 L 0.7000 · ₱1.1M/d
- 2018: ₱0.9100 -5.2% · H 1.85 L 0.7600 · ₱4.4M/d
- 2019: ₱0.8300 -8.8% · H 1.31 L 0.7700 · ₱790.1K/d
- 2020: ₱0.6700 -19.3% · H 0.9100 L 0.5500 · ₱712.0K/d
- 2021: ₱0.6000 -10.4% · H 0.8900 L 0.5900 · ₱187.9K/d
- 2022: ₱0.5800 -3.3% · H 0.7200 L 0.5300 · ₱78.8K/d
- 2023: ₱0.3850 -33.6% · H 0.6600 L 0.3600 · ₱86.4K/d
- 2024: ₱0.6900 +79.2% · H 0.8900 L 0.3500 · ₱610.2K/d
- 2025: ₱0.7700 +11.6% · H 0.8100 L 0.5400 · ₱856.0K/d
- 2026*: ₱1.23 +59.7% · H 1.50 L 0.6700 · ₱1.2M/d · div ₱0.1370 (11.1%): 11Jun 0.137

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
