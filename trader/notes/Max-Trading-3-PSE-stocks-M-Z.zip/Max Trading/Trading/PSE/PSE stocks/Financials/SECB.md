---
tags: [trading, pse, stock, secb]
---
**SECB — Security Bank Corporation**
- Status: listed on PSE · sector Financials › Banks · listed Jun 08, 1995
- Data: 1995-06-08 → 2026-11-06 (7,227 trading days)
- Last close ₱63.45 (2026-11-06) · all-time high ₱266.8 (2017-10-17) · low ₱9.60 (2003-02-14) · now -76.2% from high
- Cash dividends last 12 months ₱3.00 = 4.7% yield
- Dividend events on record (2013 → 2026): 38

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱20.27 start · H 22.31 L 19.46 · ₱9.7M/d
- 1996: ₱24.87 +22.7% · H 31.80 L 19.87 · ₱8.4M/d
- 1997: ₱13.43 -46.0% · H 31.02 L 13.02 · ₱7.5M/d
- 1998: ₱11.65 -13.2% · H 18.08 L 9.74 · ₱1.2M/d
- 1999: ₱24.09 +106.7% · H 24.09 L 11.24 · ₱7.0M/d
- 2000: ₱19.44 -19.3% · H 25.18 L 15.62 · ₱2.1M/d
- 2001: ₱13.57 -30.2% · H 21.63 L 12.20 · ₱1.5M/d
- 2002: ₱9.88 -27.2% · H 15.07 L 9.88 · ₱1.2M/d
- 2003: ₱13.57 +37.4% · H 14.80 L 9.60 · ₱3.7M/d
- 2004: ₱19.99 +47.3% · H 20.81 L 12.75 · ₱2.4M/d
- 2005: ₱23.00 +15.0% · H 24.09 L 16.57 · ₱7.6M/d
- 2006: ₱39.95 +73.7% · H 41.04 L 22.72 · ₱9.2M/d
- 2007: ₱47.05 +17.8% · H 52.79 L 39.95 · ₱15.1M/d
- 2008: ₱20.83 -55.7% · H 65.42 L 20.42 · ₱6.9M/d
- 2009: ₱45.00 +116.0% · H 53.33 L 19.58 · ₱17.1M/d
- 2010: ₱71.46 +58.8% · H 80.92 L 41.25 · ₱34.9M/d
- 2011: ₱81.21 +13.6% · H 90.42 L 60.50 · ₱52.7M/d
- 2012: ₱130.0 +60.1% · H 140.8 L 80.88 · ₱103.8M/d
- 2013: ₱115.6 -11.1% · H 168.5 L 88.08 · ₱118.5M/d · div ₱1.00 (0.9%): 09May 0.5S, 26Nov 0.5S
- 2014: ₱152.0 +31.5% · H 160.5 L 105.1 · ₱111.8M/d · div ₱1.00 (0.7%): 02May 0.5S, 10Oct 0.5S
- 2015: ₱142.0 -6.6% · H 177.0 L 120.0 · ₱117.2M/d · div ₱1.00 (0.7%): 29May 0.5S, 24Nov 0.5S
- 2016: ₱190.0 +33.8% · H 255.0 L 133.0 · ₱286.3M/d · div ₱1.00 (0.5%): 06May 0.5S, 07Nov 0.5S
- 2017: ₱251.4 +32.3% · H 266.8 L 190.7 · ₱155.8M/d · div ₱3.00 (1.2%): 08May 0.5S, 08May 1, 14Nov 0.5S, 14Nov 1
- 2018: ₱155.0 -38.3% · H 258.0 L 133.2 · ₱122.8M/d · div ₱3.00 (1.9%): 10Apr 0.5S, 10Apr 1, 14Nov 0.5S, 14Nov 1
- 2019: ₱195.0 +25.8% · H 206.0 L 154.6 · ₱98.0M/d · div ₱3.00 (1.5%): 04Apr 0.5S, 04Apr 1, 08Nov 0.5S, 08Nov 1
- 2020: ₱134.0 -31.3% · H 192.0 L 77.10 · ₱107.6M/d · div ₱3.00 (2.2%): 13Apr 0.5S, 13Apr 1, 06Nov 0.5S, 06Nov 1
- 2021: ₱119.0 -11.2% · H 138.3 L 104.2 · ₱65.0M/d · div ₱3.00 (2.5%): 13Apr 0.5S, 13Apr 1, 05Nov 0.5S, 05Nov 1
- 2022: ₱87.00 -26.9% · H 118.6 L 79.90 · ₱98.8M/d · div ₱3.00 (3.4%): 07Apr 1.5, 07Nov 1.5
- 2023: ₱71.50 -17.8% · H 102.8 L 68.05 · ₱29.2M/d · div ₱3.00 (4.2%): 11Apr 1.5, 09Nov 1.5
- 2024: ₱87.00 +21.7% · H 99.15 L 60.00 · ₱45.1M/d · div ₱3.00 (3.4%): 12Apr 1.5, 12Nov 1.5
- 2025: ₱65.65 -24.5% · H 84.75 L 61.00 · ₱30.0M/d · div ₱3.00 (4.6%): 08Apr 1.5, 11Nov 1.5
- 2026*: ₱63.45 -3.4% · H 74.50 L 60.80 · ₱15.4M/d · div ₱3.00 (4.7%): 22Apr 1.5, 10Nov 1.5 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
