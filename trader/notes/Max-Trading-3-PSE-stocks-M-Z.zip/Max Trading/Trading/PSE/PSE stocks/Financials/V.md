---
tags: [trading, pse, stock, v]
---
**V — Vantage Equities, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Mar 30, 1993
- Data: 1993-03-30 → 2026-11-06 (6,258 trading days)
- Last close ₱1.26 (2026-11-06) · all-time high ₱3.32 (2015-08-06) · low ₱0.1300 (2003-03-17) · now -62.0% from high
- Cash dividends last 12 months ₱0.0800 = 6.3% yield
- Dividend events on record (2013 → 2026): 1
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-05 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱0.7826 start · H 0.7826 L 0.4348 · ₱2.0M/d
- 1994: ₱0.4348 -44.4% · H 1.00 L 0.3044 · ₱2.1M/d
- 1995: ₱0.4131 -5.0% · H 0.5218 L 0.3696 · ₱443.8K/d
- 1996: ₱1.00 +142.1% · H 1.22 L 0.3478 · ₱13.6M/d
- 1997: ₱0.2826 -71.7% · H 1.09 L 0.2609 · ₱4.0M/d
- 1998: ₱0.3913 +38.5% · H 0.4783 L 0.1826 · ₱316.9K/d
- 1999: ₱0.4696 +20.0% · H 0.7392 L 0.2305 · ₱782.2K/d
- 2000: ₱0.4450 -5.2% · H 1.35 L 0.4087 · ₱9.6M/d
- 2001: ₱0.2500 -43.8% · H 0.6000 L 0.2000 · ₱793.2K/d
- 2002: ₱0.1400 -44.0% · H 0.3150 L 0.1350 · ₱167.7K/d
- 2003: ₱0.1950 +39.3% · H 0.2400 L 0.1300 · ₱514.4K/d
- 2004: ₱0.3250 +66.7% · H 0.4000 L 0.1600 · ₱1.2M/d
- 2005: ₱0.3000 -7.7% · H 0.4100 L 0.2750 · ₱803.6K/d
- 2006: ₱0.8300 +176.7% · H 0.8300 L 0.3100 · ₱2.6M/d
- 2007: ₱0.8800 +6.0% · H 0.9600 L 0.6600 · ₱1.4M/d
- 2008: ₱0.5500 -37.5% · H 0.8900 L 0.4750 · ₱486.8K/d
- 2009: ₱0.6500 +18.2% · H 0.6700 L 0.4150 · ₱624.7K/d
- 2010: ₱0.7150 +10.0% · H 0.7600 L 0.6300 · ₱668.0K/d
- 2011: ₱0.8500 +18.9% · H 0.9750 L 0.7150 · ₱896.6K/d
- 2012: ₱1.21 +42.4% · H 1.22 L 0.8500 · ₱2.1M/d
- 2013: ₱1.24 +2.1% · H 1.46 L 1.14 · ₱247.4K/d
- 2014: ₱1.49 +20.6% · H 1.49 L 1.24 · ₱312.6K/d
- 2015: ₱3.14 +110.7% · H 3.32 L 2.85 · ₱657.9K/d
- 2016: ₱1.25 -60.2% · H 3.20 L 1.21 · ₱266.4K/d
- 2017: ₱1.24 -0.8% · H 1.50 L 1.16 · ₱337.7K/d
- 2018: ₱1.18 -4.8% · H 1.29 L 1.13 · ₱149.5K/d
- 2019: ₱1.08 -8.5% · H 1.23 L 1.04 · ₱167.7K/d
- 2020: ₱1.04 -3.7% · H 1.19 L 0.9600 · ₱450.8K/d
- 2021: ₱0.8200 -21.2% · H 1.08 L 0.8100 · ₱76.3K/d
- 2022: ₱0.8300 +1.2% · H 0.8600 L 0.7000 · ₱133.1K/d
- 2023: ₱0.7800 -6.0% · H 0.8500 L 0.7000 · ₱242.5K/d
- 2024: ₱0.7900 +1.3% · H 0.9400 L 0.6900 · ₱3.2M/d
- 2025: ₱0.8900 +12.7% · H 1.24 L 0.6800 · ₱602.3K/d · div ₱0.0800 (9.0%): 19Dec 0.08
- 2026*: ₱1.26 +41.6% · H 1.46 L 0.7700 · ₱816.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
