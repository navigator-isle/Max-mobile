---
tags: [trading, pse, stock, med]
---
**MED — MEDCO Holdings, Inc.**
- Status: listed on PSE · sector Financials › Other Financial Institutions · listed Nov 18, 1975
- Data: 2006-04-03 → 2026-11-05 (3,084 trading days)
- Last close ₱0.0940 (2026-11-05) · all-time high ₱1.25 (2016-09-06) · low ₱0.0800 (2023-09-08) · now -92.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2008-10-07 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.2600 start · H 0.2900 L 0.1900 · ₱175.1K/d
- 2007: ₱0.5400 +107.7% · H 0.7700 L 0.2500 · ₱565.7K/d
- 2008: ₱0.1500 -72.2% · H 0.5800 L 0.1150 · ₱532.3K/d
- 2009: ₱0.3700 +146.7% · H 0.8100 L 0.1250 · ₱1.1M/d
- 2010: ₱0.4700 +27.0% · H 0.5800 L 0.3400 · ₱661.1K/d
- 2013: ₱0.2050 start · H 0.6300 L 0.1800 · ₱2.0M/d
- 2014: ₱0.4200 +104.9% · H 0.8000 L 0.1780 · ₱2.8M/d
- 2015: ₱0.4900 +16.7% · H 0.7300 L 0.3500 · ₱2.0M/d
- 2016: ₱0.5700 +16.3% · H 1.25 L 0.4000 · ₱6.7M/d
- 2017: ₱0.6000 +5.3% · H 0.8300 L 0.5600 · ₱4.7M/d
- 2018: ₱0.4650 -22.5% · H 0.6500 L 0.4200 · ₱690.6K/d
- 2019: ₱0.3750 -19.4% · H 0.5600 L 0.3500 · ₱361.9K/d
- 2020: ₱0.3750 +0.0% · H 0.4750 L 0.2600 · ₱621.2K/d
- 2021: ₱0.3300 -12.0% · H 0.5000 L 0.2850 · ₱580.6K/d
- 2022: ₱0.1630 -50.6% · H 0.3400 L 0.1560 · ₱47.6K/d
- 2023: ₱0.0900 -44.8% · H 0.2100 L 0.0800 · ₱20.4K/d
- 2024: ₱0.1200 +33.3% · H 0.2240 L 0.0860 · ₱54.7K/d
- 2025: ₱0.0900 -25.0% · H 0.1400 L 0.0890 · ₱33.7K/d
- 2026*: ₱0.0940 +4.4% · H 0.1280 L 0.0850 · ₱22.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
