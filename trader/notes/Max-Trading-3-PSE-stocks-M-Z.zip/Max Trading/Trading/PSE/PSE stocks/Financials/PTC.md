---
tags: [trading, pse, stock, ptc]
---
**PTC — Philippine Trust Company**
- Status: listed on PSE · sector Financials › Banks · listed Feb 17, 1988
- Data: 2006-04-05 → 2026-10-16 (954 trading days)
- Last close ₱88.55 (2026-10-16) · all-time high ₱720.0 (2016-09-14) · low ₱38.00 (2006-04-19) · now -87.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱50.00 start · H 50.00 L 38.00 · ₱216.1K/d
- 2007: ₱58.00 +16.0% · H 58.00 L 50.00 · ₱67.7K/d
- 2008: ₱78.00 +34.5% · H 85.00 L 60.00 · ₱698.4K/d
- 2009: ₱78.00 +0.0% · H 78.00 L 52.00 · ₱9.0M/d
- 2010: ₱78.00 +0.0% · H 85.00 L 58.00 · ₱1.3M/d
- 2011: ₱58.00 -25.6% · H 80.00 L 52.00 · ₱13.0M/d
- 2012: ₱65.00 +12.1% · H 65.00 L 58.00 · ₱2.4M/d
- 2013: ₱82.00 +26.2% · H 82.00 L 68.00 · ₱6.1M/d
- 2014: ₱95.00 +15.9% · H 95.00 L 82.00 · ₱16.8M/d
- 2015: ₱122.0 +28.4% · H 175.0 L 82.50 · ₱900.6K/d
- 2016: ₱145.0 +18.9% · H 720.0 L 100.0 · ₱371.0K/d · div ₱0.2000 (0.1%): 27Jun 0.2
- 2017: ₱145.0 +0.0% · H 151.0 L 95.50 · ₱94.4K/d · div ₱0.2000 (0.1%): 06Jul 0.2
- 2018: ₱145.2 +0.1% · H 165.0 L 100.2 · ₱257.7K/d
- 2019: ₱130.0 -10.5% · H 140.0 L 108.6 · ₱40.9K/d
- 2020: ₱120.0 -7.7% · H 130.0 L 76.60 · ₱38.8K/d
- 2021: ₱118.0 -1.7% · H 120.0 L 80.00 · ₱36.8K/d
- 2022: ₱119.0 +0.8% · H 119.0 L 90.50 · ₱10.2K/d
- 2023: ₱120.0 +0.8% · H 120.0 L 95.00 · ₱26.4K/d
- 2024: ₱119.0 -0.8% · H 119.0 L 85.00 · ₱26.3K/d
- 2025: ₱120.0 +0.8% · H 120.0 L 85.45 · ₱25.5K/d
- 2026*: ₱88.55 -26.2% · H 120.0 L 88.05 · ₱5.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
