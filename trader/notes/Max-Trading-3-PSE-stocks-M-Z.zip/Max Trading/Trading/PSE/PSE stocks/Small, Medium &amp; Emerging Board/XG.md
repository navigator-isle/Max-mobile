---
tags: [trading, pse, stock, xg]
---
**XG — NexGen Energy Corp.**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Jul 16, 2024
- Data: 2024-07-16 → 2026-11-06 (483 trading days)
- Last close ₱2.65 (2026-11-06) · all-time high ₱3.84 (2025-07-23) · low ₱1.70 (2024-08-01) · now -31.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2024: ₱2.47 start · H 2.47 L 1.70 · ₱781.8K/d
- 2025: ₱3.18 +28.7% · H 3.84 L 1.77 · ₱125.9K/d
- 2026*: ₱2.65 -16.7% · H 3.18 L 2.45 · ₱34.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
