---
tags: [trading, pse, stock, mfin]
---
**MFIN — Makati Finance Corporation**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Jan 06, 2003
- Data: 2007-08-01 → 2026-11-04 (1,130 trading days)
- Last close ₱1.90 (2026-11-04) · all-time high ₱13.50 (2014-06-30) · low ₱1.12 (2010-05-14) · now -85.9% from high
- Cash dividends last 12 months ₱0.00561 = 0.3% yield
- Dividend events on record (2013 → 2026): 14
- Splits / stock dividends detected (prices before these dates are as traded then): 2008-08-11 (÷1.5), 2011-10-10 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱4.00 start · H 6.00 L 1.88 · ₱176.1K/d
- 2008: ₱2.00 -50.0% · H 5.90 L 2.00 · ₱30.1K/d
- 2009: ₱1.44 -28.0% · H 2.00 L 1.20 · ₱20.9K/d
- 2010: ₱2.50 +73.6% · H 2.50 L 1.12 · ₱2.4K/d
- 2011: ₱3.30 +32.0% · H 3.30 L 1.30 · ₱235.6K/d
- 2012: ₱2.30 -30.3% · H 4.00 L 2.30 · ₱43.2K/d
- 2013: ₱3.50 +52.2% · H 4.80 L 2.25 · ₱35.2K/d · div ₱0.0124 (0.4%): 16Aug 0.012387
- 2014: ₱2.83 -19.1% · H 13.50 L 2.83 · ₱66.8K/d · div ₱0.0173 (0.6%): 22Aug 0.017341
- 2015: ₱2.83 +0.0% · H 10.00 L 2.57 · ₱107.4K/d · div ₱0.0308 (1.1%): 24Aug 0.030754
- 2016: ₱2.84 +0.4% · H 4.73 L 2.51 · ₱148.1K/d · div ₱0.0329 (1.2%): 23Aug 0.032912
- 2017: ₱2.85 +0.4% · H 3.33 L 2.70 · ₱111.6K/d · div ₱0.0321 (1.1%): 18Aug 0.032106
- 2018: ₱2.73 -4.2% · H 3.10 L 1.56 · ₱78.2K/d · div ₱0.0365 (1.3%): 17Aug 0.036524
- 2019: ₱2.48 -9.2% · H 3.09 L 2.17 · ₱496.4K/d · div ₱0.00594 (0.2%): 16Aug 0.005943
- 2020: ₱2.70 +8.9% · H 2.73 L 1.57 · ₱498.2K/d · div ₱0.0124 (0.5%): 24Aug 0.012382
- 2021: ₱2.50 -7.4% · H 3.54 L 2.10 · ₱361.7K/d · div ₱0.0061 (0.2%): 23Aug 0.006101
- 2022: ₱2.35 -6.0% · H 3.12 L 1.80 · ₱48.2K/d · div ₱0.00544 (0.2%): 22Aug 0.005435
- 2023: ₱1.90 -19.1% · H 2.59 L 1.48 · ₱43.3K/d · div ₱0.00994 (0.5%): 18Aug 0.009945
- 2024: ₱1.99 +4.7% · H 2.38 L 1.40 · ₱74.3K/d · div ₱0.00713 (0.4%): 21Aug 0.007128
- 2025: ₱1.80 -9.5% · H 2.14 L 1.60 · ₱38.8K/d · div ₱0.00792 (0.4%): 20Aug 0.00792
- 2026*: ₱1.90 +5.6% · H 2.50 L 1.36 · ₱27.6K/d · div ₱0.00561 (0.3%): 27Aug 0.005606

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
