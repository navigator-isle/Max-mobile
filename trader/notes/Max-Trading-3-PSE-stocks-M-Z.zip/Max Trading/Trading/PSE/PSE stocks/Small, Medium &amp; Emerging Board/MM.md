---
tags: [trading, pse, stock, mm]
---
**MM — MerryMart Consumer Corp.**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Jun 15, 2020
- Data: 2020-06-15 → 2026-06-01 (1,452 trading days)
- Last close ₱0.4350 (2026-06-01) · all-time high ₱7.99 (2021-01-04) · low ₱0.3750 (2026-03-04) · now -94.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2020: ₱6.18 start · H 6.25 L 1.50 · ₱178.7M/d
- 2021: ₱2.51 -59.4% · H 7.99 L 2.30 · ₱74.9M/d
- 2022: ₱1.21 -51.8% · H 2.40 L 1.07 · ₱4.2M/d
- 2023: ₱1.03 -14.9% · H 1.62 L 1.01 · ₱1.8M/d
- 2024: ₱0.6000 -41.7% · H 1.07 L 0.5700 · ₱947.5K/d
- 2025: ₱0.4000 -33.3% · H 0.6600 L 0.3900 · ₱542.7K/d
- 2026*: ₱0.4350 +8.7% · H 0.4600 L 0.3750 · ₱768.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
