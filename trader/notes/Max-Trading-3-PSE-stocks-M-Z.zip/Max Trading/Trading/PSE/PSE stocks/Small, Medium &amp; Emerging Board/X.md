---
tags: [trading, pse, stock, x]
---
**X — Xurpas Inc.**
- Status: listed on PSE · sector Small, Medium &amp; Emerging Board › Small, Medium &amp; Emerging Board · listed Dec 02, 2014
- Data: 2014-12-02 → 2026-11-05 (2,456 trading days)
- Last close ₱0.2330 (2026-11-05) · all-time high ₱19.80 (2016-04-14) · low ₱0.1580 (2024-12-20) · now -98.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱9.35 start · H 9.74 L 5.95 · ₱205.9M/d
- 2015: ₱15.22 +62.8% · H 17.24 L 8.40 · ₱35.9M/d
- 2016: ₱7.99 -47.5% · H 19.80 L 7.11 · ₱33.8M/d
- 2017: ₱5.57 -30.3% · H 10.50 L 3.25 · ₱23.9M/d
- 2018: ₱1.72 -69.1% · H 5.13 L 1.05 · ₱9.7M/d
- 2019: ₱0.7700 -55.2% · H 2.30 L 0.7600 · ₱13.5M/d
- 2020: ₱0.5500 -28.6% · H 0.9200 L 0.4650 · ₱1.6M/d
- 2022: ₱0.2650 start · H 0.5300 L 0.2460 · ₱718.6K/d
- 2023: ₱0.1910 -27.9% · H 0.3600 L 0.1840 · ₱164.6K/d
- 2024: ₱0.1820 -4.7% · H 0.3050 L 0.1580 · ₱214.8K/d
- 2025: ₱0.2480 +36.3% · H 0.2800 L 0.1600 · ₱329.2K/d
- 2026*: ₱0.2330 -6.0% · H 0.2600 L 0.1810 · ₱250.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
