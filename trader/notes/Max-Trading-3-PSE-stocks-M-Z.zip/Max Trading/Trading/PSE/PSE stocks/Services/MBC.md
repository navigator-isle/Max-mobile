---
tags: [trading, pse, stock, mbc]
---
**MBC — Manila Broadcasting Company**
- Status: listed on PSE · sector Services › Media · listed Oct 08, 1949
- Data: 2007-05-24 → 2026-11-06 (1,427 trading days)
- Last close ₱4.70 (2026-11-06) · all-time high ₱80.00 (2015-05-14) · low ₱1.00 (2007-05-24) · now -94.1% from high
- Cash dividends last 12 months ₱0.1500 = 3.2% yield
- Dividend events on record (2013 → 2026): 11
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-05-11 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱1.00 start · H 1.00 L 1.00 · ₱527.0K/d
- 2008: ₱1.00 +0.0% · H 1.00 L 1.00 · ₱550.0K/d
- 2010: ₱1.00 start · H 1.00 L 1.00 · ₱570.0K/d
- 2011: ₱3.04 +204.0% · H 4.27 L 1.11 · ₱1.6M/d
- 2012: ₱3.30 +8.6% · H 3.30 L 2.50 · ₱7.4K/d
- 2014: ₱3.35 start · H 3.35 L 3.35 · ₱67.0K/d · div ₱0.4300 (12.8%): 07Jan 0.18, 16Dec 0.25S
- 2015: ₱29.90 +792.5% · H 80.00 L 3.10 · ₱228.0K/d · div ₱0.0625 (0.2%): 16Dec 0.0625S
- 2016: ₱17.30 -42.1% · H 33.05 L 15.50 · ₱215.3K/d · div ₱0.3000 (1.7%): 26May 0.3S
- 2017: ₱16.50 -4.6% · H 24.45 L 14.00 · ₱107.1K/d · div ₱0.1500 (0.9%): 13Jan 0.15S
- 2018: ₱16.26 -1.5% · H 20.00 L 9.11 · ₱93.3K/d · div ₱0.3000 (1.8%): 23Jan 0.3S
- 2019: ₱11.50 -29.3% · H 18.00 L 10.80 · ₱13.8K/d · div ₱0.3000 (2.6%): 23Jan 0.3S
- 2020: ₱11.60 +0.9% · H 18.70 L 10.20 · ₱101.0K/d
- 2021: ₱9.50 -18.1% · H 12.50 L 8.50 · ₱30.6K/d
- 2022: ₱5.93 -37.6% · H 10.50 L 5.92 · ₱23.0K/d · div ₱0.3000 (5.1%): 12Jan 0.3S
- 2023: ₱8.53 +43.8% · H 8.75 L 5.80 · ₱19.1K/d · div ₱0.3000 (3.5%): 24Jan 0.3
- 2024: ₱6.40 -25.0% · H 8.94 L 6.00 · ₱16.0K/d · div ₱0.1000 (1.6%): 26Dec 0.1S
- 2025: ₱5.03 -21.4% · H 7.40 L 5.01 · ₱4.2K/d
- 2026*: ₱4.70 -6.6% · H 7.10 L 4.70 · ₱9.3K/d · div ₱0.1500 (3.2%): 15Jan 0.15

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
