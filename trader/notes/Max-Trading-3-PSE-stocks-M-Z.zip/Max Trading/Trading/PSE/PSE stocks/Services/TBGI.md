---
tags: [trading, pse, stock, tbgi]
---
**TBGI — Transpacific Broadband Group Int`l. Inc.**
- Status: listed on PSE · sector Services › Information Technology · listed Dec 12, 2003
- Data: 2003-12-11 → 2026-11-06 (4,050 trading days)
- Last close ₱0.1210 (2026-11-06) · all-time high ₱4.29 (2017-12-18) · low ₱0.1000 (2006-05-25) · now -97.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-06 (÷0.1)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2003: ₱0.1380 start · H 0.1440 L 0.1380 · ₱217.8K/d
- 2004: ₱0.1400 +1.4% · H 0.1400 L 0.1300 · ₱65.4K/d
- 2005: ₱0.1400 +0.0% · H 0.1460 L 0.1100 · ₱35.1K/d
- 2006: ₱0.1880 +34.3% · H 0.5800 L 0.1000 · ₱2.9M/d
- 2007: ₱0.2360 +25.5% · H 0.4500 L 0.1840 · ₱9.7M/d
- 2008: ₱0.2800 +18.6% · H 0.3600 L 0.1740 · ₱2.6M/d
- 2009: ₱0.3200 +14.3% · H 0.3750 L 0.2650 · ₱1.1M/d
- 2010: ₱0.4450 +39.1% · H 0.4800 L 0.3100 · ₱3.4M/d
- 2011: ₱0.3100 -30.3% · H 0.4380 L 0.2480 · ₱325.7K/d
- 2012: ₱0.2600 -16.1% · H 0.3200 L 0.2020 · ₱86.0K/d
- 2013: ₱0.2100 -19.2% · H 0.2590 L 0.1900 · ₱163.0K/d
- 2014: ₱0.2150 +2.4% · H 0.2800 L 0.1880 · ₱86.9K/d
- 2015: ₱1.51 +602.3% · H 2.12 L 1.40 · ₱47.9K/d
- 2016: ₱1.89 +25.2% · H 2.09 L 1.51 · ₱148.2K/d
- 2017: ₱2.70 +42.9% · H 4.29 L 1.74 · ₱7.6M/d
- 2018: ₱0.4400 -83.7% · H 4.05 L 0.3300 · ₱38.1M/d
- 2019: ₱0.2700 -38.6% · H 0.4850 L 0.2650 · ₱4.4M/d
- 2020: ₱0.3350 +24.1% · H 0.3800 L 0.1400 · ₱3.1M/d
- 2021: ₱0.3000 -10.4% · H 0.6400 L 0.2950 · ₱16.6M/d
- 2022: ₱0.2200 -26.7% · H 0.4250 L 0.2110 · ₱1.6M/d
- 2023: ₱0.1360 -38.2% · H 0.2700 L 0.1310 · ₱286.0K/d
- 2024: ₱0.1350 -0.7% · H 0.1540 L 0.1220 · ₱213.5K/d
- 2025: ₱0.1330 -1.5% · H 0.2480 L 0.1270 · ₱495.0K/d
- 2026*: ₱0.1210 -9.0% · H 0.1400 L 0.1100 · ₱93.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
