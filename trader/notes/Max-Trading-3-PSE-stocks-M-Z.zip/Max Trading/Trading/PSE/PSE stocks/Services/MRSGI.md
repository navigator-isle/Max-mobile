---
tags: [trading, pse, stock, mrsgi]
---
**MRSGI — Metro Retail Stores Group, Inc.**
- Status: listed on PSE · sector Services › Retail · listed Nov 24, 2015
- Data: 2015-11-24 → 2026-11-06 (2,644 trading days)
- Last close ₱1.05 (2026-11-06) · all-time high ₱5.93 (2016-08-05) · low ₱1.03 (2026-08-17) · now -82.3% from high
- Cash dividends last 12 months ₱0.0600 = 5.7% yield
- Dividend events on record (2013 → 2026): 10

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱3.98 start · H 4.01 L 3.69 · ₱80.0M/d
- 2016: ₱4.05 +1.8% · H 5.93 L 2.95 · ₱29.1M/d · div ₱0.0450 (1.1%): 30Mar 0.045
- 2017: ₱3.90 -3.7% · H 5.16 L 3.59 · ₱17.0M/d · div ₱0.0500 (1.3%): 29Mar 0.05
- 2018: ₱2.49 -36.2% · H 3.86 L 1.92 · ₱3.6M/d · div ₱0.0600 (2.4%): 10Apr 0.06
- 2019: ₱2.11 -15.3% · H 3.52 L 2.08 · ₱7.4M/d · div ₱0.0600 (2.8%): 10Apr 0.06
- 2020: ₱1.50 -28.9% · H 2.16 L 1.16 · ₱3.9M/d · div ₱0.0600 (4.0%): 26May 0.06
- 2021: ₱1.44 -4.0% · H 1.55 L 1.22 · ₱1.8M/d
- 2022: ₱1.41 -2.1% · H 1.48 L 1.09 · ₱559.9K/d
- 2023: ₱1.27 -9.9% · H 1.50 L 1.15 · ₱389.9K/d · div ₱0.0600 (4.7%): 14Apr 0.06
- 2024: ₱1.20 -5.5% · H 1.48 L 1.15 · ₱284.2K/d · div ₱0.1600 (13.3%): 19Apr 0.06, 19Apr 0.1S
- 2025: ₱1.15 -4.2% · H 1.34 L 1.11 · ₱212.5K/d · div ₱0.0600 (5.2%): 23Apr 0.06
- 2026*: ₱1.05 -8.7% · H 1.23 L 1.03 · ₱150.8K/d · div ₱0.0600 (5.7%): 07Apr 0.06

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
