---
tags: [trading, pse, stock, mjc]
---
**MJC — Manila Jockey Club, Inc.**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Oct 11, 1963
- Data: 1994-10-03 → 2023-05-15 (3,376 trading days)
- Last close ₱1.27 (2023-05-15) · all-time high ₱33.36 (1995-08-04) · low ₱0.9700 (2022-10-13) · now -96.2% from high
- Cash dividends last 12 months ₱0.0500 = 3.9% yield
- Dividend events on record (2013 → 2026): 9

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱20.31 start · H 22.13 L 12.13 · ₱252.6K/d
- 1995: ₱18.80 -7.5% · H 33.36 L 16.37 · ₱846.2K/d
- 1997: ₱9.40 start · H 27.90 L 9.40 · ₱242.2K/d
- 1998: ₱6.37 -32.3% · H 12.43 L 6.37 · ₱182.7K/d
- 1999: ₱6.37 +0.0% · H 9.40 L 5.75 · ₱140.7K/d
- 2000: ₱6.37 +0.0% · H 8.78 L 4.23 · ₱1.7M/d
- 2001: ₱6.37 +0.0% · H 13.03 L 5.15 · ₱889.0K/d
- 2002: ₱4.55 -28.5% · H 8.18 L 3.93 · ₱620.3K/d
- 2003: ₱7.27 +59.7% · H 7.88 L 4.23 · ₱209.9K/d
- 2004: ₱1.94 -73.3% · H 7.27 L 1.94 · ₱594.7K/d
- 2005: ₱2.03 +4.7% · H 3.27 L 1.91 · ₱389.4K/d
- 2006: ₱2.00 -1.5% · H 2.36 L 1.94 · ₱354.0K/d
- 2007: ₱3.03 +51.9% · H 4.29 L 1.94 · ₱318.2K/d
- 2008: ₱2.12 -30.2% · H 3.21 L 1.76 · ₱320.0K/d
- 2009: ₱2.12 +0.0% · H 2.42 L 2.00 · ₱980.6K/d
- 2010: ₱2.12 +0.0% · H 2.57 L 1.85 · ₱583.4K/d
- 2011: ₱1.31 -38.1% · H 2.78 L 1.14 · ₱635.9K/d
- 2012: ₱2.49 +90.2% · H 3.47 L 1.22 · ₱5.0M/d
- 2013: ₱2.04 -18.1% · H 2.76 L 1.79 · ₱658.4K/d · div ₱0.0500 (2.4%): 13Jun 0.05
- 2014: ₱2.04 +0.0% · H 2.21 L 1.62 · ₱386.7K/d · div ₱0.0500 (2.4%): 15May 0.05
- 2015: ₱2.00 -2.1% · H 2.18 L 1.85 · ₱150.9K/d · div ₱0.0500 (2.5%): 17Mar 0.05
- 2016: ₱2.00 +0.0% · H 2.15 L 1.81 · ₱141.8K/d · div ₱0.0500 (2.5%): 07Jun 0.05
- 2017: ₱5.00 +150.0% · H 6.49 L 2.00 · ₱4.4M/d · div ₱0.0500 (1.0%): 13Jul 0.05
- 2018: ₱5.45 +9.0% · H 6.30 L 3.91 · ₱2.8M/d · div ₱0.0500 (0.9%): 02May 0.05
- 2019: ₱3.35 -38.5% · H 5.38 L 3.00 · ₱722.2K/d
- 2020: ₱2.31 -31.0% · H 3.33 L 1.60 · ₱309.8K/d
- 2021: ₱2.40 +3.9% · H 2.91 L 1.72 · ₱236.7K/d
- 2022: ₱1.35 -43.7% · H 2.38 L 0.9700 · ₱1.7M/d · div ₱0.0500 (3.7%): 27Dec 0.05
- 2023*: ₱1.27 -5.9% · H 1.60 L 1.23 · ₱41.8K/d · div ₱0.0500 (3.9%): 30Nov 0.05 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
