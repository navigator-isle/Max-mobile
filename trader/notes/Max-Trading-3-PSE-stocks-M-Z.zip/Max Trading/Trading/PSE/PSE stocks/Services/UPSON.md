---
tags: [trading, pse, stock, upson]
---
**UPSON — Upson International Corp.**
- Status: listed on PSE · sector Services › Retail · listed Apr 03, 2023
- Data: 2023-04-03 → 2026-11-06 (862 trading days)
- Last close ₱0.7900 (2026-11-06) · all-time high ₱2.90 (2023-04-03) · low ₱0.6200 (2025-05-06) · now -72.8% from high
- Cash dividends last 12 months ₱0.0600 = 7.6% yield
- Dividend events on record (2013 → 2026): 4

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2023: ₱1.64 start · H 2.90 L 1.59 · ₱1.0M/d · div ₱0.0442 (2.7%): 21Jul 0.04416
- 2024: ₱0.6800 -58.5% · H 1.69 L 0.6700 · ₱129.5K/d · div ₱0.0600 (8.8%): 12Mar 0.06
- 2025: ₱0.7000 +2.9% · H 0.8600 L 0.6200 · ₱1.1M/d · div ₱0.0600 (8.6%): 09Jun 0.06
- 2026*: ₱0.7900 +12.9% · H 0.9300 L 0.6800 · ₱285.7K/d · div ₱0.0600 (7.6%): 08Jun 0.06

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
