---
tags: [trading, pse, stock, phr]
---
**PHR — PH Resorts Group Holdings, Inc.**
- Status: listed on PSE · sector Services › Hotel &amp; Leisure · listed Nov 24, 2011
- Data: 2011-11-24 → 2026-11-06 (3,006 trading days)
- Last close ₱0.4750 (2026-11-06) · all-time high ₱9.24 (2017-08-03) · low ₱0.1260 (2025-03-31) · now -94.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱1.65 start · H 1.90 L 1.49 · ₱1.0M/d
- 2012: ₱2.93 +77.7% · H 3.20 L 1.41 · ₱222.0K/d
- 2013: ₱4.35 +48.5% · H 6.20 L 2.67 · ₱508.8K/d
- 2014: ₱3.23 -25.6% · H 4.85 L 2.67 · ₱244.1K/d
- 2015: ₱3.70 +14.4% · H 5.75 L 2.59 · ₱114.0K/d
- 2016: ₱4.00 +8.1% · H 4.00 L 2.25 · ₱79.3K/d
- 2017: ₱6.14 +53.5% · H 9.24 L 3.50 · ₱2.5M/d
- 2018: ₱5.45 -11.2% · H 7.35 L 4.18 · ₱3.9M/d
- 2019: ₱5.20 -4.6% · H 6.98 L 3.90 · ₱1.4M/d
- 2020: ₱2.81 -46.0% · H 5.14 L 2.06 · ₱17.3M/d
- 2021: ₱0.7800 -72.2% · H 3.51 L 0.7400 · ₱13.5M/d
- 2022: ₱0.8200 +5.1% · H 1.42 L 0.7000 · ₱3.4M/d
- 2023: ₱0.8700 +6.1% · H 1.10 L 0.4800 · ₱2.6M/d
- 2024: ₱0.5400 -37.9% · H 1.01 L 0.4600 · ₱1.8M/d
- 2025: ₱0.1330 -75.4% · H 0.5800 L 0.1260 · ₱1.1M/d
- 2026*: ₱0.4750 +257.1% · H 0.4900 L 0.1300 · ₱2.8M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
