---
tags: [trading, pse, stock, wpi]
---
**WPI — Waterfront Philippines, Incorporated**
- Status: listed on PSE · sector Services › Hotel &amp; Leisure · listed Mar 17, 1995
- Data: 1995-03-17 → 2026-11-06 (6,292 trading days)
- Last close ₱0.5000 (2026-11-06) · all-time high ₱6.91 (1996-07-03) · low ₱0.1600 (2004-06-21) · now -92.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱2.95 start · H 3.27 L 1.46 · ₱9.0M/d
- 1996: ₱4.55 +53.8% · H 6.91 L 3.00 · ₱15.5M/d
- 1997: ₱1.02 -77.6% · H 4.64 L 1.02 · ₱2.7M/d
- 1998: ₱1.49 +46.4% · H 2.45 L 0.7091 · ₱2.2M/d
- 1999: ₱1.40 -6.1% · H 4.27 L 1.13 · ₱55.3M/d
- 2000: ₱0.3500 -75.0% · H 1.70 L 0.2400 · ₱4.2M/d
- 2001: ₱0.2900 -17.1% · H 0.4100 L 0.1900 · ₱532.5K/d
- 2002: ₱0.2500 -13.8% · H 0.3600 L 0.1800 · ₱351.9K/d
- 2003: ₱0.3700 +48.0% · H 0.4000 L 0.2200 · ₱174.3K/d
- 2004: ₱0.1900 -48.6% · H 0.3900 L 0.1600 · ₱483.2K/d
- 2005: ₱0.3000 +57.9% · H 0.4100 L 0.1800 · ₱294.5K/d
- 2006: ₱0.6000 +100.0% · H 0.6600 L 0.2700 · ₱1.4M/d
- 2007: ₱0.8000 +33.3% · H 1.14 L 0.5900 · ₱2.8M/d
- 2008: ₱0.2350 -70.6% · H 0.9500 L 0.2100 · ₱3.0M/d
- 2009: ₱0.2900 +23.4% · H 0.3600 L 0.1850 · ₱407.5K/d
- 2010: ₱0.3000 +3.4% · H 0.3200 L 0.2450 · ₱76.0K/d
- 2011: ₱0.5000 +66.7% · H 0.7700 L 0.2650 · ₱1.9M/d
- 2012: ₱0.4100 -18.0% · H 0.6600 L 0.3750 · ₱1.4M/d
- 2013: ₱0.3550 -13.4% · H 0.4650 L 0.3400 · ₱173.4K/d
- 2014: ₱0.3800 +7.0% · H 0.4550 L 0.3100 · ₱598.3K/d
- 2015: ₱0.3400 -10.5% · H 0.4000 L 0.1650 · ₱224.5K/d
- 2016: ₱0.3450 +1.5% · H 0.3900 L 0.3100 · ₱109.4K/d
- 2017: ₱0.9800 +184.1% · H 1.45 L 0.3450 · ₱19.8M/d
- 2018: ₱0.7000 -28.6% · H 1.35 L 0.4600 · ₱7.4M/d
- 2019: ₱0.6000 -14.3% · H 0.8700 L 0.5700 · ₱2.4M/d
- 2020: ₱0.5800 -3.3% · H 0.7200 L 0.3600 · ₱3.0M/d
- 2021: ₱0.4600 -20.7% · H 0.7000 L 0.4600 · ₱3.6M/d
- 2022: ₱0.4600 +0.0% · H 0.5400 L 0.4100 · ₱256.2K/d
- 2023: ₱0.3750 -18.5% · H 0.4850 L 0.3600 · ₱141.5K/d
- 2024: ₱0.3750 +0.0% · H 0.4200 L 0.3550 · ₱179.8K/d
- 2025: ₱0.4100 +9.3% · H 0.4500 L 0.3650 · ₱77.7K/d
- 2026*: ₱0.5000 +22.0% · H 0.5200 L 0.3650 · ₱133.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
