---
tags: [trading, pse, stock, plus]
---
**PLUS — DigiPlus Interactive Corp.**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Apr 17, 1958
- Data: 2015-01-05 → 2026-11-06 (2,882 trading days)
- Last close ₱6.40 (2026-11-06) · all-time high ₱65.00 (2025-06-11) · low ₱1.15 (2020-03-19) · now -90.2% from high
- Cash dividends last 12 months ₱0.8300 = 13.0% yield
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱7.63 start · H 11.88 L 7.10 · ₱7.6M/d
- 2016: ₱3.96 -48.1% · H 8.18 L 3.45 · ₱8.1M/d
- 2017: ₱3.98 +0.5% · H 5.23 L 3.58 · ₱7.4M/d
- 2018: ₱3.26 -18.1% · H 7.15 L 2.49 · ₱18.9M/d
- 2019: ₱2.40 -26.4% · H 4.77 L 2.40 · ₱4.0M/d
- 2020: ₱1.92 -20.0% · H 2.75 L 1.15 · ₱1.0M/d
- 2021: ₱1.49 -22.4% · H 2.10 L 1.40 · ₱2.7M/d
- 2022: ₱2.41 +61.7% · H 3.07 L 1.23 · ₱5.7M/d
- 2023: ₱8.00 +232.0% · H 8.00 L 2.41 · ₱15.1M/d
- 2024: ₱27.15 +239.4% · H 27.15 L 7.48 · ₱111.6M/d · div ₱0.1800 (0.7%): 03Apr 0.18
- 2025: ₱16.20 -40.3% · H 65.00 L 15.20 · ₱365.9M/d · div ₱0.8600 (5.3%): 21Mar 0.86
- 2026*: ₱6.40 -60.5% · H 19.96 L 6.10 · ₱116.2M/d · div ₱0.8300 (13.0%): 31Mar 0.83

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
