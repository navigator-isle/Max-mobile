---
tags: [trading, pse, stock, sbs]
---
**SBS — SBS Philippines Corporation**
- Status: listed on PSE · sector Services › Other Services · listed Aug 10, 2015
- Data: 2015-08-10 → 2026-10-30 (1,959 trading days)
- Last close ₱2.96 (2026-10-30) · all-time high ₱9.67 (2019-05-27) · low ₱2.96 (2026-10-30) · now -69.4% from high
- Cash dividends last 12 months ₱0.0035 = 0.1% yield
- Dividend events on record (2013 → 2026): 9

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱6.18 start · H 7.23 L 4.12 · ₱51.4M/d
- 2016: ₱5.75 -7.0% · H 7.22 L 4.50 · ₱8.0M/d · div ₱0.0370 (0.6%): 27May 0.037
- 2017: ₱5.60 -2.6% · H 6.86 L 5.45 · ₱4.6M/d
- 2018: ₱7.50 +33.9% · H 9.60 L 5.44 · ₱4.5M/d · div ₱0.0170 (0.2%): 29May 0.017
- 2019: ₱9.26 +23.5% · H 9.67 L 7.47 · ₱2.0M/d · div ₱0.0220 (0.2%): 07May 0.022
- 2020: ₱5.60 -39.5% · H 9.44 L 3.94 · ₱606.7K/d
- 2021: ₱4.10 -26.8% · H 5.60 L 3.76 · ₱361.1K/d · div ₱0.0220 (0.5%): 19Jul 0.022
- 2022: ₱3.90 -4.9% · H 4.28 L 3.51 · ₱121.9K/d · div ₱0.0250 (0.6%): 14Jul 0.025
- 2023: ₱4.85 +24.4% · H 4.85 L 3.82 · ₱1.0M/d
- 2024: ₱4.95 +2.1% · H 4.95 L 3.21 · ₱176.3K/d · div ₱0.0055 (0.1%): 06Jun 0.0055
- 2025: ₱3.89 -21.4% · H 5.50 L 3.50 · ₱481.3K/d · div ₱0.0650 (1.7%): 11Mar 0.005, 11Mar 0.06S
- 2026*: ₱2.96 -23.9% · H 3.70 L 2.96 · ₱62.0K/d · div ₱0.0035 (0.1%): 09Jul 0.0035

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
