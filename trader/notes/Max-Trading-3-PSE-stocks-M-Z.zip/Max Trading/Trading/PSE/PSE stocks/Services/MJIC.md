---
tags: [trading, pse, stock, mjic]
---
**MJIC — MJC Investments Corporation**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Nov 11, 1955
- Data: 2009-10-29 → 2023-05-08 (922 trading days)
- Last close ₱1.00 (2023-05-08) · all-time high ₱9.66 (2012-08-03) · low ₱0.6700 (2022-08-09) · now -89.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2010-01-29 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2009: ₱1.80 start · H 4.10 L 1.80 · ₱22.2K/d
- 2010: ₱1.44 -20.0% · H 2.65 L 1.22 · ₱19.2K/d
- 2011: ₱1.52 +5.6% · H 1.99 L 1.23 · ₱21.0K/d
- 2012: ₱5.74 +277.6% · H 9.66 L 1.33 · ₱410.9K/d
- 2013: ₱3.25 -43.4% · H 7.15 L 2.90 · ₱1.3M/d
- 2014: ₱3.35 +3.1% · H 4.00 L 3.08 · ₱42.8K/d
- 2015: ₱3.50 +4.5% · H 4.25 L 2.10 · ₱31.5K/d
- 2016: ₱3.49 -0.3% · H 4.35 L 2.30 · ₱39.5K/d
- 2017: ₱3.40 -2.6% · H 3.96 L 3.00 · ₱168.9K/d
- 2018: ₱2.56 -24.7% · H 3.73 L 2.56 · ₱42.2K/d
- 2019: ₱2.60 +1.6% · H 3.39 L 2.57 · ₱42.7K/d
- 2020: ₱1.90 -26.9% · H 2.56 L 1.48 · ₱22.8K/d
- 2021: ₱1.17 -38.4% · H 2.22 L 1.15 · ₱40.5K/d
- 2022: ₱1.30 +11.1% · H 1.43 L 0.6700 · ₱9.5K/d
- 2023*: ₱1.00 -23.1% · H 1.27 L 1.00 · ₱13.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
