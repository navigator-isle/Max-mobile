---
tags: [trading, pse, stock, web]
---
**WEB — PhilWeb Corporation**
- Status: listed on PSE · sector Services › Casinos &amp; Gaming · listed Dec 08, 1969
- Data: 1994-10-03 → 2026-11-06 (6,779 trading days)
- Last close ₱13.30 (2026-11-06) · all-time high ₱40.83 (2000-03-10) · low ₱0.0220 (2008-11-21) · now -67.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 12
- Splits / stock dividends detected (prices before these dates are as traded then): 2016-08-04 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱2.17 start · H 2.17 L 1.67 · ₱17.9K/d
- 1995: ₱2.92 +34.6% · H 2.92 L 1.50 · ₱25.0K/d
- 1997: ₱0.6667 start · H 4.79 L 0.5833 · ₱530.4K/d
- 1998: ₱0.5833 -12.5% · H 1.25 L 0.5833 · ₱128.6K/d
- 1999: ₱6.04 +935.8% · H 11.67 L 0.3500 · ₱5.4M/d
- 2000: ₱3.50 -42.1% · H 40.83 L 3.50 · ₱66.1M/d
- 2001: ₱1.50 -57.1% · H 7.71 L 1.17 · ₱6.7M/d
- 2002: ₱0.9167 -38.9% · H 2.08 L 0.8333 · ₱884.4K/d
- 2003: ₱0.9167 +0.0% · H 1.25 L 0.8333 · ₱497.2K/d
- 2004: ₱0.9167 +0.0% · H 1.17 L 0.8333 · ₱1.1M/d
- 2005: ₱1.25 +36.4% · H 2.17 L 0.8333 · ₱1.7M/d
- 2006: ₱0.0310 -97.5% · H 3.17 L 0.0240 · ₱9.9M/d
- 2007: ₱0.0450 +45.2% · H 0.0725 L 0.0320 · ₱11.8M/d
- 2008: ₱0.0280 -37.8% · H 0.0450 L 0.0220 · ₱4.0M/d
- 2009: ₱18.50 +65971.4% · H 18.75 L 0.0280 · ₱42.2M/d
- 2010: ₱16.16 -12.6% · H 18.25 L 12.00 · ₱18.5M/d
- 2011: ₱15.36 -5.0% · H 16.76 L 14.80 · ₱12.6M/d
- 2012: ₱12.56 -18.2% · H 17.62 L 12.24 · ₱17.8M/d
- 2013: ₱8.98 -28.5% · H 15.80 L 8.40 · ₱18.9M/d · div ₱0.2000 (2.2%): 28Feb 0.1, 10Oct 0.1
- 2014: ₱9.75 +8.6% · H 9.75 L 4.40 · ₱4.6M/d · div ₱0.4000 (4.1%): 13Mar 0.1, 04Jun 0.1, 27Aug 0.1, 18Nov 0.1
- 2015: ₱23.10 +136.9% · H 23.10 L 10.82 · ₱9.4M/d · div ₱0.6000 (2.6%): 27Jan 0.15, 04May 0.15, 11Aug 0.15, 09Nov 0.15
- 2016: ₱10.60 -54.1% · H 28.00 L 4.25 · ₱20.0M/d · div ₱0.4000 (3.8%): 16Feb 0.2, 09Jun 0.2
- 2017: ₱7.64 -27.9% · H 11.58 L 7.06 · ₱15.3M/d
- 2018: ₱3.22 -57.9% · H 7.76 L 2.92 · ₱6.3M/d
- 2019: ₱2.61 -18.9% · H 4.38 L 2.35 · ₱7.0M/d
- 2020: ₱2.89 +10.7% · H 4.12 L 1.12 · ₱9.1M/d
- 2021: ₱1.96 -32.2% · H 3.08 L 1.85 · ₱1.6M/d
- 2022: ₱2.60 +32.7% · H 6.09 L 1.80 · ₱11.6M/d
- 2023: ₱1.73 -33.5% · H 2.79 L 1.68 · ₱1.4M/d
- 2024: ₱1.40 -19.1% · H 2.13 L 1.30 · ₱946.0K/d
- 2025: ₱6.20 +342.9% · H 6.86 L 1.11 · ₱18.1M/d
- 2026*: ₱13.30 +114.5% · H 15.80 L 6.26 · ₱37.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
