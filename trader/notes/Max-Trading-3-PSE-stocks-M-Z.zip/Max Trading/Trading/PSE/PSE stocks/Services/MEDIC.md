---
tags: [trading, pse, stock, medic]
---
**MEDIC — Medilines Distributors Incorporated**
- Status: listed on PSE · sector Services › Other Services · listed Dec 07, 2021
- Data: 2021-12-07 → 2026-11-06 (1,146 trading days)
- Last close ₱0.2400 (2026-11-06) · all-time high ₱1.70 (2021-12-09) · low ₱0.1950 (2026-04-16) · now -85.9% from high
- Cash dividends last 12 months ₱0.00215 = 0.9% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱1.29 start · H 1.70 L 1.20 · ₱91.1M/d
- 2022: ₱0.7000 -45.7% · H 1.24 L 0.5700 · ₱2.5M/d · div ₱0.00925 (1.3%): 02Jun 0.006168, 26Aug 0.003084S
- 2023: ₱0.3300 -52.9% · H 0.7900 L 0.3100 · ₱283.4K/d · div ₱0.0105 (3.2%): 13Jul 0.010484
- 2024: ₱0.3100 -6.1% · H 0.3700 L 0.2800 · ₱189.0K/d · div ₱0.00264 (0.9%): 02Jul 0.002637
- 2025: ₱0.2600 -16.1% · H 0.3200 L 0.2450 · ₱187.6K/d · div ₱0.00945 (3.6%): 01Jul 0.009448
- 2026*: ₱0.2400 -7.7% · H 0.2600 L 0.1950 · ₱52.1K/d · div ₱0.00215 (0.9%): 27Aug 0.002152

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
