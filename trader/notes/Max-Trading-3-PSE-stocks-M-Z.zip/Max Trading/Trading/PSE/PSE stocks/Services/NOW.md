---
tags: [trading, pse, stock, now]
---
**NOW — Now Corporation**
- Status: listed on PSE · sector Services › Information Technology · listed Jul 23, 2003
- Data: 2003-07-22 → 2026-11-06 (3,964 trading days)
- Last close ₱0.3800 (2026-11-06) · all-time high ₱15.70 (2018-02-23) · low ₱0.3500 (2026-10-21) · now -97.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2005-07-01 (÷0.5), 2008-12-23 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2003: ₱1.02 start · H 1.02 L 1.00 · ₱20.6K/d
- 2004: ₱1.02 +0.0% · H 1.02 L 1.02 · ₱2.0K/d
- 2005: ₱4.20 +311.8% · H 5.00 L 1.02 · ₱27.4M/d
- 2006: ₱4.00 -4.8% · H 6.50 L 3.50 · ₱464.3K/d
- 2007: ₱3.15 -21.3% · H 5.00 L 1.62 · ₱1.2M/d
- 2008: ₱1.40 -55.6% · H 2.75 L 0.6100 · ₱204.0K/d
- 2009: ₱0.9000 -35.7% · H 1.56 L 0.8500 · ₱761.3K/d
- 2010: ₱0.6000 -33.3% · H 1.00 L 0.4600 · ₱115.9K/d
- 2011: ₱0.3950 -34.2% · H 0.8700 L 0.3600 · ₱457.0K/d
- 2012: ₱0.4050 +2.5% · H 0.6200 L 0.3800 · ₱410.8K/d
- 2013: ₱0.4050 +0.0% · H 0.4650 L 0.3550 · ₱237.6K/d
- 2014: ₱0.5700 +40.7% · H 0.8600 L 0.3650 · ₱2.1M/d
- 2015: ₱0.7500 +31.6% · H 1.03 L 0.4050 · ₱6.0M/d
- 2016: ₱2.49 +232.0% · H 4.05 L 0.5900 · ₱38.7M/d
- 2017: ₱2.82 +13.3% · H 3.20 L 2.20 · ₱11.1M/d
- 2018: ₱3.44 +22.0% · H 15.70 L 2.25 · ₱141.0M/d
- 2019: ₱2.49 -27.6% · H 4.20 L 2.02 · ₱17.4M/d
- 2020: ₱4.33 +73.9% · H 5.25 L 1.10 · ₱42.0M/d
- 2021: ₱1.29 -70.2% · H 4.24 L 1.22 · ₱11.4M/d
- 2022: ₱2.24 +73.6% · H 2.24 L 0.8500 · ₱5.3M/d
- 2023: ₱1.15 -48.7% · H 2.62 L 1.02 · ₱6.3M/d
- 2024: ₱0.5900 -48.7% · H 1.28 L 0.5800 · ₱897.2K/d
- 2025: ₱0.6800 +15.3% · H 0.9700 L 0.3600 · ₱2.5M/d
- 2026*: ₱0.3800 -44.1% · H 0.7800 L 0.3500 · ₱578.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
