---
tags: [trading, pse, stock, sevn]
---
**SEVN — Philippine Seven Corporation**
- Status: listed on PSE · sector Services › Retail · listed Feb 04, 1998
- Data: 1998-02-04 → 2026-11-06 (3,712 trading days)
- Last close ₱31.95 (2026-11-06) · all-time high ₱220.0 (2017-11-21) · low ₱0.4976 (2005-06-15) · now -85.5% from high
- Cash dividends last 12 months ₱1.10 = 3.4% yield
- Dividend events on record (2013 → 2026): 10
- Splits / stock dividends detected (prices before these dates are as traded then): 2010-12-29 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1998: ₱2.18 start · H 2.18 L 1.31 · ₱241.2K/d
- 1999: ₱1.96 -10.0% · H 2.10 L 1.31 · ₱49.6K/d
- 2000: ₱3.01 +53.3% · H 3.27 L 1.53 · ₱1.2M/d
- 2001: ₱2.84 -5.8% · H 3.06 L 2.79 · ₱3.7M/d
- 2002: ₱1.42 -50.0% · H 1.70 L 1.42 · ₱20.5K/d
- 2003: ₱1.31 -7.7% · H 1.31 L 1.09 · ₱32.5M/d
- 2004: ₱0.9340 -28.7% · H 2.18 L 0.9340 · ₱320.6K/d
- 2005: ₱0.7594 -18.7% · H 0.8293 L 0.4976 · ₱21.8K/d
- 2006: ₱2.42 +219.2% · H 2.42 L 0.6547 · ₱32.6K/d
- 2007: ₱2.61 +7.5% · H 2.61 L 1.27 · ₱34.7K/d
- 2008: ₱1.21 -53.5% · H 3.03 L 1.21 · ₱1.3M/d
- 2009: ₱4.24 +250.0% · H 4.85 L 1.52 · ₱142.3K/d
- 2010: ₱8.68 +104.6% · H 13.94 L 3.94 · ₱963.0K/d
- 2011: ₱15.70 +80.9% · H 17.88 L 9.12 · ₱38.1K/d
- 2012: ₱55.76 +255.2% · H 56.36 L 12.73 · ₱29.2M/d
- 2013: ₱59.70 +7.1% · H 84.24 L 52.12 · ₱3.1M/d · div ₱0.1000 (0.2%): 12Aug 0.1
- 2014: ₱51.21 -14.2% · H 62.55 L 48.48 · ₱3.6M/d · div ₱0.3000 (0.6%): 20May 0.3
- 2015: ₱100.0 +95.3% · H 140.6 L 83.00 · ₱5.0M/d
- 2016: ₱135.0 +35.0% · H 181.0 L 99.00 · ₱11.2M/d · div ₱0.5500 (0.4%): 06May 0.55
- 2017: ₱114.4 -15.3% · H 220.0 L 114.4 · ₱10.5M/d · div ₱0.6500 (0.6%): 29Jun 0.65
- 2018: ₱124.0 +8.4% · H 145.0 L 99.00 · ₱13.8M/d · div ₱0.4300 (0.3%): 02Aug 0.43
- 2019: ₱142.0 +14.5% · H 163.0 L 113.0 · ₱11.3M/d · div ₱0.5000 (0.4%): 01Aug 0.5
- 2020: ₱119.8 -15.6% · H 155.0 L 106.0 · ₱15.9M/d · div ₱0.3000 (0.3%): 30Jul 0.3
- 2021: ₱88.00 -26.5% · H 121.0 L 84.50 · ₱9.6M/d
- 2022: ₱72.50 -17.6% · H 92.00 L 49.00 · ₱5.4M/d
- 2023: ₱76.20 +5.1% · H 89.00 L 69.00 · ₱7.6M/d
- 2024: ₱67.80 -11.0% · H 132.0 L 65.55 · ₱28.5M/d · div ₱9.60 (14.2%): 15May 9.6
- 2025: ₱37.00 -45.4% · H 68.80 L 35.55 · ₱26.1M/d · div ₱1.00 (2.7%): 01Aug 1
- 2026*: ₱31.95 -13.6% · H 38.80 L 29.55 · ₱8.2M/d · div ₱1.10 (3.4%): 31Jul 1.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
