---
tags: [trading, pse, stock, ptt]
---
**PTT — PT&amp;T Corp.**
- Status: listed on PSE · sector Services › Telecommunications · listed Jan 10, 1990
- Data: 1999-01-08 → 2004-12-09 (599 trading days)
- Last close ₱0.3300 (2004-12-09) · all-time high ₱1.10 (2000-02-21) · low ₱0.0900 (2003-02-11) · now -70.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1999: ₱0.5300 start · H 0.7200 L 0.4000 · ₱65.1K/d
- 2000: ₱0.3100 -41.5% · H 1.10 L 0.2800 · ₱240.9K/d
- 2001: ₱0.2000 -35.5% · H 0.5000 L 0.1600 · ₱45.5K/d
- 2002: ₱0.1500 -25.0% · H 0.4000 L 0.1200 · ₱36.1K/d
- 2003: ₱0.1700 +13.3% · H 0.3000 L 0.0900 · ₱46.7K/d
- 2004*: ₱0.3300 +94.1% · H 0.4600 L 0.0900 · ₱113.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
