---
tags: [trading, pse, stock, sti]
---
**STI — STI Education Systems Holdings, Inc.**
- Status: listed on PSE · sector Services › Education · listed Oct 12, 1976
- Data: 2006-08-01 → 2026-11-06 (4,087 trading days)
- Last close ₱1.18 (2026-11-06) · all-time high ₱37.50 (2007-12-06) · low ₱0.2800 (2020-05-29) · now -96.9% from high
- Cash dividends last 12 months ₱0.0550 = 4.7% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱16.25 start · H 16.25 L 16.00 · ₱32.0K/d
- 2007: ₱4.60 -71.7% · H 37.50 L 4.60 · ₱611.9K/d
- 2008: ₱0.9000 -80.4% · H 4.55 L 0.8500 · ₱61.3K/d
- 2009: ₱1.36 +51.1% · H 2.10 L 0.9000 · ₱276.8K/d
- 2010: ₱1.80 +32.4% · H 2.49 L 1.22 · ₱102.6K/d
- 2011: ₱2.59 +43.9% · H 3.10 L 1.34 · ₱2.7M/d
- 2012: ₱1.02 -60.6% · H 2.91 L 0.9400 · ₱11.5M/d
- 2013: ₱0.6400 -37.3% · H 1.05 L 0.5900 · ₱11.4M/d · div ₱0.0151 (2.4%): 13Sep 0.015144
- 2014: ₱0.7600 +18.8% · H 0.8400 L 0.6500 · ₱4.4M/d · div ₱0.0200 (2.6%): 14Oct 0.02
- 2015: ₱0.4300 -43.4% · H 0.7400 L 0.4100 · ₱3.1M/d · div ₱0.0200 (4.7%): 07Oct 0.02
- 2016: ₱0.9700 +125.6% · H 1.01 L 0.3850 · ₱6.8M/d · div ₱0.0200 (2.1%): 11Oct 0.02
- 2017: ₱1.63 +68.0% · H 1.90 L 0.9700 · ₱20.9M/d · div ₱0.0200 (1.2%): 11Oct 0.02
- 2018: ₱0.7900 -51.5% · H 1.59 L 0.5700 · ₱6.0M/d · div ₱0.0200 (2.5%): 08Nov 0.02
- 2019: ₱0.6000 -24.1% · H 0.8400 L 0.6000 · ₱3.6M/d · div ₱0.0200 (3.3%): 17Dec 0.02
- 2020: ₱0.4650 -22.5% · H 0.6300 L 0.2800 · ₱2.5M/d · div ₱0.0037 (0.8%): 22Dec 0.0037
- 2021: ₱0.3400 -26.9% · H 0.4750 L 0.3250 · ₱1.3M/d
- 2022: ₱0.3450 +1.5% · H 0.3700 L 0.3150 · ₱384.9K/d · div ₱0.0100 (2.9%): 03Jan 0.01
- 2023: ₱0.4850 +40.6% · H 0.4900 L 0.3350 · ₱899.7K/d · div ₱0.0150 (3.1%): 03Jan 0.015
- 2024: ₱1.34 +176.3% · H 1.34 L 0.4600 · ₱4.0M/d · div ₱0.0300 (2.2%): 09Jan 0.03
- 2025: ₱1.41 +5.2% · H 1.78 L 1.18 · ₱5.3M/d · div ₱0.0450 (3.2%): 08Jan 0.045
- 2026*: ₱1.18 -16.3% · H 1.43 L 1.18 · ₱1.8M/d · div ₱0.0550 (4.7%): 07Jan 0.055

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
