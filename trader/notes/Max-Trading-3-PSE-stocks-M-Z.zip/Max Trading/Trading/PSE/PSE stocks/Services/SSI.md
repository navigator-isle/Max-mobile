---
tags: [trading, pse, stock, ssi]
---
**SSI — SSI Group, Inc.**
- Status: listed on PSE · sector Services › Retail · listed Nov 07, 2014
- Data: 2014-11-07 → 2026-11-05 (2,918 trading days)
- Last close ₱1.98 (2026-11-05) · all-time high ₱11.30 (2015-01-12) · low ₱0.9300 (2020-03-19) · now -82.5% from high
- Cash dividends last 12 months ₱0.0805 = 4.1% yield
- Dividend events on record (2013 → 2026): 11

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱9.91 start · H 9.94 L 7.73 · ₱177.0M/d
- 2015: ₱3.45 -65.2% · H 11.30 L 3.37 · ₱55.2M/d
- 2016: ₱2.55 -26.1% · H 4.15 L 2.43 · ₱22.9M/d
- 2017: ₱3.30 +29.4% · H 5.06 L 2.08 · ₱27.0M/d
- 2018: ₱2.38 -27.9% · H 3.40 L 1.81 · ₱12.9M/d · div ₱0.0230 (1.0%): 03Jul 0.01, 03Jul 0.013
- 2019: ₱2.78 +16.8% · H 3.60 L 2.09 · ₱19.0M/d · div ₱0.0151 (0.5%): 05Jul 0.0151
- 2020: ₱1.49 -46.4% · H 2.82 L 0.9300 · ₱7.3M/d
- 2021: ₱1.12 -24.8% · H 1.57 L 1.06 · ₱3.4M/d
- 2022: ₱1.56 +39.3% · H 1.63 L 1.01 · ₱2.7M/d · div ₱0.0410 (2.6%): 23Aug 0.02, 23Aug 0.021
- 2023: ₱2.27 +45.5% · H 3.30 L 1.54 · ₱4.6M/d · div ₱0.1060 (4.7%): 31May 0.027, 31May 0.079S
- 2024: ₱3.18 +40.1% · H 4.48 L 2.40 · ₱5.7M/d · div ₱0.1580 (5.0%): 30May 0.039, 30May 0.119S
- 2025: ₱2.63 -17.3% · H 3.40 L 2.32 · ₱3.1M/d · div ₱0.1530 (5.8%): 06May 0.153
- 2026*: ₱1.98 -24.7% · H 2.88 L 1.94 · ₱1.4M/d · div ₱0.0805 (4.1%): 02Jun 0.0805

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
