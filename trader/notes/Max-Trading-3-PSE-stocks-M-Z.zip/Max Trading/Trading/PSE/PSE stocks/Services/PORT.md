---
tags: [trading, pse, stock, port]
---
**PORT — Globalport 900, Inc.**
- Status: listed on PSE · sector Services › Transportation Services · listed Jun 09, 1948
- Data: 2011-12-15 → 2014-05-16 (190 trading days)
- Last close ₱7.30 (2014-05-16) · all-time high ₱34.00 (2012-05-04) · low ₱5.10 (2014-03-11) · now -78.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2013-03-27 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱30.80 start · H 32.50 L 25.50 · ₱99.8K/d
- 2012: ₱19.00 -38.3% · H 34.00 L 16.30 · ₱101.8K/d
- 2013: ₱8.00 -57.9% · H 20.00 L 8.00 · ₱14.4K/d
- 2014*: ₱7.30 -8.8% · H 10.00 L 5.10 · ₱48.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
