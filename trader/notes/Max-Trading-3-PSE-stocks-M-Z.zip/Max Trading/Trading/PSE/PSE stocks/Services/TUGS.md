---
tags: [trading, pse, stock, tugs]
---
**TUGS — Harbor Star Shipping Services, Inc.**
- Status: listed on PSE · sector Services › Transportation Services · listed Oct 30, 2013
- Data: 2013-10-30 → 2026-11-06 (3,095 trading days)
- Last close ₱1.49 (2026-11-06) · all-time high ₱5.87 (2018-02-19) · low ₱0.4600 (2026-03-19) · now -74.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱0.8067 start · H 1.27 L 0.8067 · ₱4.4M/d
- 2014: ₱0.9933 +23.1% · H 1.27 L 0.8267 · ₱2.3M/d · div ₱0.0350 (3.5%): 11Jun 0.035
- 2015: ₱1.17 +17.8% · H 1.66 L 1.15 · ₱433.4K/d · div ₱0.0380 (3.2%): 07Jul 0.038
- 2016: ₱2.65 +126.5% · H 2.67 L 1.08 · ₱4.8M/d
- 2017: ₱4.49 +69.4% · H 5.23 L 2.18 · ₱21.6M/d
- 2018: ₱2.95 -34.3% · H 5.87 L 2.32 · ₱13.0M/d
- 2019: ₱1.07 -63.7% · H 3.30 L 1.03 · ₱3.8M/d
- 2020: ₱1.55 +44.9% · H 1.77 L 0.5500 · ₱3.6M/d
- 2021: ₱0.9100 -41.3% · H 1.82 L 0.8200 · ₱1.3M/d
- 2022: ₱0.9700 +6.6% · H 1.36 L 0.6200 · ₱440.2K/d
- 2023: ₱0.7600 -21.6% · H 1.08 L 0.7200 · ₱249.0K/d
- 2024: ₱0.6200 -18.4% · H 0.8700 L 0.5600 · ₱153.9K/d
- 2025: ₱0.5900 -4.8% · H 0.6900 L 0.4700 · ₱70.3K/d
- 2026*: ₱1.49 +152.5% · H 2.07 L 0.4600 · ₱2.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
