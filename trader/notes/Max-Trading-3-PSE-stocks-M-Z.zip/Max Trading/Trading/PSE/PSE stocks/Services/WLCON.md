---
tags: [trading, pse, stock, wlcon]
---
**WLCON — Wilcon Depot, Inc.**
- Status: listed on PSE · sector Services › Retail · listed Mar 31, 2017
- Data: 2017-03-31 → 2026-11-06 (2,338 trading days)
- Last close ₱5.24 (2026-11-06) · all-time high ₱34.95 (2021-10-08) · low ₱5.10 (2026-11-04) · now -85.0% from high
- Cash dividends last 12 months ₱0.4000 = 7.6% yield
- Dividend events on record (2013 → 2026): 18

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱8.28 start · H 9.50 L 5.16 · ₱72.8M/d
- 2018: ₱12.60 +52.2% · H 12.60 L 8.20 · ₱41.0M/d · div ₱0.1100 (0.9%): 21May 0.03S, 21May 0.08
- 2019: ₱18.00 +42.9% · H 19.00 L 12.90 · ₱49.0M/d · div ₱0.1600 (0.9%): 19Mar 0.05S, 19Mar 0.11
- 2020: ₱16.90 -6.1% · H 18.92 L 12.00 · ₱36.6M/d · div ₱0.1800 (1.1%): 17Mar 0.06S, 17Mar 0.12
- 2021: ₱30.50 +80.5% · H 34.95 L 16.60 · ₱81.9M/d · div ₱0.1200 (0.4%): 16Mar 0.02S, 16Mar 0.1
- 2022: ₱29.50 -3.3% · H 33.10 L 21.55 · ₱42.5M/d · div ₱0.2100 (0.7%): 15Mar 0.06S, 15Mar 0.15
- 2023: ₱20.90 -29.2% · H 34.10 L 19.44 · ₱43.2M/d · div ₱0.3700 (1.8%): 17Mar 0.14S, 17Mar 0.23
- 2024: ₱14.30 -31.6% · H 24.00 L 12.98 · ₱34.3M/d · div ₱0.2600 (1.8%): 17Apr 0.11, 17Apr 0.15S
- 2025: ₱6.96 -51.3% · H 14.38 L 5.68 · ₱32.0M/d · div ₱0.3600 (5.2%): 15Apr 0.15, 15Apr 0.21S
- 2026*: ₱5.24 -24.7% · H 7.49 L 5.10 · ₱12.8M/d · div ₱0.4000 (7.6%): 16Apr 0.14, 16Apr 0.26

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
