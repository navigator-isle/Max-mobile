---
tags: [trading, pse, stock, mac]
---
**MAC — MacroAsia Corporation**
- Status: listed on PSE · sector Services › Transportation Services · listed May 21, 1970
- Data: 1995-12-12 → 2026-11-06 (6,039 trading days)
- Last close ₱3.37 (2026-11-06) · all-time high ₱29.95 (2018-02-26) · low ₱0.4000 (2003-01-28) · now -88.7% from high
- Cash dividends last 12 months ₱0.1100 = 3.3% yield
- Dividend events on record (2013 → 2026): 10

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱7.99 start · H 7.99 L 7.99 · ₱8.0K/d
- 1996: ₱4.20 -47.5% · H 8.99 L 4.20 · ₱2.8M/d
- 1997: ₱1.89 -55.0% · H 5.90 L 1.89 · ₱3.7M/d
- 1998: ₱1.79 -5.0% · H 2.54 L 0.6601 · ₱739.2K/d
- 1999: ₱5.69 +217.4% · H 8.60 L 1.78 · ₱17.7M/d
- 2000: ₱2.09 -63.3% · H 5.99 L 2.00 · ₱12.2M/d
- 2001: ₱1.20 -42.6% · H 2.29 L 0.8000 · ₱911.8K/d
- 2002: ₱0.4501 -62.5% · H 1.54 L 0.4401 · ₱95.6K/d
- 2003: ₱0.5801 +28.9% · H 0.8701 L 0.4000 · ₱50.9K/d
- 2004: ₱2.34 +303.4% · H 2.89 L 0.4501 · ₱1.5M/d
- 2005: ₱1.44 -38.5% · H 2.70 L 1.44 · ₱746.0K/d
- 2006: ₱2.09 +45.3% · H 2.84 L 1.28 · ₱1.6M/d
- 2007: ₱4.99 +138.8% · H 5.79 L 2.03 · ₱14.5M/d
- 2008: ₱3.49 -30.0% · H 5.09 L 2.79 · ₱1.0M/d
- 2009: ₱3.00 -14.3% · H 3.74 L 2.70 · ₱454.3K/d
- 2010: ₱3.00 +0.0% · H 3.57 L 2.59 · ₱984.5K/d
- 2011: ₱3.00 +0.0% · H 3.81 L 2.75 · ₱593.4K/d
- 2012: ₱2.68 -10.4% · H 3.07 L 2.50 · ₱290.9K/d
- 2013: ₱3.95 +47.1% · H 4.18 L 1.89 · ₱3.9M/d · div ₱0.0650 (1.6%): 19Apr 0.065
- 2014: ₱2.45 -37.9% · H 3.99 L 1.98 · ₱3.9M/d
- 2015: ₱2.35 -4.1% · H 2.50 L 1.80 · ₱166.7K/d · div ₱0.0750 (3.2%): 23Dec 0.075
- 2016: ₱2.41 +2.6% · H 2.85 L 2.05 · ₱175.7K/d
- 2017: ₱22.85 +848.1% · H 23.90 L 2.24 · ₱35.5M/d · div ₱0.0800 (0.4%): 03Jan 0.08
- 2018: ₱17.00 -25.6% · H 29.95 L 12.20 · ₱43.7M/d · div ₱0.1400 (0.8%): 02Jan 0.14
- 2019: ₱16.50 -2.9% · H 22.95 L 16.50 · ₱17.6M/d · div ₱0.2000 (1.2%): 08Apr 0.2
- 2020: ₱6.80 -58.8% · H 16.90 L 3.42 · ₱40.4M/d · div ₱0.2500 (3.7%): 31Mar 0.25
- 2021: ₱5.30 -22.1% · H 6.90 L 4.21 · ₱11.6M/d
- 2022: ₱4.90 -7.5% · H 6.19 L 4.03 · ₱4.2M/d
- 2023: ₱4.15 -15.3% · H 5.45 L 3.75 · ₱2.7M/d · div ₱0.0500 (1.2%): 18Apr 0.05
- 2024: ₱5.44 +31.1% · H 7.55 L 3.89 · ₱10.4M/d · div ₱0.1000 (1.8%): 18Apr 0.1
- 2025: ₱4.34 -20.2% · H 6.02 L 3.60 · ₱6.3M/d · div ₱0.1100 (2.5%): 24Apr 0.11
- 2026*: ₱3.37 -22.4% · H 5.01 L 3.20 · ₱2.3M/d · div ₱0.1100 (3.3%): 09Sep 0.11

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
