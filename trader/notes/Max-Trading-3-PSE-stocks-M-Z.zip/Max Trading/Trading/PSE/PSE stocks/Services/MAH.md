---
tags: [trading, pse, stock, mah]
---
**MAH — Metro Alliance Holdings &amp; Equities Corp.**
- Status: listed on PSE · sector Services › Transportation Services · listed Dec 08, 1947
- Data: 2006-04-10 → 2026-11-06 (1,420 trading days)
- Last close ₱0.5800 (2026-11-06) · all-time high ₱3.80 (2018-06-13) · low ₱0.2450 (2006-08-03) · now -84.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2018-06-04 (÷0.2), 2026-09-18 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.4900 start · H 0.5700 L 0.2450 · ₱33.4K/d
- 2007: ₱0.7000 +42.9% · H 0.9500 L 0.3700 · ₱78.4K/d
- 2018: ₱2.09 start · H 3.80 L 1.08 · ₱5.1M/d
- 2019: ₱0.9900 -52.6% · H 2.59 L 0.9800 · ₱417.7K/d
- 2020: ₱1.87 +88.9% · H 2.86 L 0.9400 · ₱8.2M/d
- 2021: ₱1.19 -36.4% · H 3.73 L 1.12 · ₱3.8M/d
- 2022: ₱0.6500 -45.4% · H 1.19 L 0.6500 · ₱40.4K/d
- 2023: ₱0.4550 -30.0% · H 0.8400 L 0.4550 · ₱18.2K/d
- 2024: ₱0.8300 +82.4% · H 0.8600 L 0.3050 · ₱32.6K/d
- 2025: ₱0.4500 -45.8% · H 0.8500 L 0.3500 · ₱16.6K/d
- 2026*: ₱0.5800 +28.9% · H 0.7200 L 0.3700 · ₱27.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
