---
tags: [trading, pse, stock, phc]
---
**PHC — Philcomsat Holdings Corporation**
- Status: listed on PSE · sector Services › Other Services · listed Nov 28, 1958
- Data: 2025-10-08 → 2026-11-05 (138 trading days)
- Last close ₱1.62 (2026-11-05) · all-time high ₱4.19 (2025-10-20) · low ₱1.40 (2025-10-08) · now -61.3% from high
- Cash dividends last 12 months ₱0.0500 = 3.1% yield
- Dividend events on record (2013 → 2026): 2

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2025: ₱1.84 start · H 4.19 L 1.40 · ₱159.7K/d
- 2026*: ₱1.62 -12.0% · H 2.16 L 1.49 · ₱41.7K/d · div ₱0.0500 (3.1%): 19Mar 0.05

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
