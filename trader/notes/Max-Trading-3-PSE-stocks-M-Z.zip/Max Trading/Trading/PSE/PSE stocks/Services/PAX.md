---
tags: [trading, pse, stock, pax]
---
**PAX — Paxys, Inc.**
- Status: listed on PSE · sector Services › Other Services · listed Oct 05, 1972
- Data: 2004-07-05 → 2026-11-06 (3,620 trading days)
- Last close ₱2.81 (2026-11-06) · all-time high ₱30.00 (2007-02-22) · low ₱0.4300 (2009-03-10) · now -90.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2004: ₱3.43 start · H 3.80 L 1.47 · ₱1.7M/d
- 2005: ₱6.40 +86.4% · H 7.67 L 3.47 · ₱7.7M/d
- 2006: ₱19.75 +208.6% · H 20.00 L 6.20 · ₱10.1M/d
- 2007: ₱5.90 -70.1% · H 30.00 L 5.40 · ₱19.5M/d
- 2008: ₱0.6000 -89.8% · H 6.20 L 0.6000 · ₱6.1M/d
- 2009: ₱2.80 +366.7% · H 3.70 L 0.4300 · ₱15.4M/d
- 2010: ₱1.38 -50.7% · H 2.95 L 1.36 · ₱1.9M/d
- 2011: ₱1.36 -1.4% · H 2.16 L 1.05 · ₱1.6M/d
- 2012: ₱2.96 +117.6% · H 3.37 L 1.36 · ₱6.0M/d
- 2013: ₱2.21 -25.3% · H 3.02 L 1.85 · ₱911.0K/d
- 2014: ₱3.00 +35.7% · H 3.20 L 2.13 · ₱1.2M/d
- 2015: ₱2.99 -0.3% · H 3.78 L 2.52 · ₱127.0K/d
- 2016: ₱3.08 +3.0% · H 3.11 L 2.30 · ₱77.5K/d
- 2017: ₱2.81 -8.8% · H 3.60 L 2.76 · ₱478.3K/d
- 2018: ₱3.25 +15.7% · H 3.94 L 2.74 · ₱256.3K/d
- 2019: ₱2.69 -17.2% · H 3.75 L 2.65 · ₱92.9K/d
- 2020: ₱2.35 -12.6% · H 2.97 L 2.00 · ₱26.5K/d
- 2021: ₱2.10 -10.6% · H 2.48 L 2.06 · ₱55.2K/d
- 2022: ₱1.83 -12.9% · H 1.99 L 1.60 · ₱15.9K/d
- 2023: ₱1.15 -37.2% · H 1.80 L 1.04 · ₱415.3K/d
- 2024: ₱1.70 +47.8% · H 2.08 L 1.04 · ₱67.9K/d
- 2025: ₱2.61 +53.5% · H 3.50 L 1.66 · ₱204.4K/d
- 2026*: ₱2.81 +7.7% · H 4.16 L 1.98 · ₱337.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
