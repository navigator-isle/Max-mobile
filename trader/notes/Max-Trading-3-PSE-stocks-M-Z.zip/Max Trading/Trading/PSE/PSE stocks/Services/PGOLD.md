---
tags: [trading, pse, stock, pgold]
---
**PGOLD — Puregold Price Club, Inc.**
- Status: listed on PSE · sector Services › Retail · listed Oct 05, 2011
- Data: 2011-10-05 → 2026-11-06 (3,673 trading days)
- Last close ₱39.10 (2026-11-06) · all-time high ₱54.90 (2017-10-03) · low ₱10.68 (2011-10-06) · now -28.8% from high
- Cash dividends last 12 months ₱1.97 = 5.0% yield
- Dividend events on record (2013 → 2026): 22

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱17.88 start · H 18.40 L 10.68 · ₱106.7M/d
- 2012: ₱33.00 +84.6% · H 34.00 L 17.90 · ₱89.4M/d
- 2013: ₱37.90 +14.8% · H 46.50 L 31.80 · ₱177.5M/d · div ₱0.4000 (1.1%): 09Jan 0.1S, 27Dec 0.1S, 27Dec 0.2
- 2014: ₱38.55 +1.7% · H 48.15 L 31.50 · ₱137.1M/d
- 2015: ₱34.70 -10.0% · H 43.00 L 30.00 · ₱97.8M/d · div ₱0.3000 (0.9%): 07Jan 0.1S, 07Jan 0.2
- 2016: ₱39.00 +12.4% · H 49.20 L 30.50 · ₱101.9M/d · div ₱0.3000 (0.8%): 05Jan 0.1S, 05Jan 0.2
- 2017: ₱50.00 +28.2% · H 54.90 L 38.85 · ₱110.4M/d · div ₱0.5000 (1.0%): 09Jan 0.1S, 09Jan 0.2, 27Dec 0.2S
- 2018: ₱43.00 -14.0% · H 54.00 L 40.20 · ₱70.4M/d
- 2019: ₱39.75 -7.6% · H 49.75 L 38.00 · ₱64.9M/d · div ₱0.4000 (1.0%): 12Feb 0.2S, 20Dec 0.2S
- 2020: ₱41.00 +3.1% · H 54.00 L 29.00 · ₱147.1M/d
- 2021: ₱39.30 -4.1% · H 44.50 L 31.65 · ₱97.3M/d · div ₱0.4500 (1.1%): 05Jan 0.2S, 05Jan 0.25
- 2022: ₱34.90 -11.2% · H 39.35 L 26.70 · ₱49.5M/d · div ₱0.2500 (0.7%): 05Jan 0.25S
- 2023: ₱26.90 -22.9% · H 36.20 L 26.05 · ₱36.7M/d · div ₱1.83 (6.8%): 05Jan 0.86, 27Dec 0.97
- 2024: ₱30.85 +14.7% · H 34.45 L 22.80 · ₱41.7M/d · div ₱0.9000 (2.9%): 28May 0.9
- 2025: ₱38.00 +23.2% · H 45.95 L 24.70 · ₱74.3M/d · div ₱1.81 (4.8%): 29Apr 1.09, 01Sep 0.72S
- 2026*: ₱39.10 +2.9% · H 49.00 L 35.60 · ₱75.2M/d · div ₱1.97 (5.0%): 16Apr 1.18, 14Aug 0.79

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
