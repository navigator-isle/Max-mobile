---
tags: [trading, pse, stock, pal]
---
**PAL — PAL Holdings, Inc.**
- Status: listed on PSE · sector Services › Transportation Services · listed Jan 04, 1954
- Data: 1986-05-07 → 2026-11-06 (5,711 trading days)
- Last close ₱4.32 (2026-11-06) · all-time high ₱18.88 (2007-10-03) · low ₱0.1900 (1989-06-26) · now -77.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2003-03-04 (÷1.5), 2005-04-22 (÷1.5), 2006-08-24 (÷4)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1986: ₱1.22 start · H 1.44 L 0.2667 · ₱8.5M/d
- 1987: ₱1.44 +18.0% · H 4.44 L 0.8889 · ₱22.7M/d
- 1988: ₱1.55 +7.6% · H 1.77 L 1.11 · ₱6.7M/d
- 1989: ₱1.55 +0.0% · H 2.22 L 0.1900 · ₱12.0M/d
- 1990: ₱1.11 -28.4% · H 1.88 L 0.6667 · ₱11.8M/d
- 1991: ₱1.11 +0.0% · H 1.22 L 0.8889 · ₱9.6M/d
- 1992: ₱1.77 +59.5% · H 1.77 L 0.8889 · ₱3.2M/d
- 1993: ₱1.22 -31.1% · H 1.77 L 1.22 · ₱1.3M/d
- 1994: ₱0.8000 -34.4% · H 1.99 L 0.6667 · ₱7.5M/d
- 1995: ₱3.77 +371.2% · H 4.88 L 0.6667 · ₱68.6M/d
- 1996: ₱6.66 +76.7% · H 7.33 L 3.77 · ₱53.5M/d
- 1997: ₱9.44 +41.7% · H 9.99 L 6.55 · ₱240.6K/d
- 1998: ₱5.11 -45.9% · H 12.22 L 4.44 · ₱168.8K/d
- 1999: ₱9.44 +84.7% · H 14.22 L 2.44 · ₱4.4M/d
- 2000: ₱4.57 -51.6% · H 9.66 L 3.02 · ₱319.0K/d
- 2001: ₱2.22 -51.4% · H 4.66 L 2.22 · ₱150.0K/d
- 2002: ₱0.7778 -65.0% · H 2.22 L 0.7778 · ₱19.5K/d
- 2003: ₱0.6000 -22.9% · H 1.00 L 0.3333 · ₱6.1K/d
- 2004: ₱2.31 +285.0% · H 3.73 L 0.6667 · ₱105.1K/d
- 2005: ₱1.57 -32.0% · H 3.15 L 1.37 · ₱50.4K/d
- 2006: ₱2.22 +41.4% · H 8.66 L 1.44 · ₱520.5K/d
- 2007: ₱13.99 +530.2% · H 18.88 L 11.11 · ₱2.5M/d
- 2008: ₱6.66 -52.4% · H 13.33 L 4.66 · ₱83.7K/d
- 2009: ₱6.33 -5.0% · H 6.66 L 4.53 · ₱51.8K/d
- 2010: ₱10.11 +59.7% · H 11.99 L 5.88 · ₱633.1K/d
- 2011: ₱15.53 +53.6% · H 17.35 L 9.17 · ₱1.6M/d
- 2012: ₱10.88 -29.9% · H 18.44 L 10.11 · ₱1.4M/d
- 2013: ₱13.28 +22.1% · H 15.46 L 11.44 · ₱504.8K/d
- 2014: ₱10.57 -20.4% · H 14.33 L 7.88 · ₱483.5K/d
- 2015: ₱4.59 -56.6% · H 5.28 L 4.33 · ₱194.8K/d
- 2016: ₱5.16 +12.4% · H 6.16 L 4.00 · ₱255.8K/d
- 2017: ₱5.15 -0.2% · H 5.69 L 4.79 · ₱160.2K/d
- 2018: ₱8.33 +61.7% · H 12.00 L 7.50 · ₱136.2K/d
- 2019: ₱7.85 -5.8% · H 15.96 L 7.30 · ₱1.7M/d
- 2020: ₱6.55 -16.6% · H 7.85 L 5.00 · ₱441.8K/d
- 2021: ₱6.05 -7.6% · H 7.00 L 5.50 · ₱301.4K/d
- 2022: ₱5.90 -2.5% · H 6.64 L 5.40 · ₱130.4K/d
- 2023: ₱5.07 -14.1% · H 6.07 L 5.03 · ₱94.0K/d
- 2024: ₱4.95 -2.4% · H 6.24 L 4.48 · ₱108.9K/d
- 2025: ₱3.80 -23.2% · H 5.19 L 3.60 · ₱61.7K/d
- 2026*: ₱4.32 +13.7% · H 4.32 L 2.10 · ₱2.3M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
