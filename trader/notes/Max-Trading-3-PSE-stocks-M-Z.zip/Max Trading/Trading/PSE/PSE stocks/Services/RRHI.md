---
tags: [trading, pse, stock, rrhi]
---
**RRHI — Robinsons Retail Holdings, Inc.**
- Status: listed on PSE · sector Services › Retail · listed Nov 11, 2013
- Data: 2013-11-11 → 2026-07-10 (3,082 trading days)
- Last close ₱38.00 (2026-07-10) · all-time high ₱106.1 (2017-10-09) · low ₱32.00 (2025-11-10) · now -64.2% from high
- Cash dividends last 12 months ₱2.00 = 5.3% yield
- Dividend events on record (2013 → 2026): 14

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2013: ₱55.20 start · H 59.90 L 50.00 · ₱299.6M/d
- 2014: ₱75.70 +37.1% · H 78.00 L 57.05 · ₱102.1M/d · div ₱0.4100 (0.5%): 14Jul 0.41
- 2015: ₱63.00 -16.8% · H 89.00 L 61.80 · ₱87.5M/d · div ₱0.5100 (0.8%): 04Aug 0.51
- 2016: ₱74.25 +17.9% · H 88.00 L 57.00 · ₱92.5M/d · div ₱0.6300 (0.8%): 24Jun 0.63
- 2017: ₱96.20 +29.6% · H 106.1 L 72.70 · ₱87.9M/d · div ₱0.7000 (0.7%): 12Jul 0.7
- 2018: ₱80.00 -16.8% · H 101.5 L 71.50 · ₱57.0M/d · div ₱0.7200 (0.9%): 13Jun 0.72
- 2019: ₱80.00 +0.0% · H 89.70 L 68.85 · ₱49.5M/d · div ₱0.7200 (0.9%): 17Jun 0.72
- 2020: ₱65.00 -18.8% · H 80.10 L 46.10 · ₱33.7M/d · div ₱1.00 (1.5%): 29May 1
- 2021: ₱65.40 +0.6% · H 68.30 L 48.50 · ₱58.3M/d · div ₱1.83 (2.8%): 17May 0.83, 17May 1S
- 2022: ₱53.85 -17.7% · H 62.75 L 46.00 · ₱36.8M/d · div ₱2.00 (3.7%): 17May 2
- 2023: ₱39.65 -26.4% · H 58.85 L 38.35 · ₱26.9M/d · div ₱2.00 (5.0%): 23May 2
- 2024: ₱36.00 -9.2% · H 41.35 L 35.00 · ₱15.0M/d · div ₱2.00 (5.6%): 24May 2
- 2025: ₱33.05 -8.2% · H 40.35 L 32.00 · ₱12.2M/d · div ₱2.00 (6.1%): 23May 2
- 2026*: ₱38.00 +15.0% · H 66.75 L 33.25 · ₱31.8M/d · div ₱2.00 (5.3%): 26May 2

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
