---
tags: [trading, pse, stock, unh]
---
**UNH — Uniholdings Inc.**
- Status: listed on PSE · sector Property › Property · listed Nov 21, 1985
- Data: 2015-01-09 → 2026-05-22 (873 trading days)
- Last close ₱117.9 (2026-05-22) · all-time high ₱419.0 (2018-03-07) · low ₱65.10 (2025-12-02) · now -71.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱100.0 start · H 243.0 L 85.00 · ₱57.4K/d
- 2016: ₱142.0 +42.0% · H 230.0 L 97.00 · ₱67.2K/d
- 2017: ₱188.0 +32.4% · H 198.5 L 140.8 · ₱182.2K/d
- 2018: ₱169.0 -10.1% · H 419.0 L 155.2 · ₱127.2K/d
- 2019: ₱170.0 +0.6% · H 175.0 L 100.0 · ₱141.2K/d
- 2020: ₱126.8 -25.4% · H 228.0 L 104.0 · ₱186.7K/d
- 2021: ₱130.4 +2.8% · H 200.0 L 127.8 · ₱40.8K/d
- 2022: ₱150.0 +15.0% · H 150.0 L 100.0 · ₱26.2K/d
- 2023: ₱161.5 +7.7% · H 264.0 L 118.1 · ₱42.6K/d
- 2024: ₱189.0 +17.0% · H 199.8 L 113.4 · ₱12.6K/d
- 2025: ₱140.0 -25.9% · H 248.6 L 65.10 · ₱67.7K/d
- 2026*: ₱117.9 -15.8% · H 160.0 L 106.8 · ₱13.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
