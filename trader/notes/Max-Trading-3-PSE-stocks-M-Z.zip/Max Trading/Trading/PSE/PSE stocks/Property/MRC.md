---
tags: [trading, pse, stock, mrc]
---
**MRC — MRC Allied, Inc.**
- Status: listed on PSE · sector Property › Property · listed May 18, 1995
- Data: 1995-05-18 → 2026-11-06 (6,352 trading days)
- Last close ₱0.6200 (2026-11-06) · all-time high ₱6.70 (1995-09-14) · low ₱0.0690 (2016-01-18) · now -90.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱4.90 start · H 6.70 L 3.20 · ₱50.6M/d
- 1996: ₱3.50 -28.6% · H 5.20 L 2.80 · ₱23.1M/d
- 1997: ₱1.00 -71.4% · H 3.85 L 1.00 · ₱4.0M/d
- 1998: ₱0.2700 -73.0% · H 1.00 L 0.1150 · ₱769.1K/d
- 1999: ₱0.6300 +133.3% · H 1.12 L 0.2400 · ₱3.1M/d
- 2000: ₱0.3800 -39.7% · H 0.8100 L 0.2200 · ₱629.8K/d
- 2001: ₱0.2200 -42.1% · H 0.5500 L 0.1800 · ₱118.6K/d
- 2002: ₱0.1000 -54.5% · H 0.2500 L 0.0700 · ₱201.8K/d
- 2003: ₱0.1200 +20.0% · H 0.2000 L 0.0700 · ₱107.9K/d
- 2004: ₱0.1300 +8.3% · H 0.1600 L 0.0700 · ₱26.2K/d
- 2005: ₱0.1000 -23.1% · H 0.2900 L 0.1000 · ₱187.1K/d
- 2006: ₱0.3800 +280.0% · H 0.4500 L 0.1000 · ₱903.9K/d
- 2007: ₱0.4600 +21.1% · H 1.08 L 0.3200 · ₱5.2M/d
- 2008: ₱0.1000 -78.3% · H 0.5700 L 0.1000 · ₱1.3M/d
- 2009: ₱0.3600 +260.0% · H 0.4200 L 0.1200 · ₱598.7K/d
- 2010: ₱0.7100 +97.2% · H 1.08 L 0.5400 · ₱7.3M/d
- 2011: ₱0.2800 -60.6% · H 0.9200 L 0.2350 · ₱8.3M/d
- 2012: ₱0.1520 -45.7% · H 0.3000 L 0.1510 · ₱3.8M/d
- 2013: ₱0.0710 -53.3% · H 0.1500 L 0.0710 · ₱765.1K/d
- 2014: ₱0.1120 +57.7% · H 0.1670 L 0.0710 · ₱2.6M/d
- 2015: ₱0.0820 -26.8% · H 0.1340 L 0.0770 · ₱433.4K/d
- 2016: ₱0.1290 +57.3% · H 0.2410 L 0.0690 · ₱6.4M/d
- 2017: ₱0.3350 +159.7% · H 0.4550 L 0.1350 · ₱36.0M/d
- 2018: ₱0.4500 +34.3% · H 0.8900 L 0.3000 · ₱75.4M/d
- 2019: ₱0.1910 -57.6% · H 0.4800 L 0.1810 · ₱4.8M/d
- 2020: ₱0.5900 +208.9% · H 0.6400 L 0.1200 · ₱23.9M/d
- 2021: ₱0.2550 -56.8% · H 0.8800 L 0.2460 · ₱34.5M/d
- 2022: ₱0.1950 -23.5% · H 0.3000 L 0.1710 · ₱1.3M/d
- 2023: ₱1.30 +566.7% · H 1.66 L 0.1810 · ₱2.5M/d
- 2024: ₱0.8400 -35.4% · H 1.50 L 0.4350 · ₱7.6M/d
- 2025: ₱0.8700 +3.6% · H 1.17 L 0.5000 · ₱26.6M/d
- 2026*: ₱0.6200 -28.7% · H 1.00 L 0.6200 · ₱31.1M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
