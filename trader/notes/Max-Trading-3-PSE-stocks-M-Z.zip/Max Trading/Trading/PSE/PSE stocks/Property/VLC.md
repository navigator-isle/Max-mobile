---
tags: [trading, pse, stock, vlc]
---
**VLC — Villar Land Holdings Corp.**
- Status: listed on PSE · sector Property › Property · listed Jun 29, 2016
- Data: 2016-06-29 → 2026-05-29 (1,878 trading days)
- Last close ₱448.0 (2026-05-29) · all-time high ₱2,494 (2025-02-18) · low ₱12.52 (2016-11-15) · now -82.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱17.00 start · H 20.30 L 12.52 · ₱15.2M/d
- 2017: ₱22.00 +29.4% · H 22.00 L 15.22 · ₱1.6M/d
- 2018: ₱325.0 +1377.3% · H 330.0 L 21.00 · ₱11.2M/d
- 2019: ₱436.0 +34.2% · H 449.8 L 325.0 · ₱1.7M/d
- 2020: ₱441.0 +1.1% · H 455.0 L 280.0 · ₱6.9M/d
- 2021: ₱540.0 +22.4% · H 540.0 L 411.8 · ₱1.0M/d
- 2022: ₱650.0 +20.4% · H 690.0 L 519.0 · ₱1.2M/d
- 2023: ₱844.5 +29.9% · H 859.0 L 650.0 · ₱5.2M/d
- 2024: ₱2,250 +166.4% · H 2,296 L 875.0 · ₱3.4M/d
- 2025: ₱1,000 -55.6% · H 2,494 L 500.0 · ₱2.4M/d
- 2026*: ₱448.0 -55.2% · H 1,118 L 401.0 · ₱162.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
