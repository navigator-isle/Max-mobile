---
tags: [trading, pse, stock, mreit]
---
**MREIT — MREIT, Inc.**
- Status: listed on PSE · sector Property › Property · listed Oct 01, 2021
- Data: 2021-10-01 → 2026-11-06 (1,246 trading days)
- Last close ₱13.78 (2026-11-06) · all-time high ₱22.50 (2022-01-28) · low ₱11.28 (2022-11-28) · now -38.8% from high
- Cash dividends last 12 months ₱1.03 = 7.5% yield
- Dividend events on record (2013 → 2026): 21

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱19.70 start · H 19.70 L 16.70 · ₱84.5M/d · div ₱0.2400 (1.2%): 04Nov 0.24
- 2022: ₱14.48 -26.5% · H 22.50 L 11.28 · ₱43.1M/d · div ₱0.9741 (6.7%): 15Mar 0.2399, 04May 0.243, 16Aug 0.2468, 22Nov 0.2444
- 2023: ₱12.30 -15.1% · H 15.90 L 11.88 · ₱8.4M/d · div ₱0.9840 (8.0%): 19Jan 0.2428, 24May 0.2476, 17Aug 0.2476, 17Nov 0.246
- 2024: ₱13.34 +8.5% · H 14.14 L 12.42 · ₱12.7M/d · div ₱0.9883 (7.4%): 15Mar 0.246, 23May 0.246, 15Aug 0.2474, 15Nov 0.2489
- 2025: ₱14.00 +4.9% · H 14.94 L 13.36 · ₱11.3M/d · div ₱1.00 (7.2%): 20Mar 0.2505, 22May 0.25047, 27Aug 0.250478, 28Nov 0.250478
- 2026*: ₱13.78 -1.6% · H 14.38 L 13.30 · ₱22.8M/d · div ₱1.05 (7.6%): 13Mar 0.250478, 14May 0.263, 13Aug 0.263, 09Nov 0.2762 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
