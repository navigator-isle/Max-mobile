---
tags: [trading, pse, stock, soc]
---
**SOC — SOCResources, Inc.**
- Status: listed on PSE · sector Property › Property · listed Jan 05, 1994
- Data: 1994-01-05 → 2026-06-16 (4,621 trading days)
- Last close ₱0.2090 (2026-06-16) · all-time high ₱3.70 (2010-07-13) · low ₱0.1350 (2001-03-21) · now -94.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱1.40 start · H 2.90 L 1.00 · ₱3.7M/d
- 1995: ₱1.40 +0.0% · H 1.80 L 1.10 · ₱1.0M/d
- 1996: ₱1.20 -14.3% · H 2.00 L 1.10 · ₱2.5M/d
- 1997: ₱0.6500 -45.8% · H 1.50 L 0.5700 · ₱950.9K/d
- 1998: ₱0.4000 -38.5% · H 1.08 L 0.4000 · ₱114.9K/d
- 1999: ₱0.6500 +62.5% · H 0.9000 L 0.1800 · ₱1.1M/d
- 2000: ₱0.3200 -50.8% · H 0.7100 L 0.2000 · ₱35.3K/d
- 2001: ₱0.2200 -31.2% · H 0.3500 L 0.1350 · ₱20.9K/d
- 2002: ₱0.2800 +27.3% · H 0.7500 L 0.1700 · ₱47.0K/d
- 2003: ₱0.2600 -7.1% · H 0.3500 L 0.1800 · ₱31.6K/d
- 2004: ₱0.3200 +23.1% · H 0.3200 L 0.2000 · ₱28.7K/d
- 2005: ₱0.6000 +87.5% · H 0.8500 L 0.3500 · ₱145.5K/d
- 2006: ₱0.9700 +61.7% · H 1.24 L 0.5200 · ₱315.0K/d
- 2007: ₱1.50 +54.6% · H 1.80 L 1.02 · ₱423.3K/d
- 2008: ₱0.9000 -40.0% · H 1.90 L 0.9000 · ₱133.3K/d
- 2009: ₱2.18 +142.2% · H 2.18 L 0.8000 · ₱588.6K/d
- 2010: ₱1.48 -32.1% · H 3.70 L 1.18 · ₱1.5M/d
- 2011: ₱1.14 -23.0% · H 1.71 L 1.14 · ₱536.2K/d
- 2012: ₱1.04 -8.8% · H 1.53 L 1.04 · ₱362.7K/d
- 2013: ₱1.09 +4.8% · H 1.25 L 0.9200 · ₱146.2K/d
- 2014: ₱1.08 -0.9% · H 1.29 L 0.9800 · ₱303.8K/d
- 2015: ₱0.7100 -34.3% · H 1.08 L 0.6100 · ₱209.5K/d
- 2016: ₱0.8300 +16.9% · H 1.10 L 0.6500 · ₱245.3K/d
- 2017: ₱0.8100 -2.4% · H 0.9400 L 0.7800 · ₱75.7K/d
- 2018: ₱0.7400 -8.6% · H 0.9700 L 0.7100 · ₱110.5K/d
- 2019: ₱0.7900 +6.8% · H 1.42 L 0.7400 · ₱2.6M/d
- 2020: ₱0.7600 -3.8% · H 0.8800 L 0.5900 · ₱236.2K/d
- 2021: ₱0.6600 -13.2% · H 1.08 L 0.6100 · ₱325.1K/d
- 2022: ₱0.4600 -30.3% · H 0.6500 L 0.4600 · ₱45.0K/d
- 2023: ₱0.3600 -21.7% · H 0.5500 L 0.3500 · ₱30.0K/d
- 2024: ₱0.1840 -48.9% · H 0.4100 L 0.1800 · ₱30.3K/d
- 2025: ₱0.1840 +0.0% · H 0.2700 L 0.1750 · ₱17.9K/d
- 2026*: ₱0.2090 +13.6% · H 0.2400 L 0.1820 · ₱12.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
