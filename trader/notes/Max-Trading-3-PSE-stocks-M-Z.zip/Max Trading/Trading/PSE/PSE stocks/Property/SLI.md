---
tags: [trading, pse, stock, sli]
---
**SLI — Sta. Lucia Land, Inc.**
- Status: listed on PSE · sector Property › Property · listed Sep 14, 1987
- Data: 1987-09-14 → 2026-11-06 (5,089 trading days)
- Last close ₱1.74 (2026-11-06) · all-time high ₱20.00 (1997-03-04) · low ₱0.2300 (2004-02-09) · now -91.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1987: ₱1.07 start · H 1.13 L 1.00 · ₱4.1M/d
- 1988: ₱0.9667 -9.4% · H 1.20 L 0.9167 · ₱4.2M/d
- 1989: ₱1.00 +3.4% · H 1.40 L 0.8000 · ₱10.0M/d
- 1990: ₱0.5500 -45.0% · H 1.00 L 0.5500 · ₱2.9M/d
- 1991: ₱0.7000 +27.3% · H 0.8000 L 0.5000 · ₱1.8M/d
- 1992: ₱1.00 +42.9% · H 2.50 L 0.8000 · ₱70.8M/d
- 1993: ₱0.8500 -15.0% · H 1.00 L 0.8000 · ₱2.1M/d
- 1994: ₱1.00 +17.6% · H 2.80 L 0.7500 · ₱17.9M/d
- 1995: ₱6.25 +525.0% · H 10.50 L 1.40 · ₱43.5M/d
- 1996: ₱6.00 -4.0% · H 7.50 L 4.70 · ₱30.9M/d
- 1997: ₱2.40 -60.0% · H 20.00 L 2.40 · ₱18.3M/d
- 1998: ₱2.80 +16.7% · H 2.90 L 1.46 · ₱212.5K/d
- 1999: ₱2.70 -3.6% · H 5.60 L 1.00 · ₱1.9M/d
- 2000: ₱1.80 -33.3% · H 2.75 L 1.80 · ₱19.9M/d
- 2001: ₱0.3000 -83.3% · H 1.10 L 0.3000 · ₱34.9M/d
- 2003: ₱0.3700 start · H 0.3700 L 0.3000 · ₱13.9K/d
- 2004: ₱0.2300 -37.8% · H 0.3000 L 0.2300 · ₱2.6K/d
- 2007: ₱1.60 start · H 2.90 L 1.60 · ₱2.7M/d
- 2008: ₱0.4500 -71.9% · H 1.62 L 0.4400 · ₱1.2M/d
- 2009: ₱0.8200 +82.2% · H 0.9000 L 0.3800 · ₱82.4K/d
- 2010: ₱1.73 +111.0% · H 2.42 L 0.6900 · ₱12.8M/d
- 2011: ₱0.7200 -58.4% · H 1.82 L 0.6400 · ₱3.5M/d
- 2012: ₱0.6600 -8.3% · H 0.8400 L 0.6500 · ₱698.2K/d
- 2013: ₱0.5800 -12.1% · H 1.25 L 0.5800 · ₱5.4M/d
- 2014: ₱0.8000 +37.9% · H 0.9800 L 0.5900 · ₱2.4M/d
- 2015: ₱0.7800 -2.5% · H 0.9800 L 0.6800 · ₱3.1M/d
- 2016: ₱1.09 +39.7% · H 1.26 L 0.7300 · ₱7.0M/d
- 2017: ₱1.01 -7.3% · H 1.12 L 0.9700 · ₱4.9M/d
- 2018: ₱1.25 +23.8% · H 1.26 L 0.9900 · ₱1.6M/d
- 2019: ₱2.48 +98.4% · H 2.80 L 1.24 · ₱3.2M/d
- 2020: ₱1.98 -20.2% · H 2.57 L 1.72 · ₱785.7K/d
- 2021: ₱2.88 +45.5% · H 3.35 L 1.96 · ₱1.9M/d · div ₱0.0400 (1.4%): 20Dec 0.04S
- 2022: ₱3.25 +12.8% · H 3.25 L 2.53 · ₱2.3M/d · div ₱0.0400 (1.2%): 13Dec 0.04S
- 2023: ₱3.40 +4.6% · H 3.49 L 3.01 · ₱396.9K/d · div ₱0.0400 (1.2%): 06Dec 0.04S
- 2024: ₱2.90 -14.7% · H 3.50 L 2.52 · ₱228.3K/d · div ₱0.0400 (1.4%): 27Nov 0.04S
- 2025: ₱2.60 -10.3% · H 2.95 L 2.03 · ₱194.4K/d · div ₱0.0400 (1.5%): 16Oct 0.04
- 2026*: ₱1.74 -33.1% · H 2.60 L 1.65 · ₱313.6K/d · div ₱0.0400 (2.3%): 19Nov 0.04 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
