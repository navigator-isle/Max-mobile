---
tags: [trading, pse, stock, phes]
---
**PHES — Philippine Estates Corporation**
- Status: listed on PSE · sector Property › Property · listed Jan 21, 1985
- Data: 2006-04-17 → 2026-11-06 (3,684 trading days)
- Last close ₱0.4550 (2026-11-06) · all-time high ₱0.9600 (2012-04-04) · low ₱0.0720 (2011-05-31) · now -52.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.1600 start · H 0.2150 L 0.1200 · ₱697.5K/d
- 2007: ₱0.3100 +93.8% · H 0.6700 L 0.1550 · ₱2.5M/d
- 2008: ₱0.1500 -51.6% · H 0.3700 L 0.1400 · ₱2.1M/d
- 2009: ₱0.1050 -30.0% · H 0.3500 L 0.1050 · ₱644.2K/d
- 2010: ₱0.0760 -27.6% · H 0.1250 L 0.0740 · ₱40.8K/d
- 2011: ₱0.2330 +206.6% · H 0.2410 L 0.0720 · ₱358.2K/d
- 2012: ₱0.6500 +179.0% · H 0.9600 L 0.2430 · ₱16.1M/d
- 2013: ₱0.3650 -43.8% · H 0.7000 L 0.3300 · ₱1.0M/d
- 2014: ₱0.3900 +6.8% · H 0.4300 L 0.3250 · ₱679.5K/d
- 2015: ₱0.2850 -26.9% · H 0.3950 L 0.2400 · ₱156.4K/d
- 2016: ₱0.2800 -1.8% · H 0.3000 L 0.1950 · ₱167.8K/d
- 2017: ₱0.3550 +26.8% · H 0.6200 L 0.2600 · ₱4.1M/d
- 2018: ₱0.4700 +32.4% · H 0.5500 L 0.3000 · ₱3.5M/d
- 2019: ₱0.4300 -8.5% · H 0.5400 L 0.3900 · ₱941.3K/d
- 2020: ₱0.4250 -1.2% · H 0.4600 L 0.2800 · ₱363.3K/d
- 2021: ₱0.5100 +20.0% · H 0.7900 L 0.3700 · ₱13.2M/d
- 2022: ₱0.3750 -26.5% · H 0.5100 L 0.3700 · ₱370.1K/d
- 2023: ₱0.3200 -14.7% · H 0.4250 L 0.3000 · ₱70.9K/d
- 2024: ₱0.2550 -20.3% · H 0.4000 L 0.2500 · ₱191.6K/d
- 2025: ₱0.3200 +25.5% · H 0.3850 L 0.2350 · ₱91.5K/d
- 2026*: ₱0.4550 +42.2% · H 0.4900 L 0.3000 · ₱188.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
