---
tags: [trading, pse, stock, str]
---
**STR — Vistamalls, Inc.**
- Status: listed on PSE · sector Property › Property · listed Nov 17, 1970
- Data: 1997-02-10 → 2026-06-01 (3,859 trading days)
- Last close ₱1.02 (2026-06-01) · all-time high ₱25.85 (2018-02-22) · low ₱0.9200 (2005-05-05) · now -96.1% from high
- Cash dividends last 12 months ₱0.0433 = 4.2% yield
- Dividend events on record (2013 → 2026): 10

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1997: ₱1.30 start · H 19.00 L 1.30 · ₱669.4M/d
- 1998: ₱2.00 +53.8% · H 5.25 L 1.00 · ₱123.4M/d
- 1999: ₱2.00 +0.0% · H 3.10 L 1.60 · ₱42.2M/d
- 2000: ₱1.50 -25.0% · H 5.25 L 1.10 · ₱222.3M/d
- 2001: ₱1.40 -6.7% · H 2.60 L 1.30 · ₱27.7M/d
- 2002: ₱1.10 -21.4% · H 2.20 L 1.10 · ₱12.2M/d
- 2003: ₱2.20 +100.0% · H 2.20 L 1.10 · ₱4.5M/d
- 2004: ₱2.00 -9.1% · H 3.40 L 1.60 · ₱13.3M/d
- 2005: ₱2.30 +15.0% · H 3.00 L 0.9200 · ₱81.1K/d
- 2006: ₱2.00 -13.0% · H 2.50 L 1.70 · ₱14.3M/d
- 2012: ₱3.98 start · H 4.50 L 3.55 · ₱457.7K/d
- 2013: ₱3.62 -9.0% · H 4.09 L 3.40 · ₱263.4K/d
- 2014: ₱7.20 +98.9% · H 7.28 L 3.36 · ₱6.2M/d
- 2015: ₱7.00 -2.8% · H 8.49 L 3.89 · ₱13.5M/d
- 2016: ₱6.95 -0.7% · H 8.00 L 4.08 · ₱518.2K/d · div ₱0.0215 (0.3%): 06Oct 0.0215
- 2017: ₱8.81 +26.8% · H 12.30 L 6.23 · ₱69.3K/d · div ₱0.0368 (0.4%): 09Oct 0.0368
- 2018: ₱5.40 -38.7% · H 25.85 L 3.94 · ₱13.3M/d · div ₱0.0489 (0.9%): 08Oct 0.0489
- 2019: ₱5.66 +4.8% · H 7.20 L 4.96 · ₱1.9M/d · div ₱0.0571 (1.0%): 10Oct 0.0571
- 2020: ₱4.24 -25.1% · H 5.93 L 3.12 · ₱583.0K/d · div ₱0.0156 (0.4%): 12Oct 0.0156
- 2021: ₱3.72 -12.3% · H 4.34 L 3.62 · ₱133.3K/d · div ₱0.0161 (0.4%): 12Oct 0.0161
- 2022: ₱2.84 -23.7% · H 4.45 L 2.84 · ₱155.6K/d · div ₱0.0262 (0.9%): 11Oct 0.0262
- 2023: ₱2.41 -15.1% · H 3.30 L 2.25 · ₱42.8K/d · div ₱0.0306 (1.3%): 12Oct 0.0306
- 2024: ₱1.62 -32.8% · H 2.40 L 1.47 · ₱38.9K/d · div ₱0.0365 (2.3%): 27Nov 0.0365
- 2025: ₱1.25 -22.8% · H 1.99 L 1.00 · ₱40.3K/d
- 2026*: ₱1.02 -18.4% · H 1.44 L 1.00 · ₱35.5K/d · div ₱0.0433 (4.2%): 14Jan 0.0433

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
