---
tags: [trading, pse, stock, vreit]
---
**VREIT — VistaREIT, Inc.**
- Status: listed on PSE · sector Property › Property · listed Jun 15, 2022
- Data: 2022-06-15 → 2026-06-01 (963 trading days)
- Last close ₱1.31 (2026-06-01) · all-time high ₱1.95 (2025-06-05) · low ₱1.06 (2025-10-21) · now -32.8% from high
- Cash dividends last 12 months ₱0.1849 = 14.1% yield
- Dividend events on record (2013 → 2026): 15

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱1.65 start · H 1.76 L 1.48 · ₱4.1M/d · div ₱0.0571 (3.5%): 24Aug 0.021, 23Nov 0.0361
- 2023: ₱1.67 +1.2% · H 1.72 L 1.54 · ₱2.2M/d · div ₱0.1574 (9.4%): 03May 0.0386, 30May 0.0392, 30Aug 0.0396, 13Dec 0.04
- 2024: ₱1.89 +13.2% · H 1.90 L 1.66 · ₱1.4M/d · div ₱0.1870 (9.9%): 06May 0.0538, 04Jun 0.04132, 11Sep 0.04523, 12Dec 0.04667
- 2025: ₱1.37 -27.5% · H 1.95 L 1.06 · ₱2.6M/d · div ₱0.1980 (14.5%): 14May 0.05107, 11Jun 0.04912, 11Sep 0.0486, 11Dec 0.0492
- 2026*: ₱1.31 -4.4% · H 1.54 L 1.22 · ₱1.9M/d · div ₱0.0380 (2.9%): 22May 0.038

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
