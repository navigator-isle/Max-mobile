---
tags: [trading, pse, stock, sun]
---
**SUN — Suntrust Resort Holdings, Inc.**
- Status: listed on PSE · sector Property › Property · listed Feb 11, 1959
- Data: 1994-08-18 → 2026-11-04 (6,645 trading days)
- Last close ₱0.4200 (2026-11-04) · all-time high ₱97.00 (1999-10-11) · low ₱0.1400 (2008-11-20) · now -99.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2004-10-07 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱1.12 start · H 1.52 L 1.02 · ₱3.8M/d
- 1995: ₱1.08 -3.6% · H 1.36 L 0.9200 · ₱4.4M/d
- 1996: ₱2.06 +90.7% · H 3.45 L 0.8500 · ₱30.4M/d
- 1997: ₱0.5100 -75.2% · H 3.95 L 0.5100 · ₱28.5M/d
- 1998: ₱1.98 +288.2% · H 3.00 L 0.3400 · ₱7.7M/d
- 1999: ₱24.25 +1124.7% · H 97.00 L 1.82 · ₱343.3M/d
- 2000: ₱0.8300 -96.6% · H 28.50 L 0.5800 · ₱75.3M/d
- 2001: ₱0.5100 -38.6% · H 0.8500 L 0.4100 · ₱2.5M/d
- 2002: ₱0.3000 -41.2% · H 0.6500 L 0.3000 · ₱187.1K/d
- 2003: ₱0.2600 -13.3% · H 0.4100 L 0.2300 · ₱81.9K/d
- 2004: ₱0.9500 +265.4% · H 1.18 L 0.2000 · ₱1.3M/d
- 2005: ₱0.6800 -28.4% · H 1.34 L 0.6600 · ₱2.7M/d
- 2006: ₱0.5900 -13.2% · H 0.7600 L 0.5100 · ₱379.2K/d
- 2007: ₱0.5700 -3.4% · H 1.24 L 0.4700 · ₱2.6M/d
- 2008: ₱0.1500 -73.7% · H 0.5800 L 0.1400 · ₱368.8K/d
- 2009: ₱0.4900 +226.7% · H 0.6500 L 0.2000 · ₱1.0M/d
- 2010: ₱0.4500 -8.2% · H 0.5800 L 0.4300 · ₱468.0K/d
- 2011: ₱0.5100 +13.3% · H 0.6700 L 0.4500 · ₱610.1K/d
- 2012: ₱0.5400 +5.9% · H 0.6000 L 0.5000 · ₱364.6K/d
- 2013: ₱0.8900 +64.8% · H 1.95 L 0.5400 · ₱6.4M/d
- 2014: ₱1.15 +29.2% · H 1.56 L 0.9000 · ₱3.0M/d
- 2015: ₱0.8400 -27.0% · H 1.50 L 0.6500 · ₱2.2M/d
- 2016: ₱0.8600 +2.4% · H 1.30 L 0.7400 · ₱2.0M/d
- 2017: ₱0.8500 -1.2% · H 1.02 L 0.8300 · ₱1.2M/d
- 2018: ₱0.7400 -12.9% · H 0.8800 L 0.6800 · ₱141.3K/d
- 2019: ₱1.23 +66.2% · H 1.71 L 0.6900 · ₱11.9M/d
- 2020: ₱1.67 +35.8% · H 2.15 L 0.9200 · ₱8.1M/d
- 2021: ₱1.12 -32.9% · H 2.40 L 1.07 · ₱3.8M/d
- 2022: ₱0.9900 -11.6% · H 1.13 L 0.9100 · ₱110.3K/d
- 2023: ₱0.8500 -14.1% · H 1.06 L 0.7000 · ₱154.0K/d
- 2024: ₱0.9000 +5.9% · H 1.00 L 0.7500 · ₱188.2K/d
- 2025: ₱0.7600 -15.6% · H 0.9000 L 0.6000 · ₱7.4M/d
- 2026*: ₱0.4200 -44.7% · H 0.7900 L 0.4000 · ₱1.1M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
