---
tags: [trading, pse, stock, rock]
---
**ROCK — Rockwell Land Corporation**
- Status: listed on PSE · sector Property › Property · listed May 11, 2012
- Data: 2012-05-11 → 2026-11-06 (3,444 trading days)
- Last close ₱2.69 (2026-11-06) · all-time high ₱4.90 (2012-05-11) · low ₱1.18 (2022-06-20) · now -45.1% from high
- Cash dividends last 12 months ₱0.1547 = 5.8% yield
- Dividend events on record (2013 → 2026): 14

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱2.43 start · H 4.90 L 2.39 · ₱2.1M/d
- 2013: ₱1.49 -38.7% · H 3.48 L 1.46 · ₱6.3M/d · div ₱0.0368 (2.5%): 22Jul 0.0368
- 2014: ₱1.74 +16.8% · H 2.12 L 1.55 · ₱1.6M/d · div ₱0.0459 (2.6%): 15Jul 0.0459
- 2015: ₱1.40 -19.5% · H 1.93 L 1.38 · ₱767.2K/d · div ₱0.0511 (3.7%): 10Jul 0.0511
- 2016: ₱1.56 +11.4% · H 1.83 L 1.35 · ₱761.1K/d · div ₱0.0537 (3.4%): 08Aug 0.0537
- 2017: ₱2.12 +35.9% · H 2.65 L 1.56 · ₱2.4M/d · div ₱0.0594 (2.8%): 20Jun 0.0594
- 2018: ₱2.01 -5.2% · H 2.23 L 1.90 · ₱915.2K/d · div ₱0.0683 (3.4%): 31Jul 0.0683
- 2019: ₱2.04 +1.5% · H 2.50 L 1.94 · ₱664.6K/d · div ₱0.0831 (4.1%): 30Jul 0.0831
- 2020: ₱1.54 -24.5% · H 2.15 L 1.37 · ₱470.1K/d · div ₱0.0483 (3.1%): 12Oct 0.0483
- 2021: ₱1.48 -3.9% · H 1.64 L 1.40 · ₱526.3K/d · div ₱0.0353 (2.4%): 18Oct 0.0353
- 2022: ₱1.40 -5.4% · H 1.56 L 1.18 · ₱109.2K/d · div ₱0.0537 (3.8%): 13Oct 0.0537
- 2023: ₱1.41 +0.7% · H 1.54 L 1.30 · ₱109.9K/d · div ₱0.0752 (5.3%): 17Aug 0.0752
- 2024: ₱1.51 +7.1% · H 1.60 L 1.36 · ₱717.1K/d · div ₱0.1018 (6.7%): 15Aug 0.1018
- 2025: ₱1.85 +22.5% · H 2.23 L 1.45 · ₱1.4M/d · div ₱0.1212 (6.6%): 06Aug 0.1212
- 2026*: ₱2.69 +45.4% · H 3.33 L 1.76 · ₱1.7M/d · div ₱0.1547 (5.8%): 18Aug 0.1547

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
