---
tags: [trading, pse, stock, win]
---
**WIN — Wellex Industries, Incorporated**
- Status: listed on PSE · sector Property › Property · listed Jan 09, 1958
- Data: 1997-03-17 → 2026-11-03 (4,788 trading days)
- Last close ₱0.3150 (2026-11-03) · all-time high ₱10.25 (1997-03-17) · low ₱0.0580 (2011-05-23) · now -96.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2004-08-12 (÷1.5), 2007-07-02 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1997: ₱0.3000 start · H 10.25 L 0.3000 · ₱13.2M/d
- 1998: ₱0.5000 +66.7% · H 0.6800 L 0.1500 · ₱1.3M/d
- 1999: ₱1.00 +100.0% · H 1.50 L 0.3600 · ₱3.8M/d
- 2000: ₱0.4900 -51.0% · H 1.52 L 0.4000 · ₱6.4M/d
- 2001: ₱0.3300 -32.7% · H 0.6700 L 0.2000 · ₱1.3M/d
- 2002: ₱0.2200 -33.3% · H 0.4200 L 0.2000 · ₱56.5K/d
- 2003: ₱0.3800 +72.7% · H 0.8000 L 0.2200 · ₱112.8K/d
- 2004: ₱0.1800 -52.6% · H 0.4500 L 0.1600 · ₱1.8M/d
- 2005: ₱0.1200 -33.3% · H 0.3600 L 0.1100 · ₱269.7K/d
- 2006: ₱0.1300 +8.3% · H 0.1550 L 0.0800 · ₱343.7K/d
- 2007: ₱0.3000 +130.8% · H 0.7300 L 0.1300 · ₱3.9M/d
- 2008: ₱0.1450 -51.7% · H 0.3000 L 0.1200 · ₱796.7K/d
- 2009: ₱0.1000 -31.0% · H 0.2050 L 0.1000 · ₱166.0K/d
- 2010: ₱0.0710 -29.0% · H 0.1200 L 0.0710 · ₱67.2K/d
- 2011: ₱0.2650 +273.2% · H 0.2800 L 0.0580 · ₱1.1M/d
- 2012: ₱0.3000 +13.2% · H 0.5800 L 0.2600 · ₱7.2M/d
- 2013: ₱0.1950 -35.0% · H 0.3050 L 0.1950 · ₱168.4K/d
- 2014: ₱0.2650 +35.9% · H 0.4000 L 0.1690 · ₱2.4M/d
- 2015: ₱0.2100 -20.8% · H 0.2750 L 0.1620 · ₱381.5K/d
- 2016: ₱0.1940 -7.6% · H 0.2390 L 0.1650 · ₱308.5K/d
- 2017: ₱0.1840 -5.2% · H 0.2480 L 0.1800 · ₱317.3K/d
- 2018: ₱0.2470 +34.2% · H 0.3900 L 0.1720 · ₱4.6M/d
- 2019: ₱0.2020 -18.2% · H 0.2750 L 0.2000 · ₱563.0K/d
- 2020: ₱0.2240 +10.9% · H 0.2500 L 0.1700 · ₱203.3K/d
- 2021: ₱0.2300 +2.7% · H 0.3300 L 0.2180 · ₱523.4K/d
- 2022: ₱0.2300 +0.0% · H 0.3000 L 0.2150 · ₱176.8K/d
- 2023: ₱0.2300 +0.0% · H 0.2750 L 0.2130 · ₱84.0K/d
- 2024: ₱0.2120 -7.8% · H 0.2900 L 0.2020 · ₱222.4K/d
- 2025: ₱0.2600 +22.6% · H 0.3300 L 0.2100 · ₱97.6K/d
- 2026*: ₱0.3150 +21.2% · H 0.3600 L 0.2600 · ₱141.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
