---
tags: [trading, pse, stock, pha]
---
**PHA — Premiere Horizon Alliance Corporation**
- Status: listed on PSE · sector Property › Property · listed May 05, 1997
- Data: 1997-05-05 → 2026-11-06 (5,955 trading days)
- Last close ₱0.2140 (2026-11-06) · all-time high ₱3.80 (1997-08-05) · low ₱0.0900 (2002-09-30) · now -94.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1997: ₱1.10 start · H 3.80 L 1.10 · ₱27.4M/d
- 1998: ₱0.5600 -49.1% · H 1.56 L 0.3000 · ₱3.8M/d
- 1999: ₱0.7500 +33.9% · H 1.38 L 0.4800 · ₱11.2M/d
- 2000: ₱0.1600 -78.7% · H 0.9400 L 0.1600 · ₱848.3K/d
- 2001: ₱0.2000 +25.0% · H 0.4300 L 0.1200 · ₱101.2K/d
- 2002: ₱0.1000 -50.0% · H 0.3000 L 0.0900 · ₱58.7K/d
- 2003: ₱0.2800 +180.0% · H 0.4700 L 0.0900 · ₱289.7K/d
- 2004: ₱0.2700 -3.6% · H 0.3900 L 0.1800 · ₱455.4K/d
- 2005: ₱0.3200 +18.5% · H 0.4100 L 0.2500 · ₱649.6K/d
- 2006: ₱0.3500 +9.4% · H 0.4000 L 0.1900 · ₱373.8K/d
- 2007: ₱1.20 +242.9% · H 1.48 L 0.3300 · ₱5.3M/d
- 2008: ₱0.7200 -40.0% · H 1.42 L 0.5500 · ₱2.5M/d
- 2009: ₱0.3600 -50.0% · H 0.8600 L 0.3500 · ₱4.1M/d
- 2010: ₱0.2550 -29.2% · H 0.3900 L 0.2450 · ₱1.8M/d
- 2011: ₱0.2600 +2.0% · H 0.4100 L 0.2350 · ₱2.7M/d
- 2012: ₱0.3300 +26.9% · H 0.3850 L 0.2700 · ₱1.0M/d
- 2013: ₱0.3000 -9.1% · H 0.3600 L 0.2500 · ₱451.8K/d
- 2014: ₱0.6000 +100.0% · H 0.6700 L 0.2750 · ₱4.4M/d
- 2015: ₱0.4900 -18.3% · H 0.7300 L 0.4350 · ₱1.8M/d
- 2016: ₱0.4600 -6.1% · H 0.4850 L 0.3800 · ₱1.8M/d
- 2017: ₱0.3650 -20.7% · H 0.5000 L 0.3250 · ₱1.8M/d
- 2018: ₱0.3250 -11.0% · H 0.5300 L 0.3150 · ₱1.7M/d · div ₱0.00148 (0.5%): 10May 0.001482
- 2019: ₱0.3400 +4.6% · H 1.62 L 0.3200 · ₱48.3M/d
- 2020: ₱1.10 +223.5% · H 1.17 L 0.1760 · ₱21.8M/d
- 2021: ₱0.5600 -49.1% · H 3.16 L 0.5000 · ₱122.7M/d
- 2022: ₱0.2900 -48.2% · H 0.8500 L 0.2550 · ₱4.6M/d
- 2023: ₱0.1620 -44.1% · H 0.4100 L 0.1610 · ₱1.0M/d
- 2024: ₱0.1740 +7.4% · H 0.2250 L 0.1610 · ₱233.3K/d
- 2025: ₱0.2370 +36.2% · H 0.3700 L 0.1220 · ₱927.0K/d
- 2026*: ₱0.2140 -9.7% · H 0.2420 L 0.1420 · ₱171.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
