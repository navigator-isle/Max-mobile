---
tags: [trading, pse, stock, prmx]
---
**PRMX — Primex Corporation**
- Status: listed on PSE · sector Property › Property · listed Aug 10, 2001
- Data: 2001-08-10 → 2026-11-04 (2,935 trading days)
- Last close ₱1.04 (2026-11-04) · all-time high ₱17.28 (2016-08-02) · low ₱0.4160 (2011-07-18) · now -94.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6
- Splits / stock dividends detected (prices before these dates are as traded then): 2006-06-02 (÷3), 2015-01-05 (÷0.2), 2016-08-17 (÷5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2001: ₱0.5000 start · H 0.5100 L 0.4600 · ₱53.9K/d
- 2002: ₱0.5400 +8.0% · H 0.5400 L 0.5100 · ₱17.9K/d
- 2003: ₱0.5200 -3.7% · H 0.7000 L 0.5000 · ₱29.1K/d
- 2004: ₱0.5600 +7.7% · H 0.5800 L 0.4600 · ₱84.0K/d
- 2005: ₱0.7200 +28.6% · H 0.7400 L 0.5700 · ₱44.4K/d
- 2006: ₱2.40 +233.3% · H 2.40 L 0.7200 · ₱87.0K/d
- 2007: ₱0.7300 -69.6% · H 0.7300 L 0.7300 · ₱68.1K/d
- 2008: ₱0.8400 +15.1% · H 0.8400 L 0.7000 · ₱90.2K/d
- 2009: ₱0.6500 -22.6% · H 1.18 L 0.6100 · ₱122.1K/d
- 2010: ₱0.6660 +2.5% · H 0.6700 L 0.4800 · ₱12.6K/d
- 2011: ₱0.4200 -36.9% · H 0.6640 L 0.4160 · ₱11.9K/d
- 2012: ₱0.7200 +71.4% · H 0.8100 L 0.4200 · ₱72.5K/d
- 2013: ₱0.5200 -27.8% · H 0.7800 L 0.5040 · ₱19.4K/d
- 2014: ₱0.9940 +91.2% · H 1.00 L 0.5100 · ₱173.0K/d
- 2015: ₱8.55 +760.2% · H 8.79 L 4.78 · ₱3.2M/d
- 2016: ₱3.38 -60.5% · H 17.28 L 2.97 · ₱3.3M/d
- 2017: ₱5.72 +69.2% · H 7.30 L 3.53 · ₱10.5M/d
- 2018: ₱3.54 -38.1% · H 5.72 L 2.54 · ₱8.5M/d · div ₱0.0550 (1.6%): 17Jul 0.055
- 2019: ₱2.09 -41.0% · H 3.68 L 1.99 · ₱2.9M/d · div ₱0.0260 (1.2%): 15Jul 0.026
- 2020: ₱1.50 -28.2% · H 2.26 L 1.12 · ₱1.1M/d
- 2021: ₱2.15 +43.3% · H 3.95 L 1.24 · ₱7.2M/d · div ₱0.0242 (1.1%): 13May 0.02, 26Nov 0.0042
- 2022: ₱2.11 -1.9% · H 2.85 L 1.90 · ₱2.7M/d · div ₱0.0320 (1.5%): 14Jul 0.032
- 2023: ₱2.59 +22.7% · H 3.44 L 1.98 · ₱344.8K/d · div ₱0.0027 (0.1%): 01Aug 0.0027
- 2024: ₱1.81 -30.1% · H 2.79 L 1.31 · ₱794.3K/d
- 2025: ₱1.28 -29.3% · H 1.80 L 1.02 · ₱368.4K/d
- 2026*: ₱1.04 -18.8% · H 1.30 L 0.9200 · ₱136.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
