---
tags: [trading, pse, stock, rcr]
---
**RCR — RL Commercial REIT, Inc.**
- Status: listed on PSE · sector Property › Property · listed Sep 14, 2021
- Data: 2021-09-14 → 2026-11-06 (1,259 trading days)
- Last close ₱6.15 (2026-11-06) · all-time high ₱8.80 (2022-01-14) · low ₱4.56 (2023-11-22) · now -30.1% from high
- Cash dividends last 12 months ₱0.4404 = 7.2% yield
- Dividend events on record (2013 → 2026): 22

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱7.61 start · H 7.81 L 6.44 · ₱59.0M/d · div ₱0.0620 (0.8%): 16Nov 0.062
- 2022: ₱5.85 -23.1% · H 8.80 L 4.98 · ₱30.2M/d · div ₱0.3831 (6.5%): 15Feb 0.092, 23May 0.0965, 18Aug 0.0972, 17Nov 0.0974
- 2023: ₱4.89 -16.4% · H 6.10 L 4.56 · ₱12.8M/d · div ₱0.3910 (8.0%): 15Feb 0.0976, 17May 0.0977, 18Aug 0.0978, 20Nov 0.0979
- 2024: ₱5.85 +19.6% · H 6.23 L 4.90 · ₱18.7M/d · div ₱0.4231 (7.2%): 19Feb 0.098, 16May 0.099, 22Aug 0.0992, 19Nov 0.026S, 19Nov 0.1009
- 2025: ₱8.02 +37.1% · H 8.26 L 5.87 · ₱78.8M/d · div ₱0.4166 (5.2%): 19Feb 0.101, 19May 0.1047, 22Aug 0.1049, 20Nov 0.106
- 2026*: ₱6.15 -23.3% · H 8.15 L 5.96 · ₱80.6M/d · div ₱0.4584 (7.5%): 19Feb 0.1112, 18May 0.1115, 25Aug 0.1117, 24Nov 0.124 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
