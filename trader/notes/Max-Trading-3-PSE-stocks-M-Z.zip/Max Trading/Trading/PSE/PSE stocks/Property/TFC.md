---
tags: [trading, pse, stock, tfc]
---
**TFC — PTFC Redevelopment Corporation**
- Status: listed on PSE · sector Property › Property · listed Dec 19, 1955
- Data: 2006-08-09 → 2026-10-27 (896 trading days)
- Last close ₱50.05 (2026-10-27) · all-time high ₱70.00 (2026-07-02) · low ₱10.00 (2006-08-09) · now -28.5% from high
- Cash dividends last 12 months ₱2.50 = 5.0% yield
- Dividend events on record (2013 → 2026): 12
- Splits / stock dividends detected (prices before these dates are as traded then): 2016-03-22 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱10.25 start · H 10.25 L 10.00 · ₱143.2K/d
- 2007: ₱10.50 +2.4% · H 10.75 L 10.00 · ₱47.9K/d
- 2008: ₱10.00 -4.8% · H 10.00 L 10.00 · ₱25.0K/d
- 2009: ₱10.50 +5.0% · H 10.50 L 10.00 · ₱9.4K/d
- 2010: ₱18.00 +71.4% · H 18.00 L 10.50 · ₱5.7K/d
- 2011: ₱16.00 -11.1% · H 31.00 L 12.50 · ₱737.7K/d
- 2012: ₱17.02 +6.4% · H 25.70 L 12.68 · ₱68.9K/d
- 2013: ₱23.00 +35.1% · H 27.00 L 18.00 · ₱152.8K/d · div ₱0.6000 (2.6%): 27Dec 0.6
- 2014: ₱26.50 +15.2% · H 27.00 L 16.22 · ₱16.7K/d · div ₱0.6000 (2.3%): 19Dec 0.6S
- 2015: ₱19.60 -26.0% · H 37.50 L 19.02 · ₱192.2K/d · div ₱0.6000 (3.1%): 28Dec 0.6S
- 2016: ₱30.00 +53.1% · H 68.60 L 10.32 · ₱287.9K/d
- 2017: ₱34.00 +13.3% · H 39.95 L 27.35 · ₱52.8K/d · div ₱0.7500 (2.2%): 03Jan 0.75S
- 2018: ₱40.00 +17.6% · H 42.00 L 29.00 · ₱186.6K/d · div ₱2.50 (6.2%): 02Jan 1S, 27Dec 1.5S
- 2019: ₱49.95 +24.9% · H 59.00 L 38.05 · ₱73.1K/d
- 2020: ₱42.15 -15.6% · H 49.45 L 31.55 · ₱67.9K/d · div ₱1.50 (3.6%): 06Jan 1.5S
- 2021: ₱43.00 +2.0% · H 52.60 L 31.00 · ₱151.0K/d · div ₱1.50 (3.5%): 05Jan 1.5
- 2022: ₱43.25 +0.6% · H 56.45 L 32.95 · ₱57.3K/d · div ₱1.50 (3.5%): 04Jan 1.5
- 2023: ₱49.00 +13.3% · H 64.00 L 40.05 · ₱82.7K/d
- 2024: ₱55.00 +12.2% · H 55.00 L 20.15 · ₱263.8K/d · div ₱2.00 (3.6%): 08Jan 2
- 2025: ₱45.10 -18.0% · H 69.50 L 35.00 · ₱78.6K/d · div ₱2.00 (4.4%): 06Jan 2
- 2026*: ₱50.05 +11.0% · H 70.00 L 38.05 · ₱21.9K/d · div ₱2.50 (5.0%): 08Jan 2.5

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
