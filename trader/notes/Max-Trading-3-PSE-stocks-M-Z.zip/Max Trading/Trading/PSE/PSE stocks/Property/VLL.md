---
tags: [trading, pse, stock, vll]
---
**VLL — Vista Land &amp; Lifescapes, Inc.**
- Status: listed on PSE · sector Property › Property · listed Jun 25, 2007
- Data: 2007-06-25 → 2026-06-01 (4,594 trading days)
- Last close ₱0.9600 (2026-06-01) · all-time high ₱8.59 (2015-03-31) · low ₱0.6900 (2009-03-05) · now -88.8% from high
- Cash dividends last 12 months ₱0.1176 = 12.2% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱6.00 start · H 7.20 L 3.65 · ₱106.8M/d
- 2008: ₱1.02 -83.0% · H 6.00 L 0.9400 · ₱25.4M/d
- 2009: ₱1.88 +84.3% · H 2.80 L 0.6900 · ₱19.6M/d
- 2010: ₱3.17 +68.6% · H 3.60 L 1.56 · ₱29.5M/d
- 2011: ₱2.84 -10.4% · H 3.45 L 2.30 · ₱30.7M/d
- 2012: ₱4.86 +71.1% · H 5.20 L 2.84 · ₱31.4M/d
- 2013: ₱5.20 +7.0% · H 7.05 L 4.40 · ₱69.6M/d · div ₱0.1020 (2.0%): 23Sep 0.102
- 2014: ₱7.20 +38.5% · H 7.20 L 5.07 · ₱98.2M/d · div ₱0.1186 (1.6%): 25Sep 0.11858
- 2015: ₱5.18 -28.1% · H 8.59 L 5.03 · ₱62.3M/d · div ₱0.1357 (2.6%): 25Sep 0.1357
- 2016: ₱4.95 -4.4% · H 6.45 L 3.65 · ₱40.5M/d · div ₱0.1185 (2.4%): 10Oct 0.1185
- 2017: ₱5.99 +21.0% · H 6.40 L 4.65 · ₱24.4M/d · div ₱0.1342 (2.2%): 11Oct 0.1342
- 2018: ₱5.41 -9.7% · H 6.99 L 5.10 · ₱37.1M/d · div ₱0.2252 (4.2%): 10Oct 0.2252
- 2019: ₱7.73 +42.9% · H 8.00 L 5.41 · ₱61.0M/d · div ₱0.2646 (3.4%): 11Oct 0.2646
- 2020: ₱4.68 -39.5% · H 7.60 L 2.91 · ₱22.2M/d · div ₱0.0500 (1.1%): 13Oct 0.05
- 2021: ₱3.53 -24.6% · H 4.81 L 3.35 · ₱11.4M/d · div ₱0.0250 (0.7%): 12Oct 0.025
- 2022: ₱1.65 -53.3% · H 3.53 L 1.39 · ₱6.5M/d · div ₱0.0292 (1.8%): 11Oct 0.0292
- 2023: ₱1.68 +1.8% · H 2.01 L 1.56 · ₱3.0M/d · div ₱0.0620 (3.7%): 13Oct 0.062
- 2024: ₱1.48 -11.9% · H 1.81 L 1.42 · ₱1.4M/d · div ₱0.1120 (7.6%): 27Nov 0.112
- 2025: ₱1.04 -29.7% · H 1.71 L 0.8300 · ₱1.7M/d
- 2026*: ₱0.9600 -7.7% · H 1.38 L 0.9000 · ₱1.4M/d · div ₱0.1176 (12.2%): 15Jan 0.1176

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
