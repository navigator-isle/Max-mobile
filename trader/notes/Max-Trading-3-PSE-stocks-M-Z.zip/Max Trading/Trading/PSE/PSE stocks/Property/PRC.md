---
tags: [trading, pse, stock, prc]
---
**PRC — Philippine Racing Club, Inc.**
- Status: listed on PSE · sector Property › Property · listed Mar 02, 1952
- Data: 2006-04-04 → 2026-11-05 (1,422 trading days)
- Last close ₱5.00 (2026-11-05) · all-time high ₱12.00 (2013-01-07) · low ₱2.00 (2010-09-30) · now -58.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 14

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱3.25 start · H 3.30 L 2.80 · ₱455.0K/d
- 2007: ₱3.55 +9.2% · H 4.40 L 2.90 · ₱1.1M/d
- 2008: ₱2.60 -26.8% · H 3.80 L 2.28 · ₱207.5K/d
- 2009: ₱2.70 +3.8% · H 2.90 L 2.02 · ₱119.3K/d
- 2010: ₱4.00 +48.1% · H 4.85 L 2.00 · ₱1.1M/d
- 2011: ₱7.00 +75.0% · H 7.30 L 4.00 · ₱4.0M/d
- 2012: ₱9.50 +35.7% · H 9.55 L 7.00 · ₱11.7M/d
- 2013: ₱9.70 +2.1% · H 12.00 L 8.50 · ₱3.5M/d · div ₱0.0600 (0.6%): 10Apr 0.06
- 2014: ₱9.45 -2.6% · H 10.28 L 8.80 · ₱2.4M/d · div ₱0.0600 (0.6%): 08Apr 0.06
- 2015: ₱9.40 -0.5% · H 10.00 L 8.50 · ₱7.8M/d · div ₱0.0800 (0.9%): 17Feb 0.08
- 2016: ₱9.89 +5.2% · H 10.00 L 8.00 · ₱2.1M/d · div ₱0.0800 (0.8%): 08Mar 0.08
- 2017: ₱8.99 -9.1% · H 9.94 L 7.70 · ₱636.2K/d · div ₱0.0800 (0.9%): 08Mar 0.08
- 2018: ₱9.48 +5.5% · H 11.98 L 7.80 · ₱535.5K/d · div ₱0.0800 (0.8%): 21Mar 0.08
- 2019: ₱8.85 -6.6% · H 9.50 L 7.00 · ₱125.7K/d · div ₱0.1300 (1.5%): 14Mar 0.08, 23Oct 0.05S
- 2020: ₱7.40 -16.4% · H 8.96 L 6.65 · ₱858.3K/d · div ₱0.0800 (1.1%): 30Apr 0.08
- 2021: ₱7.80 +5.4% · H 7.80 L 5.70 · ₱443.4K/d · div ₱0.0800 (1.0%): 30Apr 0.08
- 2022: ₱7.89 +1.2% · H 7.89 L 4.80 · ₱296.4K/d · div ₱0.0800 (1.0%): 03May 0.08
- 2023: ₱6.40 -18.9% · H 7.87 L 4.90 · ₱28.0K/d · div ₱0.0800 (1.2%): 02May 0.08
- 2024: ₱7.00 +9.4% · H 7.50 L 4.00 · ₱149.1K/d · div ₱0.0800 (1.1%): 29Oct 0.08
- 2025: ₱6.60 -5.7% · H 7.00 L 5.00 · ₱1.4M/d · div ₱0.0800 (1.2%): 24Oct 0.08
- 2026*: ₱5.00 -24.2% · H 7.00 L 5.00 · ₱60.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
