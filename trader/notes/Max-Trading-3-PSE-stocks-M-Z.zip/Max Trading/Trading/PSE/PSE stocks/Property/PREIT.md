---
tags: [trading, pse, stock, preit]
---
**PREIT — Premiere Island Power REIT Corporation**
- Status: listed on PSE · sector Property › Property · listed Dec 15, 2022
- Data: 2022-12-15 → 2026-11-06 (950 trading days)
- Last close ₱0.9000 (2026-11-06) · all-time high ₱2.48 (2025-06-05) · low ₱0.8900 (2026-10-09) · now -63.7% from high
- Cash dividends last 12 months ₱0.0614 = 6.8% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2022: ₱1.60 start · H 1.70 L 1.53 · ₱10.3M/d
- 2023: ₱1.54 -3.7% · H 1.64 L 1.47 · ₱693.2K/d · div ₱0.1340 (8.7%): 09May 0.0682, 04Jul 0.0299, 22Sep 0.0359
- 2024: ₱2.21 +43.5% · H 2.40 L 1.52 · ₱289.1K/d · div ₱0.1753 (7.9%): 19Feb 0.0388, 25Apr 0.0388, 10Jun 0.0326, 12Sep 0.0326, 12Dec 0.0325
- 2025: ₱1.02 -53.8% · H 2.48 L 0.9300 · ₱550.9K/d · div ₱0.1476 (14.5%): 06May 0.0548, 09Jun 0.0332, 09Sep 0.0331, 12Dec 0.0265
- 2026*: ₱0.9000 -11.8% · H 1.28 L 0.8900 · ₱306.9K/d · div ₱0.0349 (3.9%): 15May 0.0349

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
