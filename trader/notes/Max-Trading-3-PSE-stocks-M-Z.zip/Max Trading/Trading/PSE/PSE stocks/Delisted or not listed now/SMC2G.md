---
tags: [trading, pse, stock, smc2g]
---
**SMC2G**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-03-30 → 2020-10-08 (708 trading days)
- Last close ₱76.10 (2020-10-08) · all-time high ₱80.00 (2016-09-14) · low ₱71.20 (2019-01-02) · now -4.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱79.50 start · H 80.00 L 75.00 · ₱4.2M/d
- 2017: ₱76.60 -3.6% · H 79.95 L 76.50 · ₱1.7M/d
- 2018: ₱74.90 -2.2% · H 78.45 L 72.50 · ₱1.8M/d
- 2019: ₱76.00 +1.5% · H 77.00 L 71.20 · ₱2.5M/d
- 2020*: ₱76.10 +0.1% · H 77.85 L 73.75 · ₱2.0M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
