---
tags: [trading, pse, stock, pcp]
---
**PCP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-04 → 2008-06-04 (440 trading days)
- Last close ₱0.2050 (2008-06-04) · all-time high ₱0.6900 (2007-07-18) · low ₱0.0675 (2006-04-25) · now -70.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2006-09-01 (÷0.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.2000 start · H 0.2300 L 0.0675 · ₱2.6M/d
- 2007: ₱0.3200 +60.0% · H 0.6900 L 0.2000 · ₱14.8M/d
- 2008*: ₱0.2050 -35.9% · H 0.3300 L 0.1850 · ₱420.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
