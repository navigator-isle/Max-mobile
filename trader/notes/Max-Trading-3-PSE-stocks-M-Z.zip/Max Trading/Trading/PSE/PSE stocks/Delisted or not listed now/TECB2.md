---
tags: [trading, pse, stock, tecb2]
---
**TECB2**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2017-12-20 → 2020-10-06 (250 trading days)
- Last close ₱0.9800 (2020-10-06) · all-time high ₱1.06 (2018-02-01) · low ₱0.8000 (2018-09-20) · now -7.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2017: ₱1.00 start · H 1.00 L 1.00 · ₱71.5K/d
- 2018: ₱1.01 +1.0% · H 1.06 L 0.8000 · ₱46.5K/d
- 2019: ₱0.9600 -5.0% · H 1.03 L 0.9000 · ₱44.9K/d
- 2020*: ₱0.9800 +2.1% · H 0.9800 L 0.8400 · ₱18.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
