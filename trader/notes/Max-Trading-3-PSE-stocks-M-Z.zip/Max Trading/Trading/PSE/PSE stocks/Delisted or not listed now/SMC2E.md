---
tags: [trading, pse, stock, smc2e]
---
**SMC2E**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-09-21 → 2020-10-09 (782 trading days)
- Last close ₱75.55 (2020-10-09) · all-time high ₱81.60 (2017-04-21) · low ₱71.30 (2019-03-26) · now -7.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱76.00 start · H 80.00 L 76.00 · ₱8.7M/d
- 2016: ₱78.20 +2.9% · H 80.50 L 75.00 · ₱3.2M/d
- 2017: ₱76.50 -2.2% · H 81.60 L 76.50 · ₱2.5M/d
- 2018: ₱73.00 -4.6% · H 79.00 L 72.50 · ₱2.2M/d
- 2019: ₱77.00 +5.5% · H 77.00 L 71.30 · ₱3.8M/d
- 2020*: ₱75.55 -1.9% · H 77.15 L 74.00 · ₱4.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
