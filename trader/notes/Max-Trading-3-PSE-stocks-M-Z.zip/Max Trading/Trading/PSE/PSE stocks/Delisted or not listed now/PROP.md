---
tags: [trading, pse, stock, prop]
---
**PROP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1994-09-30 → 2021-03-12 (6,478 trading days)
- Last close ₱3,380 (2021-03-12) · all-time high ₱4,507 (2019-07-15) · low ₱361.5 (2000-10-20) · now -25.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱1,118 start · H 1,188 L 1,000 · ₱64,735.8B/d
- 1995: ₱1,193 +6.7% · H 1,288 L 821.2 · ₱69,549.3B/d
- 1996: ₱1,589 +33.3% · H 1,789 L 1,185 · ₱1,820,902.5B/d
- 1997: ₱823.7 -48.2% · H 1,748 L 723.7 · ₱542,121.1B/d
- 1998: ₱754.5 -8.4% · H 1,081 L 386.4 · ₱97,087.9B/d
- 1999: ₱776.0 +2.9% · H 1,012 L 668.9 · ₱88,840.0B/d
- 2000: ₱508.2 -34.5% · H 775.3 L 361.5
- 2001: ₱501.3 -1.4% · H 656.3 L 376.6 · ₱113.3M/d
- 2002: ₱417.5 -16.7% · H 659.4 L 403.4 · ₱120.1K/d
- 2003: ₱571.4 +36.8% · H 626.3 L 399.1
- 2004: ₱683.5 +19.6% · H 684.3 L 483.3
- 2005: ₱839.9 +22.9% · H 899.7 L 646.2 · ₱20.5K/d
- 2006: ₱1,262 +50.2% · H 1,280 L 844.9 · ₱132.8B/d
- 2007: ₱1,471 +16.6% · H 1,896 L 1,269 · ₱1,770.0B/d
- 2008: ₱623.8 -57.6% · H 1,485 L 527.8 · ₱422.8B/d
- 2009: ₱1,076 +72.6% · H 1,185 L 518.6 · ₱396.4B/d
- 2010: ₱1,582 +47.0% · H 1,642 L 946.6 · ₱914.1B/d
- 2011: ₱1,481 -6.4% · H 1,640 L 1,288 · ₱915.1B/d
- 2012: ₱2,305 +55.6% · H 2,318 L 1,504 · ₱1,623.9B/d
- 2013: ₱2,205 -4.3% · H 3,070 L 2,154 · ₱4,045.6B/d
- 2014: ₱2,810 +27.4% · H 2,914 L 2,229 · ₱3,942.4B/d
- 2015: ₱2,916 +3.7% · H 3,307 L 2,747 · ₱4,543.7B/d
- 2016: ₱3,066 +5.2% · H 3,700 L 2,370 · ₱4,458.9B/d
- 2017: ₱3,978 +29.7% · H 4,054 L 3,072 · ₱4,735.2B/d
- 2018: ₱3,628 -8.8% · H 4,138 L 3,357 · ₱4,885.4B/d
- 2019: ₱4,155 +14.5% · H 4,507 L 3,714 · ₱6,160.5B/d
- 2020: ₱3,664 -11.8% · H 4,174 L 2,409 · ₱4,364.8B/d
- 2021*: ₱3,380 -7.8% · H 3,785 L 3,363 · ₱4,003.7B/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
