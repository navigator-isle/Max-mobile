---
tags: [trading, pse, stock, pnx3b]
---
**PNX3B**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-12-18 → 2020-10-09 (490 trading days)
- Last close ₱102.3 (2020-10-09) · all-time high ₱122.0 (2016-11-10) · low ₱100.0 (2017-10-19) · now -16.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱106.0 start · H 106.8 L 105.7 · ₱1.9M/d
- 2016: ₱115.0 +8.5% · H 122.0 L 106.0 · ₱480.9K/d
- 2017: ₱109.0 -5.2% · H 121.0 L 100.0 · ₱439.1K/d
- 2018: ₱102.0 -6.4% · H 114.0 L 101.2 · ₱232.0K/d
- 2019: ₱106.7 +4.6% · H 110.0 L 102.0 · ₱167.2K/d
- 2020*: ₱102.3 -4.1% · H 109.7 L 100.0 · ₱300.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
