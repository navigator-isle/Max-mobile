---
tags: [trading, pse, stock, mpi]
---
**MPI**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-12-18 → 2021-03-12 (3,402 trading days)
- Last close ₱3.99 (2021-03-12) · all-time high ₱7.58 (2016-08-01) · low ₱1.50 (2006-12-18) · now -47.4% from high
- Cash dividends last 12 months ₱0.0345 = 0.9% yield
- Dividend events on record (2013 → 2026): 25

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱5.00 start · H 5.40 L 1.50 · ₱3.1M/d
- 2007: ₱4.40 -12.0% · H 5.60 L 3.25 · ₱1.2M/d
- 2008: ₱2.70 -38.6% · H 4.50 L 2.02 · ₱723.1K/d
- 2009: ₱2.60 -3.7% · H 6.60 L 2.50 · ₱39.7M/d
- 2010: ₱3.89 +49.6% · H 4.35 L 2.22 · ₱112.3M/d
- 2011: ₱3.66 -5.9% · H 4.15 L 2.61 · ₱99.0M/d
- 2012: ₱4.45 +21.6% · H 4.60 L 3.48 · ₱117.3M/d
- 2013: ₱4.32 -2.9% · H 6.29 L 4.26 · ₱228.0M/d · div ₱0.0350 (0.8%): 13Mar 0.02, 22Aug 0.015
- 2014: ₱4.60 +6.5% · H 5.30 L 4.10 · ₱110.1M/d · div ₱0.0880 (1.9%): 03Apr 0.022, 26Aug 0.026, 27Nov 0.04S
- 2015: ₱5.20 +13.0% · H 5.44 L 4.21 · ₱152.6M/d · div ₱0.0690 (1.3%): 20Mar 0.037, 26Aug 0.032
- 2016: ₱6.66 +28.1% · H 7.58 L 5.06 · ₱240.9M/d · div ₱0.0930 (1.4%): 23Mar 0.061, 26Aug 0.032
- 2017: ₱6.85 +2.9% · H 7.10 L 6.00 · ₱176.6M/d · div ₱0.1025 (1.5%): 27Mar 0.068, 29Aug 0.0345
- 2018: ₱4.64 -32.3% · H 6.83 L 4.30 · ₱142.3M/d · div ₱0.1105 (2.4%): 23Mar 0.076, 28Aug 0.0345
- 2019: ₱3.48 -25.0% · H 5.23 L 2.69 · ₱129.4M/d · div ₱0.1105 (3.2%): 15Mar 0.076, 14Aug 0.0345
- 2020: ₱4.28 +23.0% · H 4.55 L 2.28 · ₱146.2M/d · div ₱0.1105 (2.6%): 09Mar 0.076, 17Aug 0.0345
- 2021*: ₱3.99 -6.8% · H 4.49 L 3.95 · ₱86.0M/d · div ₱0.1105 (2.8%): 15Mar 0.0279S (upcoming), 15Mar 0.0481 (upcoming), 13Aug 0.0345 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
