---
tags: [trading, pse, stock, pnx4]
---
**PNX4**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2019-11-07 → 2020-10-09 (210 trading days)
- Last close ₱985.0 (2020-10-09) · all-time high ₱1,054 (2020-02-11) · low ₱940.0 (2020-09-04) · now -6.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱1,022 start · H 1,040 L 1,014 · ₱3.6M/d
- 2020*: ₱985.0 -3.6% · H 1,054 L 940.0 · ₱5.1M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
