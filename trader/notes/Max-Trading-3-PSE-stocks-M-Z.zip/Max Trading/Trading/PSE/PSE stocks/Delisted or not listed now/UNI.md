---
tags: [trading, pse, stock, uni]
---
**UNI**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-03 → 2018-05-17 (1,986 trading days)
- Last close ₱0.2460 (2018-05-17) · all-time high ₱0.6200 (2015-03-04) · low ₱0.0550 (2006-04-03) · now -60.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.2900 start · H 0.3500 L 0.0550 · ₱2.9M/d
- 2007: ₱0.3000 +3.4% · H 0.3200 L 0.2450 · ₱2.4M/d
- 2008: ₱0.0800 -73.3% · H 0.2700 L 0.0650 · ₱400.0K/d
- 2009: ₱0.1100 +37.5% · H 0.1400 L 0.0550 · ₱92.6K/d
- 2010: ₱0.1390 +26.4% · H 0.1800 L 0.0975 · ₱90.8K/d
- 2011: ₱0.2050 +47.5% · H 0.2550 L 0.0900 · ₱505.4K/d
- 2012: ₱0.2750 +34.1% · H 0.3700 L 0.2000 · ₱1.3M/d
- 2013: ₱0.1610 -41.5% · H 0.2950 L 0.1360 · ₱162.2K/d
- 2014: ₱0.3000 +86.3% · H 0.5600 L 0.1580 · ₱4.0M/d
- 2015: ₱0.2800 -6.7% · H 0.6200 L 0.2650 · ₱6.0M/d
- 2016: ₱0.2850 +1.8% · H 0.3550 L 0.2300 · ₱1.4M/d
- 2017: ₱0.2200 -22.8% · H 0.3400 L 0.2200 · ₱258.7K/d
- 2018*: ₱0.2460 +11.8% · H 0.2800 L 0.2110 · ₱282.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
