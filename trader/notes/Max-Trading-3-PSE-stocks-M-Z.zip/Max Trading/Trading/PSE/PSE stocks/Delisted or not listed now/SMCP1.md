---
tags: [trading, pse, stock, smcp1]
---
**SMCP1**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2010-12-08 → 2012-10-05 (335 trading days)
- Last close ₱74.00 (2012-10-05) · all-time high ₱118.5 (2010-12-09) · low ₱73.00 (2012-09-18) · now -37.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱90.00 start · H 118.5 L 87.00 · ₱16.9M/d
- 2011: ₱79.30 -11.9% · H 100.0 L 74.60 · ₱1.9M/d
- 2012*: ₱74.00 -6.7% · H 79.50 L 73.00 · ₱952.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
