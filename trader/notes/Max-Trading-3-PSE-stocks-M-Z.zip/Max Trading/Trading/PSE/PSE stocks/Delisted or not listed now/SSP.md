---
tags: [trading, pse, stock, ssp]
---
**SSP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-12-01 → 2021-03-12 (1,519 trading days)
- Last close ₱1.38 (2021-03-12) · all-time high ₱3.15 (2014-12-01) · low ₱0.5500 (2020-03-20) · now -56.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱2.80 start · H 3.15 L 2.35 · ₱39.2M/d
- 2015: ₱1.61 -42.5% · H 2.96 L 1.48 · ₱3.3M/d
- 2016: ₱1.37 -14.9% · H 1.83 L 1.32 · ₱773.3K/d
- 2017: ₱1.99 +45.3% · H 3.13 L 1.37 · ₱4.5M/d
- 2018: ₱1.41 -29.1% · H 2.68 L 1.21 · ₱2.7M/d
- 2019: ₱0.8500 -39.7% · H 1.55 L 0.8500 · ₱301.8K/d
- 2020: ₱1.53 +80.0% · H 1.70 L 0.5500 · ₱4.3M/d
- 2021*: ₱1.38 -9.8% · H 1.69 L 1.36 · ₱5.3M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
