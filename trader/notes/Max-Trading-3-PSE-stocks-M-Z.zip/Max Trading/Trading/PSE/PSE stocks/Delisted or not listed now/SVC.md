---
tags: [trading, pse, stock, svc]
---
**SVC**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-04-03 → 2020-09-25 (3,445 trading days)
- Last close ₱1,449 (2020-09-25) · all-time high ₱2,263 (2014-09-08) · low ₱1,015 (2008-10-28) · now -36.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱1,491 start · H 1,509 L 1,069 · ₱418.4B/d
- 2007: ₱1,901 +27.5% · H 1,933 L 1,380 · ₱1,525.3B/d
- 2008: ₱1,144 -39.9% · H 1,890 L 1,015 · ₱1,141.2B/d
- 2009: ₱1,509 +31.9% · H 1,536 L 1,041 · ₱870.6B/d
- 2010: ₱1,590 +5.4% · H 1,689 L 1,399 · ₱1,197.6B/d
- 2011: ₱1,616 +1.6% · H 1,625 L 1,319 · ₱1,441.1B/d
- 2012: ₱1,725 +6.7% · H 1,832 L 1,586 · ₱1,736.6B/d
- 2013: ₱1,866 +8.2% · H 2,168 L 1,747 · ₱2,920.2B/d
- 2014: ₱2,126 +13.9% · H 2,263 L 1,825 · ₱3,968.1B/d
- 2015: ₱1,530 -28.0% · H 2,245 L 1,481 · ₱2,997.5B/d
- 2016: ₱1,303 -14.9% · H 1,682 L 1,258 · ₱2,006.2B/d
- 2017: ₱1,620 +24.3% · H 1,759 L 1,302 · ₱2,329.3B/d
- 2018: ₱1,443 -10.9% · H 1,767 L 1,371 · ₱2,125.2B/d
- 2019: ₱1,531 +6.1% · H 1,717 L 1,450 · ₱2,039.5B/d
- 2020*: ₱1,449 -5.3% · H 1,578 L 1,027 · ₱1,563.3B/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
