---
tags: [trading, pse, stock, pip]
---
**PIP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2008-02-01 → 2020-06-17 (2,947 trading days)
- Last close ₱1.70 (2020-06-17) · all-time high ₱6.66 (2013-01-08) · low ₱0.6400 (2008-11-27) · now -74.5% from high
- Cash dividends last 12 months ₱0.0440 = 2.6% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2008: ₱0.8500 start · H 3.25 L 0.6400 · ₱9.5M/d
- 2009: ₱2.34 +175.3% · H 2.48 L 0.8400 · ₱9.7M/d
- 2010: ₱2.58 +10.3% · H 3.00 L 2.04 · ₱13.4M/d
- 2011: ₱2.06 -20.2% · H 2.59 L 1.96 · ₱4.5M/d
- 2012: ₱6.52 +216.5% · H 6.52 L 2.09 · ₱16.9M/d
- 2013: ₱4.50 -31.0% · H 6.66 L 4.00 · ₱22.4M/d · div ₱0.0700 (1.6%): 04Jun 0.07
- 2014: ₱4.11 -8.7% · H 5.36 L 4.01 · ₱12.7M/d
- 2015: ₱3.68 -10.5% · H 4.94 L 3.60 · ₱7.4M/d · div ₱0.0660 (1.8%): 07May 0.066S
- 2016: ₱3.24 -12.0% · H 3.99 L 2.90 · ₱6.6M/d · div ₱0.0660 (2.0%): 05May 0.066
- 2017: ₱2.15 -33.6% · H 3.91 L 2.13 · ₱5.9M/d · div ₱0.0690 (3.2%): 15May 0.069
- 2018: ₱1.34 -37.7% · H 3.03 L 1.29 · ₱5.4M/d · div ₱0.0440 (3.3%): 25Apr 0.044
- 2019: ₱1.92 +43.3% · H 2.15 L 1.15 · ₱13.4M/d · div ₱0.0440 (2.3%): 11Jul 0.044
- 2020*: ₱1.70 -11.5% · H 1.92 L 1.30 · ₱2.0M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
