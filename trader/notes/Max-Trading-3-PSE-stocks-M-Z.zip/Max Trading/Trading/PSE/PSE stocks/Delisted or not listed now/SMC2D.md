---
tags: [trading, pse, stock, smc2d]
---
**SMC2D**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-09-21 → 2020-09-08 (832 trading days)
- Last close ₱75.30 (2020-09-08) · all-time high ₱85.00 (2015-12-29) · low ₱71.20 (2019-05-03) · now -11.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱85.00 start · H 85.00 L 77.00 · ₱10.5M/d
- 2016: ₱76.00 -10.6% · H 80.00 L 75.10 · ₱3.5M/d
- 2017: ₱75.65 -0.5% · H 78.50 L 75.20 · ₱1.5M/d
- 2018: ₱74.95 -0.9% · H 77.00 L 71.40 · ₱4.0M/d
- 2019: ₱75.00 +0.1% · H 76.00 L 71.20 · ₱4.7M/d
- 2020*: ₱75.30 +0.4% · H 76.15 L 73.40 · ₱5.3M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
