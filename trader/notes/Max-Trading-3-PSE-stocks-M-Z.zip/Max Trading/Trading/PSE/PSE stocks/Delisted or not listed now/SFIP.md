---
tags: [trading, pse, stock, sfip]
---
**SFIP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2011-07-04 → 2020-10-08 (650 trading days)
- Last close ₱1.46 (2020-10-08) · all-time high ₱6.00 (2011-07-04) · low ₱0.8700 (2011-12-05) · now -75.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-07-28 (÷1.5), 2015-04-24 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱1.15 start · H 6.00 L 0.8700 · ₱45.1K/d
- 2012: ₱1.45 +26.1% · H 1.80 L 0.9000 · ₱64.3K/d
- 2013: ₱1.22 -15.9% · H 1.47 L 1.22 · ₱25.0K/d
- 2014: ₱3.00 +145.9% · H 3.00 L 1.16 · ₱26.5K/d
- 2015: ₱2.69 -10.3% · H 4.05 L 1.70 · ₱53.1K/d
- 2016: ₱2.40 -10.8% · H 3.95 L 1.81 · ₱36.1K/d
- 2017: ₱2.12 -11.7% · H 2.92 L 1.91 · ₱49.6K/d
- 2018: ₱2.15 +1.4% · H 2.27 L 1.85 · ₱19.5K/d
- 2019: ₱1.36 -36.7% · H 2.10 L 1.20 · ₱35.6K/d
- 2020*: ₱1.46 +7.4% · H 1.85 L 1.35 · ₱14.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
