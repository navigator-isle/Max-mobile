---
tags: [trading, pse, stock, mahb]
---
**MAHB**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2006-08-03 → 2021-03-12 (452 trading days)
- Last close ₱2.51 (2021-03-12) · all-time high ₱3.89 (2018-06-13) · low ₱0.3300 (2006-09-14) · now -35.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2018-06-04 (÷0.25)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.3600 start · H 0.6000 L 0.3300 · ₱72.4K/d
- 2007: ₱0.8400 +133.3% · H 0.9900 L 0.3600 · ₱88.0K/d
- 2018: ₱2.27 start · H 3.89 L 1.38 · ₱579.0K/d
- 2019: ₱1.00 -55.9% · H 2.50 L 1.00 · ₱57.3K/d
- 2020: ₱1.93 +93.0% · H 2.91 L 0.9600 · ₱252.6K/d
- 2021*: ₱2.51 +30.1% · H 3.68 L 1.76 · ₱307.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
