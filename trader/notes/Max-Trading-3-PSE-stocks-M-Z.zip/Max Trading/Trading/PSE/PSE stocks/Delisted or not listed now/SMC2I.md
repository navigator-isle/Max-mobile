---
tags: [trading, pse, stock, smc2i]
---
**SMC2I**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-03-30 → 2020-10-08 (932 trading days)
- Last close ₱76.30 (2020-10-08) · all-time high ₱81.70 (2017-11-23) · low ₱40.80 (2019-04-16) · now -6.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱78.00 start · H 79.10 L 75.00 · ₱9.6M/d
- 2017: ₱79.80 +2.3% · H 81.70 L 77.25 · ₱6.0M/d
- 2018: ₱73.50 -7.9% · H 79.80 L 73.10 · ₱3.7M/d
- 2019: ₱75.20 +2.3% · H 77.00 L 40.80 · ₱5.2M/d
- 2020*: ₱76.30 +1.5% · H 79.00 L 74.00 · ₱7.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
