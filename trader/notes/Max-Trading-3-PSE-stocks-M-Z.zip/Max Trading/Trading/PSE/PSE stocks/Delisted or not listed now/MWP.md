---
tags: [trading, pse, stock, mwp]
---
**MWP**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-12-03 → 2020-10-09 (950 trading days)
- Last close ₱101.5 (2020-10-09) · all-time high ₱115.9 (2015-05-04) · low ₱97.50 (2020-04-07) · now -12.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱103.0 start · H 103.0 L 101.0 · ₱5.6M/d
- 2015: ₱107.5 +4.4% · H 115.9 L 102.0 · ₱2.3M/d
- 2016: ₱110.1 +2.4% · H 115.9 L 106.0 · ₱1.5M/d
- 2017: ₱109.4 -0.6% · H 112.9 L 104.3 · ₱1.3M/d
- 2018: ₱98.00 -10.4% · H 108.8 L 98.00 · ₱1.0M/d
- 2019: ₱100.3 +2.3% · H 103.0 L 98.00 · ₱640.6K/d
- 2020*: ₱101.5 +1.2% · H 101.5 L 97.50 · ₱3.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
