---
tags: [trading, pse, stock, prf2a]
---
**PRF2A**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-11-03 → 2019-10-02 (548 trading days)
- Last close ₱1,000 (2019-10-02) · all-time high ₱1,160 (2015-04-27) · low ₱910.0 (2019-05-15) · now -13.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱1,020 start · H 1,048 L 1,016 · ₱3.2M/d
- 2015: ₱1,070 +4.9% · H 1,160 L 1,005 · ₱2.3M/d
- 2016: ₱1,045 -2.3% · H 1,140 L 1,000 · ₱2.9M/d
- 2017: ₱1,060 +1.4% · H 1,090 L 1,020 · ₱2.3M/d
- 2018: ₱980.0 -7.5% · H 1,070 L 932.0 · ₱1.4M/d
- 2019*: ₱1,000 +2.0% · H 1,028 L 910.0 · ₱531.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
