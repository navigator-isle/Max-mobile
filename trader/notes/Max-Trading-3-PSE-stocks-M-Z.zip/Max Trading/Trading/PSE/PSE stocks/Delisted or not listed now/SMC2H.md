---
tags: [trading, pse, stock, smc2h]
---
**SMC2H**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2016-03-30 → 2020-10-08 (868 trading days)
- Last close ₱76.80 (2020-10-08) · all-time high ₱79.70 (2017-08-16) · low ₱71.00 (2019-03-01) · now -3.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱77.10 start · H 79.00 L 75.00 · ₱10.7M/d
- 2017: ₱79.50 +3.1% · H 79.70 L 76.15 · ₱4.9M/d
- 2018: ₱74.50 -6.3% · H 79.60 L 73.00 · ₱2.5M/d
- 2019: ₱75.05 +0.7% · H 79.00 L 71.00 · ₱4.6M/d
- 2020*: ₱76.80 +2.3% · H 77.10 L 74.00 · ₱3.9M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
