---
tags: [trading, pse, stock, pnx3a]
---
**PNX3A**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-12-18 → 2020-10-06 (599 trading days)
- Last close ₱99.60 (2020-10-06) · all-time high ₱111.0 (2016-08-16) · low ₱96.45 (2020-09-04) · now -10.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱103.0 start · H 104.0 L 103.0 · ₱1.9M/d
- 2016: ₱105.0 +1.9% · H 111.0 L 103.5 · ₱1.3M/d
- 2017: ₱103.7 -1.2% · H 108.0 L 100.1 · ₱793.0K/d
- 2018: ₱100.0 -3.6% · H 105.7 L 99.00 · ₱546.0K/d
- 2019: ₱102.3 +2.3% · H 104.0 L 98.75 · ₱371.2K/d
- 2020*: ₱99.60 -2.6% · H 102.5 L 96.45 · ₱696.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
