---
tags: [trading, pse, stock, prf3a]
---
**PRF3A**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2019-06-25 → 2020-10-09 (271 trading days)
- Last close ₱1,060 (2020-10-09) · all-time high ₱1,070 (2020-02-20) · low ₱990.0 (2019-06-25) · now -0.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱1,031 start · H 1,060 L 990.0 · ₱4.5M/d
- 2020*: ₱1,060 +2.8% · H 1,070 L 993.0 · ₱4.0M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
