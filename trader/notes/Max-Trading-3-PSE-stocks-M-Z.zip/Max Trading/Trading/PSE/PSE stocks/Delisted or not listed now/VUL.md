---
tags: [trading, pse, stock, vul]
---
**VUL**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1986-07-03 → 2021-03-12 (6,582 trading days)
- Last close ₱2.35 (2021-03-12) · all-time high ₱3.85 (2021-02-15) · low ₱0.0220 (2004-06-11) · now -39.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2004-06-14 (÷0.1), 2018-11-07 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1986: ₱0.8650 start · H 0.8750 L 0.7850 · ₱97.4K/d
- 1987: ₱1.68 +93.6% · H 2.50 L 0.8600 · ₱896.5K/d
- 1988: ₱1.12 -32.8% · H 1.93 L 0.9875 · ₱560.3K/d
- 1989: ₱1.10 -2.2% · H 1.35 L 1.00 · ₱478.3K/d
- 1990: ₱0.9250 -15.9% · H 1.25 L 0.7750 · ₱218.4K/d
- 1991: ₱0.8500 -8.1% · H 1.05 L 0.7750 · ₱160.7K/d
- 1992: ₱1.30 +52.9% · H 1.35 L 0.8000 · ₱667.9K/d
- 1993: ₱1.45 +11.5% · H 1.60 L 1.15 · ₱963.0K/d
- 1994: ₱0.9000 -37.9% · H 1.50 L 0.8000 · ₱478.0K/d
- 1995: ₱0.8000 -11.1% · H 1.20 L 0.7500 · ₱283.1K/d
- 1996: ₱0.8500 +6.2% · H 1.20 L 0.7500 · ₱960.7K/d
- 1997: ₱0.2200 -74.1% · H 1.80 L 0.2200 · ₱3.2M/d
- 1998: ₱0.2300 +4.5% · H 0.5300 L 0.1100 · ₱147.8K/d
- 1999: ₱0.5900 +156.5% · H 0.8900 L 0.1300 · ₱594.5K/d
- 2000: ₱0.1900 -67.8% · H 0.6500 L 0.1800 · ₱233.4K/d
- 2001: ₱0.2200 +15.8% · H 0.3000 L 0.1500 · ₱103.0K/d
- 2002: ₱0.1800 -18.2% · H 0.2900 L 0.1300 · ₱107.2K/d
- 2003: ₱0.1750 -2.8% · H 0.2300 L 0.1100 · ₱37.6K/d
- 2004: ₱0.1700 -2.9% · H 0.2700 L 0.0220 · ₱77.3K/d
- 2005: ₱0.3300 +94.1% · H 0.4400 L 0.2100 · ₱214.5K/d
- 2006: ₱1.40 +324.2% · H 1.72 L 0.3000 · ₱2.8M/d
- 2007: ₱1.02 -27.1% · H 1.68 L 1.00 · ₱8.5M/d
- 2008: ₱0.6200 -39.2% · H 1.12 L 0.6100 · ₱522.3K/d
- 2009: ₱0.6200 +0.0% · H 0.9100 L 0.4100 · ₱143.7K/d
- 2010: ₱0.8100 +30.6% · H 1.20 L 0.5100 · ₱911.4K/d
- 2011: ₱0.8800 +8.6% · H 1.13 L 0.6800 · ₱934.8K/d
- 2012: ₱1.40 +59.1% · H 2.08 L 0.9000 · ₱3.4M/d
- 2013: ₱1.34 -4.3% · H 2.22 L 1.30 · ₱4.4M/d
- 2014: ₱1.73 +29.1% · H 1.96 L 1.35 · ₱1.8M/d
- 2015: ₱1.08 -37.6% · H 1.76 L 1.00 · ₱762.1K/d
- 2016: ₱1.12 +3.7% · H 1.43 L 0.9800 · ₱793.4K/d
- 2017: ₱0.7800 -30.4% · H 1.17 L 0.6000 · ₱452.0K/d
- 2018: ₱1.60 +105.1% · H 2.88 L 0.6900 · ₱33.1M/d
- 2019: ₱0.8600 -46.2% · H 1.66 L 0.8600 · ₱7.5M/d
- 2020: ₱1.05 +22.1% · H 1.34 L 0.4800 · ₱1.7M/d
- 2021*: ₱2.35 +123.8% · H 3.85 L 1.00 · ₱82.7M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
