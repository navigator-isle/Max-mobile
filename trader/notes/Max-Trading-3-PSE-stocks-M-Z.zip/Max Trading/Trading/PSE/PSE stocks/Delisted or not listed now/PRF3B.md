---
tags: [trading, pse, stock, prf3b]
---
**PRF3B**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2019-06-25 → 2020-10-09 (249 trading days)
- Last close ₱1,075 (2020-10-09) · all-time high ₱1,100 (2020-07-22) · low ₱1,000 (2020-03-27) · now -2.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2019: ₱1,055 start · H 1,082 L 1,002 · ₱3.5M/d
- 2020*: ₱1,075 +1.9% · H 1,100 L 1,000 · ₱1.6M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
