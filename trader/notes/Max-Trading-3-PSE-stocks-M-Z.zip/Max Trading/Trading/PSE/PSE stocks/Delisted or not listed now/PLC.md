---
tags: [trading, pse, stock, plc]
---
**PLC**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 1995-08-28 → 2021-03-12 (5,282 trading days)
- Last close ₱0.4250 (2021-03-12) · all-time high ₱3.40 (1997-02-18) · low ₱0.008 (2002-02-06) · now -87.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 10
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-09-05 (÷1.5), 2003-07-31 (÷10), 2003-10-07 (÷0.1), 2003-10-27 (÷10), 2004-01-12 (÷0.1), 2004-10-28 (÷10), 2004-12-10 (÷0.1), 2004-12-20 (÷10)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱1.00 start · H 1.30 L 0.8500 · ₱3.2M/d
- 1996: ₱1.70 +70.0% · H 2.00 L 0.9500 · ₱10.7M/d
- 1997: ₱0.5500 -67.6% · H 3.40 L 0.4800 · ₱36.4M/d
- 1998: ₱0.3700 -32.7% · H 0.6300 L 0.1200 · ₱3.2M/d
- 1999: ₱0.2800 -24.3% · H 0.5600 L 0.2600 · ₱2.6M/d
- 2000: ₱0.1000 -64.3% · H 0.3400 L 0.0700 · ₱312.4K/d
- 2001: ₱0.0700 -30.0% · H 0.1250 L 0.0600 · ₱195.0K/d
- 2002: ₱0.0220 -68.6% · H 0.1300 L 0.008 · ₱201.0K/d
- 2003: ₱0.0190 -13.6% · H 0.3300 L 0.0180 · ₱195.1K/d
- 2004: ₱0.0460 +142.1% · H 0.4000 L 0.0180 · ₱496.3K/d
- 2005: ₱0.1250 +171.7% · H 0.2400 L 0.0430 · ₱1.8M/d
- 2006: ₱0.1600 +28.0% · H 0.1750 L 0.1150 · ₱1.0M/d
- 2007: ₱0.3300 +106.2% · H 0.7000 L 0.1550 · ₱15.9M/d
- 2008: ₱0.1200 -63.6% · H 0.3400 L 0.1150 · ₱917.7K/d
- 2009: ₱0.2400 +100.0% · H 0.3300 L 0.1100 · ₱1.1M/d
- 2010: ₱0.3100 +29.2% · H 0.3300 L 0.2350 · ₱1.4M/d
- 2011: ₱0.3400 +9.7% · H 0.4800 L 0.2850 · ₱2.5M/d
- 2012: ₱0.3150 -7.4% · H 0.3900 L 0.3000 · ₱1.3M/d
- 2013: ₱0.2700 -14.3% · H 0.3850 L 0.2600 · ₱3.0M/d
- 2014: ₱2.13 +688.9% · H 2.25 L 0.2650 · ₱57.7M/d
- 2015: ₱0.6400 -70.0% · H 2.08 L 0.5700 · ₱35.1M/d · div ₱0.0220 (3.4%): 17Mar 0.022
- 2016: ₱1.17 +82.8% · H 1.22 L 0.4450 · ₱22.7M/d · div ₱0.0215 (1.8%): 07Mar 0.0215
- 2017: ₱1.35 +15.4% · H 1.69 L 1.17 · ₱17.2M/d · div ₱0.0281 (2.1%): 07Mar 0.0281
- 2018: ₱0.8000 -40.7% · H 1.30 L 0.6300 · ₱5.2M/d · div ₱0.0839 (10.5%): 06Mar 0.04, 06Mar 0.04391
- 2019: ₱0.5700 -28.8% · H 1.01 L 0.5600 · ₱4.6M/d · div ₱0.0502 (8.8%): 05Mar 0.05024
- 2020: ₱0.4450 -21.9% · H 0.6000 L 0.2600 · ₱6.6M/d · div ₱0.0502 (11.3%): 03Mar 0.05024
- 2021*: ₱0.4250 -4.5% · H 0.5400 L 0.4150 · ₱6.4M/d · div ₱0.0408 (9.6%): 23Apr 0.04075 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
