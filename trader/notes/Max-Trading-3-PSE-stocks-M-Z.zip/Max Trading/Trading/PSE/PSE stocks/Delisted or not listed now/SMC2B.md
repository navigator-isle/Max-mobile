---
tags: [trading, pse, stock, smc2b]
---
**SMC2B**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2012-09-28 → 2019-09-12 (1,200 trading days)
- Last close ₱76.05 (2019-09-12) · all-time high ₱85.60 (2015-05-25) · low ₱73.95 (2012-12-18) · now -11.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱75.00 start · H 80.00 L 73.95 · ₱1.2M/d
- 2013: ₱76.30 +1.7% · H 82.00 L 74.50 · ₱4.3M/d
- 2014: ₱78.15 +2.4% · H 79.00 L 74.70 · ₱2.8M/d
- 2015: ₱77.40 -1.0% · H 85.60 L 76.00 · ₱1.4M/d
- 2016: ₱80.00 +3.4% · H 81.00 L 75.75 · ₱1.4M/d
- 2017: ₱76.50 -4.4% · H 78.30 L 74.50 · ₱976.3K/d
- 2018: ₱75.00 -2.0% · H 77.50 L 75.00 · ₱2.7M/d
- 2019*: ₱76.05 +1.4% · H 77.00 L 74.00 · ₱522.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
