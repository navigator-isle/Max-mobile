---
tags: [trading, pse, stock, smc2a]
---
**SMC2A**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2012-09-28 → 2015-09-08 (709 trading days)
- Last close ₱74.00 (2015-09-08) · all-time high ₱80.40 (2013-04-29) · low ₱74.00 (2015-09-08) · now -8.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱75.00 start · H 75.00 L 74.75 · ₱66.1M/d
- 2013: ₱76.15 +1.5% · H 80.40 L 74.70 · ₱98.1M/d
- 2014: ₱75.60 -0.7% · H 76.90 L 74.30 · ₱39.5M/d
- 2015*: ₱74.00 -2.1% · H 76.80 L 74.00 · ₱10.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
