---
tags: [trading, pse, stock, prf2b]
---
**PRF2B**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2014-11-03 → 2020-10-08 (637 trading days)
- Last close ₱1,054 (2020-10-08) · all-time high ₱1,490 (2018-12-28) · low ₱911.0 (2019-06-07) · now -29.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱1,030 start · H 1,050 L 1,012 · ₱2.5M/d
- 2015: ₱1,065 +3.4% · H 1,170 L 1,016 · ₱1.8M/d
- 2016: ₱1,160 +8.9% · H 1,239 L 1,030 · ₱844.9K/d
- 2017: ₱1,140 -1.7% · H 1,180 L 1,000 · ₱1.3M/d
- 2018: ₱1,490 +30.7% · H 1,490 L 950.0 · ₱612.6K/d
- 2019: ₱1,049 -29.6% · H 1,100 L 911.0 · ₱898.1K/d
- 2020*: ₱1,054 +0.5% · H 1,115 L 990.0 · ₱425.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
