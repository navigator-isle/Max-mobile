---
tags: [trading, pse, stock, smc2f]
---
**SMC2F**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2015-09-21 → 2020-10-09 (1,017 trading days)
- Last close ₱77.50 (2020-10-09) · all-time high ₱82.70 (2017-10-20) · low ₱72.00 (2019-01-03) · now -6.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱79.90 start · H 80.85 L 78.00 · ₱26.7M/d
- 2016: ₱79.50 -0.5% · H 81.00 L 76.20 · ₱4.4M/d
- 2017: ₱81.95 +3.1% · H 82.70 L 79.00 · ₱3.3M/d
- 2018: ₱75.00 -8.5% · H 81.50 L 74.30 · ₱4.3M/d
- 2019: ₱75.80 +1.1% · H 78.00 L 72.00 · ₱4.1M/d
- 2020*: ₱77.50 +2.2% · H 79.95 L 74.15 · ₱7.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
