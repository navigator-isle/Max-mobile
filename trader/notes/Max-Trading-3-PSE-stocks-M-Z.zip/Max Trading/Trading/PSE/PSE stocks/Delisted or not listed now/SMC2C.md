---
tags: [trading, pse, stock, smc2c]
---
**SMC2C**
- Status: not in the Nov 2026 PSE list (delisted, suspended or renamed)
- Data: 2012-09-28 → 2020-10-09 (1,843 trading days)
- Last close ₱78.00 (2020-10-09) · all-time high ₱89.05 (2015-06-24) · low ₱74.50 (2012-12-20) · now -12.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱74.50 start · H 77.90 L 74.50 · ₱5.9M/d
- 2013: ₱77.50 +4.0% · H 84.00 L 74.50 · ₱7.7M/d
- 2014: ₱78.00 +0.6% · H 82.50 L 75.60 · ₱5.6M/d
- 2015: ₱83.00 +6.4% · H 89.05 L 78.50 · ₱5.7M/d
- 2016: ₱80.40 -3.1% · H 83.00 L 78.50 · ₱3.8M/d
- 2017: ₱80.00 -0.5% · H 83.00 L 80.00 · ₱3.8M/d
- 2018: ₱76.00 -5.0% · H 81.50 L 76.00 · ₱2.4M/d
- 2019: ₱77.50 +2.0% · H 79.00 L 75.00 · ₱1.8M/d
- 2020*: ₱78.00 +0.6% · H 79.00 L 75.50 · ₱2.0M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
