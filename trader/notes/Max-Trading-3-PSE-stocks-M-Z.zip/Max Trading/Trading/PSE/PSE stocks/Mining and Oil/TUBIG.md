---
tags: [trading, pse, stock, tubig]
---
**TUBIG — Tubig Pilipinas Holdings Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Oct 23, 2012
- Data: 2015-01-05 → 2026-10-16 (2,101 trading days)
- Last close ₱0.0630 (2026-10-16) · all-time high ₱0.9700 (2015-01-13) · low ₱0.0120 (2025-08-26) · now -93.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱0.5800 start · H 0.9700 L 0.5600 · ₱830.6K/d
- 2016: ₱0.4500 -22.4% · H 0.5900 L 0.2900 · ₱921.1K/d
- 2017: ₱0.3100 -31.1% · H 0.5300 L 0.3000 · ₱505.5K/d
- 2018: ₱0.3000 -3.2% · H 0.3350 L 0.2850 · ₱168.1K/d
- 2019: ₱0.2700 -10.0% · H 0.3600 L 0.2650 · ₱167.3K/d
- 2020: ₱0.2900 +7.4% · H 0.3300 L 0.1710 · ₱290.0K/d
- 2021: ₱0.2650 -8.6% · H 0.3600 L 0.2600 · ₱385.7K/d
- 2022: ₱0.2000 -24.5% · H 0.3150 L 0.2000 · ₱121.0K/d
- 2023: ₱0.1200 -40.0% · H 0.2280 L 0.1200 · ₱73.1K/d
- 2024: ₱0.1550 +29.2% · H 0.2000 L 0.1160 · ₱79.8K/d
- 2025: ₱0.0280 -81.9% · H 0.1600 L 0.0120 · ₱1.4M/d
- 2026*: ₱0.0630 +125.0% · H 0.0630 L 0.0420 · ₱114.4M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
