---
tags: [trading, pse, stock, nikl]
---
**NIKL — Nickel Asia Corporation**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Nov 22, 2010
- Data: 2010-11-22 → 2026-11-06 (3,888 trading days)
- Last close ₱3.85 (2026-11-06) · all-time high ₱48.45 (2015-01-05) · low ₱1.46 (2020-03-24) · now -92.1% from high
- Cash dividends last 12 months ₱0.2100 = 5.5% yield
- Dividend events on record (2013 → 2026): 26
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-05 (÷0.333), 2015-07-13 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2010: ₱2.88 start · H 2.99 L 2.70 · ₱24.4M/d
- 2011: ₱3.64 +26.2% · H 4.12 L 2.92 · ₱6.4M/d
- 2012: ₱4.29 +17.8% · H 6.30 L 3.73 · ₱5.5M/d
- 2013: ₱5.06 +18.1% · H 7.51 L 4.34 · ₱8.1M/d · div ₱0.3500 (6.9%): 17Apr 0.35
- 2014: ₱15.87 +213.5% · H 15.99 L 5.01 · ₱36.2M/d · div ₱0.8000 (5.0%): 04Apr 0.3, 19Nov 0.5S
- 2015: ₱6.25 -60.6% · H 48.45 L 6.16 · ₱84.9M/d · div ₱1.00 (16.0%): 10Apr 0.3S, 10Apr 0.7
- 2016: ₱7.98 +27.7% · H 8.75 L 3.40 · ₱47.2M/d · div ₱0.0800 (1.0%): 28Mar 0.08
- 2017: ₱6.33 -20.7% · H 8.49 L 5.60 · ₱36.4M/d · div ₱0.0800 (1.3%): 24Mar 0.08
- 2018: ₱2.20 -65.2% · H 6.89 L 1.94 · ₱13.6M/d · div ₱0.4200 (19.1%): 23Mar 0.12, 06Sep 0.3S
- 2019: ₱3.39 +54.1% · H 4.90 L 2.09 · ₱29.4M/d · div ₱0.0700 (2.1%): 25Mar 0.07
- 2020: ₱5.60 +65.2% · H 5.60 L 1.46 · ₱34.0M/d · div ₱0.3000 (5.4%): 24Mar 0.08, 18Aug 0.22S
- 2021: ₱5.35 -4.5% · H 6.32 L 4.70 · ₱38.7M/d · div ₱0.4500 (8.4%): 22Mar 0.09, 22Mar 0.14S, 15Nov 0.22S
- 2022: ₱5.84 +9.2% · H 9.52 L 4.79 · ₱52.9M/d · div ₱0.4500 (7.7%): 21Mar 0.05S, 21Mar 0.17, 21Nov 0.23
- 2023: ₱5.48 -6.2% · H 7.70 L 5.00 · ₱36.0M/d · div ₱0.2400 (4.4%): 24Mar 0.17, 23Nov 0.07S
- 2024: ₱3.49 -36.3% · H 5.27 L 2.97 · ₱10.2M/d · div ₱0.1300 (3.7%): 26Mar 0.05S, 26Mar 0.08
- 2025: ₱3.89 +11.5% · H 4.00 L 2.02 · ₱17.7M/d · div ₱0.1800 (4.6%): 12Mar 0.044S, 12Mar 0.066, 27Nov 0.07S
- 2026*: ₱3.85 -1.0% · H 5.64 L 3.53 · ₱35.3M/d · div ₱0.1400 (3.6%): 11Mar 0.14

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
