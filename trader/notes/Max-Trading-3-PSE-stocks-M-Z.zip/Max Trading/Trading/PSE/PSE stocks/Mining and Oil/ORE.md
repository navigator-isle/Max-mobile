---
tags: [trading, pse, stock, ore]
---
**ORE — Oriental Peninsula Resources Group, Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Dec 19, 2007
- Data: 2007-12-19 → 2026-11-06 (4,284 trading days)
- Last close ₱0.5600 (2026-11-06) · all-time high ₱8.25 (2012-04-17) · low ₱0.3150 (2025-06-19) · now -93.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱3.30 start · H 3.40 L 3.05 · ₱83.1M/d
- 2008: ₱0.4400 -86.7% · H 3.30 L 0.3400 · ₱2.7M/d
- 2009: ₱0.8500 +93.2% · H 1.02 L 0.3500 · ₱555.8K/d
- 2010: ₱3.78 +344.7% · H 4.27 L 0.7500 · ₱28.0M/d
- 2011: ₱3.99 +5.6% · H 5.41 L 2.24 · ₱21.9M/d
- 2012: ₱3.10 -22.3% · H 8.25 L 3.08 · ₱23.1M/d
- 2013: ₱1.40 -54.8% · H 3.86 L 1.16 · ₱2.9M/d
- 2014: ₱2.10 +50.0% · H 2.90 L 1.40 · ₱5.4M/d
- 2015: ₱1.40 -33.3% · H 2.57 L 1.24 · ₱1.0M/d
- 2016: ₱1.06 -24.3% · H 1.43 L 0.8400 · ₱710.9K/d
- 2017: ₱0.9500 -10.4% · H 1.27 L 0.8600 · ₱661.8K/d
- 2018: ₱0.9400 -1.1% · H 1.50 L 0.8200 · ₱2.7M/d
- 2019: ₱0.7500 -20.2% · H 1.06 L 0.7400 · ₱544.8K/d
- 2020: ₱0.8100 +8.0% · H 0.8400 L 0.4300 · ₱596.0K/d
- 2021: ₱0.7800 -3.7% · H 1.31 L 0.7200 · ₱3.3M/d
- 2022: ₱0.7200 -7.7% · H 1.29 L 0.6500 · ₱876.1K/d
- 2023: ₱0.6300 -12.5% · H 1.08 L 0.6300 · ₱830.4K/d
- 2024: ₱0.4400 -30.2% · H 0.6700 L 0.4000 · ₱90.5K/d
- 2025: ₱0.3700 -15.9% · H 0.5300 L 0.3150 · ₱76.8K/d
- 2026*: ₱0.5600 +51.4% · H 0.6500 L 0.3900 · ₱177.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
