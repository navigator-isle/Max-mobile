---
tags: [trading, pse, stock, pxp]
---
**PXP — PXP Energy Corporation**
- Status: listed on PSE · sector Mining and Oil › Oil · listed Sep 12, 2011
- Data: 2011-09-12 → 2026-11-06 (3,685 trading days)
- Last close ₱2.92 (2026-11-06) · all-time high ₱47.00 (2012-06-27) · low ₱1.19 (2016-01-15) · now -93.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱7.02 start · H 9.96 L 4.48 · ₱6.8M/d
- 2012: ₱29.95 +326.6% · H 47.00 L 7.10 · ₱26.7M/d
- 2013: ₱7.77 -74.1% · H 34.00 L 7.60 · ₱3.5M/d
- 2014: ₱5.04 -35.1% · H 9.95 L 5.04 · ₱2.0M/d
- 2015: ₱1.30 -74.2% · H 5.35 L 1.20 · ₱4.7M/d
- 2016: ₱3.31 +154.6% · H 5.38 L 1.19 · ₱20.2M/d
- 2017: ₱7.96 +140.5% · H 10.92 L 2.91 · ₱42.4M/d
- 2018: ₱15.20 +91.0% · H 19.20 L 7.84 · ₱84.7M/d
- 2019: ₱8.64 -43.2% · H 16.20 L 6.84 · ₱23.1M/d
- 2020: ₱11.00 +27.3% · H 13.90 L 3.70 · ₱16.8M/d
- 2021: ₱6.15 -44.1% · H 12.48 L 5.88 · ₱6.6M/d
- 2022: ₱7.67 +24.7% · H 7.67 L 4.10 · ₱2.8M/d
- 2023: ₱3.95 -48.5% · H 8.59 L 3.10 · ₱2.7M/d
- 2024: ₱2.87 -27.3% · H 4.50 L 2.80 · ₱2.0M/d
- 2025: ₱2.38 -17.1% · H 3.38 L 2.00 · ₱3.0M/d
- 2026*: ₱2.92 +22.7% · H 3.90 L 2.31 · ₱4.9M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
