---
tags: [trading, pse, stock, ni]
---
**NI — NiHAO Mineral Resources International, Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Oct 03, 1990
- Data: 1995-11-23 → 2026-11-06 (4,456 trading days)
- Last close ₱0.5200 (2026-11-06) · all-time high ₱27.00 (2007-10-17) · low ₱0.2700 (2025-03-20) · now -98.1% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2009-10-06 (÷3)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱1.10 start · H 1.10 L 1.10 · ₱2.2K/d
- 1996: ₱1.50 +36.4% · H 1.60 L 1.09 · ₱27.0K/d
- 1997: ₱1.48 -1.1% · H 1.57 L 1.37 · ₱22.4K/d
- 1998: ₱1.37 -7.9% · H 1.37 L 1.37 · ₱8.2K/d
- 1999: ₱1.39 +1.8% · H 1.63 L 1.11 · ₱111.6K/d
- 2000: ₱1.25 -10.2% · H 1.57 L 1.05 · ₱188.1K/d
- 2001: ₱1.12 -10.7% · H 1.35 L 1.12 · ₱37.1K/d
- 2002: ₱1.00 -10.5% · H 1.08 L 1.00 · ₱2.6M/d
- 2003: ₱1.00 +0.0% · H 1.00 L 1.00 · ₱120.8K/d
- 2004: ₱0.9333 -6.7% · H 1.00 L 0.9333 · ₱56.2K/d
- 2005: ₱1.00 +7.1% · H 1.17 L 0.9833 · ₱129.3K/d
- 2006: ₱1.05 +5.3% · H 1.05 L 0.9333 · ₱12.5K/d
- 2007: ₱18.75 +1680.1% · H 27.00 L 7.30 · ₱47.9M/d
- 2008: ₱3.70 -80.3% · H 19.00 L 3.45 · ₱4.4M/d
- 2009: ₱4.25 +14.9% · H 15.25 L 3.30 · ₱17.0M/d
- 2010: ₱3.15 -25.9% · H 4.50 L 2.60 · ₱14.4M/d
- 2011: ₱4.51 +43.2% · H 4.51 L 2.10 · ₱27.3M/d
- 2012: ₱4.99 +10.6% · H 12.56 L 4.73 · ₱52.6M/d
- 2013: ₱1.53 -69.3% · H 5.34 L 1.49 · ₱5.9M/d
- 2014: ₱2.30 +50.3% · H 3.23 L 1.57 · ₱4.0M/d
- 2015: ₱2.80 +21.7% · H 4.17 L 2.30 · ₱8.9M/d
- 2016: ₱2.83 +1.1% · H 3.37 L 2.02 · ₱1.3M/d
- 2017: ₱1.51 -46.6% · H 2.88 L 1.43 · ₱355.3K/d
- 2018: ₱1.08 -28.5% · H 1.53 L 1.00 · ₱325.3K/d
- 2019: ₱1.02 -5.6% · H 1.28 L 0.9500 · ₱400.1K/d
- 2020: ₱3.02 +196.1% · H 3.22 L 0.7800 · ₱1.7M/d
- 2021: ₱1.03 -65.9% · H 3.45 L 0.9700 · ₱2.4M/d
- 2022: ₱0.7900 -23.3% · H 1.36 L 0.6400 · ₱173.9K/d
- 2023: ₱0.5500 -30.4% · H 0.8800 L 0.4500 · ₱46.6K/d
- 2024: ₱0.3850 -30.0% · H 1.00 L 0.3450 · ₱298.6K/d
- 2025: ₱0.3150 -18.2% · H 0.6600 L 0.2700 · ₱192.4K/d
- 2026*: ₱0.5200 +65.1% · H 0.6500 L 0.3150 · ₱280.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
