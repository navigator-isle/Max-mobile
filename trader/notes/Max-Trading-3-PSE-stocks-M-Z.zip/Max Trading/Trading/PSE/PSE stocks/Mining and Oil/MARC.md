---
tags: [trading, pse, stock, marc]
---
**MARC — Marcventures Holdings, Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Jan 10, 1958
- Data: 1995-08-24 → 2026-11-06 (5,782 trading days)
- Last close ₱0.7400 (2026-11-06) · all-time high ₱5,900 (1997-01-21) · low ₱0.4950 (2025-07-23) · now -100.0% from high
- Cash dividends last 12 months ₱0.1327 = 17.9% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱400.0 start · H 1,100 L 360.0 · ₱404.8K/d
- 1996: ₱1,700 +325.0% · H 1,950 L 300.0 · ₱252.3K/d
- 1997: ₱170.0 -90.0% · H 5,900 L 170.0 · ₱7.6M/d
- 1998: ₱94.00 -44.7% · H 330.0 L 28.00 · ₱85.5K/d
- 1999: ₱920.0 +878.7% · H 2,900 L 51.00 · ₱2.0M/d
- 2000: ₱90.00 -90.2% · H 1,200 L 71.00 · ₱4.0M/d
- 2001: ₱78.00 -13.3% · H 138.0 L 46.00 · ₱1.4M/d
- 2002: ₱17.00 -78.2% · H 88.00 L 14.00 · ₱245.9K/d
- 2003: ₱3.00 -82.4% · H 19.00 L 2.00 · ₱167.5K/d
- 2004: ₱3.00 +0.0% · H 3.00 L 2.00 · ₱135.0K/d
- 2005: ₱2.00 -33.3% · H 7.00 L 2.00 · ₱548.2K/d
- 2006: ₱3.00 +50.0% · H 3.00 L 2.00 · ₱432.5K/d
- 2010: ₱1.95 start · H 2.60 L 1.70 · ₱4.4M/d
- 2011: ₱1.98 +1.5% · H 2.51 L 1.73 · ₱4.5M/d
- 2012: ₱1.85 -6.6% · H 3.73 L 1.71 · ₱12.5M/d
- 2013: ₱2.95 +59.5% · H 4.01 L 1.56 · ₱11.0M/d · div ₱0.3000 (10.2%): 21Nov 0.3
- 2014: ₱6.70 +127.1% · H 8.00 L 3.08 · ₱33.2M/d · div ₱0.3000 (4.5%): 30Sep 0.15, 16Dec 0.15
- 2015: ₱2.00 -70.1% · H 6.65 L 1.90 · ₱2.9M/d
- 2016: ₱2.43 +21.5% · H 2.61 L 1.36 · ₱2.2M/d
- 2017: ₱1.78 -26.7% · H 2.75 L 1.60 · ₱2.4M/d
- 2018: ₱1.18 -33.7% · H 1.76 L 1.00 · ₱604.2K/d
- 2019: ₱0.9800 -16.9% · H 1.33 L 0.8100 · ₱2.4M/d
- 2020: ₱1.46 +49.0% · H 1.57 L 0.5000 · ₱3.6M/d
- 2021: ₱1.17 -19.9% · H 1.88 L 0.8600 · ₱3.1M/d · div ₱0.1300 (11.1%): 02Dec 0.13S
- 2022: ₱1.20 +2.6% · H 2.44 L 1.16 · ₱5.4M/d
- 2023: ₱1.08 -10.0% · H 1.34 L 0.6600 · ₱1.1M/d
- 2024: ₱0.7500 -30.6% · H 1.10 L 0.5800 · ₱703.9K/d · div ₱0.1000 (13.3%): 11Jan 0.1
- 2025: ₱0.7000 -6.7% · H 0.7700 L 0.4950 · ₱797.8K/d
- 2026*: ₱0.7400 +5.7% · H 0.9200 L 0.5800 · ₱2.0M/d · div ₱0.1327 (17.9%): 13Feb 0.132678

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
