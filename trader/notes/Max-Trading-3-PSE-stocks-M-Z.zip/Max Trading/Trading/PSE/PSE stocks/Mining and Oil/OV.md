---
tags: [trading, pse, stock, ov]
---
**OV — The Philodrill Corporation**
- Status: listed on PSE · sector Mining and Oil › Oil · listed Sep 25, 1969
- Data: 1985-01-07 → 2026-11-05 (4,939 trading days)
- Last close ₱0.0098 (2026-11-05) · all-time high ₱0.0600 (2012-04-26) · low ₱0.0001 (1985-01-07) · now -83.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1985: ₱0.0001 start · H 0.0001 L 0.0001 · ₱139.8K/d
- 1998: ₱0.0001 start · H 0.0001 L 0.0001 · ₱147.2K/d
- 1999: ₱0.0001 +0.0% · H 0.0001 L 0.0001 · ₱210.6K/d
- 2000: ₱0.0001 +0.0% · H 0.0001 L 0.0001 · ₱826.4K/d
- 2005: ₱0.0001 start · H 0.0001 L 0.0001 · ₱713.2K/d
- 2006: ₱0.0092 +9100.0% · H 0.0122 L 0.0001 · ₱1.9M/d
- 2007: ₱0.0274 +197.8% · H 0.0274 L 0.0094 · ₱9.5M/d
- 2008: ₱0.0085 -69.0% · H 0.0309 L 0.0085 · ₱6.3M/d
- 2009: ₱0.0150 +76.5% · H 0.0180 L 0.009 · ₱2.2M/d
- 2010: ₱0.0150 +0.0% · H 0.0150 L 0.0120 · ₱961.4K/d
- 2011: ₱0.0220 +46.7% · H 0.0220 L 0.0130 · ₱5.8M/d
- 2012: ₱0.0390 +77.3% · H 0.0600 L 0.0220 · ₱37.8M/d
- 2013: ₱0.0350 -10.3% · H 0.0460 L 0.0340 · ₱7.9M/d · div ₱0.001 (2.9%): 31May 0.0005, 05Nov 0.0005
- 2014: ₱0.0180 -48.6% · H 0.0400 L 0.0180 · ₱2.5M/d · div ₱0.001 (5.6%): 28Feb 0.0005, 07Nov 0.0005
- 2015: ₱0.0120 -33.3% · H 0.0220 L 0.009 · ₱2.0M/d · div ₱0.000391 (3.3%): 30Oct 0.000391
- 2016: ₱0.0120 +0.0% · H 0.0140 L 0.0096 · ₱857.8K/d · div ₱0.00025 (2.1%): 30Sep 0.00025
- 2017: ₱0.0120 +0.0% · H 0.0150 L 0.0110 · ₱1.2M/d
- 2018: ₱0.0130 +8.3% · H 0.0140 L 0.0110 · ₱549.7K/d
- 2019: ₱0.0110 -15.4% · H 0.0130 L 0.0100 · ₱477.9K/d
- 2020: ₱0.0110 +0.0% · H 0.0120 L 0.0064 · ₱633.3K/d
- 2021: ₱0.0100 -9.1% · H 0.0280 L 0.0087 · ₱5.3M/d
- 2022: ₱0.0098 -2.0% · H 0.0110 L 0.0082 · ₱250.9K/d
- 2023: ₱0.0081 -17.3% · H 0.0098 L 0.007 · ₱149.3K/d
- 2024: ₱0.0075 -7.4% · H 0.0097 L 0.0063 · ₱296.5K/d
- 2025: ₱0.0089 +18.7% · H 0.0099 L 0.007 · ₱740.8K/d
- 2026*: ₱0.0098 +10.1% · H 0.0110 L 0.0077 · ₱528.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
