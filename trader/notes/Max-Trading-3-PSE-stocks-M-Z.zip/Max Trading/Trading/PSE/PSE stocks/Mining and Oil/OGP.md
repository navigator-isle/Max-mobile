---
tags: [trading, pse, stock, ogp]
---
**OGP — OceanaGold (Philippines), Inc.**
- Status: listed on PSE · sector Mining and Oil › Mining · listed May 13, 2024
- Data: 2024-05-13 → 2026-11-06 (610 trading days)
- Last close ₱33.60 (2026-11-06) · all-time high ₱40.00 (2026-01-21) · low ₱12.40 (2024-05-15) · now -16.0% from high
- Cash dividends last 12 months ₱3.45 = 10.3% yield
- Dividend events on record (2013 → 2026): 10

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2024: ₱14.02 start · H 16.10 L 12.40 · ₱25.3M/d · div ₱1.19 (8.5%): 13Aug 0.38, 19Nov 0.81
- 2025: ₱32.20 +129.7% · H 32.20 L 14.26 · ₱26.6M/d · div ₱2.44 (7.6%): 05Mar 0.57, 21May 0.42, 20Aug 0.63, 19Nov 0.8225
- 2026*: ₱33.60 +4.3% · H 40.00 L 28.85 · ₱28.2M/d · div ₱3.35 (10.0%): 04Mar 0.9734, 20May 1.192, 19Aug 0.4621, 18Nov 0.7186 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
