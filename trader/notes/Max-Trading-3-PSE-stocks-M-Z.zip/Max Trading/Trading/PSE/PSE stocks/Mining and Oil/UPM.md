---
tags: [trading, pse, stock, upm]
---
**UPM — United Paragon Mining Corporation**
- Status: listed on PSE · sector Mining and Oil › Mining · listed Aug 31, 1972
- Data: 1992-10-09 → 2026-11-05 (5,834 trading days)
- Last close ₱0.0087 (2026-11-05) · all-time high ₱1.28 (2007-06-12) · low ₱0.0004 (2002-12-19) · now -99.3% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2002-01-21 (÷1.5), 2002-04-24 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1992: ₱0.0183 start · H 0.0186 L 0.0172 · ₱218.1K/d
- 1993: ₱0.0366 +100.0% · H 0.0379 L 0.0172 · ₱3.9M/d
- 1994: ₱0.0200 -45.4% · H 0.0393 L 0.0150 · ₱1.8M/d
- 1995: ₱0.0120 -40.0% · H 0.0300 L 0.0110 · ₱1.3M/d
- 1996: ₱0.0160 +33.3% · H 0.0200 L 0.0100 · ₱3.0M/d
- 1997: ₱0.0042 -73.8% · H 0.0500 L 0.0042 · ₱24.9M/d
- 1998: ₱0.0038 -9.5% · H 0.0074 L 0.0026 · ₱515.3K/d
- 1999: ₱0.0042 +10.5% · H 0.006 L 0.0028 · ₱448.5K/d
- 2000: ₱0.003 -28.6% · H 0.0072 L 0.0024 · ₱197.8K/d
- 2001: ₱0.0019 -36.7% · H 0.0046 L 0.0019 · ₱58.5K/d
- 2002: ₱0.0004 -78.9% · H 0.0032 L 0.0004 · ₱30.3K/d
- 2003: ₱0.0019 +375.0% · H 0.0019 L 0.0005 · ₱25.0K/d
- 2004: ₱0.0036 +89.5% · H 0.0041 L 0.0018 · ₱93.8K/d
- 2005: ₱0.005 +38.9% · H 0.0092 L 0.0031 · ₱236.4K/d
- 2006: ₱0.7200 +14300.0% · H 0.8400 L 0.0048 · ₱889.4K/d
- 2007: ₱0.7500 +4.2% · H 1.28 L 0.6500 · ₱2.7M/d
- 2008: ₱0.0032 -99.6% · H 0.7700 L 0.0032 · ₱278.3K/d
- 2009: ₱0.0075 +134.4% · H 0.0110 L 0.003 · ₱311.6K/d
- 2010: ₱0.0160 +113.3% · H 0.0180 L 0.007 · ₱1.3M/d
- 2011: ₱0.0220 +37.5% · H 0.0270 L 0.0110 · ₱7.7M/d
- 2012: ₱0.0170 -22.7% · H 0.0250 L 0.0140 · ₱3.8M/d
- 2013: ₱0.0095 -44.1% · H 0.0190 L 0.0087 · ₱559.8K/d
- 2014: ₱0.0110 +15.8% · H 0.0140 L 0.0095 · ₱423.9K/d
- 2015: ₱0.0072 -34.5% · H 0.0120 L 0.007 · ₱641.7K/d
- 2016: ₱0.0083 +15.3% · H 0.0160 L 0.007 · ₱857.5K/d
- 2017: ₱0.0067 -19.3% · H 0.0099 L 0.006 · ₱119.5K/d
- 2018: ₱0.0055 -17.9% · H 0.0100 L 0.0055 · ₱227.6K/d
- 2019: ₱0.0052 -5.5% · H 0.0088 L 0.0052 · ₱216.6K/d
- 2020: ₱0.0058 +11.5% · H 0.0071 L 0.0032 · ₱356.3K/d
- 2021: ₱0.0069 +19.0% · H 0.0120 L 0.0057 · ₱1.7M/d
- 2022: ₱0.0054 -21.7% · H 0.0084 L 0.0051 · ₱99.6K/d
- 2023: ₱0.0044 -18.5% · H 0.0059 L 0.0038 · ₱38.5K/d
- 2024: ₱0.0034 -22.7% · H 0.0047 L 0.0028 · ₱71.5K/d
- 2025: ₱0.0058 +70.6% · H 0.0061 L 0.0028 · ₱125.8K/d
- 2026*: ₱0.0087 +50.0% · H 0.0100 L 0.0041 · ₱316.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
