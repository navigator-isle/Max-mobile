---
tags: [trading, pse, stock, scc]
---
**SCC — Semirara Mining and Power Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power and Water · listed Nov 28, 1983
- Data: 2005-02-04 → 2026-11-06 (5,183 trading days)
- Last close ₱10.82 (2026-11-06) · all-time high ₱179.0 (2017-09-11) · low ₱1.19 (2007-01-23) · now -94.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 23
- Splits / stock dividends detected (prices before these dates are as traded then): 2015-01-05 (÷0.25), 2017-09-13 (÷4)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2005: ₱2.35 start · H 4.09 L 1.94 · ₱33.4M/d
- 2006: ₱1.48 -37.1% · H 2.51 L 1.48 · ₱9.3M/d
- 2007: ₱3.56 +141.1% · H 3.89 L 1.19 · ₱12.9M/d
- 2008: ₱2.46 -31.0% · H 5.33 L 2.46 · ₱2.4M/d
- 2009: ₱4.58 +86.4% · H 4.58 L 1.85 · ₱3.5M/d
- 2010: ₱15.42 +236.4% · H 15.92 L 3.92 · ₱17.0M/d
- 2011: ₱18.45 +19.7% · H 20.03 L 13.67 · ₱33.8M/d
- 2012: ₱19.45 +5.4% · H 21.33 L 16.67 · ₱19.8M/d
- 2013: ₱24.00 +23.4% · H 25.25 L 19.07 · ₱22.5M/d · div ₱12.00 (50.0%): 14May 12
- 2014: ₱35.50 +47.9% · H 35.50 L 23.83 · ₱54.4M/d · div ₱12.00 (33.8%): 12May 12
- 2015: ₱136.5 +284.5% · H 168.4 L 111.1 · ₱119.0M/d · div ₱4.00 (2.9%): 04May 4
- 2016: ₱130.0 -4.8% · H 138.0 L 100.8 · ₱78.3M/d · div ₱4.00 (3.1%): 12May 4
- 2017: ₱36.80 -71.7% · H 179.0 L 35.10 · ₱143.8M/d · div ₱10.00 (27.2%): 06Apr 5, 22Aug 5S
- 2018: ₱23.05 -37.4% · H 38.70 L 22.50 · ₱59.1M/d · div ₱2.25 (9.8%): 05Mar 1.25, 16Nov 1S
- 2019: ₱22.00 -4.6% · H 24.90 L 19.76 · ₱40.4M/d · div ₱1.25 (5.7%): 28Mar 1.25
- 2020: ₱13.78 -37.4% · H 22.20 L 8.92 · ₱34.6M/d · div ₱1.25 (9.1%): 10Mar 1.25
- 2021: ₱21.35 +54.9% · H 30.50 L 11.78 · ₱53.4M/d · div ₱3.00 (14.1%): 07Apr 1.25, 20Oct 1.75S
- 2022: ₱34.50 +61.6% · H 44.10 L 22.60 · ₱146.3M/d · div ₱5.00 (14.5%): 11Apr 1.5, 26Oct 3.5
- 2023: ₱30.25 -12.3% · H 36.65 L 27.00 · ₱58.1M/d · div ₱7.00 (23.1%): 05Apr 1.7S, 05Apr 1.8, 20Oct 3.5S
- 2024: ₱34.90 +15.4% · H 35.50 L 28.75 · ₱56.6M/d · div ₱6.00 (17.2%): 08Apr 1.5, 08Apr 2S, 28Oct 2.5S
- 2025: ₱28.25 -19.1% · H 38.60 L 27.25 · ₱50.2M/d · div ₱3.25 (11.5%): 07Apr 0.75S, 07Apr 1.25, 03Nov 1.25
- 2026*: ₱10.82 -61.7% · H 33.20 L 10.50 · ₱53.5M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
