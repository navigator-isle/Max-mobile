---
tags: [trading, pse, stock, srdc]
---
**SRDC — Supercity Realty Development Corporation**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Dec 19, 2003
- Data: 2025-12-18 → 2026-11-06 (152 trading days)
- Last close ₱28.60 (2026-11-06) · all-time high ₱45.95 (2026-01-07) · low ₱1.20 (2025-12-18) · now -37.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2025: ₱9.10 start · H 9.10 L 1.20 · ₱45.7K/d
- 2026*: ₱28.60 +214.3% · H 45.95 L 8.00 · ₱74.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
