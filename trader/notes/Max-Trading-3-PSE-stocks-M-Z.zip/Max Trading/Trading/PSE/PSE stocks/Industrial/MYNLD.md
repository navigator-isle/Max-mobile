---
tags: [trading, pse, stock, mynld]
---
**MYNLD — Maynilad Water Services, Inc.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Nov 07, 2025
- Data: 2025-11-07 → 2026-11-06 (244 trading days)
- Last close ₱16.88 (2026-11-06) · all-time high ₱24.45 (2026-05-13) · low ₱14.10 (2025-11-12) · now -31.0% from high
- Cash dividends last 12 months ₱1.14 = 6.8% yield
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2025: ₱16.90 start · H 16.90 L 14.10 · ₱209.0M/d
- 2026*: ₱16.88 -0.1% · H 24.45 L 15.70 · ₱120.7M/d · div ₱1.14 (6.8%): 06Mar 1.14

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
