---
tags: [trading, pse, stock, perc]
---
**PERC — PetroEnergy Resources Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Aug 11, 2004
- Data: 2004-08-11 → 2026-11-05 (4,621 trading days)
- Last close ₱4.77 (2026-11-05) · all-time high ₱16.50 (2006-08-03) · low ₱1.54 (2004-08-16) · now -71.1% from high
- Cash dividends last 12 months ₱0.0500 = 1.0% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2004: ₱1.80 start · H 2.85 L 1.54 · ₱342.9K/d
- 2005: ₱2.88 +60.3% · H 3.58 L 1.78 · ₱399.0K/d
- 2006: ₱9.80 +239.7% · H 16.50 L 2.85 · ₱8.5M/d
- 2007: ₱9.80 +0.0% · H 13.25 L 9.00 · ₱1.7M/d
- 2008: ₱4.50 -54.1% · H 10.50 L 4.45 · ₱1.6M/d
- 2009: ₱7.40 +64.4% · H 8.30 L 5.00 · ₱2.1M/d
- 2010: ₱6.05 -18.2% · H 8.00 L 4.80 · ₱1.6M/d
- 2011: ₱5.25 -13.2% · H 7.11 L 5.22 · ₱1.8M/d
- 2012: ₱6.10 +16.2% · H 6.74 L 5.30 · ₱457.1K/d
- 2013: ₱5.42 -11.1% · H 7.04 L 5.40 · ₱379.0K/d · div ₱0.0500 (0.9%): 22Jul 0.05
- 2014: ₱6.20 +14.4% · H 7.44 L 5.40 · ₱887.9K/d
- 2015: ₱3.50 -43.5% · H 6.25 L 3.20 · ₱391.4K/d
- 2016: ₱4.15 +18.6% · H 4.25 L 3.12 · ₱147.7K/d
- 2017: ₱6.10 +47.0% · H 8.55 L 3.97 · ₱2.4M/d
- 2018: ₱3.50 -42.6% · H 6.08 L 3.50 · ₱1.3M/d · div ₱0.0500 (1.4%): 20Aug 0.05
- 2019: ₱4.10 +17.1% · H 4.89 L 3.60 · ₱747.0K/d
- 2020: ₱3.74 -8.8% · H 4.25 L 2.30 · ₱225.9K/d
- 2021: ₱4.05 +8.3% · H 4.46 L 3.50 · ₱360.8K/d
- 2022: ₱4.80 +18.5% · H 5.15 L 4.00 · ₱389.3K/d · div ₱0.0500 (1.0%): 10Aug 0.05
- 2023: ₱4.95 +3.1% · H 5.00 L 4.15 · ₱316.0K/d · div ₱0.0500 (1.0%): 13Dec 0.05
- 2024: ₱3.60 -27.3% · H 4.95 L 3.45 · ₱354.1K/d · div ₱0.0500 (1.4%): 07Aug 0.05
- 2025: ₱3.50 -2.8% · H 3.97 L 2.94 · ₱132.3K/d · div ₱0.0500 (1.4%): 11Dec 0.05
- 2026*: ₱4.77 +36.3% · H 5.05 L 3.22 · ₱631.5K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
