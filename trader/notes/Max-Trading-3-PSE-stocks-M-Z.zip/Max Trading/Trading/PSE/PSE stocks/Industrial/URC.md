---
tags: [trading, pse, stock, urc]
---
**URC — Universal Robina Corporation**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Mar 25, 1994
- Data: 1994-03-28 → 2026-11-06 (7,318 trading days)
- Last close ₱61.65 (2026-11-06) · all-time high ₱230.0 (2015-04-06) · low ₱1.41 (1998-08-12) · now -73.2% from high
- Cash dividends last 12 months ₱4.40 = 7.1% yield
- Dividend events on record (2013 → 2026): 26

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱12.68 start · H 19.20 L 11.78 · ₱23.3M/d
- 1995: ₱11.30 -10.9% · H 13.04 L 7.97 · ₱13.2M/d
- 1996: ₱12.83 +13.5% · H 13.48 L 10.00 · ₱17.6M/d
- 1997: ₱4.30 -66.4% · H 13.26 L 3.87 · ₱7.6M/d
- 1998: ₱3.78 -12.1% · H 7.57 L 1.41 · ₱5.6M/d
- 1999: ₱6.26 +65.5% · H 7.48 L 3.83 · ₱6.3M/d
- 2000: ₱4.00 -36.1% · H 6.52 L 3.00 · ₱2.4M/d
- 2001: ₱3.83 -4.3% · H 5.30 L 3.57 · ₱2.4M/d
- 2002: ₱2.39 -37.5% · H 4.78 L 2.35 · ₱2.7M/d
- 2003: ₱4.70 +96.4% · H 5.39 L 2.35 · ₱3.8M/d
- 2004: ₱8.35 +77.8% · H 8.70 L 4.61 · ₱2.4M/d
- 2005: ₱16.96 +103.1% · H 16.96 L 8.09 · ₱1.7M/d
- 2006: ₱19.25 +13.5% · H 23.75 L 16.09 · ₱40.5M/d
- 2007: ₱14.00 -27.3% · H 20.25 L 13.50 · ₱61.1M/d
- 2008: ₱5.80 -58.6% · H 14.75 L 4.60 · ₱17.0M/d
- 2009: ₱16.25 +180.2% · H 16.25 L 5.90 · ₱27.9M/d
- 2010: ₱34.95 +115.1% · H 46.65 L 15.50 · ₱99.3M/d
- 2011: ₱48.00 +37.3% · H 51.90 L 32.50 · ₱105.8M/d
- 2012: ₱83.85 +74.7% · H 83.85 L 48.50 · ₱150.2M/d
- 2013: ₱113.1 +34.9% · H 133.5 L 85.00 · ₱295.1M/d · div ₱2.40 (2.1%): 07May 0.9S, 07May 1.5
- 2014: ₱196.0 +73.3% · H 198.9 L 114.4 · ₱334.0M/d · div ₱1.50 (0.8%): 21Feb 1.5S
- 2015: ₱186.0 -5.1% · H 230.0 L 176.0 · ₱500.0M/d · div ₱1.50 (0.8%): 23Feb 1.5S
- 2016: ₱163.5 -12.1% · H 219.2 L 150.0 · ₱401.6M/d · div ₱3.15 (1.9%): 23Feb 1.5S, 23Feb 1.65
- 2017: ₱151.0 -7.6% · H 183.3 L 132.0 · ₱242.4M/d · div ₱3.15 (2.1%): 24Feb 1.5S, 24Feb 1.65
- 2018: ₱127.0 -15.9% · H 174.0 L 112.8 · ₱166.4M/d · div ₱3.15 (2.5%): 21Feb 1.5S, 21Feb 1.65
- 2019: ₱145.0 +14.2% · H 178.0 L 127.5 · ₱176.1M/d · div ₱3.15 (2.2%): 11Mar 1.5, 26Jun 1.65S
- 2020: ₱152.5 +5.2% · H 162.0 L 95.05 · ₱180.7M/d · div ₱3.15 (2.1%): 19Mar 1.5, 27May 1.65S
- 2021: ₱128.0 -16.1% · H 159.9 L 121.8 · ₱145.3M/d · div ₱3.30 (2.6%): 17May 1.5, 16Aug 1.8S
- 2022: ₱136.0 +6.2% · H 138.0 L 94.00 · ₱164.9M/d · div ₱3.45 (2.5%): 30Mar 1.5, 30Mar 1.95S
- 2023: ₱118.2 -13.1% · H 154.8 L 108.9 · ₱133.7M/d · div ₱3.62 (3.1%): 28Mar 1.5, 29Aug 2.12
- 2024: ₱79.00 -33.2% · H 124.0 L 74.50 · ₱186.4M/d · div ₱3.80 (4.8%): 11Apr 1.9, 29Aug 1.9
- 2025: ₱67.30 -14.8% · H 98.90 L 57.90 · ₱166.7M/d · div ₱4.20 (6.2%): 10Apr 2, 04Sep 2.2S
- 2026*: ₱61.65 -8.4% · H 81.95 L 55.90 · ₱102.3M/d · div ₱4.40 (7.1%): 08Apr 2.1, 03Sep 2.3

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
