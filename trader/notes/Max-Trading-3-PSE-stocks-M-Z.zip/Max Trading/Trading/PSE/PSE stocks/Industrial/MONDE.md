---
tags: [trading, pse, stock, monde]
---
**MONDE — Monde Nissin Corporation**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Jun 01, 2021
- Data: 2021-06-01 → 2026-11-06 (1,332 trading days)
- Last close ₱6.40 (2026-11-06) · all-time high ₱20.25 (2021-09-27) · low ₱5.65 (2025-11-11) · now -68.4% from high
- Cash dividends last 12 months ₱0.4000 = 6.2% yield
- Dividend events on record (2013 → 2026): 8

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱16.20 start · H 20.25 L 13.10 · ₱520.7M/d
- 2022: ₱11.08 -31.6% · H 18.16 L 11.06 · ₱187.4M/d · div ₱0.1400 (1.3%): 05Sep 0.14
- 2023: ₱8.38 -24.4% · H 14.86 L 6.18 · ₱90.9M/d · div ₱0.1200 (1.4%): 13Dec 0.12
- 2024: ₱8.60 +2.6% · H 11.72 L 7.08 · ₱47.3M/d · div ₱0.2600 (3.0%): 09May 0.12, 29Nov 0.14
- 2025: ₱5.80 -32.6% · H 8.60 L 5.65 · ₱48.5M/d · div ₱0.3100 (5.3%): 24Apr 0.15, 03Dec 0.16
- 2026*: ₱6.40 +10.3% · H 7.45 L 5.67 · ₱34.3M/d · div ₱0.5000 (7.8%): 23Apr 0.24, 24Nov 0.26 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
