---
tags: [trading, pse, stock, t]
---
**T — TKC Metals Corporation**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Jul 20, 2001
- Data: 2007-07-27 → 2026-06-01 (3,693 trading days)
- Last close ₱0.3000 (2026-06-01) · all-time high ₱20.00 (2007-08-03) · low ₱0.2800 (2025-04-23) · now -98.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱9.00 start · H 20.00 L 4.40 · ₱11.5M/d
- 2008: ₱2.70 -70.0% · H 8.90 L 2.00 · ₱1.8M/d
- 2009: ₱3.70 +37.0% · H 4.60 L 2.12 · ₱579.3K/d
- 2010: ₱2.50 -32.4% · H 3.99 L 2.50 · ₱655.0K/d
- 2011: ₱2.18 -12.8% · H 4.35 L 1.99 · ₱1.7M/d
- 2012: ₱1.75 -19.7% · H 2.67 L 1.69 · ₱281.6K/d
- 2013: ₱1.83 +4.6% · H 3.05 L 1.59 · ₱1.1M/d
- 2014: ₱1.62 -11.5% · H 2.26 L 1.60 · ₱464.6K/d
- 2015: ₱1.00 -38.3% · H 2.07 L 0.8400 · ₱405.2K/d
- 2016: ₱1.42 +42.0% · H 2.70 L 0.8800 · ₱3.8M/d
- 2017: ₱1.18 -16.9% · H 1.64 L 1.13 · ₱354.2K/d
- 2018: ₱0.8500 -28.0% · H 1.31 L 0.8000 · ₱441.7K/d
- 2019: ₱1.02 +20.0% · H 1.53 L 0.8300 · ₱3.1M/d
- 2020: ₱0.9700 -4.9% · H 1.05 L 0.5800 · ₱303.9K/d
- 2021: ₱0.7800 -19.6% · H 2.15 L 0.7700 · ₱2.5M/d
- 2022: ₱0.5500 -29.5% · H 0.9400 L 0.5100 · ₱54.4K/d
- 2023: ₱0.4150 -24.5% · H 0.8000 L 0.4100 · ₱25.4K/d
- 2024: ₱0.3600 -13.3% · H 0.4900 L 0.3050 · ₱43.3K/d
- 2025: ₱0.4400 +22.2% · H 0.4400 L 0.2800 · ₱240.4K/d
- 2026*: ₱0.3000 -31.8% · H 0.4400 L 0.2800 · ₱30.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
