---
tags: [trading, pse, stock, pizza]
---
**PIZZA — Shakey&#039;s Pizza Asia Ventures, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Dec 15, 2016
- Data: 2016-12-15 → 2026-11-06 (2,388 trading days)
- Last close ₱5.46 (2026-11-06) · all-time high ₱17.28 (2018-02-19) · low ₱4.70 (2020-04-01) · now -68.4% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 9

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱11.50 start · H 12.24 L 11.20 · ₱148.7M/d
- 2017: ₱13.46 +17.0% · H 14.56 L 11.48 · ₱24.0M/d · div ₱0.1000 (0.7%): 01Jun 0.1
- 2018: ₱11.90 -11.6% · H 17.28 L 9.84 · ₱7.9M/d · div ₱0.1000 (0.8%): 11Sep 0.1
- 2019: ₱9.90 -16.8% · H 14.80 L 9.80 · ₱6.7M/d · div ₱0.1000 (1.0%): 16Jul 0.1
- 2020: ₱7.70 -22.2% · H 9.91 L 4.70 · ₱7.2M/d · div ₱0.0100 (0.1%): 11Aug 0.01
- 2021: ₱10.10 +31.2% · H 10.40 L 6.75 · ₱2.9M/d · div ₱0.0200 (0.2%): 12Aug 0.02
- 2022: ₱7.65 -24.3% · H 10.18 L 6.80 · ₱1.7M/d · div ₱0.0300 (0.4%): 29Jun 0.03
- 2023: ₱9.80 +28.1% · H 9.80 L 7.50 · ₱1.8M/d · div ₱0.1000 (1.0%): 17Jul 0.1
- 2024: ₱7.99 -18.5% · H 10.72 L 7.95 · ₱1.5M/d · div ₱0.2000 (2.5%): 14May 0.2
- 2025: ₱6.80 -14.9% · H 8.40 L 6.60 · ₱1.8M/d · div ₱0.2000 (2.9%): 01Aug 0.2
- 2026*: ₱5.46 -19.7% · H 7.25 L 4.90 · ₱1.6M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
