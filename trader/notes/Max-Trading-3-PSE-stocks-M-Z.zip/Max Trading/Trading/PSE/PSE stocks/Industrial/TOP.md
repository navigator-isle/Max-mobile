---
tags: [trading, pse, stock, top]
---
**TOP — Top Line Business Development Corp.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power and Water · listed Apr 08, 2025
- Data: 2025-04-08 → 2026-11-06 (387 trading days)
- Last close ₱1.70 (2026-11-06) · all-time high ₱1.95 (2025-11-27) · low ₱0.3000 (2025-04-08) · now -12.8% from high
- Cash dividends last 12 months ₱0.00342 = 0.2% yield
- Dividend events on record (2013 → 2026): 3

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2025: ₱1.60 start · H 1.95 L 0.3000 · ₱14.7M/d · div ₱0.0053 (0.3%): 21May 0.0032, 03Sep 0.0021S
- 2026*: ₱1.70 +6.2% · H 1.84 L 1.37 · ₱2.5M/d · div ₱0.00342 (0.2%): 04Jun 0.00342

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
