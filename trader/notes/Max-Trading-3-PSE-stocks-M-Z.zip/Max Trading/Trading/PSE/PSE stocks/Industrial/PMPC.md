---
tags: [trading, pse, stock, pmpc]
---
**PMPC — Panasonic Manufacturing Philippines Corporation**
- Status: listed on PSE · sector Industrial › Electrical Components &amp; Equipment · listed Jan 21, 1983
- Data: 2006-04-18 → 2026-11-05 (2,717 trading days)
- Last close ₱7.19 (2026-11-05) · all-time high ₱14.00 (2017-09-28) · low ₱3.37 (2014-07-14) · now -48.6% from high
- Cash dividends last 12 months ₱0.6791 = 9.4% yield
- Dividend events on record (2013 → 2026): 17

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱6.60 start · H 7.00 L 6.30 · ₱348.3K/d
- 2007: ₱6.70 +1.5% · H 7.40 L 6.50 · ₱56.3K/d
- 2008: ₱7.00 +4.5% · H 7.50 L 6.00 · ₱79.1K/d
- 2009: ₱6.50 -7.1% · H 7.00 L 4.20 · ₱118.5K/d
- 2010: ₱6.50 +0.0% · H 7.00 L 6.30 · ₱59.7K/d
- 2011: ₱6.50 +0.0% · H 6.50 L 4.50 · ₱34.9K/d
- 2012: ₱6.00 -7.7% · H 6.75 L 4.50 · ₱30.5K/d
- 2013: ₱6.49 +8.2% · H 6.60 L 4.50 · ₱296.6K/d · div ₱0.1000 (1.5%): 08Apr 0.1
- 2014: ₱4.02 -38.1% · H 6.29 L 3.37 · ₱525.4K/d · div ₱0.1000 (2.5%): 04Apr 0.1
- 2015: ₱3.95 -1.7% · H 4.40 L 3.50 · ₱187.7K/d · div ₱0.1000 (2.5%): 31Mar 0.1
- 2016: ₱5.10 +29.1% · H 5.28 L 3.90 · ₱132.7K/d · div ₱0.2000 (3.9%): 04Apr 0.2
- 2017: ₱8.68 +70.2% · H 14.00 L 5.06 · ₱1.3M/d · div ₱0.7000 (8.1%): 11Apr 0.2, 11Apr 0.5S
- 2018: ₱5.85 -32.6% · H 9.69 L 5.51 · ₱226.9K/d · div ₱1.07 (18.3%): 27Feb 0.2, 01Mar 0.5S, 20Apr 0.3717
- 2019: ₱5.43 -7.2% · H 7.10 L 5.00 · ₱199.5K/d · div ₱0.2099 (3.9%): 02May 0.209918
- 2020: ₱5.39 -0.7% · H 6.07 L 3.50 · ₱92.3K/d · div ₱0.1498 (2.8%): 18May 0.1498S
- 2021: ₱6.00 +11.3% · H 6.83 L 5.41 · ₱247.1K/d · div ₱0.5245 (8.7%): 01Jun 0.5245S
- 2022: ₱5.37 -10.5% · H 6.60 L 5.06 · ₱73.3K/d · div ₱0.2489 (4.6%): 01Jun 0.2489
- 2023: ₱5.80 +8.0% · H 5.90 L 4.57 · ₱35.6K/d · div ₱0.2594 (4.5%): 08Jun 0.2594
- 2024: ₱5.48 -5.5% · H 5.98 L 4.64 · ₱66.6K/d · div ₱0.3298 (6.0%): 07Jun 0.329785
- 2025: ₱10.80 +97.1% · H 10.80 L 5.18 · ₱269.4K/d · div ₱0.7393 (6.8%): 05Jun 0.7393
- 2026*: ₱7.19 -33.4% · H 11.40 L 7.01 · ₱190.4K/d · div ₱0.6791 (9.4%): 05Jun 0.6791

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
