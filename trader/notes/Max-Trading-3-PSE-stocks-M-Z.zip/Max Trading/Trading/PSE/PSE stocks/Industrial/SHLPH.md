---
tags: [trading, pse, stock, shlph]
---
**SHLPH — Shell Pilipinas Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Nov 03, 2016
- Data: 2016-11-03 → 2026-11-06 (2,441 trading days)
- Last close ₱8.00 (2026-11-06) · all-time high ₱80.00 (2017-02-20) · low ₱4.71 (2025-05-27) · now -90.0% from high
- Cash dividends last 12 months ₱0.3000 = 3.8% yield
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2016: ₱69.80 start · H 72.00 L 67.00 · ₱154.3M/d
- 2017: ₱61.00 -12.6% · H 80.00 L 57.30 · ₱61.8M/d · div ₱1.65 (2.7%): 02May 1.65
- 2018: ₱47.75 -21.7% · H 66.20 L 46.20 · ₱35.6M/d · div ₱5.14 (10.8%): 23Mar 5.14
- 2019: ₱32.80 -31.3% · H 50.00 L 31.40 · ₱22.9M/d · div ₱3.00 (9.1%): 02Apr 3
- 2020: ₱20.65 -37.0% · H 34.20 L 14.80 · ₱16.6M/d
- 2021: ₱19.88 -3.7% · H 24.25 L 17.62 · ₱8.3M/d
- 2022: ₱16.90 -15.0% · H 22.20 L 16.50 · ₱4.9M/d · div ₱1.00 (5.9%): 22Aug 1
- 2023: ₱10.94 -35.3% · H 18.56 L 10.94 · ₱1.9M/d
- 2024: ₱7.50 -31.4% · H 11.60 L 7.48 · ₱1.6M/d
- 2025: ₱6.93 -7.6% · H 7.48 L 4.71 · ₱2.6M/d
- 2026*: ₱8.00 +15.4% · H 12.78 L 6.56 · ₱8.7M/d · div ₱0.3000 (3.8%): 10Apr 0.3

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
