---
tags: [trading, pse, stock, mwc]
---
**MWC — Manila Water Company, Inc.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Mar 18, 2005
- Data: 2005-03-18 → 2026-11-06 (5,261 trading days)
- Last close ₱29.65 (2026-11-06) · all-time high ₱44.90 (2026-05-06) · low ₱5.60 (2005-05-17) · now -34.0% from high
- Cash dividends last 12 months ₱2.03 = 6.8% yield
- Dividend events on record (2013 → 2026): 22

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2005: ₱6.20 start · H 6.90 L 5.60 · ₱40.0M/d
- 2006: ₱9.40 +51.6% · H 11.00 L 6.20 · ₱32.5M/d
- 2007: ₱18.50 +96.8% · H 18.75 L 8.90 · ₱66.5M/d
- 2008: ₱13.25 -28.4% · H 19.25 L 11.25 · ₱54.7M/d
- 2009: ₱15.75 +18.9% · H 16.50 L 9.40 · ₱59.7M/d
- 2010: ₱19.18 +21.8% · H 19.50 L 14.75 · ₱41.7M/d
- 2011: ₱19.40 +1.1% · H 19.94 L 16.08 · ₱32.3M/d
- 2012: ₱32.00 +64.9% · H 33.00 L 19.64 · ₱61.4M/d
- 2013: ₱22.00 -31.2% · H 41.00 L 21.35 · ₱87.3M/d · div ₱0.7640 (3.5%): 24Apr 0.382, 07Oct 0.382
- 2014: ₱29.00 +31.8% · H 30.00 L 21.60 · ₱51.8M/d · div ₱0.8062 (2.8%): 03Mar 0.4031, 16Oct 0.4031
- 2015: ₱24.80 -14.5% · H 33.00 L 20.00 · ₱51.9M/d · div ₱0.8150 (3.3%): 03Mar 0.4075, 20Aug 0.4075S
- 2016: ₱29.00 +16.9% · H 32.35 L 24.00 · ₱56.6M/d · div ₱0.8334 (2.9%): 08Mar 0.4167, 12Oct 0.4167
- 2017: ₱28.05 -3.3% · H 33.05 L 27.80 · ₱45.4M/d · div ₱0.8488 (3.0%): 10Mar 0.4244, 12Oct 0.4244
- 2018: ₱28.25 +0.7% · H 29.15 L 23.45 · ₱27.1M/d · div ₱0.8585 (3.0%): 12Mar 0.4302, 12Oct 0.4283
- 2019: ₱10.36 -63.3% · H 27.65 L 6.00 · ₱45.7M/d · div ₱0.9102 (8.8%): 11Mar 0.4551, 09Oct 0.4551
- 2020: ₱15.98 +54.2% · H 16.50 L 8.50 · ₱66.1M/d
- 2021: ₱24.75 +54.9% · H 27.00 L 13.84 · ₱38.6M/d · div ₱0.5310 (2.1%): 29Nov 0.531
- 2022: ₱19.10 -22.8% · H 26.00 L 13.00 · ₱21.0M/d · div ₱0.3790 (2.0%): 28Nov 0.379
- 2023: ₱18.60 -2.6% · H 20.60 L 16.92 · ₱14.0M/d · div ₱0.6190 (3.3%): 11Apr 0.619
- 2024: ₱27.00 +45.2% · H 29.65 L 17.62 · ₱51.3M/d · div ₱1.13 (4.2%): 15Mar 1.129
- 2025: ₱40.30 +49.3% · H 42.45 L 26.40 · ₱77.2M/d · div ₱1.84 (4.6%): 07Mar 0.167S, 07Mar 1.674
- 2026*: ₱29.65 -26.4% · H 44.90 L 29.65 · ₱67.3M/d · div ₱2.03 (6.8%): 12Mar 0.254, 12Mar 1.772

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
