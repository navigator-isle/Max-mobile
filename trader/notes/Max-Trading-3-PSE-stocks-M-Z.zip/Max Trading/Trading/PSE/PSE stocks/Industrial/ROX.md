---
tags: [trading, pse, stock, rox]
---
**ROX — Roxas Holdings,  Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Aug 08, 1996
- Data: 1996-08-08 → 2024-05-20 (4,442 trading days)
- Last close ₱1.45 (2024-05-20) · all-time high ₱8.06 (2014-05-06) · low ₱0.3900 (1998-08-07) · now -82.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 5

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱2.58 start · H 4.00 L 2.58 · ₱5.3M/d
- 1997: ₱0.8400 -67.4% · H 2.54 L 0.7500 · ₱419.9K/d
- 1998: ₱0.7500 -10.7% · H 0.9800 L 0.3900 · ₱171.0K/d
- 1999: ₱0.9100 +21.3% · H 1.52 L 0.6400 · ₱475.8K/d
- 2000: ₱0.8200 -9.9% · H 1.06 L 0.7100 · ₱174.2K/d
- 2001: ₱0.8000 -2.4% · H 1.00 L 0.7300 · ₱163.3K/d
- 2002: ₱0.9000 +12.5% · H 1.00 L 0.6500 · ₱199.0K/d
- 2003: ₱0.9700 +7.8% · H 1.06 L 0.7500 · ₱357.1K/d
- 2004: ₱0.8200 -15.5% · H 1.02 L 0.8000 · ₱238.6K/d
- 2005: ₱1.32 +61.0% · H 1.32 L 0.8500 · ₱336.0K/d
- 2006: ₱2.70 +104.5% · H 4.05 L 1.34 · ₱2.9M/d
- 2007: ₱2.80 +3.7% · H 3.00 L 2.06 · ₱1.1M/d
- 2008: ₱2.70 -3.6% · H 3.60 L 2.00 · ₱2.2M/d
- 2009: ₱2.90 +7.4% · H 3.50 L 2.00 · ₱133.4K/d
- 2010: ₱3.18 +9.7% · H 4.50 L 2.55 · ₱95.5K/d
- 2011: ₱2.34 -26.4% · H 3.49 L 2.01 · ₱55.2K/d
- 2012: ₱2.95 +26.1% · H 3.72 L 2.34 · ₱719.9K/d
- 2013: ₱5.31 +80.0% · H 7.30 L 2.28 · ₱1.2M/d · div ₱0.1200 (2.3%): 27Aug 0.06, 15Nov 0.06
- 2014: ₱6.70 +26.2% · H 8.06 L 5.48 · ₱1.4M/d · div ₱0.2400 (3.6%): 18Aug 0.12, 17Dec 0.12
- 2015: ₱4.79 -28.5% · H 7.09 L 3.80 · ₱130.0K/d · div ₱0.1200 (2.5%): 01Sep 0.12
- 2016: ₱2.75 -42.6% · H 6.34 L 2.65 · ₱96.9K/d
- 2017: ₱4.06 +47.6% · H 5.48 L 2.73 · ₱890.6K/d
- 2018: ₱2.67 -34.2% · H 4.46 L 2.61 · ₱216.9K/d
- 2019: ₱1.80 -32.6% · H 3.02 L 1.79 · ₱123.6K/d
- 2020: ₱1.81 +0.6% · H 1.99 L 1.28 · ₱179.6K/d
- 2021: ₱1.04 -42.5% · H 1.80 L 1.01 · ₱172.5K/d
- 2022: ₱0.7700 -26.0% · H 1.60 L 0.6000 · ₱83.3K/d
- 2023: ₱0.7700 +0.0% · H 0.9100 L 0.5000 · ₱18.9K/d
- 2024*: ₱1.45 +88.3% · H 1.45 L 0.5100 · ₱38.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
