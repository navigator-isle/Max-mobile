---
tags: [trading, pse, stock, mg]
---
**MG — Millennium Global Holdings, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Mar 01, 1976
- Data: 1996-05-24 → 2026-11-05 (2,713 trading days)
- Last close ₱0.0740 (2026-11-05) · all-time high ₱25.00 (1997-02-21) · low ₱0.0560 (2025-11-04) · now -99.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2013-03-21 (÷3)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱4.00 start · H 4.00 L 1.50 · ₱123.1K/d
- 1997: ₱8.50 +112.5% · H 25.00 L 5.50 · ₱202.1K/d
- 1998: ₱10.00 +17.6% · H 10.00 L 10.00 · ₱10.0K/d
- 1999: ₱7.90 -21.0% · H 10.25 L 3.50 · ₱208.2K/d
- 2000: ₱3.00 -62.0% · H 7.50 L 2.50 · ₱1.8M/d
- 2001: ₱1.98 -34.0% · H 1.98 L 1.98 · ₱17.7M/d
- 2004: ₱3.50 start · H 3.50 L 2.95 · ₱3.2K/d
- 2005: ₱2.50 -28.6% · H 3.50 L 2.10 · ₱1.5M/d
- 2006: ₱2.00 -20.0% · H 2.50 L 2.00 · ₱2.2M/d
- 2013: ₱0.3700 start · H 0.6600 L 0.3500 · ₱407.2K/d
- 2014: ₱0.3650 -1.4% · H 0.5800 L 0.3600 · ₱1.3M/d
- 2015: ₱0.2800 -23.3% · H 0.3850 L 0.2500 · ₱389.0K/d
- 2016: ₱0.2490 -11.1% · H 0.3100 L 0.2400 · ₱254.6K/d
- 2017: ₱0.2040 -18.1% · H 0.3850 L 0.1880 · ₱2.5M/d
- 2018: ₱0.1760 -13.7% · H 0.2200 L 0.1600 · ₱303.1K/d
- 2019: ₱0.1530 -13.1% · H 0.2350 L 0.1530 · ₱290.6K/d
- 2020: ₱0.2190 +43.1% · H 0.2650 L 0.1050 · ₱594.5K/d
- 2021: ₱0.1590 -27.4% · H 0.5400 L 0.1450 · ₱5.8M/d
- 2022: ₱0.1140 -28.3% · H 0.1620 L 0.1020 · ₱76.4K/d
- 2023: ₱0.1010 -11.4% · H 0.1410 L 0.0900 · ₱51.8K/d
- 2024: ₱0.0940 -6.9% · H 0.1250 L 0.0800 · ₱50.7K/d
- 2025: ₱0.0600 -36.2% · H 0.0880 L 0.0560 · ₱26.7K/d
- 2026*: ₱0.0740 +23.3% · H 0.0770 L 0.0580 · ₱18.7K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
