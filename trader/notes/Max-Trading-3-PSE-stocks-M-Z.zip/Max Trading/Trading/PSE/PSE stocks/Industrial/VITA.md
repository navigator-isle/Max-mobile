---
tags: [trading, pse, stock, vita]
---
**VITA — Vitarich Corporation**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Feb 08, 1995
- Data: 1995-02-08 → 2026-11-06 (6,714 trading days)
- Last close ₱0.4800 (2026-11-06) · all-time high ₱11.25 (1995-02-08) · low ₱0.0950 (2009-03-19) · now -95.7% from high
- Cash dividends last 12 months ₱0.0491 = 10.2% yield
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱7.20 start · H 11.25 L 7.00 · ₱10.4M/d
- 1996: ₱2.85 -60.4% · H 7.00 L 2.14 · ₱2.3M/d
- 1997: ₱0.6800 -76.1% · H 3.50 L 0.6800 · ₱1.2M/d
- 1998: ₱0.4100 -39.7% · H 0.9600 L 0.2000 · ₱325.1K/d
- 1999: ₱0.6500 +58.5% · H 1.58 L 0.3600 · ₱819.3K/d
- 2000: ₱0.4000 -38.5% · H 0.7700 L 0.3500 · ₱134.4K/d
- 2001: ₱0.3800 -5.0% · H 0.5500 L 0.3500 · ₱165.6K/d
- 2002: ₱0.3200 -15.8% · H 0.4900 L 0.2000 · ₱95.2K/d
- 2003: ₱0.2600 -18.8% · H 0.3500 L 0.1800 · ₱116.0K/d
- 2004: ₱0.2700 +3.8% · H 0.3500 L 0.2000 · ₱195.6K/d
- 2005: ₱0.2900 +7.4% · H 0.3200 L 0.2500 · ₱189.3K/d
- 2006: ₱0.2200 -24.1% · H 0.2900 L 0.1900 · ₱171.7K/d
- 2007: ₱0.3800 +72.7% · H 0.5000 L 0.2600 · ₱373.5K/d
- 2008: ₱0.1650 -56.6% · H 0.3800 L 0.1500 · ₱83.1K/d
- 2009: ₱0.3500 +112.1% · H 0.4200 L 0.0950 · ₱140.2K/d
- 2010: ₱0.2900 -17.1% · H 0.4100 L 0.2400 · ₱111.6K/d
- 2011: ₱0.4400 +51.7% · H 0.8800 L 0.2500 · ₱1.1M/d
- 2012: ₱0.9400 +113.6% · H 1.52 L 0.4500 · ₱3.6M/d
- 2013: ₱0.5900 -37.2% · H 1.03 L 0.5500 · ₱1.1M/d
- 2014: ₱0.8200 +39.0% · H 1.20 L 0.6000 · ₱7.5M/d
- 2015: ₱0.6000 -26.8% · H 0.8700 L 0.5900 · ₱954.2K/d
- 2016: ₱1.36 +126.7% · H 2.97 L 0.5600 · ₱30.9M/d
- 2017: ₱1.96 +44.1% · H 2.50 L 1.50 · ₱18.8M/d
- 2018: ₱1.99 +1.5% · H 3.80 L 1.38 · ₱36.9M/d
- 2019: ₱1.20 -39.7% · H 2.19 L 1.07 · ₱8.5M/d
- 2020: ₱0.9100 -24.2% · H 1.30 L 0.7100 · ₱9.1M/d
- 2021: ₱0.7400 -18.7% · H 1.05 L 0.6900 · ₱2.8M/d
- 2022: ₱0.6000 -18.9% · H 0.7200 L 0.5200 · ₱313.1K/d
- 2023: ₱0.5200 -13.3% · H 0.7300 L 0.4750 · ₱339.0K/d
- 2024: ₱0.5400 +3.8% · H 0.8000 L 0.4200 · ₱1.7M/d
- 2025: ₱0.5300 -1.9% · H 0.7200 L 0.4900 · ₱3.4M/d
- 2026*: ₱0.4800 -9.4% · H 0.6200 L 0.4750 · ₱341.0K/d · div ₱0.0491 (10.2%): 14Apr 0.049111

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
