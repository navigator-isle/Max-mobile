---
tags: [trading, pse, stock, mwide]
---
**MWIDE — Megawide Construction Corporation**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Feb 18, 2011
- Data: 2011-02-18 → 2026-11-06 (3,820 trading days)
- Last close ₱5.29 (2026-11-06) · all-time high ₱24.00 (2018-05-02) · low ₱1.88 (2025-05-23) · now -78.0% from high
- Cash dividends last 12 months ₱0.1450 = 2.7% yield
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱4.92 start · H 5.85 L 4.15 · ₱3.8M/d
- 2012: ₱9.73 +97.8% · H 9.73 L 4.63 · ₱5.3M/d
- 2013: ₱9.62 -1.1% · H 12.64 L 6.94 · ₱9.4M/d
- 2014: ₱8.89 -7.6% · H 9.50 L 7.89 · ₱7.0M/d
- 2015: ₱6.20 -30.3% · H 8.60 L 5.21 · ₱5.3M/d
- 2016: ₱14.80 +138.7% · H 16.30 L 5.50 · ₱31.2M/d
- 2017: ₱18.00 +21.6% · H 19.60 L 14.18 · ₱48.0M/d · div ₱0.0500 (0.3%): 20Dec 0.05S
- 2018: ₱18.50 +2.8% · H 24.00 L 14.02 · ₱68.6M/d · div ₱0.1200 (0.6%): 10Oct 0.12S
- 2019: ₱16.38 -11.5% · H 22.95 L 16.38 · ₱44.3M/d
- 2020: ₱7.94 -51.5% · H 16.22 L 4.63 · ₱34.6M/d · div ₱0.1200 (1.5%): 10Jan 0.12S
- 2021: ₱5.18 -34.8% · H 8.64 L 5.01 · ₱8.3M/d
- 2022: ₱3.11 -40.0% · H 5.58 L 2.99 · ₱2.9M/d
- 2023: ₱3.08 -1.0% · H 4.22 L 2.94 · ₱5.8M/d · div ₱1.00 (32.5%): 01Mar 0.5S, 23May 0.5S
- 2024: ₱2.43 -21.1% · H 3.42 L 2.32 · ₱1.1M/d
- 2025: ₱2.99 +23.0% · H 3.58 L 1.88 · ₱2.2M/d
- 2026*: ₱5.29 +76.9% · H 5.43 L 2.71 · ₱4.2M/d · div ₱0.1450 (2.7%): 22Jul 0.145

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
