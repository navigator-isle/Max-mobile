---
tags: [trading, pse, stock, macay]
---
**MACAY — Macay Holdings, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Jan 28, 1987
- Data: 2012-03-07 → 2026-10-21 (1,828 trading days)
- Last close ₱5.86 (2026-10-21) · all-time high ₱60.00 (2015-07-01) · low ₱3.05 (2022-06-16) · now -90.2% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 6

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱24.60 start · H 39.15 L 4.00 · ₱3.0M/d
- 2013: ₱18.12 -26.3% · H 32.40 L 16.20 · ₱511.5K/d
- 2014: ₱46.50 +156.6% · H 49.00 L 20.30 · ₱971.3K/d · div ₱1.35 (2.9%): 08Jul 1.35
- 2015: ₱41.35 -11.1% · H 60.00 L 39.95 · ₱459.3K/d · div ₱1.45 (3.5%): 22Apr 1.45
- 2016: ₱26.95 -34.8% · H 41.25 L 26.55 · ₱261.7K/d · div ₱0.1200 (0.4%): 26Apr 0.12
- 2017: ₱21.00 -22.1% · H 29.45 L 20.00 · ₱89.3K/d · div ₱0.1200 (0.6%): 15May 0.12
- 2018: ₱9.68 -53.9% · H 26.40 L 8.46 · ₱68.8K/d · div ₱0.1200 (1.2%): 28May 0.12
- 2019: ₱6.19 -36.1% · H 16.32 L 6.11 · ₱2.9M/d · div ₱0.2000 (3.2%): 09Sep 0.2
- 2020: ₱8.86 +43.1% · H 9.00 L 4.75 · ₱68.6K/d
- 2021: ₱5.42 -38.8% · H 8.45 L 5.18 · ₱48.3K/d
- 2022: ₱6.70 +23.6% · H 6.88 L 3.05 · ₱17.9K/d
- 2023: ₱6.35 -5.2% · H 8.18 L 4.90 · ₱7.0M/d
- 2024: ₱7.52 +18.4% · H 8.50 L 5.67 · ₱34.9K/d
- 2025: ₱6.99 -7.0% · H 8.44 L 6.00 · ₱65.3K/d
- 2026*: ₱5.86 -16.2% · H 6.95 L 5.30 · ₱27.2K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
