---
tags: [trading, pse, stock, tech]
---
**TECH — Cirtek Holdings Philippines Corporation**
- Status: listed on PSE · sector Industrial › Electrical Components &amp; Equipment · listed Nov 18, 2011
- Data: 2011-11-18 → 2026-11-06 (3,636 trading days)
- Last close ₱1.30 (2026-11-06) · all-time high ₱56.00 (2018-01-24) · low ₱0.5100 (2026-03-23) · now -97.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 11

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱8.20 start · H 8.20 L 7.59 · ₱13.6M/d
- 2012: ₱25.80 +214.6% · H 25.80 L 7.78 · ₱1.9M/d
- 2013: ₱14.50 -43.8% · H 29.10 L 12.00 · ₱912.8K/d
- 2014: ₱19.00 +31.0% · H 19.00 L 12.50 · ₱533.0K/d
- 2015: ₱20.75 +9.2% · H 35.30 L 18.04 · ₱16.2M/d · div ₱0.2900 (1.4%): 05Mar 0.17, 19Aug 0.12
- 2016: ₱22.90 +10.4% · H 25.00 L 16.12 · ₱49.1M/d · div ₱0.4080 (1.8%): 09Feb 0.24, 20Jun 0.168033
- 2017: ₱45.95 +100.7% · H 45.95 L 22.45 · ₱19.9M/d · div ₱0.4559 (1.0%): 01Feb 0.22, 26Sep 0.235852
- 2018: ₱30.95 -32.6% · H 56.00 L 29.50 · ₱25.2M/d · div ₱0.5000 (1.6%): 13Feb 0.24, 13Sep 0.26
- 2019: ₱4.07 -86.8% · H 31.80 L 3.82 · ₱5.7M/d · div ₱0.2400 (5.9%): 06Jun 0.12S, 06Nov 0.12S
- 2020: ₱6.64 +63.1% · H 11.84 L 3.75 · ₱41.9M/d · div ₱0.0600 (0.9%): 30Jul 0.06
- 2021: ₱3.77 -43.2% · H 8.24 L 3.50 · ₱20.9M/d
- 2022: ₱2.71 -28.1% · H 4.08 L 2.27 · ₱5.0M/d
- 2023: ₱1.59 -41.3% · H 3.38 L 1.52 · ₱2.4M/d
- 2024: ₱1.32 -17.0% · H 1.96 L 1.26 · ₱509.0K/d
- 2025: ₱0.6300 -52.3% · H 1.35 L 0.5300 · ₱354.7K/d
- 2026*: ₱1.30 +106.3% · H 1.64 L 0.5100 · ₱4.2M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
