---
tags: [trading, pse, stock, rci]
---
**RCI — Roxas and Company, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Nov 29, 1948
- Data: 2009-07-20 → 2026-11-05 (2,676 trading days)
- Last close ₱2.47 (2026-11-05) · all-time high ₱7.72 (2013-11-07) · low ₱0.4150 (2024-01-30) · now -68.0% from high
- Cash dividends last 12 months ₱0.5000 = 20.2% yield
- Dividend events on record (2013 → 2026): 4
- Splits / stock dividends detected (prices before these dates are as traded then): 2013-12-10 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2009: ₱1.80 start · H 2.20 L 1.80 · ₱19.0K/d
- 2010: ₱1.50 -16.7% · H 1.64 L 0.9500 · ₱13.6K/d
- 2011: ₱1.64 +9.3% · H 2.10 L 1.10 · ₱25.1K/d
- 2012: ₱2.25 +37.2% · H 3.50 L 1.26 · ₱52.5K/d
- 2013: ₱3.00 +33.3% · H 7.72 L 2.25 · ₱914.6K/d · div ₱0.0200 (0.7%): 27Dec 0.02
- 2014: ₱2.90 -3.3% · H 4.50 L 1.65 · ₱232.7K/d
- 2015: ₱2.40 -17.2% · H 3.19 L 1.70 · ₱2.9M/d · div ₱0.0200 (0.8%): 12Jan 0.02
- 2016: ₱2.34 -2.5% · H 2.90 L 2.19 · ₱133.1K/d · div ₱0.0100 (0.4%): 12Jan 0.01
- 2017: ₱2.55 +9.0% · H 2.90 L 1.80 · ₱255.7K/d
- 2018: ₱1.98 -22.4% · H 4.50 L 1.77 · ₱2.5M/d
- 2019: ₱2.17 +9.6% · H 2.20 L 1.30 · ₱2.5M/d
- 2020: ₱1.29 -40.6% · H 2.28 L 1.10 · ₱5.7M/d
- 2021: ₱0.6500 -49.6% · H 1.32 L 0.6200 · ₱3.2M/d
- 2022: ₱0.4750 -26.9% · H 0.7300 L 0.4500 · ₱707.9K/d
- 2023: ₱0.4800 +1.1% · H 0.5800 L 0.4200 · ₱366.0K/d
- 2024: ₱2.72 +466.7% · H 4.48 L 0.4150 · ₱9.8M/d
- 2025: ₱2.68 -1.5% · H 3.99 L 2.09 · ₱966.9K/d
- 2026*: ₱2.47 -7.8% · H 3.30 L 2.00 · ₱345.1K/d · div ₱0.5000 (20.2%): 30Sep 0.5

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
