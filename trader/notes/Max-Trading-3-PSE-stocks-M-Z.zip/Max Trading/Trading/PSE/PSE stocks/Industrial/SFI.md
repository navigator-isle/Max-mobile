---
tags: [trading, pse, stock, sfi]
---
**SFI — Swift Foods, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Nov 15, 1994
- Data: 1994-11-15 → 2026-11-05 (5,436 trading days)
- Last close ₱0.0490 (2026-11-05) · all-time high ₱9.33 (1994-11-15) · low ₱0.0440 (2025-07-02) · now -99.5% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2004-07-19 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱8.33 start · H 9.33 L 6.67 · ₱26.2M/d
- 1995: ₱3.25 -61.0% · H 8.17 L 3.20 · ₱1.8M/d
- 1996: ₱2.10 -35.4% · H 3.40 L 1.74 · ₱1.1M/d
- 1997: ₱0.8200 -61.0% · H 2.75 L 0.7000 · ₱1.1M/d
- 1998: ₱0.6500 -20.7% · H 1.14 L 0.3800 · ₱183.5K/d
- 1999: ₱1.20 +84.6% · H 1.80 L 0.6500 · ₱349.7K/d
- 2000: ₱1.00 -16.7% · H 1.22 L 0.7500 · ₱19.5K/d
- 2001: ₱0.8000 -20.0% · H 1.00 L 0.6000 · ₱23.6K/d
- 2002: ₱0.7800 -2.5% · H 2.30 L 0.7800 · ₱66.6K/d
- 2003: ₱0.2100 -73.1% · H 0.8000 L 0.2100 · ₱71.9K/d
- 2004: ₱0.3500 +66.7% · H 0.5500 L 0.1800 · ₱125.8K/d
- 2005: ₱0.2200 -37.1% · H 0.4200 L 0.2000 · ₱53.0K/d
- 2006: ₱0.3300 +50.0% · H 0.4000 L 0.1800 · ₱106.0K/d
- 2007: ₱0.4400 +33.3% · H 0.6200 L 0.3300 · ₱406.5K/d
- 2008: ₱0.1500 -65.9% · H 0.4400 L 0.1500 · ₱35.2K/d
- 2009: ₱0.1450 -3.3% · H 0.2200 L 0.1400 · ₱996.2K/d
- 2010: ₱0.1740 +20.0% · H 0.3300 L 0.1350 · ₱1.9M/d
- 2011: ₱0.1180 -32.2% · H 0.2210 L 0.1150 · ₱1.0M/d
- 2012: ₱0.1410 +19.5% · H 0.2150 L 0.1200 · ₱1.2M/d
- 2013: ₱0.1200 -14.9% · H 0.1540 L 0.1180 · ₱288.3K/d
- 2014: ₱0.1610 +34.2% · H 0.2650 L 0.1180 · ₱2.5M/d
- 2015: ₱0.1440 -10.6% · H 0.2030 L 0.1290 · ₱1.7M/d
- 2016: ₱0.1400 -2.8% · H 0.1700 L 0.1330 · ₱880.4K/d
- 2017: ₱0.1340 -4.3% · H 0.1610 L 0.1330 · ₱545.9K/d
- 2018: ₱0.1250 -6.7% · H 0.1390 L 0.1210 · ₱173.5K/d
- 2019: ₱0.1170 -6.4% · H 0.1400 L 0.1150 · ₱255.0K/d
- 2020: ₱0.1280 +9.4% · H 0.1300 L 0.1000 · ₱92.2K/d
- 2021: ₱0.1040 -18.8% · H 0.1680 L 0.1040 · ₱3.1M/d
- 2022: ₱0.0770 -26.0% · H 0.1090 L 0.0730 · ₱103.1K/d
- 2023: ₱0.0690 -10.4% · H 0.0840 L 0.0500 · ₱36.1K/d
- 2024: ₱0.0580 -15.9% · H 0.0830 L 0.0490 · ₱29.9K/d
- 2025: ₱0.0470 -19.0% · H 0.0630 L 0.0440 · ₱28.6K/d
- 2026*: ₱0.0490 +4.3% · H 0.0670 L 0.0440 · ₱35.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
