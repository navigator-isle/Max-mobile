---
tags: [trading, pse, stock, redc]
---
**REDC — Repower Energy Development Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Jul 24, 2023
- Data: 2023-07-24 → 2026-11-06 (658 trading days)
- Last close ₱9.70 (2026-11-06) · all-time high ₱9.80 (2026-08-18) · low ₱5.00 (2023-07-26) · now -1.0% from high
- Cash dividends last 12 months ₱0.0800 = 0.8% yield
- Dividend events on record (2013 → 2026): 1

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2023: ₱7.00 start · H 7.28 L 5.00 · ₱829.1K/d
- 2024: ₱5.10 -27.1% · H 7.88 L 5.00 · ₱143.9K/d
- 2025: ₱6.35 +24.5% · H 6.92 L 5.02 · ₱80.7K/d · div ₱0.0800 (1.3%): 10Dec 0.08
- 2026*: ₱9.70 +52.8% · H 9.80 L 6.30 · ₱37.6K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
