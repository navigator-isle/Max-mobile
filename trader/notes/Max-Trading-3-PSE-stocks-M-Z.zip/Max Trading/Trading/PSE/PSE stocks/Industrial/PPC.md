---
tags: [trading, pse, stock, ppc]
---
**PPC — Pryce Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Oct 29, 1991
- Data: 2015-03-16 → 2026-11-06 (2,640 trading days)
- Last close ₱16.56 (2026-11-06) · all-time high ₱18.88 (2026-10-01) · low ₱1.40 (2015-03-19) · now -12.3% from high
- Cash dividends last 12 months ₱0.5900 = 3.6% yield
- Dividend events on record (2013 → 2026): 19

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2015: ₱2.38 start · H 4.07 L 1.40 · ₱8.6M/d
- 2016: ₱5.00 +110.1% · H 5.20 L 2.12 · ₱2.9M/d
- 2017: ₱6.80 +36.0% · H 7.50 L 4.70 · ₱2.5M/d
- 2018: ₱5.80 -14.7% · H 6.75 L 5.05 · ₱406.1K/d · div ₱0.2400 (4.1%): 09Jan 0.12, 20Jun 0.12
- 2019: ₱5.06 -12.8% · H 6.44 L 4.70 · ₱1.5M/d · div ₱0.3600 (7.1%): 08Jan 0.12, 10Jun 0.12, 26Dec 0.12
- 2020: ₱5.01 -1.0% · H 5.45 L 3.82 · ₱1.9M/d · div ₱0.2400 (4.8%): 09Jun 0.12, 18Dec 0.12
- 2021: ₱5.79 +15.6% · H 6.10 L 5.14 · ₱1.1M/d · div ₱0.2400 (4.1%): 10Jun 0.12, 31Dec 0.12
- 2022: ₱5.05 -12.8% · H 6.00 L 5.00 · ₱856.6K/d · div ₱0.2800 (5.5%): 24May 0.14, 26Dec 0.14
- 2023: ₱5.31 +5.1% · H 5.84 L 5.05 · ₱1.2M/d · div ₱0.3100 (5.8%): 23May 0.14, 06Dec 0.17
- 2024: ₱10.68 +101.1% · H 11.88 L 5.19 · ₱1.0M/d · div ₱0.4000 (3.7%): 06Jun 0.2, 29Nov 0.2
- 2025: ₱13.20 +23.6% · H 13.20 L 9.48 · ₱1.0M/d · div ₱0.5200 (3.9%): 29May 0.26, 27Nov 0.26
- 2026*: ₱16.56 +25.5% · H 18.88 L 13.20 · ₱1.1M/d · div ₱0.6600 (4.0%): 29May 0.33, 12Nov 0.33 (upcoming)

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
