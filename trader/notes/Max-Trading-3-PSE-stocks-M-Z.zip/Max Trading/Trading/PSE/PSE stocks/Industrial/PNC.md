---
tags: [trading, pse, stock, pnc]
---
**PNC — Philippine National Construction Corporation**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Mar 13, 1974
- Data: 2006-04-10 → 2008-04-09 (124 trading days)
- Last close ₱4.90 (2008-04-09) · all-time high ₱6.50 (2006-12-18) · low ₱2.90 (2006-04-27) · now -24.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱6.30 start · H 6.50 L 2.90 · ₱223.3K/d
- 2007: ₱5.80 -7.9% · H 6.30 L 4.50 · ₱223.6K/d
- 2008*: ₱4.90 -15.5% · H 5.50 L 3.60 · ₱31.4K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
