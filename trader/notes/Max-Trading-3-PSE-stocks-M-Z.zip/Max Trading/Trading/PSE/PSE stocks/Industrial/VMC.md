---
tags: [trading, pse, stock, vmc]
---
**VMC — Victorias Milling Company, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Nov 15, 1993
- Data: 2012-05-21 → 2026-10-27 (2,484 trading days)
- Last close ₱1.90 (2026-10-27) · all-time high ₱5.25 (2014-05-27) · low ₱1.13 (2012-10-22) · now -63.8% from high
- Cash dividends last 12 months ₱0.0500 = 2.6% yield
- Dividend events on record (2013 → 2026): 8
- Splits / stock dividends detected (prices before these dates are as traded then): 2024-09-16 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2012: ₱1.39 start · H 2.99 L 1.13 · ₱7.7M/d
- 2013: ₱1.90 +36.7% · H 2.09 L 1.40 · ₱5.2M/d
- 2014: ₱4.58 +141.1% · H 5.25 L 1.97 · ₱16.2M/d
- 2015: ₱4.70 +2.6% · H 4.80 L 4.20 · ₱1.0M/d
- 2016: ₱4.60 -2.1% · H 4.90 L 4.07 · ₱1.0M/d
- 2017: ₱2.98 -35.2% · H 4.56 L 2.80 · ₱831.9K/d
- 2018: ₱2.33 -21.8% · H 2.99 L 2.32 · ₱213.5K/d
- 2019: ₱2.60 +11.6% · H 3.00 L 2.32 · ₱432.8K/d
- 2020: ₱2.50 -3.8% · H 2.80 L 2.11 · ₱110.7K/d
- 2021: ₱2.50 +0.0% · H 2.65 L 2.19 · ₱152.4K/d · div ₱0.0500 (2.0%): 17Dec 0.05S
- 2022: ₱2.59 +3.6% · H 3.01 L 2.40 · ₱264.7K/d · div ₱0.0700 (2.7%): 27Dec 0.02S, 27Dec 0.05
- 2023: ₱3.30 +27.4% · H 3.80 L 2.60 · ₱206.8K/d
- 2024: ₱2.05 -37.9% · H 3.85 L 1.90 · ₱228.5K/d · div ₱0.1200 (5.9%): 15Mar 0.05, 15Mar 0.07S
- 2025: ₱2.04 -0.5% · H 2.20 L 1.61 · ₱550.0K/d · div ₱0.0600 (2.9%): 18Feb 0.01S, 18Feb 0.05
- 2026*: ₱1.90 -6.9% · H 2.17 L 1.86 · ₱99.7K/d · div ₱0.0500 (2.6%): 16Feb 0.05

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
