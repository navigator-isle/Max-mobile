---
tags: [trading, pse, stock, pcor]
---
**PCOR — Petron Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Sep 07, 1994
- Data: 1994-09-07 → 2026-11-06 (7,880 trading days)
- Last close ₱2.20 (2026-11-06) · all-time high ₱19.74 (2011-01-03) · low ₱0.9800 (2000-10-18) · now -88.9% from high
- Cash dividends last 12 months ₱0.1500 = 6.8% yield
- Dividend events on record (2013 → 2026): 13

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱11.47 start · H 14.40 L 10.27 · ₱142.8M/d
- 1995: ₱9.00 -21.5% · H 11.87 L 6.67 · ₱48.6M/d
- 1996: ₱7.42 -17.6% · H 10.42 L 6.25 · ₱35.8M/d
- 1997: ₱3.35 -54.8% · H 10.00 L 3.15 · ₱40.1M/d
- 1998: ₱4.25 +26.9% · H 6.70 L 2.20 · ₱26.2M/d
- 1999: ₱3.20 -24.7% · H 5.70 L 2.95 · ₱24.1M/d
- 2000: ₱1.20 -62.5% · H 3.25 L 0.9800 · ₱5.7M/d
- 2001: ₱1.44 +20.0% · H 2.46 L 1.02 · ₱9.5M/d
- 2002: ₱1.56 +8.3% · H 2.06 L 1.34 · ₱7.6M/d
- 2003: ₱2.26 +44.9% · H 2.32 L 1.54 · ₱8.0M/d
- 2004: ₱3.25 +43.8% · H 3.55 L 2.34 · ₱11.5M/d
- 2005: ₱4.50 +38.5% · H 4.65 L 2.65 · ₱12.4M/d
- 2006: ₱4.10 -8.9% · H 5.00 L 3.45 · ₱18.7M/d
- 2007: ₱5.70 +39.0% · H 7.20 L 3.95 · ₱45.0M/d
- 2008: ₱5.10 -10.5% · H 6.50 L 4.20 · ₱30.1M/d
- 2009: ₱5.30 +3.9% · H 6.00 L 4.70 · ₱6.8M/d
- 2010: ₱18.82 +255.1% · H 18.82 L 5.00 · ₱11.3M/d
- 2011: ₱12.60 -33.0% · H 19.74 L 12.46 · ₱22.3M/d
- 2012: ₱10.46 -17.0% · H 13.40 L 9.74 · ₱59.7M/d
- 2013: ₱13.96 +33.5% · H 16.20 L 10.38 · ₱72.3M/d · div ₱0.0500 (0.4%): 08Apr 0.05
- 2014: ₱10.60 -24.1% · H 14.30 L 9.60 · ₱88.2M/d · div ₱2.43 (22.9%): 03Apr 0.05, 16May 2.382
- 2015: ₱6.99 -34.1% · H 10.62 L 6.75 · ₱28.6M/d · div ₱0.0500 (0.7%): 27Mar 0.05
- 2016: ₱9.95 +42.3% · H 11.88 L 5.36 · ₱62.4M/d · div ₱0.1000 (1.0%): 28Mar 0.1
- 2017: ₱9.17 -7.8% · H 11.26 L 8.57 · ₱47.3M/d · div ₱0.1000 (1.1%): 23Mar 0.1
- 2018: ₱7.71 -15.9% · H 9.80 L 7.66 · ₱15.3M/d · div ₱0.1500 (1.9%): 22Mar 0.15
- 2019: ₱3.86 -49.9% · H 7.89 L 3.85 · ₱23.0M/d · div ₱0.1000 (2.6%): 22Mar 0.1
- 2020: ₱3.99 +3.4% · H 4.27 L 2.04 · ₱8.4M/d · div ₱0.1000 (2.5%): 19Mar 0.1
- 2021: ₱3.17 -20.6% · H 4.02 L 2.93 · ₱7.6M/d
- 2022: ₱2.40 -24.3% · H 3.94 L 2.27 · ₱3.9M/d
- 2023: ₱3.55 +47.9% · H 4.65 L 2.37 · ₱9.8M/d · div ₱0.1000 (2.8%): 15Mar 0.1
- 2024: ₱2.43 -31.5% · H 3.50 L 2.33 · ₱1.8M/d · div ₱0.1000 (4.1%): 18Mar 0.1
- 2025: ₱2.48 +2.1% · H 2.66 L 2.28 · ₱1.4M/d · div ₱0.1000 (4.0%): 17Mar 0.1
- 2026*: ₱2.20 -11.3% · H 3.50 L 2.15 · ₱9.3M/d · div ₱0.1500 (6.8%): 17Mar 0.15

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
