---
tags: [trading, pse, stock, spc]
---
**SPC — SPC Power Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Apr 02, 2002
- Data: 2002-04-02 → 2026-11-06 (3,617 trading days)
- Last close ₱8.75 (2026-11-06) · all-time high ₱15.00 (2022-02-22) · low ₱1.50 (2002-11-12) · now -41.7% from high
- Cash dividends last 12 months ₱0.8000 = 9.1% yield
- Dividend events on record (2013 → 2026): 20

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2002: ₱1.60 start · H 1.88 L 1.50 · ₱9.9M/d
- 2003: ₱2.06 +28.7% · H 2.38 L 1.50 · ₱346.5K/d
- 2004: ₱2.10 +1.9% · H 2.60 L 2.00 · ₱701.6K/d
- 2005: ₱1.68 -20.0% · H 2.42 L 1.58 · ₱122.6K/d
- 2006: ₱1.80 +7.1% · H 2.00 L 1.60 · ₱51.9K/d
- 2007: ₱2.40 +33.3% · H 2.46 L 1.70 · ₱91.6K/d
- 2008: ₱2.10 -12.5% · H 2.50 L 2.10 · ₱56.4K/d
- 2009: ₱3.30 +57.1% · H 3.30 L 2.20 · ₱64.5K/d
- 2010: ₱4.15 +25.8% · H 4.25 L 3.00 · ₱44.2K/d
- 2011: ₱3.80 -8.4% · H 5.00 L 2.90 · ₱43.5K/d
- 2012: ₱4.50 +18.4% · H 7.13 L 3.00 · ₱3.1M/d
- 2013: ₱4.45 -1.1% · H 5.75 L 4.00 · ₱147.1K/d
- 2014: ₱4.50 +1.1% · H 5.20 L 4.10 · ₱108.7K/d
- 2015: ₱4.18 -7.1% · H 4.56 L 3.30 · ₱113.1K/d · div ₱0.1000 (2.4%): 14Apr 0.1
- 2016: ₱4.59 +9.8% · H 4.66 L 3.70 · ₱252.2K/d · div ₱0.5867 (12.8%): 13Apr 0.3, 21Dec 0.2867S
- 2017: ₱5.40 +17.6% · H 6.82 L 4.15 · ₱1.3M/d · div ₱0.8000 (14.8%): 08Jun 0.4, 06Dec 0.4
- 2018: ₱5.44 +0.7% · H 5.80 L 4.81 · ₱1.6M/d · div ₱0.8000 (14.7%): 06Jun 0.4, 07Dec 0.4
- 2019: ₱8.19 +50.6% · H 8.90 L 5.48 · ₱1.3M/d · div ₱1.10 (13.4%): 16Apr 0.4, 05Dec 0.7
- 2020: ₱9.82 +19.9% · H 11.20 L 6.71 · ₱2.1M/d · div ₱0.8000 (8.1%): 19May 0.4, 16Dec 0.4
- 2021: ₱13.96 +42.2% · H 14.76 L 9.72 · ₱2.3M/d · div ₱1.55 (11.1%): 20Apr 0.4, 09Jun 0.6, 20Dec 0.55
- 2022: ₱9.46 -32.2% · H 15.00 L 8.36 · ₱1.8M/d · div ₱0.2000 (2.1%): 10Jun 0.2
- 2023: ₱7.00 -26.0% · H 9.45 L 6.75 · ₱577.4K/d · div ₱0.2000 (2.9%): 04Aug 0.2S
- 2024: ₱9.01 +28.7% · H 9.74 L 6.95 · ₱629.2K/d · div ₱1.00 (11.1%): 21Feb 0.6S, 24Apr 0.4
- 2025: ₱9.74 +8.1% · H 11.50 L 7.50 · ₱943.0K/d · div ₱1.20 (12.3%): 25Jun 0.4, 23Dec 0.8
- 2026*: ₱8.75 -10.2% · H 11.10 L 8.50 · ₱974.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
