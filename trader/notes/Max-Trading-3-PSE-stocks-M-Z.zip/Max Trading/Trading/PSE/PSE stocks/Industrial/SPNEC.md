---
tags: [trading, pse, stock, spnec]
---
**SPNEC — SP New Energy Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Dec 17, 2021
- Data: 2021-12-17 → 2026-11-06 (1,063 trading days)
- Last close ₱1.35 (2026-11-06) · all-time high ₱2.32 (2022-02-02) · low ₱0.9100 (2024-05-31) · now -41.8% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2021: ₱1.28 start · H 1.39 L 1.01 · ₱480.1M/d
- 2022: ₱1.20 -6.2% · H 2.32 L 1.08 · ₱123.9M/d
- 2023: ₱1.32 +10.0% · H 1.77 L 1.08 · ₱68.6M/d
- 2024: ₱1.02 -22.7% · H 1.34 L 0.9100 · ₱33.2M/d
- 2025: ₱1.17 +14.7% · H 1.62 L 1.03 · ₱22.9M/d
- 2026*: ₱1.35 +15.4% · H 1.72 L 1.11 · ₱36.3M/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
