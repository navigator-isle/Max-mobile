---
tags: [trading, pse, stock, mvc]
---
**MVC — Mabuhay Vinyl Corporation**
- Status: listed on PSE · sector Industrial › Chemicals · listed Feb 05, 1997
- Data: 1997-02-05 → 2026-11-06 (4,099 trading days)
- Last close ₱5.19 (2026-11-06) · all-time high ₱6.72 (2022-11-22) · low ₱0.2100 (1998-01-08) · now -22.8% from high
- Cash dividends last 12 months ₱0.1000 = 1.9% yield
- Dividend events on record (2013 → 2026): 14

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1997: ₱0.3000 start · H 1.62 L 0.2900 · ₱1.8M/d
- 1998: ₱0.3900 +30.0% · H 0.5500 L 0.2100 · ₱207.8K/d
- 1999: ₱0.4200 +7.7% · H 0.5500 L 0.2900 · ₱194.9K/d
- 2000: ₱0.5600 +33.3% · H 0.7100 L 0.3600 · ₱2.0M/d
- 2001: ₱0.7000 +25.0% · H 0.9500 L 0.4600 · ₱230.7K/d
- 2002: ₱0.5600 -20.0% · H 0.6900 L 0.3400 · ₱60.6K/d
- 2003: ₱1.16 +107.1% · H 2.02 L 0.5800 · ₱1.1M/d
- 2004: ₱0.9300 -19.8% · H 1.30 L 0.8000 · ₱915.1K/d
- 2005: ₱0.7500 -19.4% · H 0.9900 L 0.6500 · ₱169.3K/d
- 2006: ₱0.6400 -14.7% · H 0.7600 L 0.5100 · ₱70.0K/d
- 2007: ₱0.8600 +34.4% · H 1.38 L 0.5100 · ₱2.2M/d
- 2008: ₱0.4000 -53.5% · H 0.8500 L 0.3000 · ₱247.8K/d
- 2009: ₱0.9800 +145.0% · H 1.04 L 0.4000 · ₱415.7K/d
- 2010: ₱1.02 +4.1% · H 1.20 L 0.8000 · ₱74.5K/d
- 2011: ₱1.23 +20.6% · H 1.32 L 0.7100 · ₱85.5K/d
- 2012: ₱1.61 +30.9% · H 1.70 L 1.23 · ₱818.3K/d
- 2013: ₱2.20 +36.6% · H 3.50 L 1.60 · ₱105.6K/d · div ₱0.0500 (2.3%): 21May 0.05
- 2014: ₱2.43 +10.5% · H 2.77 L 2.20 · ₱55.4K/d · div ₱0.0500 (2.1%): 20May 0.05S
- 2015: ₱3.10 +27.6% · H 6.00 L 1.61 · ₱374.5K/d · div ₱0.0500 (1.6%): 26May 0.05
- 2016: ₱3.83 +23.5% · H 4.85 L 2.60 · ₱300.7K/d · div ₱0.0500 (1.3%): 24May 0.05
- 2017: ₱3.20 -16.4% · H 4.40 L 3.02 · ₱269.7K/d · div ₱0.0700 (2.2%): 23May 0.07
- 2018: ₱3.30 +3.1% · H 3.42 L 3.01 · ₱66.4K/d · div ₱0.0700 (2.1%): 16May 0.07
- 2019: ₱3.50 +6.1% · H 3.83 L 3.10 · ₱78.0K/d · div ₱0.0700 (2.0%): 20May 0.07
- 2020: ₱4.53 +29.4% · H 4.72 L 2.92 · ₱54.7K/d · div ₱0.1000 (2.2%): 13Jul 0.1
- 2021: ₱4.28 -5.5% · H 5.49 L 3.50 · ₱51.2K/d · div ₱0.1000 (2.3%): 21May 0.1
- 2022: ₱5.48 +28.0% · H 6.72 L 4.10 · ₱26.5K/d · div ₱0.1000 (1.8%): 23May 0.1
- 2023: ₱5.86 +6.9% · H 6.20 L 4.99 · ₱28.5K/d · div ₱0.1000 (1.7%): 23May 0.1
- 2024: ₱5.39 -8.0% · H 6.54 L 4.09 · ₱37.6K/d · div ₱0.1000 (1.9%): 23May 0.1
- 2025: ₱5.19 -3.7% · H 5.86 L 4.52 · ₱17.4K/d · div ₱0.1000 (1.9%): 22May 0.1
- 2026*: ₱5.19 +0.0% · H 5.69 L 4.90 · ₱20.5K/d · div ₱0.1000 (1.9%): 25May 0.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
