---
tags: [trading, pse, stock, sgp]
---
**SGP — Synergy Grid &amp; Development Phils., Inc.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed May 10, 1972
- Data: 2011-05-31 → 2026-11-06 (2,117 trading days)
- Last close ₱22.95 (2026-11-06) · all-time high ₱1,049 (2011-06-03) · low ₱5.96 (2023-11-21) · now -97.8% from high
- Cash dividends last 12 months ₱1.04 = 4.5% yield
- Dividend events on record (2013 → 2026): 13
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-08-18 (÷1.5), 2014-02-17 (÷1.5), 2014-09-09 (÷2), 2019-12-10 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2011: ₱510.0 start · H 1,049 L 326.0 · ₱212.1K/d
- 2012: ₱375.0 -26.5% · H 635.0 L 375.0 · ₱33.0K/d
- 2013: ₱390.0 +4.0% · H 490.0 L 227.0 · ₱38.2K/d
- 2014: ₱310.0 -20.5% · H 500.0 L 175.0 · ₱43.9K/d
- 2015: ₱150.0 -51.6% · H 310.0 L 140.0 · ₱39.2K/d
- 2016: ₱187.1 +24.7% · H 250.0 L 133.0 · ₱65.5K/d
- 2017: ₱180.0 -3.8% · H 250.0 L 174.0 · ₱57.2K/d
- 2018: ₱536.0 +197.8% · H 877.5 L 175.1 · ₱816.7K/d
- 2019: ₱195.0 -63.6% · H 598.0 L 168.0 · ₱306.6K/d
- 2020: ₱242.0 +24.1% · H 313.6 L 144.0 · ₱211.6K/d
- 2021: ₱13.12 -94.6% · H 439.0 L 12.60 · ₱91.8M/d · div ₱0.6750 (5.1%): 06Oct 0.475, 09Dec 0.2
- 2022: ₱11.10 -15.4% · H 13.88 L 10.86 · ₱29.7M/d · div ₱1.00 (9.0%): 01Apr 0.22, 01Jul 0.26, 30Sep 0.26, 19Dec 0.26
- 2023: ₱6.55 -41.0% · H 12.00 L 5.96 · ₱12.4M/d · div ₱0.3474 (5.3%): 20Mar 0.1737, 03Jul 0.1737
- 2024: ₱9.80 +49.6% · H 10.72 L 6.52 · ₱13.8M/d · div ₱0.3474 (3.5%): 25Apr 0.3474
- 2025: ₱16.56 +69.0% · H 18.00 L 10.14 · ₱38.5M/d · div ₱0.6948 (4.2%): 17Sep 0.3474S, 11Dec 0.3474
- 2026*: ₱22.95 +38.6% · H 33.75 L 16.94 · ₱66.6M/d · div ₱0.6948 (3.0%): 14Apr 0.3474, 07Jul 0.3474

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
