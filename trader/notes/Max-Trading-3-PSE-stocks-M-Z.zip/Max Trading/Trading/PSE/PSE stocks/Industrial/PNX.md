---
tags: [trading, pse, stock, pnx]
---
**PNX — Phoenix Petroleum Philippines, Inc.**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Jul 11, 2007
- Data: 2007-07-11 → 2024-05-16 (3,858 trading days)
- Last close ₱4.17 (2024-05-16) · all-time high ₱14.88 (2020-10-19) · low ₱1.23 (2008-10-24) · now -72.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 7

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2007: ₱3.64 start · H 7.05 L 3.33 · ₱8.6M/d
- 2008: ₱1.90 -47.9% · H 3.59 L 1.23 · ₱288.4K/d
- 2009: ₱3.59 +89.2% · H 3.59 L 2.03 · ₱2.3M/d
- 2010: ₱6.34 +76.6% · H 6.50 L 3.38 · ₱2.4M/d
- 2011: ₱5.78 -8.7% · H 7.69 L 5.33 · ₱3.6M/d
- 2012: ₱6.95 +20.1% · H 7.63 L 5.51 · ₱4.9M/d
- 2013: ₱4.50 -35.2% · H 8.52 L 4.35 · ₱8.8M/d · div ₱0.1000 (2.2%): 05Apr 0.1
- 2014: ₱3.09 -31.3% · H 6.75 L 3.05 · ₱4.3M/d · div ₱0.1000 (3.2%): 12Mar 0.1
- 2015: ₱3.65 +18.1% · H 4.16 L 3.13 · ₱3.3M/d · div ₱0.0500 (1.4%): 13Mar 0.05
- 2016: ₱5.64 +54.5% · H 6.45 L 3.50 · ₱3.8M/d · div ₱0.0800 (1.4%): 31Mar 0.08
- 2017: ₱13.00 +130.5% · H 13.08 L 5.65 · ₱24.8M/d · div ₱0.1000 (0.8%): 27Mar 0.1
- 2018: ₱10.74 -17.4% · H 13.80 L 10.50 · ₱6.2M/d · div ₱0.1500 (1.4%): 26Mar 0.15
- 2019: ₱11.94 +11.2% · H 12.30 L 10.44 · ₱2.3M/d · div ₱0.1500 (1.3%): 03Apr 0.15
- 2020: ₱12.50 +4.7% · H 14.88 L 9.45 · ₱4.6M/d
- 2021: ₱10.86 -13.1% · H 13.58 L 10.70 · ₱1.5M/d
- 2022: ₱8.60 -20.8% · H 10.86 L 7.02 · ₱390.7K/d
- 2023: ₱4.90 -43.0% · H 8.59 L 4.76 · ₱1.9M/d
- 2024*: ₱4.17 -14.9% · H 4.90 L 3.80 · ₱74.8K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
