---
tags: [trading, pse, stock, stn]
---
**STN — Steniel Manufacturing Corporation**
- Status: listed on PSE · sector Industrial › Other Industrials · listed Nov 22, 1993
- Data: 1993-11-22 → 2026-11-05 (2,288 trading days)
- Last close ₱1.99 (2026-11-05) · all-time high ₱10.80 (1994-01-06) · low ₱0.0800 (2002-12-11) · now -81.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2003-01-31 (÷0.25), 2003-03-05 (÷3), 2005-04-04 (÷1.5), 2024-04-30 (÷0.2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱8.67 start · H 8.67 L 5.07 · ₱5.5M/d
- 1994: ₱5.52 -36.3% · H 10.80 L 5.27 · ₱4.4M/d
- 1995: ₱4.20 -23.9% · H 5.90 L 3.20 · ₱5.3M/d
- 1996: ₱1.88 -55.2% · H 4.50 L 1.70 · ₱3.2M/d
- 1997: ₱0.2800 -85.1% · H 2.32 L 0.2600 · ₱814.6K/d
- 1998: ₱0.7800 +178.6% · H 0.9100 L 0.1600 · ₱471.8K/d
- 1999: ₱0.6800 -12.8% · H 1.16 L 0.4200 · ₱566.0K/d
- 2000: ₱0.6000 -11.8% · H 0.7000 L 0.3000 · ₱130.6K/d
- 2001: ₱0.5100 -15.0% · H 0.7500 L 0.4700 · ₱359.8K/d
- 2002: ₱0.0800 -84.3% · H 0.5500 L 0.0800 · ₱36.1K/d
- 2003: ₱0.1300 +62.5% · H 0.6000 L 0.1000 · ₱112.5K/d
- 2004: ₱0.1500 +15.4% · H 0.1800 L 0.1000 · ₱19.3K/d
- 2005: ₱0.1500 +0.0% · H 0.2600 L 0.1100 · ₱26.7K/d
- 2006: ₱0.2600 +73.3% · H 0.6800 L 0.1100 · ₱509.5K/d
- 2024: ₱1.57 start · H 2.05 L 0.8000 · ₱1.0M/d
- 2025: ₱2.18 +38.9% · H 2.76 L 1.26 · ₱755.3K/d
- 2026*: ₱1.99 -8.7% · H 2.18 L 1.80 · ₱119.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
