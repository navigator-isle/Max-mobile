---
tags: [trading, pse, stock, phn]
---
**PHN — Phinma Corporation**
- Status: listed on PSE · sector Industrial › Construction, Infra. &amp; Allied Services · listed Aug 18, 1958
- Data: 1988-09-01 → 2026-11-06 (5,558 trading days)
- Last close ₱14.02 (2026-11-06) · all-time high ₱68.18 (1993-12-17) · low ₱3.31 (1998-01-19) · now -79.4% from high
- Cash dividends last 12 months ₱0.6000 = 4.3% yield
- Dividend events on record (2013 → 2026): 16
- Splits / stock dividends detected (prices before these dates are as traded then): 2004-09-10 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1988: ₱8.08 start · H 8.26 L 7.73 · ₱37.8K/d
- 1989: ₱8.98 +11.1% · H 8.98 L 6.11 · ₱21.7K/d
- 1990: ₱8.98 +0.0% · H 8.98 L 7.19 · ₱77.8K/d
- 1991: ₱14.88 +65.6% · H 16.17 L 11.68 · ₱21.3K/d
- 1992: ₱7.23 -51.4% · H 18.59 L 5.51 · ₱510.7K/d
- 1993: ₱66.12 +814.3% · H 68.18 L 9.64 · ₱964.0K/d
- 1994: ₱57.85 -12.5% · H 66.12 L 44.21 · ₱3.2M/d
- 1995: ₱46.49 -19.6% · H 57.85 L 41.84 · ₱3.5M/d
- 1996: ₱35.54 -23.6% · H 57.44 L 34.71 · ₱5.4M/d
- 1997: ₱5.37 -84.9% · H 39.05 L 5.37 · ₱2.1M/d
- 1998: ₱16.53 +207.7% · H 29.75 L 3.31 · ₱4.0M/d
- 1999: ₱13.22 -20.0% · H 18.18 L 11.57 · ₱493.4K/d
- 2000: ₱11.16 -15.6% · H 12.81 L 5.37 · ₱736.8K/d
- 2001: ₱9.09 -18.5% · H 11.16 L 6.78 · ₱289.1K/d
- 2002: ₱8.26 -9.1% · H 9.09 L 7.44 · ₱183.1K/d
- 2003: ₱8.26 +0.0% · H 9.09 L 7.44 · ₱301.9K/d
- 2004: ₱13.22 +60.0% · H 26.45 L 7.44 · ₱2.4M/d
- 2005: ₱7.44 -43.8% · H 23.14 L 7.44 · ₱1.7M/d
- 2006: ₱6.86 -7.8% · H 8.88 L 6.86 · ₱2.0M/d
- 2010: ₱10.64 start · H 12.27 L 8.36 · ₱136.8K/d
- 2011: ₱10.82 +1.7% · H 12.73 L 9.36 · ₱122.9K/d
- 2012: ₱10.64 -1.7% · H 11.09 L 9.24 · ₱457.3K/d
- 2013: ₱10.91 +2.6% · H 14.53 L 9.80 · ₱552.7K/d · div ₱0.4000 (3.7%): 19Mar 0.4
- 2014: ₱9.16 -16.0% · H 12.71 L 9.07 · ₱833.2K/d · div ₱0.4000 (4.4%): 17Mar 0.4
- 2015: ₱11.80 +28.8% · H 12.28 L 10.10 · ₱371.9K/d · div ₱0.4000 (3.4%): 13Mar 0.4
- 2016: ₱11.80 +0.0% · H 11.80 L 11.00 · ₱289.5K/d · div ₱0.4000 (3.4%): 15Mar 0.4
- 2017: ₱8.40 -28.8% · H 11.70 L 8.35 · ₱360.4K/d · div ₱0.4000 (4.8%): 31Mar 0.4
- 2018: ₱9.09 +8.2% · H 9.09 L 7.50 · ₱310.0K/d · div ₱0.4000 (4.4%): 19Mar 0.4
- 2019: ₱10.06 +10.7% · H 12.00 L 8.23 · ₱1.6M/d · div ₱0.8000 (8.0%): 18Mar 0.4, 20Nov 0.4S
- 2020: ₱10.00 -0.6% · H 10.06 L 8.02 · ₱316.6K/d · div ₱0.4000 (4.0%): 12Mar 0.4
- 2021: ₱20.15 +101.5% · H 20.50 L 9.65 · ₱1.5M/d · div ₱0.4000 (2.0%): 08Apr 0.4
- 2022: ₱19.06 -5.4% · H 21.15 L 18.92 · ₱3.8M/d · div ₱0.5000 (2.6%): 17Mar 0.1S, 17Mar 0.4
- 2023: ₱20.40 +7.0% · H 20.75 L 18.92 · ₱1.1M/d · div ₱0.6000 (2.9%): 17Mar 0.6
- 2024: ₱19.00 -6.9% · H 29.65 L 18.00 · ₱1.1M/d · div ₱0.6000 (3.2%): 22Mar 0.6
- 2025: ₱16.70 -12.1% · H 18.98 L 15.66 · ₱302.5K/d · div ₱0.6000 (3.6%): 09May 0.6
- 2026*: ₱14.02 -16.0% · H 16.70 L 12.40 · ₱221.3K/d · div ₱0.6000 (4.3%): 30Mar 0.6

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
