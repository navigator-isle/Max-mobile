---
tags: [trading, pse, stock, maxs]
---
**MAXS — Max&#039;s Group, Inc.**
- Status: listed on PSE · sector Industrial › Food, Beverage &amp; Tobacco · listed Dec 15, 2000
- Data: 2000-12-15 → 2026-11-05 (3,908 trading days)
- Last close ₱1.90 (2026-11-05) · all-time high ₱61.80 (2014-08-19) · low ₱0.5000 (2001-10-25) · now -96.9% from high
- Cash dividends last 12 months ₱0.1225 = 6.4% yield
- Dividend events on record (2013 → 2026): 9

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2000: ₱0.8400 start · H 0.8800 L 0.7700 · ₱181.1K/d
- 2001: ₱0.7700 -8.3% · H 0.8800 L 0.5000 · ₱259.1K/d
- 2002: ₱0.7300 -5.2% · H 0.7300 L 0.7300 · ₱2.5M/d
- 2003: ₱0.7700 +5.5% · H 0.8100 L 0.7700 · ₱2.4M/d
- 2004: ₱0.7000 -9.1% · H 1.02 L 0.6400 · ₱751.7K/d
- 2005: ₱1.95 +178.6% · H 1.95 L 0.5500 · ₱488.6K/d
- 2006: ₱3.15 +61.5% · H 3.15 L 1.77 · ₱187.1K/d
- 2007: ₱5.00 +58.7% · H 5.00 L 3.00 · ₱1.5M/d
- 2008: ₱4.50 -10.0% · H 5.00 L 3.50 · ₱280.3K/d
- 2009: ₱4.25 -5.6% · H 5.00 L 4.25 · ₱73.5K/d
- 2010: ₱4.68 +10.1% · H 6.00 L 3.75 · ₱36.8K/d
- 2011: ₱5.00 +6.8% · H 5.50 L 3.50 · ₱790.3K/d
- 2012: ₱3.89 -22.2% · H 6.10 L 3.40 · ₱150.2K/d
- 2013: ₱7.50 +92.8% · H 8.60 L 3.75 · ₱80.2K/d
- 2014: ₱24.55 +227.3% · H 61.80 L 7.32 · ₱5.0M/d
- 2015: ₱19.98 -18.6% · H 34.40 L 19.68 · ₱21.1M/d
- 2016: ₱25.00 +25.1% · H 34.50 L 13.40 · ₱18.9M/d · div ₱0.1153 (0.5%): 23Mar 0.115306
- 2017: ₱18.60 -25.6% · H 28.30 L 17.68 · ₱14.7M/d · div ₱0.1300 (0.7%): 27Mar 0.13
- 2018: ₱10.26 -44.8% · H 18.32 L 9.50 · ₱4.7M/d · div ₱0.1441 (1.4%): 28Mar 0.144122
- 2019: ₱12.40 +20.9% · H 15.90 L 10.26 · ₱10.5M/d · div ₱0.1452 (1.2%): 29Mar 0.14515
- 2020: ₱6.89 -44.4% · H 12.00 L 4.25 · ₱7.1M/d · div ₱0.1750 (2.5%): 26Mar 0.175
- 2021: ₱6.48 -6.0% · H 7.58 L 5.20 · ₱1.7M/d
- 2022: ₱4.88 -24.7% · H 6.80 L 4.22 · ₱451.8K/d
- 2023: ₱3.27 -33.0% · H 5.43 L 3.01 · ₱533.7K/d · div ₱0.1928 (5.9%): 27Mar 0.1928
- 2024: ₱2.67 -18.3% · H 3.50 L 2.50 · ₱401.0K/d · div ₱0.1689 (6.3%): 03Apr 0.16885
- 2025: ₱2.45 -8.2% · H 2.65 L 2.15 · ₱146.2K/d · div ₱0.1408 (5.7%): 10Apr 0.14082S
- 2026*: ₱1.90 -22.4% · H 2.65 L 1.86 · ₱145.2K/d · div ₱0.1225 (6.4%): 08Apr 0.1225

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
