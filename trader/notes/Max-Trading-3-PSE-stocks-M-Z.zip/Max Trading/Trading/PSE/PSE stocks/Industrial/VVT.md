---
tags: [trading, pse, stock, vvt]
---
**VVT — Vivant Corporation**
- Status: listed on PSE · sector Industrial › Electricity, Energy, Power &amp; Water · listed Jun 23, 1994
- Data: 2006-08-03 → 2026-11-04 (1,606 trading days)
- Last close ₱20.00 (2026-11-04) · all-time high ₱44.00 (2017-05-03) · low ₱0.8000 (2006-09-14) · now -54.5% from high
- Cash dividends last 12 months ₱0.6076 = 3.0% yield
- Dividend events on record (2013 → 2026): 19
- Splits / stock dividends detected (prices before these dates are as traded then): 2011-12-13 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.8300 start · H 0.8700 L 0.8000 · ₱12.6K/d
- 2007: ₱7.00 +743.4% · H 7.00 L 0.9300 · ₱100.1K/d
- 2008: ₱4.00 -42.9% · H 7.10 L 4.00 · ₱62.2K/d
- 2009: ₱5.90 +47.5% · H 6.00 L 3.40 · ₱20.7K/d
- 2010: ₱4.68 -20.7% · H 7.00 L 4.00 · ₱27.7K/d
- 2011: ₱3.81 -18.6% · H 6.00 L 2.55 · ₱13.1K/d
- 2012: ₱9.01 +136.5% · H 14.52 L 2.65 · ₱5.0M/d
- 2013: ₱11.04 +22.5% · H 12.00 L 8.35 · ₱49.7K/d · div ₱0.2047 (1.9%): 01Jul 0.0489S, 01Jul 0.1558
- 2014: ₱20.00 +81.2% · H 22.00 L 10.00 · ₱176.8K/d · div ₱0.2203 (1.1%): 04Jul 0.0489S, 04Jul 0.1714
- 2015: ₱22.50 +12.5% · H 25.50 L 19.00 · ₱456.6K/d · div ₱0.2618 (1.2%): 04Jun 0.0733S, 04Jun 0.1885
- 2016: ₱31.50 +40.0% · H 35.90 L 22.50 · ₱120.6K/d · div ₱0.2618 (0.8%): 31May 0.0733S, 31May 0.1885
- 2017: ₱24.90 -21.0% · H 44.00 L 22.80 · ₱86.4K/d · div ₱0.2792 (1.1%): 23May 0.0807S, 23May 0.1985
- 2018: ₱16.88 -32.2% · H 29.95 L 15.20 · ₱60.1K/d · div ₱0.2792 (1.7%): 01Jun 0.2792
- 2019: ₱15.12 -10.4% · H 17.00 L 14.52 · ₱62.4K/d · div ₱0.3382 (2.2%): 24May 0.3382
- 2020: ₱14.12 -6.6% · H 15.12 L 11.00 · ₱68.5K/d · div ₱0.4571 (3.2%): 22May 0.4571
- 2021: ₱14.50 +2.7% · H 18.90 L 13.30 · ₱83.3K/d · div ₱0.3500 (2.4%): 01Jun 0.35
- 2022: ₱15.90 +9.7% · H 18.38 L 12.82 · ₱42.5K/d · div ₱0.4341 (2.7%): 25May 0.4341
- 2023: ₱14.22 -10.6% · H 19.80 L 12.80 · ₱53.3K/d · div ₱0.3897 (2.7%): 29May 0.3897
- 2024: ₱18.02 +26.7% · H 19.50 L 11.28 · ₱28.4K/d · div ₱0.5580 (3.1%): 06Jun 0.558
- 2025: ₱19.44 +7.9% · H 25.00 L 17.16 · ₱33.9K/d · div ₱0.5753 (3.0%): 09Jun 0.5753
- 2026*: ₱20.00 +2.9% · H 22.45 L 18.40 · ₱40.4K/d · div ₱0.6076 (3.0%): 29May 0.6076

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
