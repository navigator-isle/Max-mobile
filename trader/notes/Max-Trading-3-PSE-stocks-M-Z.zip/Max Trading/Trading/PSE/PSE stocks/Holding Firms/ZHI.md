---
tags: [trading, pse, stock, zhi]
---
**ZHI — Zeus Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Jul 15, 1991
- Data: 1994-05-27 → 2026-11-06 (3,868 trading days)
- Last close ₱0.0690 (2026-11-06) · all-time high ₱4.95 (1996-11-15) · low ₱0.0500 (2026-06-24) · now -98.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1994: ₱0.6500 start · H 1.80 L 0.6500 · ₱578.7K/d
- 1995: ₱1.10 +69.2% · H 1.10 L 0.6500 · ₱136.2K/d
- 1996: ₱4.30 +290.9% · H 4.95 L 0.9000 · ₱1.8M/d
- 1997: ₱0.7000 -83.7% · H 4.55 L 0.6000 · ₱623.7K/d
- 1998: ₱0.3500 -50.0% · H 0.9000 L 0.0800 · ₱92.0K/d
- 1999: ₱0.3800 +8.6% · H 1.10 L 0.1500 · ₱96.8K/d
- 2000: ₱0.3000 -21.1% · H 0.4000 L 0.2700 · ₱28.2K/d
- 2001: ₱0.3000 +0.0% · H 0.5000 L 0.3000 · ₱135.5K/d
- 2002: ₱0.3000 +0.0% · H 0.3000 L 0.3000 · ₱6.0K/d
- 2004: ₱0.2000 start · H 0.2000 L 0.2000 · ₱4.0K/d
- 2005: ₱0.2000 +0.0% · H 0.3000 L 0.2000 · ₱12.1K/d
- 2006: ₱0.3300 +65.0% · H 0.3300 L 0.1500 · ₱67.8K/d
- 2007: ₱0.5000 +51.5% · H 1.02 L 0.2600 · ₱403.8K/d
- 2008: ₱0.1500 -70.0% · H 0.4200 L 0.0800 · ₱38.7K/d
- 2009: ₱0.2050 +36.7% · H 0.4200 L 0.2000 · ₱1.3M/d
- 2010: ₱0.1930 -5.9% · H 0.2250 L 0.1630 · ₱126.4K/d
- 2011: ₱0.7500 +288.6% · H 1.26 L 0.1760 · ₱40.3M/d
- 2012: ₱0.3400 -54.7% · H 0.8400 L 0.3300 · ₱1.5M/d
- 2013: ₱0.2950 -13.2% · H 0.6900 L 0.2950 · ₱2.7M/d
- 2014: ₱0.3250 +10.2% · H 0.4650 L 0.3000 · ₱1.3M/d
- 2015: ₱0.2550 -21.5% · H 0.3700 L 0.2100 · ₱349.6K/d
- 2016: ₱0.2490 -2.4% · H 0.3950 L 0.2290 · ₱1.2M/d
- 2017: ₱0.2060 -17.3% · H 0.2850 L 0.1850 · ₱229.1K/d
- 2018: ₱0.2230 +8.3% · H 0.2500 L 0.1850 · ₱122.9K/d
- 2019: ₱0.2000 -10.3% · H 0.4700 L 0.1900 · ₱5.5M/d
- 2020: ₱0.1840 -8.0% · H 0.2440 L 0.1130 · ₱525.1K/d
- 2021: ₱0.1800 -2.2% · H 0.2850 L 0.1660 · ₱1.1M/d
- 2022: ₱0.1270 -29.4% · H 0.1810 L 0.1270 · ₱94.2K/d
- 2023: ₱0.0710 -44.1% · H 0.1500 L 0.0710 · ₱57.4K/d
- 2024: ₱0.0720 +1.4% · H 0.1050 L 0.0620 · ₱41.2K/d
- 2025: ₱0.0670 -6.9% · H 0.0960 L 0.0610 · ₱30.9K/d
- 2026*: ₱0.0690 +3.0% · H 0.0800 L 0.0500 · ₱28.1K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
