---
tags: [trading, pse, stock, prim]
---
**PRIM — Prime Media Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Jul 29, 1964
- Data: 2006-04-06 → 2026-11-06 (3,605 trading days)
- Last close ₱0.8500 (2026-11-06) · all-time high ₱4.48 (2024-04-15) · low ₱0.2000 (2009-04-16) · now -81.0% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2008-10-17 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2006: ₱0.9500 start · H 1.20 L 0.8000 · ₱94.4K/d
- 2007: ₱0.6500 -31.6% · H 1.28 L 0.6200 · ₱155.8K/d
- 2008: ₱0.3000 -53.8% · H 0.7800 L 0.3000 · ₱35.6K/d
- 2009: ₱1.50 +400.0% · H 3.00 L 0.2000 · ₱2.5M/d
- 2010: ₱1.96 +30.7% · H 2.85 L 1.42 · ₱550.3K/d
- 2011: ₱1.45 -26.0% · H 2.44 L 1.45 · ₱263.3K/d
- 2012: ₱1.28 -11.7% · H 1.92 L 1.08 · ₱287.8K/d
- 2013: ₱1.49 +16.4% · H 2.25 L 1.19 · ₱1.2M/d
- 2014: ₱1.39 -6.7% · H 1.98 L 1.25 · ₱3.4M/d
- 2015: ₱1.20 -13.7% · H 1.68 L 1.08 · ₱115.3K/d
- 2016: ₱1.13 -5.8% · H 1.62 L 0.9000 · ₱1.4M/d
- 2017: ₱1.15 +1.8% · H 1.77 L 0.9100 · ₱913.7K/d
- 2018: ₱1.23 +7.0% · H 1.68 L 1.10 · ₱3.0M/d
- 2019: ₱1.20 -2.4% · H 1.83 L 1.04 · ₱1.8M/d
- 2020: ₱0.8600 -28.3% · H 1.28 L 0.7000 · ₱210.6K/d
- 2021: ₱1.17 +36.0% · H 4.20 L 0.8200 · ₱9.7M/d
- 2022: ₱2.08 +77.8% · H 3.41 L 1.10 · ₱1.9M/d
- 2023: ₱2.87 +38.0% · H 2.99 L 1.81 · ₱2.2M/d
- 2024: ₱2.13 -25.8% · H 4.48 L 1.70 · ₱2.5M/d
- 2025: ₱1.30 -39.0% · H 2.27 L 1.07 · ₱91.7K/d
- 2026*: ₱0.8500 -34.6% · H 1.29 L 0.7000 · ₱88.0K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
