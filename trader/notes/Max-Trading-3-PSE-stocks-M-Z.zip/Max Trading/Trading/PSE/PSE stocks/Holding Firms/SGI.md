---
tags: [trading, pse, stock, sgi]
---
**SGI — Solid Group, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Apr 26, 1948
- Data: 1996-09-04 → 2026-11-06 (5,928 trading days)
- Last close ₱1.14 (2026-11-06) · all-time high ₱7.50 (1997-03-12) · low ₱0.1600 (2003-01-27) · now -84.8% from high
- Cash dividends last 12 months ₱0.1000 = 8.8% yield
- Dividend events on record (2013 → 2026): 12
- Splits / stock dividends detected (prices before these dates are as traded then): 2009-02-23 (÷1.5)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1996: ₱5.40 start · H 6.30 L 5.00 · ₱24.9M/d
- 1997: ₱1.60 -70.4% · H 7.50 L 1.56 · ₱20.9M/d
- 1998: ₱0.5400 -66.2% · H 2.40 L 0.4800 · ₱3.9M/d
- 1999: ₱1.26 +133.3% · H 1.46 L 0.5100 · ₱3.8M/d
- 2000: ₱0.5200 -58.7% · H 3.15 L 0.4500 · ₱5.7M/d
- 2001: ₱0.3300 -36.5% · H 0.8500 L 0.3300 · ₱1.6M/d
- 2002: ₱0.2100 -36.4% · H 0.4300 L 0.2100 · ₱171.1K/d
- 2003: ₱0.2900 +38.1% · H 0.4800 L 0.1600 · ₱77.1K/d
- 2004: ₱0.3700 +27.6% · H 0.4600 L 0.3000 · ₱324.1K/d
- 2005: ₱0.4900 +32.4% · H 0.6600 L 0.3800 · ₱274.1K/d
- 2006: ₱0.6500 +32.7% · H 0.8400 L 0.4500 · ₱414.4K/d
- 2007: ₱0.7500 +15.4% · H 0.9800 L 0.6100 · ₱498.0K/d
- 2008: ₱0.3800 -49.3% · H 0.6700 L 0.3200 · ₱138.9K/d
- 2009: ₱0.8800 +131.6% · H 1.02 L 0.2900 · ₱1.3M/d
- 2010: ₱0.8000 -9.1% · H 1.02 L 0.6900 · ₱299.7K/d
- 2011: ₱1.16 +45.0% · H 1.66 L 0.8200 · ₱775.6K/d
- 2012: ₱1.98 +70.7% · H 2.42 L 1.14 · ₱2.5M/d
- 2013: ₱1.18 -40.4% · H 2.40 L 1.04 · ₱1.6M/d · div ₱0.0600 (5.1%): 27Aug 0.06
- 2014: ₱1.24 +5.1% · H 1.84 L 1.18 · ₱792.9K/d · div ₱0.0600 (4.8%): 26Aug 0.06
- 2015: ₱1.14 -8.1% · H 1.31 L 1.14 · ₱269.4K/d · div ₱0.0600 (5.3%): 25Aug 0.06
- 2016: ₱1.22 +7.0% · H 1.41 L 0.9700 · ₱745.4K/d · div ₱0.1000 (8.2%): 25Aug 0.1
- 2017: ₱1.57 +28.7% · H 1.97 L 1.25 · ₱3.1M/d · div ₱0.0700 (4.5%): 25Aug 0.07
- 2018: ₱1.32 -15.9% · H 1.84 L 1.26 · ₱1.2M/d · div ₱0.0600 (4.5%): 28Aug 0.06
- 2019: ₱1.22 -7.6% · H 1.46 L 1.22 · ₱235.2K/d · div ₱0.0600 (4.9%): 27Aug 0.06
- 2020: ₱1.11 -9.0% · H 1.29 L 0.8000 · ₱148.7K/d
- 2021: ₱1.08 -2.7% · H 1.44 L 1.06 · ₱177.2K/d
- 2022: ₱0.8700 -19.4% · H 1.16 L 0.7900 · ₱153.0K/d · div ₱0.0600 (6.9%): 26Jul 0.06
- 2023: ₱0.9400 +8.0% · H 1.06 L 0.8500 · ₱226.7K/d · div ₱0.0600 (6.4%): 15Aug 0.06
- 2024: ₱1.03 +9.6% · H 1.07 L 0.8900 · ₱148.8K/d · div ₱0.1000 (9.7%): 12Jul 0.1
- 2025: ₱1.27 +23.3% · H 1.46 L 0.9900 · ₱198.3K/d · div ₱0.1000 (7.9%): 14Jul 0.1
- 2026*: ₱1.14 -10.2% · H 1.41 L 1.07 · ₱211.2K/d · div ₱0.1000 (8.8%): 14Jul 0.1

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
