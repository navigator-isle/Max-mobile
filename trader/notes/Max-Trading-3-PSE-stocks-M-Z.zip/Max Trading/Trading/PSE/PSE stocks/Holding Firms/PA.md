---
tags: [trading, pse, stock, pa]
---
**PA — Pacifica Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Nov 23, 1959
- Data: 1995-08-16 → 2026-11-06 (5,707 trading days)
- Last close ₱2.32 (2026-11-06) · all-time high ₱6.75 (2019-12-05) · low ₱0.006 (1998-01-09) · now -65.6% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1995: ₱0.0110 start · H 0.0210 L 0.0065 · ₱1.2M/d
- 1996: ₱0.0190 +72.7% · H 0.0210 L 0.0100 · ₱801.4K/d
- 1997: ₱0.0100 -47.4% · H 0.1150 L 0.0100 · ₱9.9M/d
- 1998: ₱0.0140 +40.0% · H 0.0280 L 0.006 · ₱472.8K/d
- 1999: ₱0.0200 +42.9% · H 0.0470 L 0.0110 · ₱1.3M/d
- 2000: ₱0.0140 -30.0% · H 0.0460 L 0.0100 · ₱3.5M/d
- 2001: ₱0.0140 +0.0% · H 0.0220 L 0.0110 · ₱263.5K/d
- 2002: ₱0.0100 -28.6% · H 0.0190 L 0.0100 · ₱119.1K/d
- 2003: ₱0.009 -10.0% · H 0.0120 L 0.0075 · ₱84.4K/d
- 2004: ₱0.009 +0.0% · H 0.0140 L 0.007 · ₱152.1K/d
- 2005: ₱0.009 +0.0% · H 0.0180 L 0.009 · ₱245.8K/d
- 2006: ₱0.0200 +122.2% · H 0.0230 L 0.009 · ₱614.1K/d
- 2007: ₱0.2050 +925.0% · H 0.2700 L 0.0160 · ₱51.3M/d
- 2008: ₱0.0625 -69.5% · H 0.2100 L 0.0525 · ₱3.3M/d
- 2009: ₱0.0775 +24.0% · H 0.1000 L 0.0625 · ₱2.8M/d
- 2010: ₱0.0490 -36.8% · H 0.0750 L 0.0470 · ₱475.5K/d
- 2011: ₱0.0600 +22.4% · H 0.0840 L 0.0500 · ₱1.4M/d
- 2012: ₱0.0500 -16.7% · H 0.0660 L 0.0450 · ₱561.3K/d
- 2013: ₱0.0330 -34.0% · H 0.0520 L 0.0270 · ₱150.2K/d
- 2014: ₱0.0420 +27.3% · H 0.0590 L 0.0300 · ₱1.2M/d
- 2015: ₱0.0310 -26.2% · H 0.0570 L 0.0280 · ₱3.2M/d
- 2016: ₱0.0380 +22.6% · H 0.0400 L 0.0260 · ₱1.4M/d
- 2017: ₱0.0450 +18.4% · H 0.0680 L 0.0370 · ₱7.6M/d
- 2018: ₱0.0370 -17.8% · H 0.0500 L 0.0330 · ₱756.1K/d
- 2019: ₱4.75 +12737.8% · H 6.75 L 0.0360 · ₱1.6M/d
- 2020: ₱3.19 -32.8% · H 5.82 L 2.60 · ₱354.2K/d
- 2021: ₱3.20 +0.3% · H 6.50 L 2.85 · ₱475.8K/d
- 2022: ₱1.90 -40.6% · H 3.13 L 1.82 · ₱28.6K/d
- 2023: ₱1.38 -27.4% · H 2.24 L 1.00 · ₱24.8K/d
- 2024: ₱1.60 +15.9% · H 1.62 L 0.7000 · ₱18.7K/d
- 2025: ₱1.00 -37.5% · H 1.60 L 0.8400 · ₱28.4K/d
- 2026*: ₱2.32 +132.0% · H 2.50 L 0.7100 · ₱46.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
