---
tags: [trading, pse, stock, mhc]
---
**MHC — Mabuhay Holdings Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Oct 22, 1990
- Data: 1993-11-15 → 2026-11-03 (3,853 trading days)
- Last close ₱0.1420 (2026-11-03) · all-time high ₱2.70 (1995-08-08) · low ₱0.0600 (2002-09-12) · now -94.7% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0
- Splits / stock dividends detected (prices before these dates are as traded then): 2003-09-25 (÷1.5), 2003-10-15 (÷0.5), 2003-11-12 (÷2), 2004-05-19 (÷2)

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 1993: ₱1.00 start · H 1.30 L 0.5500 · ₱249.0K/d
- 1994: ₱1.64 +64.0% · H 2.44 L 0.8000 · ₱653.1K/d
- 1995: ₱1.28 -22.0% · H 2.70 L 1.20 · ₱12.3M/d
- 1996: ₱1.58 +23.4% · H 2.55 L 0.8200 · ₱23.0M/d
- 1997: ₱0.4500 -71.5% · H 1.80 L 0.4500 · ₱2.9M/d
- 1998: ₱0.4000 -11.1% · H 0.6000 L 0.1400 · ₱198.2K/d
- 1999: ₱0.4300 +7.5% · H 1.02 L 0.2000 · ₱401.1K/d
- 2000: ₱0.1800 -58.1% · H 0.6600 L 0.1500 · ₱181.2K/d
- 2001: ₱0.2000 +11.1% · H 0.4700 L 0.1200 · ₱106.3K/d
- 2002: ₱0.1400 -30.0% · H 0.2800 L 0.0600 · ₱566.7K/d
- 2003: ₱0.1500 +7.1% · H 0.3100 L 0.0700 · ₱304.8K/d
- 2004: ₱0.1500 +0.0% · H 0.2600 L 0.1200 · ₱121.4K/d
- 2005: ₱0.1000 -33.3% · H 0.2800 L 0.1000 · ₱23.5K/d
- 2006: ₱0.3200 +220.0% · H 0.4400 L 0.1000 · ₱84.1K/d
- 2007: ₱0.4000 +25.0% · H 0.8700 L 0.3200 · ₱556.9K/d
- 2008: ₱0.2000 -50.0% · H 0.4200 L 0.0700 · ₱110.0K/d
- 2009: ₱0.4000 +100.0% · H 0.5500 L 0.1300 · ₱152.6K/d
- 2010: ₱0.4000 +0.0% · H 0.6200 L 0.3300 · ₱1.6M/d
- 2011: ₱0.4200 +5.0% · H 0.7700 L 0.3000 · ₱2.3M/d
- 2012: ₱0.3500 -16.7% · H 0.8000 L 0.3200 · ₱1.1M/d
- 2013: ₱0.5900 +68.6% · H 0.7300 L 0.3950 · ₱1.2M/d
- 2014: ₱0.6400 +8.5% · H 0.7100 L 0.5900 · ₱634.3K/d
- 2015: ₱0.4700 -26.6% · H 0.7000 L 0.4500 · ₱446.3K/d
- 2016: ₱0.4800 +2.1% · H 0.5300 L 0.4200 · ₱327.7K/d
- 2017: ₱0.3050 -36.5% · H 0.4750 L 0.2800 · ₱313.5K/d
- 2018: ₱0.5900 +93.4% · H 0.8200 L 0.3050 · ₱4.4M/d
- 2019: ₱0.5700 -3.4% · H 0.7700 L 0.5100 · ₱1.0M/d
- 2020: ₱0.5400 -5.3% · H 0.6000 L 0.3700 · ₱128.7K/d
- 2021: ₱0.3750 -30.6% · H 0.6600 L 0.3700 · ₱434.1K/d
- 2022: ₱0.2260 -39.7% · H 0.3750 L 0.2260 · ₱23.8K/d
- 2023: ₱0.1120 -50.4% · H 0.2380 L 0.1110 · ₱25.5K/d
- 2024: ₱0.1610 +43.8% · H 0.2150 L 0.1160 · ₱28.4K/d
- 2025: ₱0.1140 -29.2% · H 0.1610 L 0.1060 · ₱17.3K/d
- 2026*: ₱0.1420 +24.6% · H 0.1780 L 0.0840 · ₱10.3K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
