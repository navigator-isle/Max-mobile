---
tags: [trading, pse, stock, sm]
---
**SM — SM Investments Corporation**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Mar 22, 2005
- Data: 2005-03-22 → 2026-11-06 (5,272 trading days)
- Last close ₱561.0 (2026-11-06) · all-time high ₱1,140 (2018-01-26) · low ₱89.60 (2008-10-27) · now -50.8% from high
- Cash dividends last 12 months ₱17.00 = 3.0% yield
- Dividend events on record (2013 → 2026): 15

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2005: ₱128.0 start · H 136.0 L 106.7 · ₱151.9M/d
- 2006: ₱173.3 +35.4% · H 176.0 L 109.9 · ₱79.0M/d
- 2007: ₱181.3 +4.6% · H 240.0 L 164.0 · ₱136.0M/d
- 2008: ₱102.4 -43.5% · H 184.0 L 89.60 · ₱68.8M/d
- 2009: ₱216.7 +111.6% · H 228.3 L 119.3 · ₱62.1M/d
- 2010: ₱362.0 +67.1% · H 391.3 L 206.7 · ₱108.3M/d
- 2011: ₱388.3 +7.3% · H 390.3 L 294.7 · ₱179.1M/d
- 2012: ₱588.0 +51.4% · H 600.3 L 372.7 · ₱210.3M/d
- 2013: ₱474.0 -19.4% · H 802.0 L 422.7 · ₱371.2M/d · div ₱11.80 (2.5%): 21May 11.8
- 2014: ₱543.3 +14.6% · H 554.7 L 453.3 · ₱234.0M/d · div ₱10.34 (1.9%): 27May 10.34
- 2015: ₱864.0 +59.0% · H 970.0 L 810.0 · ₱283.0M/d · div ₱10.61 (1.2%): 11May 10.61
- 2016: ₱655.0 -24.2% · H 1,026 L 608.0 · ₱267.3M/d · div ₱10.63 (1.6%): 06May 10.63
- 2017: ₱990.0 +51.1% · H 998.0 L 599.0 · ₱314.1M/d · div ₱7.77 (0.8%): 08May 7.77
- 2018: ₱917.5 -7.3% · H 1,140 L 837.0 · ₱298.5M/d · div ₱8.20 (0.9%): 07May 8.2
- 2019: ₱1,043 +13.7% · H 1,091 L 884.5 · ₱357.5M/d · div ₱9.12 (0.9%): 06May 9.12
- 2020: ₱1,049 +0.6% · H 1,100 L 667.0 · ₱564.5M/d · div ₱4.25 (0.4%): 06Jul 4.25
- 2021: ₱943.0 -10.1% · H 1,079 L 900.0 · ₱356.1M/d · div ₱4.25 (0.5%): 10May 4.25
- 2022: ₱900.0 -4.6% · H 980.0 L 725.0 · ₱355.9M/d · div ₱6.25 (0.7%): 10May 6.25
- 2023: ₱872.0 -3.1% · H 950.0 L 789.5 · ₱351.2M/d · div ₱7.50 (0.9%): 08May 7.5
- 2024: ₱899.0 +3.1% · H 1,000 L 809.0 · ₱309.2M/d · div ₱9.00 (1.0%): 08May 9
- 2025: ₱699.5 -22.2% · H 908.0 L 677.0 · ₱313.0M/d · div ₱13.00 (1.9%): 15May 2S, 15May 11
- 2026*: ₱561.0 -19.8% · H 745.5 L 492.0 · ₱370.0M/d · div ₱17.00 (3.0%): 13May 17

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
