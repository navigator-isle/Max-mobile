---
tags: [trading, pse, stock, tfhi]
---
**TFHI — Top Frontier Investment Holdings, Inc.**
- Status: listed on PSE · sector Holding Firms › Holding Firms · listed Jan 13, 2014
- Data: 2014-01-13 → 2026-11-06 (2,882 trading days)
- Last close ₱53.05 (2026-11-06) · all-time high ₱310.8 (2018-09-03) · low ₱50.30 (2026-05-05) · now -82.9% from high
- No cash dividend in the last 12 months
- Dividend events on record (2013 → 2026): 0

**Year by year** (close, change, H high, L low, ₱/d average traded value per day, div = cash dividends that year (yield on year-end close): ex-date amount per share, S = special; * = year to date; prices as traded)
- 2014: ₱124.0 start · H 153.8 L 58.10 · ₱9.1M/d
- 2015: ₱67.60 -45.5% · H 126.9 L 63.00 · ₱4.6M/d
- 2016: ₱262.0 +287.6% · H 262.0 L 62.90 · ₱6.3M/d
- 2017: ₱286.0 +9.2% · H 310.0 L 262.0 · ₱2.2M/d
- 2018: ₱249.8 -12.7% · H 310.8 L 249.0 · ₱4.4M/d
- 2019: ₱214.0 -14.3% · H 289.6 L 210.0 · ₱4.3M/d
- 2020: ₱140.0 -34.6% · H 214.0 L 120.0 · ₱2.6M/d
- 2021: ₱127.7 -8.8% · H 143.0 L 121.0 · ₱6.6M/d
- 2022: ₱95.00 -25.6% · H 127.7 L 95.00 · ₱3.4M/d
- 2023: ₱101.9 +7.3% · H 135.0 L 83.15 · ₱1.0M/d
- 2024: ₱63.10 -38.1% · H 103.0 L 61.00 · ₱159.2K/d
- 2025: ₱61.00 -3.3% · H 67.80 L 51.90 · ₱152.2K/d
- 2026*: ₱53.05 -13.0% · H 78.00 L 50.30 · ₱200.9K/d

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
