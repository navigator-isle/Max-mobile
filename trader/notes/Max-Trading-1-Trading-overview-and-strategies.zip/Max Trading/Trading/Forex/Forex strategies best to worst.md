---
tags: [trading, forex, strategy]
---
**Forex strategies tested 2000 → Oct 2026 (26 years), ranked by return**
- 10 currencies vs USD (EUR, JPY, GBP, CHF, CAD, AUD, NZD, MXN, ZAR, BRL); returns include the interest gap (carry); no leverage; 0.03% per trade

| # | Strategy | %/yr | Worst drop | 2000-08 | 2009-16 | 2017-26 |
|---|---|---|---|---|---|---|
| 1 | Carry, only when the currency trend agrees (6-month) | 0.8% | -25.5% | 1.9% | 2.9% | -1.9% |
| 2 | Carry: long 3 highest rates, short 3 lowest (monthly) | 0.7% | -17.3% | -0.3% | 0.7% | 1.6% |
| 3 | Carry + trend 50/50 | 0.7% | -10.0% | 1.6% | 1.6% | -0.9% |
| 4 | Hold all 10 currencies vs USD equally (with interest) | 0.5% | -38.3% | 2.5% | -0.5% | -0.5% |
| 5 | Trend: each currency long/short by its 126-day direction | 0.5% | -29.1% | 3.1% | 2.4% | -3.3% |
| 6 | Carry: long 2 highest, short 2 lowest | 0.4% | -29.8% | -1.0% | -0.6% | 2.4% |
| 7 | Trend: each currency long/short by its 252-day direction | 0.4% | -31.6% | 4.7% | -1.7% | -1.5% |
| 8 | Trend: each currency long/short by its 63-day direction | 0.1% | -26.2% | 2.1% | -0.1% | -1.4% |
| 9 | Momentum: long 3 strongest, short 3 weakest (252-day) | 0.1% | -22.1% | 1.7% | -0.4% | -1.1% |
| 10 | Momentum: long 3 strongest, short 3 weakest (63-day) | -0.4% | -29.8% | 0.9% | -1.0% | -1.0% |

**Gold (2000 → Nov 2026)**
- Hold gold: 10.5%/yr, worst drop −44% · hold only above 200-day average: 6.9%/yr, −39.5% · above 200-day sized to 12% volatility: 6.3%/yr, −34% (CHOSEN, 30% of MAX-MASTER-3)

**Verdict**
- No forex strategy kept an edge over 26 years (all between −1.9% and +0.8% a year; results flip sign between periods)
- Forex only becomes "profitable" with leverage, which multiplies the same weak edge and the losses
- Forex kept as a watch-only paper book

**Day trading forex (2024–2026 hourly)**
- London breakout and Asian-session mean reversion ≈ break-even after costs

**Sources**
- FRED H.10 exchange rates · OECD 3-month rates · CFTC COT · results file trader/research/2026-11-09-fx-copy-long-results.json
