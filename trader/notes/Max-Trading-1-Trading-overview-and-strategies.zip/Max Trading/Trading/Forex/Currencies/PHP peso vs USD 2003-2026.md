---
tags: [trading, forex, php]
---
**Philippine peso (USD/PHP, monthly closes)**
- Higher number = weaker peso
- Record low ₱62.565 per USD on 2 Sep 2026 (Radar PH)

- 2003: USD/PHP year-end 55.24 · high 55.24 · low 55.24
- 2004: USD/PHP year-end 56.03 · high 56.10 · low 55.56
- 2005: USD/PHP year-end 52.98 · high 56.20 · low 52.98
- 2006: USD/PHP year-end 48.84 · high 52.93 · low 48.84
- 2007: USD/PHP year-end 41.15 · high 48.74 · low 41.15
- 2008: USD/PHP year-end 47.26 · high 48.75 · low 40.30
- 2009: USD/PHP year-end 46.40 · high 48.64 · low 46.38
- 2010: USD/PHP year-end 43.74 · high 46.55 · low 42.95
- 2011: USD/PHP year-end 43.70 · high 43.99 · low 42.15
- 2012: USD/PHP year-end 40.97 · high 43.71 · low 40.77
- 2013: USD/PHP year-end 44.29 · high 44.44 · low 40.55
- 2014: USD/PHP year-end 44.64 · high 45.22 · low 43.31
- 2015: USD/PHP year-end 46.79 · high 47.09 · low 44.09
- 2016: USD/PHP year-end 49.60 · high 49.60 · low 45.74
- 2017: USD/PHP year-end 49.95 · high 51.53 · low 49.67
- 2018: USD/PHP year-end 52.51 · high 53.89 · low 51.27
- 2019: USD/PHP year-end 50.75 · high 52.66 · low 50.75
- 2020: USD/PHP year-end 48.07 · high 51.38 · low 48.07
- 2021: USD/PHP year-end 51.24 · high 51.24 · low 47.75
- 2022: USD/PHP year-end 55.67 · high 58.60 · low 50.97
- 2023: USD/PHP year-end 55.31 · high 56.76 · low 54.30
- 2024: USD/PHP year-end 58.03 · high 58.66 · low 56.05
- 2025: USD/PHP year-end 58.88 · high 58.88 · low 55.60
- 2026: USD/PHP year-end 63.03 · high 63.60 · low 16.20

**Sources**
- Yahoo Finance PHP=X monthly
- https://radar.ph/peso-hits-record-low-for-fourth-straight-session-as-psei-falls-september-2-2026/
