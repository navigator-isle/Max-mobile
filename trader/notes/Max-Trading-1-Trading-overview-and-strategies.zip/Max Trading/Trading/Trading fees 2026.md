---
tags: [trading, fees]
---
**Real trading fees (checked 8 Nov 2026)**

**COL Financial (PSE)**
- Buy: commission 0.25% + 12% VAT on commission + PSE fee 0.005% + SCCP 0.01% = **0.295%**
- Sell: same + sales tax 0.1% (cut from 0.6% on 1 Jul 2025) = **0.395%**
- Round trip ≈ **0.69%** + bid-ask spread (blue chips ~0.1–0.3%) → plan ~0.9%
- Source: https://colfinancial.freshdesk.com/support/solutions/articles/6000073098-what-are-the-fees-charged-for-executing-trades-buy-and-sell-

**Binance (crypto) — VIP 0**
- Spot: **0.10%** maker and taker · paying fees with BNB: **0.075%** → round trip 0.15–0.20% + slippage
- USDⓈ-M futures: **0.02% maker / 0.05% taker** (−10% with BNB) → round trip 0.04–0.10% (futures = leverage risk; Max rule: 1× only, paper)
- Sources: https://tradetoolworks.com/en/cost/binance-fees/ (updated 7 Nov 2026) · https://binancemakertakerfee.org/ (third-party; confirm on Binance's own fee page)

**Invo (copy trading, runs on Hyperliquid perpetuals)**
- Taker **0.0768%**, maker rebate 0.048% (tier 0, < $5M volume in 14 days); lower tiers above $5M
- Copied traders earn 15% of the fees their copiers generate (not a profit share) → traders are paid for activity, not for winning
- Hyperliquid funding payments apply on open perps; leverage is common
- Warning (KuCoin research): ~400,000 wallets on Invo and 5 similar apps lost ~$280M; for BTC trades, fees exceeded users' realized gains
- Sources: https://www.invoapp.com/guides/fees · https://www.invoapp.com/guides/monetize-your-edge · https://www.kucoin.com/blog/hyperliquid-retail-traders-280-million-losses

**What this changes in Max's tests**
- PSE: tests already used ~0.55%/side (0.75% all stocks) → realistic
- Crypto swing/position: 0.15%/side used → matches spot with BNB + slippage
- BTC day-trade breakout: needed ≤ 0.10% round trip → only reachable with futures maker orders (leverage risk); with spot fees it loses
- Copy trading on Invo: ~0.15% round trip + funding + the copied trader's incentive to trade often → copy only traders with long, low-turnover records; paper first
