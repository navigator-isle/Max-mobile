---
tags: [trading, crypto, strategy]
---
**Crypto strategies tested (ranked best → worst by 2022–2026 return per unit of worst drop)**
- Bitcoin Jul 2010 → Nov 2026 (16 years — Bitcoin did not exist before 2009); top-20 coins by market cap 2013 → 2026 incl. dead coins
- Trade at next close; fee + slippage 0.30% per side before 2017, 0.15% after
- Early years show huge numbers (Bitcoin $0.30 → $126,000); the 2022–2026 column matters most

| # | Strategy | From | %/yr all | Worst drop | 2011/13-16 | 2017-21 | 2022-26 |
|---|---|---|---|---|---|---|---|
| 1 | Mix: 30% BTC>100d vol40 + 70% swing | 2013 | 49.0% | -25.9% | 49.2% | 83.0% | 17.8% |
| 2 | Mix: 50% BTC>100d vol40 + 50% swing | 2013 | 50.3% | -27.3% | 55.6% | 80.6% | 18.3% |
| 3 | Top-20 coins: Swing + only when BTC above 50-day avg (CURRENT PLAN) | 2013-02-22 | 46.1% | -27.7% | 39.1% | 85.2% | 16.4% |
| 4 | Mix: 30% BTC>100d + 70% swing | 2013 | 63.8% | -35.8% | 76.8% | 104.3% | 19.1% |
| 5 | Mix: 30% BTC>50d + 70% swing | 2013 | 61.4% | -33.9% | 71.9% | 103.1% | 17.6% |
| 6 | Bitcoin only: Above 100-day avg, sized to 40% volatility | 2011-01-01 | 62.6% | -35.2% | 104.1% | 71.0% | 16.5% |
| 7 | Top-20 coins: COMBO: 50% BTC above 100-day + 50% swing (filter) | 2013-01-01 | 78.4% | -43.8% | 118.1% | 114.4% | 20.4% |
| 8 | Mix: 50% BTC>100d + 50% swing | 2013 | 73.9% | -43.8% | 101.6% | 114.4% | 20.4% |
| 9 | Mix: 50% BTC>50d + 50% swing | 2013 | 70.1% | -43.2% | 93.0% | 113.0% | 18.0% |
| 10 | Bitcoin only: Breakout 55-day high + 3×ATR trailing stop | 2011-01-08 | 109.7% | -53.7% | 320.3% | 56.4% | 20.3% |
| 11 | Bitcoin only: Hold only above 200-day average | 2011-02-03 | 99.9% | -90.3% | 211.7% | 84.2% | 26.5% |
| 12 | Bitcoin only: Hold only above 50-day average | 2011-01-02 | 136.0% | -72.1% | 321.1% | 128.6% | 19.2% |
| 13 | Bitcoin only: Hold only above 100-day average | 2011-01-02 | 132.7% | -74.9% | 304.7% | 128.2% | 19.8% |
| 14 | Top-20 coins: Swing: 20-day breakout + 2×ATR trail (no filter) | 2013-01-23 | 47.0% | -31.4% | 52.4% | 87.2% | 8.2% |
| 15 | Top-20 coins: Swing 3×ATR + BTC above 50-day avg | 2013-02-22 | 30.2% | -27.2% | 33.8% | 55.3% | 4.1% |
| 16 | Bitcoin only: 50-day above 200-day (golden cross) | 2011-02-03 | 99.6% | -86.0% | 227.4% | 96.4% | 11.0% |
| 17 | Bitcoin only: Buy & hold Bitcoin | 2011-01-02 | 119.1% | -92.3% | 284.1% | 116.6% | 10.7% |
| 18 | Bitcoin only: Breakout 20-day high + 3×ATR trailing stop | 2011-01-02 | 119.8% | -66.0% | 333.3% | 97.0% | 6.2% |
| 19 | Bitcoin only: Breakout 20-day high + 4×ATR trailing stop | 2011-01-02 | 134.6% | -64.1% | 363.2% | 126.1% | 5.0% |
| 20 | Bitcoin only: Breakout 20-day high + 25% trailing stop | 2011-01-02 | 105.0% | -81.7% | 322.5% | 67.6% | 3.1% |
| 21 | Bitcoin only: Breakout 20-day high + 2×ATR trailing stop | 2011-01-02 | 111.9% | -62.8% | 338.5% | 80.0% | 1.9% |
| 22 | Bitcoin only: Breakout 20-day high + 15% trailing stop | 2011-01-02 | 121.9% | -76.1% | 349.0% | 117.3% | -5.3% |
| 23 | Top-20 coins: Hold top-20 coins equally (monthly rebalance) | 2013-01-02 | 154.0% | -90.5% | 528.1% | 205.3% | -9.6% |
| 24 | Top-20 coins: Momentum: top-5 by 14-day return weekly, BTC>50-day | 2013-02-20 | 139.8% | -73.2% | 102.5% | 533.5% | -7.9% |
| 25 | Top-20 coins: Momentum: top-5 by 60-day return weekly, BTC>50-day | 2013-03-06 | 110.4% | -69.0% | 92.1% | 333.2% | 0.0% |

**Quality filter test on ALL Binance coins (2022 → Nov 2026)**
- A every breakout (current): 5.5%/yr, worst drop -30.2%, 589 trades, 32.9% wins
- B only when BTC above 200-day avg: 2.2%/yr, worst drop -31.1%, 369 trades, 32.5% wins
- C only when BTC above 50-day avg: 9.1%/yr, worst drop -28.3%, 453 trades, 35.5% wins
- D breakout with 1.5x volume: 3.8%/yr, worst drop -31.3%, 391 trades, 35.0% wins
- E coin above its 50-day avg + BTC above 200-day: 5.0%/yr, worst drop -27.8%, 337 trades, 33.2% wins
- F all filters (BTC>200d, coin>50d, 1.5x volume): 4.9%/yr, worst drop -18.4%, 226 trades, 35.4% wins

**Chosen (in Max's paper trading)**
- 70% swing: buy a top-20 coin closing above its 20-day high, only when Bitcoin is above its 50-day average; stop 2×ATR, trailing; risk 0.5% per trade; max 8 coins
- 30% Bitcoin trend: hold Bitcoin only above its 100-day average, sized to 40% yearly volatility
- Day trading crypto: BTC 2-hour opening-range breakout loses with spot fees (−38% 2024–2026); works only at ≤0.10% round trip

**Sources**
- Results files: trader/research/2026-11-09-crypto-long-results.json, crypto-combos.json, quality-filter-test.json, 2026-11-08-crypto-binance-results.json
- Coin Metrics community data · Bitstamp · Binance market data API
