---
tags: [trading, crypto, btc]
---
**Bitcoin month-end closes (USD)**
- 2010: Jul $0.0675 · Aug $0.0600 · Sep $0.0619 · Oct $0.1925 · Nov $0.2082 · Dec $0.3000
- 2011: Jan $0.5251 · Feb $0.8602 · Mar $0.7846 · Apr $3.50 · May $8.72 · Jun $16.19 · Jul $13.37 · Aug $8.00 · Sep $4.82 · Oct $3.30 · Nov $3.19 · Dec $4.58
- 2012: Jan $5.30 · Feb $4.99 · Mar $4.90 · Apr $5.00 · May $5.17 · Jun $6.61 · Jul $9.28 · Aug $10.16 · Sep $12.22 · Oct $11.00 · Nov $12.43 · Dec $13.24
- 2013: Jan $20.46 · Feb $33.53 · Mar $96.15 · Apr $139.9 · May $127.9 · Jun $89.53 · Jul $98.28 · Aug $128.0 · Sep $126.2 · Oct $203.5 · Nov $1,120 · Dec $732.0
- 2014: Jan $803.0 · Feb $551.9 · Mar $454.8 · Apr $448.9 · May $627.8 · Jun $641.1 · Jul $582.0 · Aug $479.0 · Sep $391.1 · Oct $338.0 · Nov $377.0 · Dec $321.0
- 2015: Jan $216.9 · Feb $253.5 · Mar $244.2 · Apr $236.2 · May $228.9 · Jun $262.5 · Jul $284.3 · Aug $229.9 · Sep $236.2 · Oct $310.2 · Nov $376.7 · Dec $430.9
- 2016: Jan $368.5 · Feb $435.2 · Mar $414.7 · Apr $448.4 · May $531.8 · Jun $668.0 · Jul $623.8 · Aug $570.8 · Sep $608.2 · Oct $697.0 · Nov $742.1 · Dec $966.3
- 2017: Jan $964.0 · Feb $1,191 · Mar $1,070 · Apr $1,350 · May $2,298 · Jun $2,465 · Jul $2,856 · Aug $4,734 · Sep $4,326 · Oct $6,434 · Nov $9,948 · Dec $13,880
- 2018: Jan $10,149 · Feb $10,315 · Mar $6,929 · Apr $9,242 · May $7,492 · Jun $6,386 · Jul $7,725 · Aug $7,017 · Sep $6,598 · Oct $6,303 · Nov $3,971 · Dec $3,693
- 2019: Jan $3,413 · Feb $3,791 · Mar $4,096 · Apr $5,269 · May $8,547 · Jun $10,760 · Jul $10,085 · Aug $9,594 · Sep $8,298 · Oct $9,150 · Nov $7,551 · Dec $7,168
- 2020: Jan $9,328 · Feb $8,528 · Mar $6,421 · Apr $8,627 · May $9,446 · Jun $9,133 · Jul $11,357 · Aug $11,655 · Sep $10,778 · Oct $13,816 · Nov $19,700 · Dec $28,993
- 2021: Jan $33,141 · Feb $45,241 · Mar $58,783 · Apr $57,775 · May $37,341 · Jun $35,037 · Jul $41,490 · Aug $47,156 · Sep $43,834 · Oct $61,359 · Nov $56,974 · Dec $46,214
- 2022: Jan $38,492 · Feb $43,179 · Mar $45,517 · Apr $37,640 · May $31,763 · Jun $19,925 · Jul $23,323 · Aug $20,059 · Sep $19,425 · Oct $20,498 · Nov $17,170 · Dec $16,528
- 2023: Jan $23,127 · Feb $23,136 · Mar $28,476 · Apr $29,235 · May $27,219 · Jun $30,469 · Jul $29,231 · Aug $25,932 · Sep $26,966 · Oct $34,661 · Nov $37,719 · Dec $42,258
- 2024: Jan $42,558 · Feb $61,161 · Mar $71,285 · Apr $60,632 · May $67,477 · Jun $62,676 · Jul $64,612 · Aug $58,967 · Sep $63,302 · Oct $70,231 · Nov $96,441 · Dec $93,381
- 2025: Jan $102,412 · Feb $84,321 · Mar $82,538 · Apr $94,181 · May $104,646 · Jun $107,179 · Jul $115,750 · Aug $108,269 · Sep $114,065 · Oct $109,554 · Nov $90,382 · Dec $87,496
- 2026: Jan $78,635 · Feb $66,985 · Mar $68,215 · Apr $76,310 · May $73,568 · Jun $58,526 · Jul $62,818 · Aug $78,571 · Sep $83,563 · Oct $77,430 · Nov $75,747

**Halvings (new BTC per block cut in half)**
- 2012-11-28: price $12.22 → 1 year later $1,013
- 2016-07-09: price $647.8 → 1 year later $2,502
- 2020-05-11: price $8,572 → 1 year later $56,764
- 2024-04-20: price $64,990 → 1 year later $85,198

**Sources**
- Coin Metrics community data (Jul 2010 → Aug 2011) + Bitstamp daily closes (Aug 2011 → Nov 2026)
