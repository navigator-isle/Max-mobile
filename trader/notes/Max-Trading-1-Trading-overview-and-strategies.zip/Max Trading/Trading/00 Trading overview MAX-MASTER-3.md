---
tags: [trading, strategy, core]
---
**Max trading — overview (9 Nov 2026)**
- Paper trading only (pretend money). No real orders. Not financial advice.
- Everything here comes from downloaded data and tests; Max answers trading questions from these notes

**MAX-MASTER-3 (current plan)**
- 40% PSE dividend top-20 (3-month rebalance, keep while in top-40, 25% trailing stop)
- 21% crypto swing (top-20 coins, 20-day breakout, 2×ATR trailing stop, only when Bitcoin > 50-day average, 0.5% risk per trade)
- 9% Bitcoin trend (above 100-day average, volatility-sized)
- 30% gold trend (above 200-day average, sized to 12% volatility)
- Watch only: forex fade big traders, copy steady traders, copy hot traders, crypto momentum rotation
- Backtest 2014 → Oct 2026: 17.6%/yr, worst drop -11.6%, worst month -5.0%; 2014–19 17.7%/yr, 2020–26 17.4%/yr
- By year: 2014 +9.8% · 2015 +5.2% · 2016 +20.7% · 2017 +70.2% · 2018 -7.7% · 2019 +21.2% · 2020 +34.3% · 2021 +34.6% · 2022 -5.5% · 2023 +16.1% · 2024 +36.5% · 2025 +18.0% · 2026 -6.1%

**Test rules (all tests)**
- Decide at a close → trade at the next close; real fees and slippage; settings chosen on older years, judged on later years
- Delisted stocks and dead coins kept (no survivor bias in PSE/crypto); bad prints removed

**Where to look**
- PSE: strategies, market by year, dividend yields now, dividend history, one note per stock (PSE stocks › sector)
- Crypto: strategies, Bitcoin monthly closes, Binance coin lists, one note per coin
- Forex: strategies, one note per currency (incl. peso), gold
- Copy trading: strategies, platforms
- Events 2003–2026 · Trading fees 2026
- Paper trading live: dashboard https://claude.ai/artifact/25fnUcKASedJmKSZBRbW9H (weekly email every Sunday)

**Data downloaded**
- PSE: 372 stocks, 2002 → 6 Nov 2026; 2,897 cash dividends 2013 → 2026
- Crypto: Bitcoin 2010 → 2026; 136 coins with market caps (Coin Metrics); 773 Binance USDT pairs incl. delisted
- Forex: 10 currencies + peso 2000 → 2026; OECD rates; CFTC positions 1998 → 2026; gold 2000 → 2026
- Copy trading: 1,500 Hyperliquid traders' full histories; 48,237-row leaderboard
