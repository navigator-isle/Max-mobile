---
tags: [trading, pse, strategy]
---
**PSE strategies tested (ranked best → worst by return per unit of worst drop)**
- Data: 372 PSE stocks incl. delisted; prices 2002 → 6 Nov 2026; dividends 2013 → 2026
- Rules: decide at a close, trade at the next close; COL fees + slippage 0.545% per side; 10% dividend tax; bad prints (moves beyond the ±50% daily limit) removed
- Dividend strategies 2014 → Nov 2026; momentum/benchmark rows marked 2003–2026 cover 24 years

| # | Strategy | %/yr | Worst drop | Sharpe | 2014-19 %/yr | 2020-26 %/yr | Buys |
|---|---|---|---|---|---|---|---|
| 1 | buffer top-40 + trailing stop 25% | 8.4% | -23.7% | 0.75 | 5.7% | 10.8% | 276 |
| 2 | stop: sell if 25% below highest close | 8.4% | -24.1% | 0.73 | 5.1% | 11.3% | 415 |
| 3 | A + trailing stop 25% below highest close | 8.4% | -24.1% | 0.73 | 5.1% | 11.3% | 415 |
| 4 | A + trailing stop 30% | 8.4% | -26.3% | 0.72 | 5.4% | 11.1% | 381 |
| 5 | A + trailing stop 20% | 6.5% | -21.9% | 0.61 | 2.9% | 9.8% | 485 |
| 6 | P2 + trailing stop 15% (2003–2026) | 12.8% | -49.9% | 0.7 | 15.7% | 5.7% | 1153 |
| 7 | Momentum top-10, only when market above 200-day avg (2003–2026) | 14.7% | -65.0% | 0.7 | 17.4% | 8.4% | 831 |
| 8 | Momentum top-10 when market up (2003–2026) | 14.7% | -65.0% | 0.7 | 17.4% | 8.4% | 831 |
| 9 | stop: sell if 20% below buy price | 7.3% | -33.5% | 0.63 | 4.4% | 10.0% | 360 |
| 10 | P2 + trailing stop 20% (2003–2026) | 12.3% | -59.6% | 0.65 | 15.6% | 4.5% | 1017 |
| 11 | 50% J dividend + 50% P4 momentum (2014–2026) | 7.4% | -36.3% | 0.62 | 6.4% | 8.3% | – |
| 12 | 50% DJ dividend + 50% P4 momentum (2014–2026) | 7.5% | -36.8% | 0.62 | 6.7% | 8.1% | – |
| 13 | ... every 6 months | 8.5% | -41.8% | 0.68 | 6.8% | 10.0% | 173 |
| 14 | 50% J dividend + 50% P2 momentum (2014–2026) | 8.0% | -40.0% | 0.61 | 5.2% | 10.6% | – |
| 15 | Dividend top-20, rebalance every 3 months (current plan) | 8.3% | -41.6% | 0.64 | 5.5% | 10.8% | 296 |
| 16 | Dividend top-20, 3 months (current) | 8.3% | -41.6% | 0.64 | 5.5% | 10.8% | 296 |
| 17 | 50% DJ dividend + 50% P2 momentum (2014–2026) | 8.0% | -40.6% | 0.61 | 5.5% | 10.3% | – |
| 18 | Momentum top-10 by 6-month return, monthly (2003–2026) | 14.4% | -73.1% | 0.63 | 17.5% | 6.9% | 986 |
| 19 | buffer: buy top-20, keep while in top-40 (3 months) | 7.0% | -43.1% | 0.55 | 5.9% | 7.9% | 112 |
| 20 | trap filter: skip if price −30% in a year or yield >15% | 7.0% | -44.0% | 0.6 | 3.0% | 10.6% | 334 |
| 21 | ... every 12 months | 6.4% | -41.0% | 0.54 | 6.6% | 6.3% | 111 |
| 22 | Benchmark all liquid stocks (2003–2026) | 9.0% | -62.5% | 0.59 | 13.3% | -0.9% | 1855 |
| 23 | rank by REGULAR dividends only (no specials) | 5.7% | -40.8% | 0.48 | 5.6% | 5.8% | 308 |
| 24 | buffer top-60 | 6.0% | -43.0% | 0.48 | 5.2% | 6.8% | 90 |
| 25 | only stocks that paid in each of the last 2 years | 5.7% | -41.5% | 0.47 | 1.7% | 9.3% | 279 |
| 26 | stop: sell if below its 200-day average | 1.8% | -16.7% | 0.34 | 0.6% | 2.8% | 856 |
| 27 | 50% dividend combo L + 50% momentum-when-market-up | 4.9% | -48.2% | 0.4 | 2.4% | 7.3% | – |
| 28 | combo L + stop 25% below highest close | 2.7% | -32.9% | 0.29 | -0.3% | 5.3% | 269 |
| 29 | combo L, top-10 instead of 20 | 3.1% | -43.3% | 0.3 | -2.6% | 8.4% | 129 |
| 30 | combo: regular divs + paid 2 yrs + trap filter + buffer 40 | 2.2% | -44.3% | 0.23 | -0.6% | 4.7% | 165 |
| 31 | Benchmark: hold all liquid stocks (dividends included) | 1.1% | -51.5% | 0.15 | 3.3% | -0.9% | 1342 |

**Chosen (in Max's paper trading)**
- Dividend top-20, rebalance every 3 months, keep holdings while in top-40, sell if 25% below the highest close since buying
- 2014 → Nov 2026: 8.4%/yr, worst drop -23.7%
- By year: 2014 +39.5% · 2015 -8.2% · 2016 +5.8% · 2017 +8.0% · 2018 -9.2% · 2019 +4.8% · 2020 +28.3% · 2021 +30.1% · 2022 -1.7% · 2023 -3.1% · 2024 +22.4% · 2025 +14.1% · 2026 -9.3%

**Earlier short test (2021 → Nov 2026, unseen years)**
- High dividend yield top-20: 9.0%/yr, worst drop -12.5%
- High dividend yield top-10: 8.5%/yr, worst drop -16.8%
- High dividend yield top-10 + market filter: 6.0%/yr, worst drop -14.7%
- High dividend yield top-20 + market filter: 3.9%/yr, worst drop -12.5%
- Momentum rotation (monthly, market filter): 3.4%/yr, worst drop -26.8%
- Swing breakout + ATR trailing stop: 2.7%/yr, worst drop -28.0%
- Hold all liquid stocks equally (with dividends): -0.4%/yr, worst drop -28.0%
- RSI(2) pullback: -1.8%/yr, worst drop -19.1%
- Low-volatility rotation: -2.3%/yr, worst drop -22.4%
- Dividend capture (−10d/+5d, yield ≥2.0%): -5.3%/yr, worst drop -32.1%
- Trend each stock (SMA): -5.5%/yr, worst drop -29.1%
- Dividend capture (−5d/+3d, yield ≥1.5%): -10.2%/yr, worst drop -48.0%
- Dividend capture (−3d/+1d, yield ≥2.0%): -10.7%/yr, worst drop -49.1%

**Day trading PSE (6 weeks of 30-minute data)**
- Loses to costs (~0.9% round trip incl. spread); not used

**Why not other things**
- Dividend capture (buy before ex-date, sell after): −27% to −48% (2021–2026); price drops by about the dividend and fees + tax eat the rest
- Market filter on dividend stocks: lowers returns (3.9% vs 9.0%/yr 2021–2026)
- Tighter stops (20%, 200-day average) and "trap"/consistency filters: worse

**Sources**
- Results files: trader/research/2026-11-09-pse-long-results*.json, 2026-11-08-pse-full-results.json
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
