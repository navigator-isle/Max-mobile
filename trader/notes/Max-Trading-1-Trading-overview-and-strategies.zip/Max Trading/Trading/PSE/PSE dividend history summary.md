---
tags: [trading, pse, dividend]
---
**PSE cash dividends on record**
- Every payment (ex-date, peso per share) is in each stock's note under PSE stocks
- 2013 → Sep 2025: PSE Quarterly Dividend Reports; Oct 2025 → 2026: PSE Edge dividends list (both in real pesos per share as declared)
- Before 2013: PSE reports are not online, so dividend tests start in 2014

- 2013: 183 cash dividend payments on record
- 2014: 184 cash dividend payments on record
- 2015: 195 cash dividend payments on record
- 2016: 189 cash dividend payments on record
- 2017: 196 cash dividend payments on record
- 2018: 209 cash dividend payments on record
- 2019: 192 cash dividend payments on record
- 2020: 167 cash dividend payments on record
- 2021: 193 cash dividend payments on record
- 2022: 229 cash dividend payments on record
- 2023: 249 cash dividend payments on record
- 2024: 249 cash dividend payments on record
- 2025: 250 cash dividend payments on record
- 2026: 212 cash dividend payments on record
- Total: 2,897 payments, 222 stocks

**Sources**
- PSE Edge daily prices (edge.pse.com.ph, 2015 → Nov 2026) + PSE archive (2002 → Mar 2021, incl. delisted)
- Dividends (real peso amounts): PSE Quarterly Dividend Reports 4Q2013 → 3Q2025 (documents.pse.com.ph) + PSE Edge dividends list (Oct 2025 → 2026)
