---
tags: [trading, copy-trading, strategy]
---
**Copy trading — what was tested**
- Real copy-trading records exist only on Hyperliquid (on-chain, 2023 → 2026); eToro/ZuluTrade/Bybit/Binance do not publish full trader histories
- For 20+ years: "copy the big traders" through CFTC weekly positions (1998 → 2026)

**1) Hyperliquid traders (the exchange Invo copies), Mar 2023 → Oct 2026**
- 1500 accounts (1,500 most active), 17,560 trader-months; blown-up accounts included
- Median trader month -0.17% · positive months 47.9% · copy delay cost 0.5%/month
| # | Copy rule | %/yr | Worst drop | Green months | Months |
|---|---|---|---|---|---|
| 1 | Copy top-5 steady (≥4/6 green months, 90d>0, ≥$100k) | 143.2% | -36.9% | 63% | 30 |
| 2 | Copy top-5 by sharpe6 | 142.2% | -53.3% | 66% | 32 |
| 3 | Copy top-10 steady (≥4/6 green months, 90d>0, ≥$100k) | 138.9% | -30.7% | 63% | 27 |
| 4 | Copy top-20 by sharpe6 | 120.9% | -21.2% | 69% | 29 |
| 5 | Copy top-10 by sharpe6 | 106.6% | -42.5% | 62% | 29 |
| 6 | Copy top-20 steady (≥4/6 green months, 90d>0, ≥$100k) | 97.6% | -10.8% | 68% | 22 |
| 7 | Copy top-20 by pnl90 | 57.1% | -43.5% | 70% | 33 |
| 8 | Copy top-20 by r180 | 23.3% | -40.4% | 50% | 30 |
| 9 | Copy top-10 by r180 | 17.6% | -59.0% | 58% | 31 |
| 10 | Copy everyone (average active trader) | 16.8% | -61.8% | 49% | 41 |
| 11 | Copy top-10 by pnl90 | 15.4% | -69.9% | 59% | 34 |
| 12 | Copy top-5 by pnl90 | 8.5% | -80.9% | 54% | 35 |
| 13 | Copy top-20 by r90 | -10.1% | -72.6% | 52% | 33 |
| 14 | Copy top-5 by r180 | -13.0% | -82.3% | 62% | 32 |
| 15 | Copy top-5 by r90 | -18.5% | -94.4% | 40% | 35 |
| 16 | Copy top-10 by r90 | -19.3% | -92.9% | 53% | 34 |
| 17 | Copy top-10 by r30 | -50.2% | -95.2% | 47% | 36 |
| 18 | Copy top-20 by r30 | -50.6% | -94.9% | 50% | 34 |
| 19 | Copy top-5 by r30 | -69.0% | -99.2% | 43% | 37 |
- Warning: sample = today's most active accounts (survivor bias); steady accounts may be market makers that cannot be copied

**2) Copy / fade big traders via CFTC (2000 → Oct 2026)**
| # | Rule (10 currencies) | %/yr | Worst drop | 2000-08 | 2009-16 | 2017-26 |
|---|---|---|---|---|---|---|
| 1 | COPY speculators (non-commercial): level | 0.8% | -12.1% | 2.2% | 1.6% | -1.1% |
| 2 | FADE big companies/hedgers (commercial): level | 0.7% | -16.5% | 2.5% | 1.5% | -1.7% |
| 3 | FADE big companies/hedgers (commercial): change vs 13-wk avg | 0.7% | -20.6% | 1.5% | 2.6% | -1.6% |
| 4 | COPY speculators (non-commercial): change vs 13-wk avg | 0.3% | -25.8% | 2.1% | 1.5% | -2.2% |
| 5 | COPY hedge funds (leveraged funds, 2006+): level | 0.1% | -20.9% | 1.5% | 0.7% | -1.7% |
| 6 | FADE hedge funds (leveraged funds, 2006+): change vs 13-wk avg | -0.0% | -24.7% | -1.2% | -1.8% | 2.5% |
| 7 | COPY asset managers (2006+): level | 0.0% | -21.1% | 1.8% | -1.6% | -0.1% |
| 8 | FADE asset managers (2006+): level | -0.4% | -20.4% | -1.9% | 0.9% | -0.3% |
| 9 | COPY asset managers (2006+): change vs 13-wk avg | -0.4% | -21.0% | -0.1% | 0.5% | -1.5% |
| 10 | FADE asset managers (2006+): change vs 13-wk avg | -0.5% | -19.7% | -0.3% | -1.7% | 0.3% |
| 11 | FADE hedge funds (leveraged funds, 2006+): level | -0.7% | -25.3% | -1.8% | -1.5% | 1.0% |
| 12 | COPY hedge funds (leveraged funds, 2006+): change vs 13-wk avg | -1.0% | -32.3% | 0.8% | 0.6% | -3.7% |
| 13 | COPY big companies/hedgers (commercial): level | -1.3% | -40.3% | -3.3% | -2.3% | 1.2% |
| 14 | FADE speculators (non-commercial): level | -1.5% | -39.5% | -3.1% | -2.4% | 0.7% |
| 15 | FADE speculators (non-commercial): change vs 13-wk avg | -1.6% | -44.2% | -3.5% | -2.7% | 1.1% |
| 16 | COPY big companies/hedgers (commercial): change vs 13-wk avg | -1.9% | -46.6% | -2.9% | -3.8% | 0.6% |

| # | Rule (gold) | %/yr | Worst drop | 2000-08 | 2009-16 | 2017-26 |
|---|---|---|---|---|---|---|
| 1 | Hold gold | 10.3% | -44.4% | 14.5% | 3.2% | 12.7% |
| 2 | COPY big companies/hedgers in gold (change vs 13-wk avg) | 1.3% | -49.9% | 5.4% | -5.1% | 3.4% |
| 3 | FADE speculators in gold (change vs 13-wk avg) | 0.7% | -49.7% | 5.0% | -4.8% | 1.8% |
| 4 | COPY speculators in gold (change vs 13-wk avg) | -4.7% | -78.2% | -8.8% | 0.9% | -5.5% |
| 5 | FADE big companies/hedgers in gold (change vs 13-wk avg) | -5.2% | -79.6% | -9.1% | 1.2% | -6.9% |

**Verdict**
- No copy rule kept an edge for 20+ years; copying the "hottest" traders lost 45–97%
- Only "steady" Hyperliquid traders were positive, with too short a record → watch-only paper books (copy steady, copy hot)

**Sources**
- api.hyperliquid.xyz portfolio data; stats-data.hyperliquid.xyz leaderboard · CFTC COT · results files 2026-11-08-copytrading-hl-results.json, 2026-11-09-fx-copy-long-results.json
